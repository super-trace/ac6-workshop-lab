--
-- PostgreSQL database dump
--

\restrict d6y9fg1XTM7yMgn856LsBEBRiYmpwbvxk0cyzeO2cIjhvPqzYUaXOelDZerYeUp

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: natural_sort; Type: COLLATION; Schema: public; Owner: -
--

CREATE COLLATION public.natural_sort (provider = icu, locale = 'und-u-kn');


--
-- Name: ltree; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS ltree WITH SCHEMA public;


--
-- Name: EXTENSION ltree; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION ltree IS 'data type for hierarchical tree-like structures';


--
-- Name: circuits_circuittermination_denorm_from_dcim_location_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.circuits_circuittermination_denorm_from_dcim_location_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "circuits_circuittermination"
                   SET "_site_id" = NEW."site_id", ("_region_id", "_site_group_id") = (SELECT "region_id", "group_id" FROM "dcim_site" WHERE id = NEW."site_id")
                 WHERE "_location_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: circuits_circuittermination_denorm_from_dcim_site_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.circuits_circuittermination_denorm_from_dcim_site_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "circuits_circuittermination"
                   SET "_region_id" = NEW."region_id", "_site_group_id" = NEW."group_id"
                 WHERE "_site_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: dcim_cabletermination_denorm_from_dcim_device_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_cabletermination_denorm_from_dcim_device_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "dcim_cabletermination"
                   SET "_rack_id" = NEW."rack_id", "_location_id" = NEW."location_id", "_site_id" = NEW."site_id"
                 WHERE "_device_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: dcim_cabletermination_denorm_from_dcim_location_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_cabletermination_denorm_from_dcim_location_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "dcim_cabletermination"
                   SET "_site_id" = NEW."site_id"
                 WHERE "_location_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: dcim_cabletermination_denorm_from_dcim_rack_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_cabletermination_denorm_from_dcim_rack_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "dcim_cabletermination"
                   SET "_location_id" = NEW."location_id", "_site_id" = NEW."site_id"
                 WHERE "_rack_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: dcim_consoleport_denorm_from_dcim_device_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_consoleport_denorm_from_dcim_device_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "dcim_consoleport"
                   SET "_site_id" = NEW."site_id", "_location_id" = NEW."location_id", "_rack_id" = NEW."rack_id"
                 WHERE "device_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: dcim_consoleserverport_denorm_from_dcim_device_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_consoleserverport_denorm_from_dcim_device_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "dcim_consoleserverport"
                   SET "_site_id" = NEW."site_id", "_location_id" = NEW."location_id", "_rack_id" = NEW."rack_id"
                 WHERE "device_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: dcim_coolingintake_denorm_from_dcim_device_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_coolingintake_denorm_from_dcim_device_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "dcim_coolingintake"
                   SET "_site_id" = NEW."site_id", "_location_id" = NEW."location_id", "_rack_id" = NEW."rack_id"
                 WHERE "device_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: dcim_coolingoutflow_denorm_from_dcim_device_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_coolingoutflow_denorm_from_dcim_device_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "dcim_coolingoutflow"
                   SET "_site_id" = NEW."site_id", "_location_id" = NEW."location_id", "_rack_id" = NEW."rack_id"
                 WHERE "device_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: dcim_devicebay_denorm_from_dcim_device_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_devicebay_denorm_from_dcim_device_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "dcim_devicebay"
                   SET "_site_id" = NEW."site_id", "_location_id" = NEW."location_id", "_rack_id" = NEW."rack_id"
                 WHERE "device_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: dcim_devicerole_ltree_cascade_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_devicerole_ltree_cascade_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
    -- COALESCE guards against a NULL sort_path slipping in via a raw write that
    -- bypassed the BEFORE trigger: without it, length(NULL)/substring(... FROM NULL)
    -- would cascade NULL to every descendant's sort_path in one shot.
    -- `nlevel($2) > 0` guards against an empty OLD.path ('', reachable only via a
    -- trigger-bypassing raw write): `path <@ ''` is true for EVERY row, so without
    -- this the cascade would rewrite the entire table on one reparent.
    EXECUTE format(
        'UPDATE %I SET '
        '  path = $1 || subpath(path, nlevel($2)), '
        '  sort_path = COALESCE($4, '''') || substring(COALESCE(sort_path, '''') FROM length(COALESCE($5, '''')) + 1) '
        'WHERE nlevel($2) > 0 AND path <@ $2 AND id != $3',
        TG_TABLE_NAME
    ) USING NEW.path, OLD.path, NEW.id, NEW.sort_path, OLD.sort_path;
    RETURN NULL;
END
$_$;


--
-- Name: dcim_devicerole_ltree_compute_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_devicerole_ltree_compute_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    parent_path ltree;
    parent_sort_path text;
    dest_root text;
    old_root text;
    key_dest bigint;
    key_old bigint;
BEGIN

    -- A brand-new root (INSERT with parent_id IS NULL) starts its own singleton
    -- tree that no concurrent transaction can yet see (MVCC: the uncommitted row
    -- is invisible) or reference (no other transaction has its PK). For such a
    -- row this BEFORE function reads no other row (the parent lookup below is
    -- gated on parent_id) and the AFTER cascade fires only on UPDATE, so the
    -- insert touches solely its own NEW row -- there is nothing to serialize
    -- against, and the advisory lock it would otherwise take can never contend.
    -- Skipping it here is what stops a bulk import of many top-level objects from
    -- taking one xact-lock per root and exhausting the shared lock table
    -- (sized by max_locks_per_transaction). Every other case still locks below:
    -- a child insert, any reparent, and a reparent-to-root (TG_OP = UPDATE, where
    -- the existing row has a real subtree the AFTER cascade must rewrite).
    IF NOT (TG_OP = 'INSERT' AND NEW.parent_id IS NULL) THEN
        -- Destination tree root: the parent's root label, or this row's own label
        -- when it is (or becomes) a root. The CASE guards against a parent whose path
        -- is the empty ltree '' (reachable only via a trigger-bypassing raw write):
        -- subltree('', 0, 1) would raise 'invalid positions', so fall back to the
        -- child's own label as the lock key rather than aborting the insert/move.
        IF NEW.parent_id IS NOT NULL THEN
            EXECUTE format(
                'SELECT CASE WHEN nlevel(path) > 0 THEN subltree(path, 0, 1)::text END'
                ' FROM %I WHERE id = $1',
                TG_TABLE_NAME
            ) INTO dest_root USING NEW.parent_id;
        END IF;
        dest_root := COALESCE(dest_root, lpad(NEW.id::text, 19, '0'));
        -- Source tree root (moves only): this row's current root, which the AFTER
        -- cascade will rewrite.
        IF TG_OP = 'UPDATE' AND OLD.path IS NOT NULL AND nlevel(OLD.path) > 0 THEN
            old_root := subltree(OLD.path, 0, 1)::text;
        END IF;
        key_dest := hashtextextended(TG_TABLE_NAME || ':' || dest_root, 0);
        IF old_root IS NOT NULL AND old_root <> dest_root THEN
            -- Cross-tree move: lock both roots, ascending, to avoid deadlock between
            -- two concurrent moves that touch the same pair.
            key_old := hashtextextended(TG_TABLE_NAME || ':' || old_root, 0);
            PERFORM pg_advisory_xact_lock(LEAST(key_dest, key_old));
            PERFORM pg_advisory_xact_lock(GREATEST(key_dest, key_old));
        ELSE
            PERFORM pg_advisory_xact_lock(key_dest);
        END IF;
    END IF;

    -- sort_path joins ancestor names with chr(9) (TAB); a literal tab in a name
    -- would inject a spurious separator and corrupt sibling ordering for the node
    -- and its descendants. LtreeModel.clean() rejects this for forms/serializers;
    -- this is the backstop for bulk_create / scripts / raw writes that bypass clean().
    IF position(chr(9) in COALESCE(NEW."name", '')) > 0 THEN
        RAISE EXCEPTION 'name contains a tab character, which is not allowed'
            USING ERRCODE = 'check_violation';
    END IF;
    IF NEW.parent_id IS NOT NULL THEN
        EXECUTE format('SELECT path, sort_path FROM %I WHERE id = $1', TG_TABLE_NAME)
            INTO parent_path, parent_sort_path USING NEW.parent_id;
        -- Cycle guard. See _COMPUTE_PATH_ONLY_FN for the rationale; this catches
        -- raw UPDATE / bulk_update paths that bypass LtreeModel.save().
        IF parent_path ~ ('*.' || lpad(NEW.id::text, 19, '0') || '.*')::lquery
            OR parent_path = lpad(NEW.id::text, 19, '0')::ltree THEN
            RAISE EXCEPTION 'cycle detected: % cannot be its own ancestor', TG_TABLE_NAME
                USING ERRCODE = 'check_violation';
        END IF;
        NEW.path := parent_path || lpad(NEW.id::text, 19, '0')::ltree;
        NEW.sort_path := parent_sort_path || chr(9) || NEW."name";
    ELSE
        NEW.path := lpad(NEW.id::text, 19, '0')::ltree;
        NEW.sort_path := NEW."name";
    END IF;
    RETURN NEW;
END
$_$;


--
-- Name: dcim_frontport_denorm_from_dcim_device_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_frontport_denorm_from_dcim_device_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "dcim_frontport"
                   SET "_site_id" = NEW."site_id", "_location_id" = NEW."location_id", "_rack_id" = NEW."rack_id"
                 WHERE "device_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: dcim_interface_denorm_from_dcim_device_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_interface_denorm_from_dcim_device_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "dcim_interface"
                   SET "_site_id" = NEW."site_id", "_location_id" = NEW."location_id", "_rack_id" = NEW."rack_id"
                 WHERE "device_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: dcim_inventoryitem_denorm_from_dcim_device_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_inventoryitem_denorm_from_dcim_device_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "dcim_inventoryitem"
                   SET "_site_id" = NEW."site_id", "_location_id" = NEW."location_id", "_rack_id" = NEW."rack_id"
                 WHERE "device_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: dcim_inventoryitem_ltree_cascade_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_inventoryitem_ltree_cascade_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
    -- `nlevel($2) > 0` guards against an empty OLD.path ('', reachable only via a
    -- trigger-bypassing raw write): `path <@ ''` is true for EVERY row, so without
    -- this the cascade would rewrite the entire table on one reparent.
    EXECUTE format(
        'UPDATE %I SET path = $1 || subpath(path, nlevel($2))'
        ' WHERE nlevel($2) > 0 AND path <@ $2 AND id != $3',
        TG_TABLE_NAME
    ) USING NEW.path, OLD.path, NEW.id;
    RETURN NULL;
END
$_$;


--
-- Name: dcim_inventoryitem_ltree_compute_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_inventoryitem_ltree_compute_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    parent_path ltree;
    dest_root text;
    old_root text;
    key_dest bigint;
    key_old bigint;
BEGIN

    -- A brand-new root (INSERT with parent_id IS NULL) starts its own singleton
    -- tree that no concurrent transaction can yet see (MVCC: the uncommitted row
    -- is invisible) or reference (no other transaction has its PK). For such a
    -- row this BEFORE function reads no other row (the parent lookup below is
    -- gated on parent_id) and the AFTER cascade fires only on UPDATE, so the
    -- insert touches solely its own NEW row -- there is nothing to serialize
    -- against, and the advisory lock it would otherwise take can never contend.
    -- Skipping it here is what stops a bulk import of many top-level objects from
    -- taking one xact-lock per root and exhausting the shared lock table
    -- (sized by max_locks_per_transaction). Every other case still locks below:
    -- a child insert, any reparent, and a reparent-to-root (TG_OP = UPDATE, where
    -- the existing row has a real subtree the AFTER cascade must rewrite).
    IF NOT (TG_OP = 'INSERT' AND NEW.parent_id IS NULL) THEN
        -- Destination tree root: the parent's root label, or this row's own label
        -- when it is (or becomes) a root. The CASE guards against a parent whose path
        -- is the empty ltree '' (reachable only via a trigger-bypassing raw write):
        -- subltree('', 0, 1) would raise 'invalid positions', so fall back to the
        -- child's own label as the lock key rather than aborting the insert/move.
        IF NEW.parent_id IS NOT NULL THEN
            EXECUTE format(
                'SELECT CASE WHEN nlevel(path) > 0 THEN subltree(path, 0, 1)::text END'
                ' FROM %I WHERE id = $1',
                TG_TABLE_NAME
            ) INTO dest_root USING NEW.parent_id;
        END IF;
        dest_root := COALESCE(dest_root, lpad(NEW.id::text, 19, '0'));
        -- Source tree root (moves only): this row's current root, which the AFTER
        -- cascade will rewrite.
        IF TG_OP = 'UPDATE' AND OLD.path IS NOT NULL AND nlevel(OLD.path) > 0 THEN
            old_root := subltree(OLD.path, 0, 1)::text;
        END IF;
        key_dest := hashtextextended(TG_TABLE_NAME || ':' || dest_root, 0);
        IF old_root IS NOT NULL AND old_root <> dest_root THEN
            -- Cross-tree move: lock both roots, ascending, to avoid deadlock between
            -- two concurrent moves that touch the same pair.
            key_old := hashtextextended(TG_TABLE_NAME || ':' || old_root, 0);
            PERFORM pg_advisory_xact_lock(LEAST(key_dest, key_old));
            PERFORM pg_advisory_xact_lock(GREATEST(key_dest, key_old));
        ELSE
            PERFORM pg_advisory_xact_lock(key_dest);
        END IF;
    END IF;

    IF NEW.parent_id IS NOT NULL THEN
        EXECUTE format('SELECT path FROM %I WHERE id = $1', TG_TABLE_NAME)
            INTO parent_path USING NEW.parent_id;
        -- Cycle guard. The Python LtreeModel.save() also rejects cyclic moves,
        -- but a QuerySet.update() / bulk_update() bypasses save() entirely, so
        -- catch the case here as a last line of defense. A cycle exists iff
        -- this row's own label appears anywhere in parent_path (the row would
        -- become its own ancestor). Match the label as any segment via lquery.
        IF parent_path ~ ('*.' || lpad(NEW.id::text, 19, '0') || '.*')::lquery
            OR parent_path = lpad(NEW.id::text, 19, '0')::ltree THEN
            RAISE EXCEPTION 'cycle detected: % cannot be its own ancestor', TG_TABLE_NAME
                USING ERRCODE = 'check_violation';
        END IF;
        NEW.path := parent_path || lpad(NEW.id::text, 19, '0')::ltree;
    ELSE
        NEW.path := lpad(NEW.id::text, 19, '0')::ltree;
    END IF;
    RETURN NEW;
END
$_$;


--
-- Name: dcim_inventoryitemtemplate_ltree_cascade_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_inventoryitemtemplate_ltree_cascade_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
    -- `nlevel($2) > 0` guards against an empty OLD.path ('', reachable only via a
    -- trigger-bypassing raw write): `path <@ ''` is true for EVERY row, so without
    -- this the cascade would rewrite the entire table on one reparent.
    EXECUTE format(
        'UPDATE %I SET path = $1 || subpath(path, nlevel($2))'
        ' WHERE nlevel($2) > 0 AND path <@ $2 AND id != $3',
        TG_TABLE_NAME
    ) USING NEW.path, OLD.path, NEW.id;
    RETURN NULL;
END
$_$;


--
-- Name: dcim_inventoryitemtemplate_ltree_compute_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_inventoryitemtemplate_ltree_compute_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    parent_path ltree;
    dest_root text;
    old_root text;
    key_dest bigint;
    key_old bigint;
BEGIN

    -- A brand-new root (INSERT with parent_id IS NULL) starts its own singleton
    -- tree that no concurrent transaction can yet see (MVCC: the uncommitted row
    -- is invisible) or reference (no other transaction has its PK). For such a
    -- row this BEFORE function reads no other row (the parent lookup below is
    -- gated on parent_id) and the AFTER cascade fires only on UPDATE, so the
    -- insert touches solely its own NEW row -- there is nothing to serialize
    -- against, and the advisory lock it would otherwise take can never contend.
    -- Skipping it here is what stops a bulk import of many top-level objects from
    -- taking one xact-lock per root and exhausting the shared lock table
    -- (sized by max_locks_per_transaction). Every other case still locks below:
    -- a child insert, any reparent, and a reparent-to-root (TG_OP = UPDATE, where
    -- the existing row has a real subtree the AFTER cascade must rewrite).
    IF NOT (TG_OP = 'INSERT' AND NEW.parent_id IS NULL) THEN
        -- Destination tree root: the parent's root label, or this row's own label
        -- when it is (or becomes) a root. The CASE guards against a parent whose path
        -- is the empty ltree '' (reachable only via a trigger-bypassing raw write):
        -- subltree('', 0, 1) would raise 'invalid positions', so fall back to the
        -- child's own label as the lock key rather than aborting the insert/move.
        IF NEW.parent_id IS NOT NULL THEN
            EXECUTE format(
                'SELECT CASE WHEN nlevel(path) > 0 THEN subltree(path, 0, 1)::text END'
                ' FROM %I WHERE id = $1',
                TG_TABLE_NAME
            ) INTO dest_root USING NEW.parent_id;
        END IF;
        dest_root := COALESCE(dest_root, lpad(NEW.id::text, 19, '0'));
        -- Source tree root (moves only): this row's current root, which the AFTER
        -- cascade will rewrite.
        IF TG_OP = 'UPDATE' AND OLD.path IS NOT NULL AND nlevel(OLD.path) > 0 THEN
            old_root := subltree(OLD.path, 0, 1)::text;
        END IF;
        key_dest := hashtextextended(TG_TABLE_NAME || ':' || dest_root, 0);
        IF old_root IS NOT NULL AND old_root <> dest_root THEN
            -- Cross-tree move: lock both roots, ascending, to avoid deadlock between
            -- two concurrent moves that touch the same pair.
            key_old := hashtextextended(TG_TABLE_NAME || ':' || old_root, 0);
            PERFORM pg_advisory_xact_lock(LEAST(key_dest, key_old));
            PERFORM pg_advisory_xact_lock(GREATEST(key_dest, key_old));
        ELSE
            PERFORM pg_advisory_xact_lock(key_dest);
        END IF;
    END IF;

    IF NEW.parent_id IS NOT NULL THEN
        EXECUTE format('SELECT path FROM %I WHERE id = $1', TG_TABLE_NAME)
            INTO parent_path USING NEW.parent_id;
        -- Cycle guard. The Python LtreeModel.save() also rejects cyclic moves,
        -- but a QuerySet.update() / bulk_update() bypasses save() entirely, so
        -- catch the case here as a last line of defense. A cycle exists iff
        -- this row's own label appears anywhere in parent_path (the row would
        -- become its own ancestor). Match the label as any segment via lquery.
        IF parent_path ~ ('*.' || lpad(NEW.id::text, 19, '0') || '.*')::lquery
            OR parent_path = lpad(NEW.id::text, 19, '0')::ltree THEN
            RAISE EXCEPTION 'cycle detected: % cannot be its own ancestor', TG_TABLE_NAME
                USING ERRCODE = 'check_violation';
        END IF;
        NEW.path := parent_path || lpad(NEW.id::text, 19, '0')::ltree;
    ELSE
        NEW.path := lpad(NEW.id::text, 19, '0')::ltree;
    END IF;
    RETURN NEW;
END
$_$;


--
-- Name: dcim_location_ltree_cascade_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_location_ltree_cascade_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
    -- COALESCE guards against a NULL sort_path slipping in via a raw write that
    -- bypassed the BEFORE trigger: without it, length(NULL)/substring(... FROM NULL)
    -- would cascade NULL to every descendant's sort_path in one shot.
    -- `nlevel($2) > 0` guards against an empty OLD.path ('', reachable only via a
    -- trigger-bypassing raw write): `path <@ ''` is true for EVERY row, so without
    -- this the cascade would rewrite the entire table on one reparent.
    EXECUTE format(
        'UPDATE %I SET '
        '  path = $1 || subpath(path, nlevel($2)), '
        '  sort_path = COALESCE($4, '''') || substring(COALESCE(sort_path, '''') FROM length(COALESCE($5, '''')) + 1) '
        'WHERE nlevel($2) > 0 AND path <@ $2 AND id != $3',
        TG_TABLE_NAME
    ) USING NEW.path, OLD.path, NEW.id, NEW.sort_path, OLD.sort_path;
    RETURN NULL;
END
$_$;


--
-- Name: dcim_location_ltree_compute_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_location_ltree_compute_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    parent_path ltree;
    parent_sort_path text;
    dest_root text;
    old_root text;
    key_dest bigint;
    key_old bigint;
BEGIN

    -- A brand-new root (INSERT with parent_id IS NULL) starts its own singleton
    -- tree that no concurrent transaction can yet see (MVCC: the uncommitted row
    -- is invisible) or reference (no other transaction has its PK). For such a
    -- row this BEFORE function reads no other row (the parent lookup below is
    -- gated on parent_id) and the AFTER cascade fires only on UPDATE, so the
    -- insert touches solely its own NEW row -- there is nothing to serialize
    -- against, and the advisory lock it would otherwise take can never contend.
    -- Skipping it here is what stops a bulk import of many top-level objects from
    -- taking one xact-lock per root and exhausting the shared lock table
    -- (sized by max_locks_per_transaction). Every other case still locks below:
    -- a child insert, any reparent, and a reparent-to-root (TG_OP = UPDATE, where
    -- the existing row has a real subtree the AFTER cascade must rewrite).
    IF NOT (TG_OP = 'INSERT' AND NEW.parent_id IS NULL) THEN
        -- Destination tree root: the parent's root label, or this row's own label
        -- when it is (or becomes) a root. The CASE guards against a parent whose path
        -- is the empty ltree '' (reachable only via a trigger-bypassing raw write):
        -- subltree('', 0, 1) would raise 'invalid positions', so fall back to the
        -- child's own label as the lock key rather than aborting the insert/move.
        IF NEW.parent_id IS NOT NULL THEN
            EXECUTE format(
                'SELECT CASE WHEN nlevel(path) > 0 THEN subltree(path, 0, 1)::text END'
                ' FROM %I WHERE id = $1',
                TG_TABLE_NAME
            ) INTO dest_root USING NEW.parent_id;
        END IF;
        dest_root := COALESCE(dest_root, lpad(NEW.id::text, 19, '0'));
        -- Source tree root (moves only): this row's current root, which the AFTER
        -- cascade will rewrite.
        IF TG_OP = 'UPDATE' AND OLD.path IS NOT NULL AND nlevel(OLD.path) > 0 THEN
            old_root := subltree(OLD.path, 0, 1)::text;
        END IF;
        key_dest := hashtextextended(TG_TABLE_NAME || ':' || dest_root, 0);
        IF old_root IS NOT NULL AND old_root <> dest_root THEN
            -- Cross-tree move: lock both roots, ascending, to avoid deadlock between
            -- two concurrent moves that touch the same pair.
            key_old := hashtextextended(TG_TABLE_NAME || ':' || old_root, 0);
            PERFORM pg_advisory_xact_lock(LEAST(key_dest, key_old));
            PERFORM pg_advisory_xact_lock(GREATEST(key_dest, key_old));
        ELSE
            PERFORM pg_advisory_xact_lock(key_dest);
        END IF;
    END IF;

    -- sort_path joins ancestor names with chr(9) (TAB); a literal tab in a name
    -- would inject a spurious separator and corrupt sibling ordering for the node
    -- and its descendants. LtreeModel.clean() rejects this for forms/serializers;
    -- this is the backstop for bulk_create / scripts / raw writes that bypass clean().
    IF position(chr(9) in COALESCE(NEW."name", '')) > 0 THEN
        RAISE EXCEPTION 'name contains a tab character, which is not allowed'
            USING ERRCODE = 'check_violation';
    END IF;
    IF NEW.parent_id IS NOT NULL THEN
        EXECUTE format('SELECT path, sort_path FROM %I WHERE id = $1', TG_TABLE_NAME)
            INTO parent_path, parent_sort_path USING NEW.parent_id;
        -- Cycle guard. See _COMPUTE_PATH_ONLY_FN for the rationale; this catches
        -- raw UPDATE / bulk_update paths that bypass LtreeModel.save().
        IF parent_path ~ ('*.' || lpad(NEW.id::text, 19, '0') || '.*')::lquery
            OR parent_path = lpad(NEW.id::text, 19, '0')::ltree THEN
            RAISE EXCEPTION 'cycle detected: % cannot be its own ancestor', TG_TABLE_NAME
                USING ERRCODE = 'check_violation';
        END IF;
        NEW.path := parent_path || lpad(NEW.id::text, 19, '0')::ltree;
        NEW.sort_path := parent_sort_path || chr(9) || NEW."name";
    ELSE
        NEW.path := lpad(NEW.id::text, 19, '0')::ltree;
        NEW.sort_path := NEW."name";
    END IF;
    RETURN NEW;
END
$_$;


--
-- Name: dcim_modulebay_denorm_from_dcim_device_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_modulebay_denorm_from_dcim_device_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "dcim_modulebay"
                   SET "_site_id" = NEW."site_id", "_location_id" = NEW."location_id", "_rack_id" = NEW."rack_id"
                 WHERE "device_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: dcim_modulebay_ltree_cascade_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_modulebay_ltree_cascade_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
    -- COALESCE guards against a NULL sort_path slipping in via a raw write that
    -- bypassed the BEFORE trigger: without it, length(NULL)/substring(... FROM NULL)
    -- would cascade NULL to every descendant's sort_path in one shot.
    -- `nlevel($2) > 0` guards against an empty OLD.path ('', reachable only via a
    -- trigger-bypassing raw write): `path <@ ''` is true for EVERY row, so without
    -- this the cascade would rewrite the entire table on one reparent.
    EXECUTE format(
        'UPDATE %I SET '
        '  path = $1 || subpath(path, nlevel($2)), '
        '  sort_path = COALESCE($4, '''') || substring(COALESCE(sort_path, '''') FROM length(COALESCE($5, '''')) + 1) '
        'WHERE nlevel($2) > 0 AND path <@ $2 AND id != $3',
        TG_TABLE_NAME
    ) USING NEW.path, OLD.path, NEW.id, NEW.sort_path, OLD.sort_path;
    RETURN NULL;
END
$_$;


--
-- Name: dcim_modulebay_ltree_compute_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_modulebay_ltree_compute_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    parent_path ltree;
    parent_sort_path text;
    dest_root text;
    old_root text;
    key_dest bigint;
    key_old bigint;
BEGIN

    -- A brand-new root (INSERT with parent_id IS NULL) starts its own singleton
    -- tree that no concurrent transaction can yet see (MVCC: the uncommitted row
    -- is invisible) or reference (no other transaction has its PK). For such a
    -- row this BEFORE function reads no other row (the parent lookup below is
    -- gated on parent_id) and the AFTER cascade fires only on UPDATE, so the
    -- insert touches solely its own NEW row -- there is nothing to serialize
    -- against, and the advisory lock it would otherwise take can never contend.
    -- Skipping it here is what stops a bulk import of many top-level objects from
    -- taking one xact-lock per root and exhausting the shared lock table
    -- (sized by max_locks_per_transaction). Every other case still locks below:
    -- a child insert, any reparent, and a reparent-to-root (TG_OP = UPDATE, where
    -- the existing row has a real subtree the AFTER cascade must rewrite).
    IF NOT (TG_OP = 'INSERT' AND NEW.parent_id IS NULL) THEN
        -- Destination tree root: the parent's root label, or this row's own label
        -- when it is (or becomes) a root. The CASE guards against a parent whose path
        -- is the empty ltree '' (reachable only via a trigger-bypassing raw write):
        -- subltree('', 0, 1) would raise 'invalid positions', so fall back to the
        -- child's own label as the lock key rather than aborting the insert/move.
        IF NEW.parent_id IS NOT NULL THEN
            EXECUTE format(
                'SELECT CASE WHEN nlevel(path) > 0 THEN subltree(path, 0, 1)::text END'
                ' FROM %I WHERE id = $1',
                TG_TABLE_NAME
            ) INTO dest_root USING NEW.parent_id;
        END IF;
        dest_root := COALESCE(dest_root, lpad(NEW.id::text, 19, '0'));
        -- Source tree root (moves only): this row's current root, which the AFTER
        -- cascade will rewrite.
        IF TG_OP = 'UPDATE' AND OLD.path IS NOT NULL AND nlevel(OLD.path) > 0 THEN
            old_root := subltree(OLD.path, 0, 1)::text;
        END IF;
        key_dest := hashtextextended(TG_TABLE_NAME || ':' || dest_root, 0);
        IF old_root IS NOT NULL AND old_root <> dest_root THEN
            -- Cross-tree move: lock both roots, ascending, to avoid deadlock between
            -- two concurrent moves that touch the same pair.
            key_old := hashtextextended(TG_TABLE_NAME || ':' || old_root, 0);
            PERFORM pg_advisory_xact_lock(LEAST(key_dest, key_old));
            PERFORM pg_advisory_xact_lock(GREATEST(key_dest, key_old));
        ELSE
            PERFORM pg_advisory_xact_lock(key_dest);
        END IF;
    END IF;

    -- sort_path joins ancestor names with chr(9) (TAB); a literal tab in a name
    -- would inject a spurious separator and corrupt sibling ordering for the node
    -- and its descendants. LtreeModel.clean() rejects this for forms/serializers;
    -- this is the backstop for bulk_create / scripts / raw writes that bypass clean().
    IF position(chr(9) in COALESCE(NEW."name", '')) > 0 THEN
        RAISE EXCEPTION 'name contains a tab character, which is not allowed'
            USING ERRCODE = 'check_violation';
    END IF;
    IF NEW.parent_id IS NOT NULL THEN
        EXECUTE format('SELECT path, sort_path FROM %I WHERE id = $1', TG_TABLE_NAME)
            INTO parent_path, parent_sort_path USING NEW.parent_id;
        -- Cycle guard. See _COMPUTE_PATH_ONLY_FN for the rationale; this catches
        -- raw UPDATE / bulk_update paths that bypass LtreeModel.save().
        IF parent_path ~ ('*.' || lpad(NEW.id::text, 19, '0') || '.*')::lquery
            OR parent_path = lpad(NEW.id::text, 19, '0')::ltree THEN
            RAISE EXCEPTION 'cycle detected: % cannot be its own ancestor', TG_TABLE_NAME
                USING ERRCODE = 'check_violation';
        END IF;
        NEW.path := parent_path || lpad(NEW.id::text, 19, '0')::ltree;
        NEW.sort_path := parent_sort_path || chr(9) || NEW."name";
    ELSE
        NEW.path := lpad(NEW.id::text, 19, '0')::ltree;
        NEW.sort_path := NEW."name";
    END IF;
    RETURN NEW;
END
$_$;


--
-- Name: dcim_platform_ltree_cascade_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_platform_ltree_cascade_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
    -- COALESCE guards against a NULL sort_path slipping in via a raw write that
    -- bypassed the BEFORE trigger: without it, length(NULL)/substring(... FROM NULL)
    -- would cascade NULL to every descendant's sort_path in one shot.
    -- `nlevel($2) > 0` guards against an empty OLD.path ('', reachable only via a
    -- trigger-bypassing raw write): `path <@ ''` is true for EVERY row, so without
    -- this the cascade would rewrite the entire table on one reparent.
    EXECUTE format(
        'UPDATE %I SET '
        '  path = $1 || subpath(path, nlevel($2)), '
        '  sort_path = COALESCE($4, '''') || substring(COALESCE(sort_path, '''') FROM length(COALESCE($5, '''')) + 1) '
        'WHERE nlevel($2) > 0 AND path <@ $2 AND id != $3',
        TG_TABLE_NAME
    ) USING NEW.path, OLD.path, NEW.id, NEW.sort_path, OLD.sort_path;
    RETURN NULL;
END
$_$;


--
-- Name: dcim_platform_ltree_compute_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_platform_ltree_compute_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    parent_path ltree;
    parent_sort_path text;
    dest_root text;
    old_root text;
    key_dest bigint;
    key_old bigint;
BEGIN

    -- A brand-new root (INSERT with parent_id IS NULL) starts its own singleton
    -- tree that no concurrent transaction can yet see (MVCC: the uncommitted row
    -- is invisible) or reference (no other transaction has its PK). For such a
    -- row this BEFORE function reads no other row (the parent lookup below is
    -- gated on parent_id) and the AFTER cascade fires only on UPDATE, so the
    -- insert touches solely its own NEW row -- there is nothing to serialize
    -- against, and the advisory lock it would otherwise take can never contend.
    -- Skipping it here is what stops a bulk import of many top-level objects from
    -- taking one xact-lock per root and exhausting the shared lock table
    -- (sized by max_locks_per_transaction). Every other case still locks below:
    -- a child insert, any reparent, and a reparent-to-root (TG_OP = UPDATE, where
    -- the existing row has a real subtree the AFTER cascade must rewrite).
    IF NOT (TG_OP = 'INSERT' AND NEW.parent_id IS NULL) THEN
        -- Destination tree root: the parent's root label, or this row's own label
        -- when it is (or becomes) a root. The CASE guards against a parent whose path
        -- is the empty ltree '' (reachable only via a trigger-bypassing raw write):
        -- subltree('', 0, 1) would raise 'invalid positions', so fall back to the
        -- child's own label as the lock key rather than aborting the insert/move.
        IF NEW.parent_id IS NOT NULL THEN
            EXECUTE format(
                'SELECT CASE WHEN nlevel(path) > 0 THEN subltree(path, 0, 1)::text END'
                ' FROM %I WHERE id = $1',
                TG_TABLE_NAME
            ) INTO dest_root USING NEW.parent_id;
        END IF;
        dest_root := COALESCE(dest_root, lpad(NEW.id::text, 19, '0'));
        -- Source tree root (moves only): this row's current root, which the AFTER
        -- cascade will rewrite.
        IF TG_OP = 'UPDATE' AND OLD.path IS NOT NULL AND nlevel(OLD.path) > 0 THEN
            old_root := subltree(OLD.path, 0, 1)::text;
        END IF;
        key_dest := hashtextextended(TG_TABLE_NAME || ':' || dest_root, 0);
        IF old_root IS NOT NULL AND old_root <> dest_root THEN
            -- Cross-tree move: lock both roots, ascending, to avoid deadlock between
            -- two concurrent moves that touch the same pair.
            key_old := hashtextextended(TG_TABLE_NAME || ':' || old_root, 0);
            PERFORM pg_advisory_xact_lock(LEAST(key_dest, key_old));
            PERFORM pg_advisory_xact_lock(GREATEST(key_dest, key_old));
        ELSE
            PERFORM pg_advisory_xact_lock(key_dest);
        END IF;
    END IF;

    -- sort_path joins ancestor names with chr(9) (TAB); a literal tab in a name
    -- would inject a spurious separator and corrupt sibling ordering for the node
    -- and its descendants. LtreeModel.clean() rejects this for forms/serializers;
    -- this is the backstop for bulk_create / scripts / raw writes that bypass clean().
    IF position(chr(9) in COALESCE(NEW."name", '')) > 0 THEN
        RAISE EXCEPTION 'name contains a tab character, which is not allowed'
            USING ERRCODE = 'check_violation';
    END IF;
    IF NEW.parent_id IS NOT NULL THEN
        EXECUTE format('SELECT path, sort_path FROM %I WHERE id = $1', TG_TABLE_NAME)
            INTO parent_path, parent_sort_path USING NEW.parent_id;
        -- Cycle guard. See _COMPUTE_PATH_ONLY_FN for the rationale; this catches
        -- raw UPDATE / bulk_update paths that bypass LtreeModel.save().
        IF parent_path ~ ('*.' || lpad(NEW.id::text, 19, '0') || '.*')::lquery
            OR parent_path = lpad(NEW.id::text, 19, '0')::ltree THEN
            RAISE EXCEPTION 'cycle detected: % cannot be its own ancestor', TG_TABLE_NAME
                USING ERRCODE = 'check_violation';
        END IF;
        NEW.path := parent_path || lpad(NEW.id::text, 19, '0')::ltree;
        NEW.sort_path := parent_sort_path || chr(9) || NEW."name";
    ELSE
        NEW.path := lpad(NEW.id::text, 19, '0')::ltree;
        NEW.sort_path := NEW."name";
    END IF;
    RETURN NEW;
END
$_$;


--
-- Name: dcim_poweroutlet_denorm_from_dcim_device_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_poweroutlet_denorm_from_dcim_device_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "dcim_poweroutlet"
                   SET "_site_id" = NEW."site_id", "_location_id" = NEW."location_id", "_rack_id" = NEW."rack_id"
                 WHERE "device_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: dcim_powerport_denorm_from_dcim_device_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_powerport_denorm_from_dcim_device_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "dcim_powerport"
                   SET "_site_id" = NEW."site_id", "_location_id" = NEW."location_id", "_rack_id" = NEW."rack_id"
                 WHERE "device_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: dcim_rearport_denorm_from_dcim_device_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_rearport_denorm_from_dcim_device_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "dcim_rearport"
                   SET "_site_id" = NEW."site_id", "_location_id" = NEW."location_id", "_rack_id" = NEW."rack_id"
                 WHERE "device_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: dcim_region_ltree_cascade_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_region_ltree_cascade_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
    -- COALESCE guards against a NULL sort_path slipping in via a raw write that
    -- bypassed the BEFORE trigger: without it, length(NULL)/substring(... FROM NULL)
    -- would cascade NULL to every descendant's sort_path in one shot.
    -- `nlevel($2) > 0` guards against an empty OLD.path ('', reachable only via a
    -- trigger-bypassing raw write): `path <@ ''` is true for EVERY row, so without
    -- this the cascade would rewrite the entire table on one reparent.
    EXECUTE format(
        'UPDATE %I SET '
        '  path = $1 || subpath(path, nlevel($2)), '
        '  sort_path = COALESCE($4, '''') || substring(COALESCE(sort_path, '''') FROM length(COALESCE($5, '''')) + 1) '
        'WHERE nlevel($2) > 0 AND path <@ $2 AND id != $3',
        TG_TABLE_NAME
    ) USING NEW.path, OLD.path, NEW.id, NEW.sort_path, OLD.sort_path;
    RETURN NULL;
END
$_$;


--
-- Name: dcim_region_ltree_compute_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_region_ltree_compute_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    parent_path ltree;
    parent_sort_path text;
    dest_root text;
    old_root text;
    key_dest bigint;
    key_old bigint;
BEGIN

    -- A brand-new root (INSERT with parent_id IS NULL) starts its own singleton
    -- tree that no concurrent transaction can yet see (MVCC: the uncommitted row
    -- is invisible) or reference (no other transaction has its PK). For such a
    -- row this BEFORE function reads no other row (the parent lookup below is
    -- gated on parent_id) and the AFTER cascade fires only on UPDATE, so the
    -- insert touches solely its own NEW row -- there is nothing to serialize
    -- against, and the advisory lock it would otherwise take can never contend.
    -- Skipping it here is what stops a bulk import of many top-level objects from
    -- taking one xact-lock per root and exhausting the shared lock table
    -- (sized by max_locks_per_transaction). Every other case still locks below:
    -- a child insert, any reparent, and a reparent-to-root (TG_OP = UPDATE, where
    -- the existing row has a real subtree the AFTER cascade must rewrite).
    IF NOT (TG_OP = 'INSERT' AND NEW.parent_id IS NULL) THEN
        -- Destination tree root: the parent's root label, or this row's own label
        -- when it is (or becomes) a root. The CASE guards against a parent whose path
        -- is the empty ltree '' (reachable only via a trigger-bypassing raw write):
        -- subltree('', 0, 1) would raise 'invalid positions', so fall back to the
        -- child's own label as the lock key rather than aborting the insert/move.
        IF NEW.parent_id IS NOT NULL THEN
            EXECUTE format(
                'SELECT CASE WHEN nlevel(path) > 0 THEN subltree(path, 0, 1)::text END'
                ' FROM %I WHERE id = $1',
                TG_TABLE_NAME
            ) INTO dest_root USING NEW.parent_id;
        END IF;
        dest_root := COALESCE(dest_root, lpad(NEW.id::text, 19, '0'));
        -- Source tree root (moves only): this row's current root, which the AFTER
        -- cascade will rewrite.
        IF TG_OP = 'UPDATE' AND OLD.path IS NOT NULL AND nlevel(OLD.path) > 0 THEN
            old_root := subltree(OLD.path, 0, 1)::text;
        END IF;
        key_dest := hashtextextended(TG_TABLE_NAME || ':' || dest_root, 0);
        IF old_root IS NOT NULL AND old_root <> dest_root THEN
            -- Cross-tree move: lock both roots, ascending, to avoid deadlock between
            -- two concurrent moves that touch the same pair.
            key_old := hashtextextended(TG_TABLE_NAME || ':' || old_root, 0);
            PERFORM pg_advisory_xact_lock(LEAST(key_dest, key_old));
            PERFORM pg_advisory_xact_lock(GREATEST(key_dest, key_old));
        ELSE
            PERFORM pg_advisory_xact_lock(key_dest);
        END IF;
    END IF;

    -- sort_path joins ancestor names with chr(9) (TAB); a literal tab in a name
    -- would inject a spurious separator and corrupt sibling ordering for the node
    -- and its descendants. LtreeModel.clean() rejects this for forms/serializers;
    -- this is the backstop for bulk_create / scripts / raw writes that bypass clean().
    IF position(chr(9) in COALESCE(NEW."name", '')) > 0 THEN
        RAISE EXCEPTION 'name contains a tab character, which is not allowed'
            USING ERRCODE = 'check_violation';
    END IF;
    IF NEW.parent_id IS NOT NULL THEN
        EXECUTE format('SELECT path, sort_path FROM %I WHERE id = $1', TG_TABLE_NAME)
            INTO parent_path, parent_sort_path USING NEW.parent_id;
        -- Cycle guard. See _COMPUTE_PATH_ONLY_FN for the rationale; this catches
        -- raw UPDATE / bulk_update paths that bypass LtreeModel.save().
        IF parent_path ~ ('*.' || lpad(NEW.id::text, 19, '0') || '.*')::lquery
            OR parent_path = lpad(NEW.id::text, 19, '0')::ltree THEN
            RAISE EXCEPTION 'cycle detected: % cannot be its own ancestor', TG_TABLE_NAME
                USING ERRCODE = 'check_violation';
        END IF;
        NEW.path := parent_path || lpad(NEW.id::text, 19, '0')::ltree;
        NEW.sort_path := parent_sort_path || chr(9) || NEW."name";
    ELSE
        NEW.path := lpad(NEW.id::text, 19, '0')::ltree;
        NEW.sort_path := NEW."name";
    END IF;
    RETURN NEW;
END
$_$;


--
-- Name: dcim_sitegroup_ltree_cascade_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_sitegroup_ltree_cascade_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
    -- COALESCE guards against a NULL sort_path slipping in via a raw write that
    -- bypassed the BEFORE trigger: without it, length(NULL)/substring(... FROM NULL)
    -- would cascade NULL to every descendant's sort_path in one shot.
    -- `nlevel($2) > 0` guards against an empty OLD.path ('', reachable only via a
    -- trigger-bypassing raw write): `path <@ ''` is true for EVERY row, so without
    -- this the cascade would rewrite the entire table on one reparent.
    EXECUTE format(
        'UPDATE %I SET '
        '  path = $1 || subpath(path, nlevel($2)), '
        '  sort_path = COALESCE($4, '''') || substring(COALESCE(sort_path, '''') FROM length(COALESCE($5, '''')) + 1) '
        'WHERE nlevel($2) > 0 AND path <@ $2 AND id != $3',
        TG_TABLE_NAME
    ) USING NEW.path, OLD.path, NEW.id, NEW.sort_path, OLD.sort_path;
    RETURN NULL;
END
$_$;


--
-- Name: dcim_sitegroup_ltree_compute_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dcim_sitegroup_ltree_compute_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    parent_path ltree;
    parent_sort_path text;
    dest_root text;
    old_root text;
    key_dest bigint;
    key_old bigint;
BEGIN

    -- A brand-new root (INSERT with parent_id IS NULL) starts its own singleton
    -- tree that no concurrent transaction can yet see (MVCC: the uncommitted row
    -- is invisible) or reference (no other transaction has its PK). For such a
    -- row this BEFORE function reads no other row (the parent lookup below is
    -- gated on parent_id) and the AFTER cascade fires only on UPDATE, so the
    -- insert touches solely its own NEW row -- there is nothing to serialize
    -- against, and the advisory lock it would otherwise take can never contend.
    -- Skipping it here is what stops a bulk import of many top-level objects from
    -- taking one xact-lock per root and exhausting the shared lock table
    -- (sized by max_locks_per_transaction). Every other case still locks below:
    -- a child insert, any reparent, and a reparent-to-root (TG_OP = UPDATE, where
    -- the existing row has a real subtree the AFTER cascade must rewrite).
    IF NOT (TG_OP = 'INSERT' AND NEW.parent_id IS NULL) THEN
        -- Destination tree root: the parent's root label, or this row's own label
        -- when it is (or becomes) a root. The CASE guards against a parent whose path
        -- is the empty ltree '' (reachable only via a trigger-bypassing raw write):
        -- subltree('', 0, 1) would raise 'invalid positions', so fall back to the
        -- child's own label as the lock key rather than aborting the insert/move.
        IF NEW.parent_id IS NOT NULL THEN
            EXECUTE format(
                'SELECT CASE WHEN nlevel(path) > 0 THEN subltree(path, 0, 1)::text END'
                ' FROM %I WHERE id = $1',
                TG_TABLE_NAME
            ) INTO dest_root USING NEW.parent_id;
        END IF;
        dest_root := COALESCE(dest_root, lpad(NEW.id::text, 19, '0'));
        -- Source tree root (moves only): this row's current root, which the AFTER
        -- cascade will rewrite.
        IF TG_OP = 'UPDATE' AND OLD.path IS NOT NULL AND nlevel(OLD.path) > 0 THEN
            old_root := subltree(OLD.path, 0, 1)::text;
        END IF;
        key_dest := hashtextextended(TG_TABLE_NAME || ':' || dest_root, 0);
        IF old_root IS NOT NULL AND old_root <> dest_root THEN
            -- Cross-tree move: lock both roots, ascending, to avoid deadlock between
            -- two concurrent moves that touch the same pair.
            key_old := hashtextextended(TG_TABLE_NAME || ':' || old_root, 0);
            PERFORM pg_advisory_xact_lock(LEAST(key_dest, key_old));
            PERFORM pg_advisory_xact_lock(GREATEST(key_dest, key_old));
        ELSE
            PERFORM pg_advisory_xact_lock(key_dest);
        END IF;
    END IF;

    -- sort_path joins ancestor names with chr(9) (TAB); a literal tab in a name
    -- would inject a spurious separator and corrupt sibling ordering for the node
    -- and its descendants. LtreeModel.clean() rejects this for forms/serializers;
    -- this is the backstop for bulk_create / scripts / raw writes that bypass clean().
    IF position(chr(9) in COALESCE(NEW."name", '')) > 0 THEN
        RAISE EXCEPTION 'name contains a tab character, which is not allowed'
            USING ERRCODE = 'check_violation';
    END IF;
    IF NEW.parent_id IS NOT NULL THEN
        EXECUTE format('SELECT path, sort_path FROM %I WHERE id = $1', TG_TABLE_NAME)
            INTO parent_path, parent_sort_path USING NEW.parent_id;
        -- Cycle guard. See _COMPUTE_PATH_ONLY_FN for the rationale; this catches
        -- raw UPDATE / bulk_update paths that bypass LtreeModel.save().
        IF parent_path ~ ('*.' || lpad(NEW.id::text, 19, '0') || '.*')::lquery
            OR parent_path = lpad(NEW.id::text, 19, '0')::ltree THEN
            RAISE EXCEPTION 'cycle detected: % cannot be its own ancestor', TG_TABLE_NAME
                USING ERRCODE = 'check_violation';
        END IF;
        NEW.path := parent_path || lpad(NEW.id::text, 19, '0')::ltree;
        NEW.sort_path := parent_sort_path || chr(9) || NEW."name";
    ELSE
        NEW.path := lpad(NEW.id::text, 19, '0')::ltree;
        NEW.sort_path := NEW."name";
    END IF;
    RETURN NEW;
END
$_$;


--
-- Name: ipam_prefix_denorm_from_dcim_location_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ipam_prefix_denorm_from_dcim_location_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "ipam_prefix"
                   SET "_site_id" = NEW."site_id", ("_region_id", "_site_group_id") = (SELECT "region_id", "group_id" FROM "dcim_site" WHERE id = NEW."site_id")
                 WHERE "_location_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: ipam_prefix_denorm_from_dcim_site_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ipam_prefix_denorm_from_dcim_site_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "ipam_prefix"
                   SET "_region_id" = NEW."region_id", "_site_group_id" = NEW."group_id"
                 WHERE "_site_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: tenancy_contactgroup_ltree_cascade_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tenancy_contactgroup_ltree_cascade_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
    -- COALESCE guards against a NULL sort_path slipping in via a raw write that
    -- bypassed the BEFORE trigger: without it, length(NULL)/substring(... FROM NULL)
    -- would cascade NULL to every descendant's sort_path in one shot.
    -- `nlevel($2) > 0` guards against an empty OLD.path ('', reachable only via a
    -- trigger-bypassing raw write): `path <@ ''` is true for EVERY row, so without
    -- this the cascade would rewrite the entire table on one reparent.
    EXECUTE format(
        'UPDATE %I SET '
        '  path = $1 || subpath(path, nlevel($2)), '
        '  sort_path = COALESCE($4, '''') || substring(COALESCE(sort_path, '''') FROM length(COALESCE($5, '''')) + 1) '
        'WHERE nlevel($2) > 0 AND path <@ $2 AND id != $3',
        TG_TABLE_NAME
    ) USING NEW.path, OLD.path, NEW.id, NEW.sort_path, OLD.sort_path;
    RETURN NULL;
END
$_$;


--
-- Name: tenancy_contactgroup_ltree_compute_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tenancy_contactgroup_ltree_compute_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    parent_path ltree;
    parent_sort_path text;
    dest_root text;
    old_root text;
    key_dest bigint;
    key_old bigint;
BEGIN

    -- A brand-new root (INSERT with parent_id IS NULL) starts its own singleton
    -- tree that no concurrent transaction can yet see (MVCC: the uncommitted row
    -- is invisible) or reference (no other transaction has its PK). For such a
    -- row this BEFORE function reads no other row (the parent lookup below is
    -- gated on parent_id) and the AFTER cascade fires only on UPDATE, so the
    -- insert touches solely its own NEW row -- there is nothing to serialize
    -- against, and the advisory lock it would otherwise take can never contend.
    -- Skipping it here is what stops a bulk import of many top-level objects from
    -- taking one xact-lock per root and exhausting the shared lock table
    -- (sized by max_locks_per_transaction). Every other case still locks below:
    -- a child insert, any reparent, and a reparent-to-root (TG_OP = UPDATE, where
    -- the existing row has a real subtree the AFTER cascade must rewrite).
    IF NOT (TG_OP = 'INSERT' AND NEW.parent_id IS NULL) THEN
        -- Destination tree root: the parent's root label, or this row's own label
        -- when it is (or becomes) a root. The CASE guards against a parent whose path
        -- is the empty ltree '' (reachable only via a trigger-bypassing raw write):
        -- subltree('', 0, 1) would raise 'invalid positions', so fall back to the
        -- child's own label as the lock key rather than aborting the insert/move.
        IF NEW.parent_id IS NOT NULL THEN
            EXECUTE format(
                'SELECT CASE WHEN nlevel(path) > 0 THEN subltree(path, 0, 1)::text END'
                ' FROM %I WHERE id = $1',
                TG_TABLE_NAME
            ) INTO dest_root USING NEW.parent_id;
        END IF;
        dest_root := COALESCE(dest_root, lpad(NEW.id::text, 19, '0'));
        -- Source tree root (moves only): this row's current root, which the AFTER
        -- cascade will rewrite.
        IF TG_OP = 'UPDATE' AND OLD.path IS NOT NULL AND nlevel(OLD.path) > 0 THEN
            old_root := subltree(OLD.path, 0, 1)::text;
        END IF;
        key_dest := hashtextextended(TG_TABLE_NAME || ':' || dest_root, 0);
        IF old_root IS NOT NULL AND old_root <> dest_root THEN
            -- Cross-tree move: lock both roots, ascending, to avoid deadlock between
            -- two concurrent moves that touch the same pair.
            key_old := hashtextextended(TG_TABLE_NAME || ':' || old_root, 0);
            PERFORM pg_advisory_xact_lock(LEAST(key_dest, key_old));
            PERFORM pg_advisory_xact_lock(GREATEST(key_dest, key_old));
        ELSE
            PERFORM pg_advisory_xact_lock(key_dest);
        END IF;
    END IF;

    -- sort_path joins ancestor names with chr(9) (TAB); a literal tab in a name
    -- would inject a spurious separator and corrupt sibling ordering for the node
    -- and its descendants. LtreeModel.clean() rejects this for forms/serializers;
    -- this is the backstop for bulk_create / scripts / raw writes that bypass clean().
    IF position(chr(9) in COALESCE(NEW."name", '')) > 0 THEN
        RAISE EXCEPTION 'name contains a tab character, which is not allowed'
            USING ERRCODE = 'check_violation';
    END IF;
    IF NEW.parent_id IS NOT NULL THEN
        EXECUTE format('SELECT path, sort_path FROM %I WHERE id = $1', TG_TABLE_NAME)
            INTO parent_path, parent_sort_path USING NEW.parent_id;
        -- Cycle guard. See _COMPUTE_PATH_ONLY_FN for the rationale; this catches
        -- raw UPDATE / bulk_update paths that bypass LtreeModel.save().
        IF parent_path ~ ('*.' || lpad(NEW.id::text, 19, '0') || '.*')::lquery
            OR parent_path = lpad(NEW.id::text, 19, '0')::ltree THEN
            RAISE EXCEPTION 'cycle detected: % cannot be its own ancestor', TG_TABLE_NAME
                USING ERRCODE = 'check_violation';
        END IF;
        NEW.path := parent_path || lpad(NEW.id::text, 19, '0')::ltree;
        NEW.sort_path := parent_sort_path || chr(9) || NEW."name";
    ELSE
        NEW.path := lpad(NEW.id::text, 19, '0')::ltree;
        NEW.sort_path := NEW."name";
    END IF;
    RETURN NEW;
END
$_$;


--
-- Name: tenancy_tenantgroup_ltree_cascade_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tenancy_tenantgroup_ltree_cascade_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
    -- COALESCE guards against a NULL sort_path slipping in via a raw write that
    -- bypassed the BEFORE trigger: without it, length(NULL)/substring(... FROM NULL)
    -- would cascade NULL to every descendant's sort_path in one shot.
    -- `nlevel($2) > 0` guards against an empty OLD.path ('', reachable only via a
    -- trigger-bypassing raw write): `path <@ ''` is true for EVERY row, so without
    -- this the cascade would rewrite the entire table on one reparent.
    EXECUTE format(
        'UPDATE %I SET '
        '  path = $1 || subpath(path, nlevel($2)), '
        '  sort_path = COALESCE($4, '''') || substring(COALESCE(sort_path, '''') FROM length(COALESCE($5, '''')) + 1) '
        'WHERE nlevel($2) > 0 AND path <@ $2 AND id != $3',
        TG_TABLE_NAME
    ) USING NEW.path, OLD.path, NEW.id, NEW.sort_path, OLD.sort_path;
    RETURN NULL;
END
$_$;


--
-- Name: tenancy_tenantgroup_ltree_compute_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tenancy_tenantgroup_ltree_compute_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    parent_path ltree;
    parent_sort_path text;
    dest_root text;
    old_root text;
    key_dest bigint;
    key_old bigint;
BEGIN

    -- A brand-new root (INSERT with parent_id IS NULL) starts its own singleton
    -- tree that no concurrent transaction can yet see (MVCC: the uncommitted row
    -- is invisible) or reference (no other transaction has its PK). For such a
    -- row this BEFORE function reads no other row (the parent lookup below is
    -- gated on parent_id) and the AFTER cascade fires only on UPDATE, so the
    -- insert touches solely its own NEW row -- there is nothing to serialize
    -- against, and the advisory lock it would otherwise take can never contend.
    -- Skipping it here is what stops a bulk import of many top-level objects from
    -- taking one xact-lock per root and exhausting the shared lock table
    -- (sized by max_locks_per_transaction). Every other case still locks below:
    -- a child insert, any reparent, and a reparent-to-root (TG_OP = UPDATE, where
    -- the existing row has a real subtree the AFTER cascade must rewrite).
    IF NOT (TG_OP = 'INSERT' AND NEW.parent_id IS NULL) THEN
        -- Destination tree root: the parent's root label, or this row's own label
        -- when it is (or becomes) a root. The CASE guards against a parent whose path
        -- is the empty ltree '' (reachable only via a trigger-bypassing raw write):
        -- subltree('', 0, 1) would raise 'invalid positions', so fall back to the
        -- child's own label as the lock key rather than aborting the insert/move.
        IF NEW.parent_id IS NOT NULL THEN
            EXECUTE format(
                'SELECT CASE WHEN nlevel(path) > 0 THEN subltree(path, 0, 1)::text END'
                ' FROM %I WHERE id = $1',
                TG_TABLE_NAME
            ) INTO dest_root USING NEW.parent_id;
        END IF;
        dest_root := COALESCE(dest_root, lpad(NEW.id::text, 19, '0'));
        -- Source tree root (moves only): this row's current root, which the AFTER
        -- cascade will rewrite.
        IF TG_OP = 'UPDATE' AND OLD.path IS NOT NULL AND nlevel(OLD.path) > 0 THEN
            old_root := subltree(OLD.path, 0, 1)::text;
        END IF;
        key_dest := hashtextextended(TG_TABLE_NAME || ':' || dest_root, 0);
        IF old_root IS NOT NULL AND old_root <> dest_root THEN
            -- Cross-tree move: lock both roots, ascending, to avoid deadlock between
            -- two concurrent moves that touch the same pair.
            key_old := hashtextextended(TG_TABLE_NAME || ':' || old_root, 0);
            PERFORM pg_advisory_xact_lock(LEAST(key_dest, key_old));
            PERFORM pg_advisory_xact_lock(GREATEST(key_dest, key_old));
        ELSE
            PERFORM pg_advisory_xact_lock(key_dest);
        END IF;
    END IF;

    -- sort_path joins ancestor names with chr(9) (TAB); a literal tab in a name
    -- would inject a spurious separator and corrupt sibling ordering for the node
    -- and its descendants. LtreeModel.clean() rejects this for forms/serializers;
    -- this is the backstop for bulk_create / scripts / raw writes that bypass clean().
    IF position(chr(9) in COALESCE(NEW."name", '')) > 0 THEN
        RAISE EXCEPTION 'name contains a tab character, which is not allowed'
            USING ERRCODE = 'check_violation';
    END IF;
    IF NEW.parent_id IS NOT NULL THEN
        EXECUTE format('SELECT path, sort_path FROM %I WHERE id = $1', TG_TABLE_NAME)
            INTO parent_path, parent_sort_path USING NEW.parent_id;
        -- Cycle guard. See _COMPUTE_PATH_ONLY_FN for the rationale; this catches
        -- raw UPDATE / bulk_update paths that bypass LtreeModel.save().
        IF parent_path ~ ('*.' || lpad(NEW.id::text, 19, '0') || '.*')::lquery
            OR parent_path = lpad(NEW.id::text, 19, '0')::ltree THEN
            RAISE EXCEPTION 'cycle detected: % cannot be its own ancestor', TG_TABLE_NAME
                USING ERRCODE = 'check_violation';
        END IF;
        NEW.path := parent_path || lpad(NEW.id::text, 19, '0')::ltree;
        NEW.sort_path := parent_sort_path || chr(9) || NEW."name";
    ELSE
        NEW.path := lpad(NEW.id::text, 19, '0')::ltree;
        NEW.sort_path := NEW."name";
    END IF;
    RETURN NEW;
END
$_$;


--
-- Name: virtualization_cluster_denorm_from_dcim_location_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.virtualization_cluster_denorm_from_dcim_location_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "virtualization_cluster"
                   SET "_site_id" = NEW."site_id", ("_region_id", "_site_group_id") = (SELECT "region_id", "group_id" FROM "dcim_site" WHERE id = NEW."site_id")
                 WHERE "_location_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: virtualization_cluster_denorm_from_dcim_site_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.virtualization_cluster_denorm_from_dcim_site_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "virtualization_cluster"
                   SET "_region_id" = NEW."region_id", "_site_group_id" = NEW."group_id"
                 WHERE "_site_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: wireless_wirelesslan_denorm_from_dcim_location_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.wireless_wirelesslan_denorm_from_dcim_location_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "wireless_wirelesslan"
                   SET "_site_id" = NEW."site_id", ("_region_id", "_site_group_id") = (SELECT "region_id", "group_id" FROM "dcim_site" WHERE id = NEW."site_id")
                 WHERE "_location_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: wireless_wirelesslan_denorm_from_dcim_site_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.wireless_wirelesslan_denorm_from_dcim_site_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                UPDATE "wireless_wirelesslan"
                   SET "_region_id" = NEW."region_id", "_site_group_id" = NEW."group_id"
                 WHERE "_site_id" = NEW.id;
                RETURN NULL;
            END
            $$;


--
-- Name: wireless_wirelesslangroup_ltree_cascade_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.wireless_wirelesslangroup_ltree_cascade_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
    -- COALESCE guards against a NULL sort_path slipping in via a raw write that
    -- bypassed the BEFORE trigger: without it, length(NULL)/substring(... FROM NULL)
    -- would cascade NULL to every descendant's sort_path in one shot.
    -- `nlevel($2) > 0` guards against an empty OLD.path ('', reachable only via a
    -- trigger-bypassing raw write): `path <@ ''` is true for EVERY row, so without
    -- this the cascade would rewrite the entire table on one reparent.
    EXECUTE format(
        'UPDATE %I SET '
        '  path = $1 || subpath(path, nlevel($2)), '
        '  sort_path = COALESCE($4, '''') || substring(COALESCE(sort_path, '''') FROM length(COALESCE($5, '''')) + 1) '
        'WHERE nlevel($2) > 0 AND path <@ $2 AND id != $3',
        TG_TABLE_NAME
    ) USING NEW.path, OLD.path, NEW.id, NEW.sort_path, OLD.sort_path;
    RETURN NULL;
END
$_$;


--
-- Name: wireless_wirelesslangroup_ltree_compute_path_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.wireless_wirelesslangroup_ltree_compute_path_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    parent_path ltree;
    parent_sort_path text;
    dest_root text;
    old_root text;
    key_dest bigint;
    key_old bigint;
BEGIN

    -- A brand-new root (INSERT with parent_id IS NULL) starts its own singleton
    -- tree that no concurrent transaction can yet see (MVCC: the uncommitted row
    -- is invisible) or reference (no other transaction has its PK). For such a
    -- row this BEFORE function reads no other row (the parent lookup below is
    -- gated on parent_id) and the AFTER cascade fires only on UPDATE, so the
    -- insert touches solely its own NEW row -- there is nothing to serialize
    -- against, and the advisory lock it would otherwise take can never contend.
    -- Skipping it here is what stops a bulk import of many top-level objects from
    -- taking one xact-lock per root and exhausting the shared lock table
    -- (sized by max_locks_per_transaction). Every other case still locks below:
    -- a child insert, any reparent, and a reparent-to-root (TG_OP = UPDATE, where
    -- the existing row has a real subtree the AFTER cascade must rewrite).
    IF NOT (TG_OP = 'INSERT' AND NEW.parent_id IS NULL) THEN
        -- Destination tree root: the parent's root label, or this row's own label
        -- when it is (or becomes) a root. The CASE guards against a parent whose path
        -- is the empty ltree '' (reachable only via a trigger-bypassing raw write):
        -- subltree('', 0, 1) would raise 'invalid positions', so fall back to the
        -- child's own label as the lock key rather than aborting the insert/move.
        IF NEW.parent_id IS NOT NULL THEN
            EXECUTE format(
                'SELECT CASE WHEN nlevel(path) > 0 THEN subltree(path, 0, 1)::text END'
                ' FROM %I WHERE id = $1',
                TG_TABLE_NAME
            ) INTO dest_root USING NEW.parent_id;
        END IF;
        dest_root := COALESCE(dest_root, lpad(NEW.id::text, 19, '0'));
        -- Source tree root (moves only): this row's current root, which the AFTER
        -- cascade will rewrite.
        IF TG_OP = 'UPDATE' AND OLD.path IS NOT NULL AND nlevel(OLD.path) > 0 THEN
            old_root := subltree(OLD.path, 0, 1)::text;
        END IF;
        key_dest := hashtextextended(TG_TABLE_NAME || ':' || dest_root, 0);
        IF old_root IS NOT NULL AND old_root <> dest_root THEN
            -- Cross-tree move: lock both roots, ascending, to avoid deadlock between
            -- two concurrent moves that touch the same pair.
            key_old := hashtextextended(TG_TABLE_NAME || ':' || old_root, 0);
            PERFORM pg_advisory_xact_lock(LEAST(key_dest, key_old));
            PERFORM pg_advisory_xact_lock(GREATEST(key_dest, key_old));
        ELSE
            PERFORM pg_advisory_xact_lock(key_dest);
        END IF;
    END IF;

    -- sort_path joins ancestor names with chr(9) (TAB); a literal tab in a name
    -- would inject a spurious separator and corrupt sibling ordering for the node
    -- and its descendants. LtreeModel.clean() rejects this for forms/serializers;
    -- this is the backstop for bulk_create / scripts / raw writes that bypass clean().
    IF position(chr(9) in COALESCE(NEW."name", '')) > 0 THEN
        RAISE EXCEPTION 'name contains a tab character, which is not allowed'
            USING ERRCODE = 'check_violation';
    END IF;
    IF NEW.parent_id IS NOT NULL THEN
        EXECUTE format('SELECT path, sort_path FROM %I WHERE id = $1', TG_TABLE_NAME)
            INTO parent_path, parent_sort_path USING NEW.parent_id;
        -- Cycle guard. See _COMPUTE_PATH_ONLY_FN for the rationale; this catches
        -- raw UPDATE / bulk_update paths that bypass LtreeModel.save().
        IF parent_path ~ ('*.' || lpad(NEW.id::text, 19, '0') || '.*')::lquery
            OR parent_path = lpad(NEW.id::text, 19, '0')::ltree THEN
            RAISE EXCEPTION 'cycle detected: % cannot be its own ancestor', TG_TABLE_NAME
                USING ERRCODE = 'check_violation';
        END IF;
        NEW.path := parent_path || lpad(NEW.id::text, 19, '0')::ltree;
        NEW.sort_path := parent_sort_path || chr(9) || NEW."name";
    ELSE
        NEW.path := lpad(NEW.id::text, 19, '0')::ltree;
        NEW.sort_path := NEW."name";
    END IF;
    RETURN NEW;
END
$_$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: circuits_circuit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.circuits_circuit (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    cid character varying(100) NOT NULL,
    status character varying(50) NOT NULL,
    install_date date,
    commit_rate integer,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    provider_id bigint NOT NULL,
    tenant_id bigint,
    termination_a_id bigint,
    termination_z_id bigint,
    type_id bigint NOT NULL,
    termination_date date,
    provider_account_id bigint,
    _abs_distance numeric(13,4),
    distance numeric(8,2),
    distance_unit character varying(50),
    owner_id bigint,
    CONSTRAINT circuits_circuit_commit_rate_check CHECK ((commit_rate >= 0))
);


--
-- Name: circuits_circuit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.circuits_circuit ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.circuits_circuit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: circuits_circuitgroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.circuits_circuitgroup (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    tenant_id bigint,
    owner_id bigint,
    comments text NOT NULL
);


--
-- Name: circuits_circuitgroup_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.circuits_circuitgroup ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.circuits_circuitgroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: circuits_circuitgroupassignment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.circuits_circuitgroupassignment (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    priority character varying(50),
    member_id bigint CONSTRAINT circuits_circuitgroupassignment_circuit_id_not_null NOT NULL,
    group_id bigint NOT NULL,
    member_type_id integer NOT NULL,
    CONSTRAINT circuits_circuitgroupassignment_member_id_0c42fe52_check CHECK ((member_id >= 0))
);


--
-- Name: circuits_circuitgroupassignment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.circuits_circuitgroupassignment ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.circuits_circuitgroupassignment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: circuits_circuittermination; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.circuits_circuittermination (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint NOT NULL,
    mark_connected boolean NOT NULL,
    term_side character varying(1) NOT NULL,
    port_speed integer,
    upstream_speed integer,
    xconnect_id character varying(50) NOT NULL,
    pp_info character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    cable_id bigint,
    circuit_id bigint NOT NULL,
    _provider_network_id bigint,
    custom_field_data jsonb NOT NULL,
    cable_end character varying(1),
    termination_id bigint,
    termination_type_id integer,
    _location_id bigint,
    _region_id bigint,
    _site_id bigint,
    _site_group_id bigint,
    cable_connector smallint,
    cable_positions smallint[],
    CONSTRAINT circuits_circuittermination_cable_connector_check CHECK ((cable_connector >= 0)),
    CONSTRAINT circuits_circuittermination_port_speed_check CHECK ((port_speed >= 0)),
    CONSTRAINT circuits_circuittermination_termination_id_check CHECK ((termination_id >= 0)),
    CONSTRAINT circuits_circuittermination_upstream_speed_check CHECK ((upstream_speed >= 0))
);


--
-- Name: circuits_circuittermination_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.circuits_circuittermination ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.circuits_circuittermination_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: circuits_circuittype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.circuits_circuittype (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    color character varying(6) NOT NULL,
    owner_id bigint,
    comments text NOT NULL
);


--
-- Name: circuits_circuittype_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.circuits_circuittype ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.circuits_circuittype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: circuits_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.circuits_provider (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    slug character varying(100) NOT NULL,
    comments text NOT NULL,
    description character varying(200) NOT NULL,
    owner_id bigint
);


--
-- Name: circuits_provider_asns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.circuits_provider_asns (
    id bigint NOT NULL,
    provider_id bigint NOT NULL,
    asn_id bigint NOT NULL
);


--
-- Name: circuits_provider_asns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.circuits_provider_asns ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.circuits_provider_asns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: circuits_provider_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.circuits_provider ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.circuits_provider_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: circuits_provideraccount; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.circuits_provideraccount (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    account character varying(100) NOT NULL,
    name character varying(100) NOT NULL,
    provider_id bigint NOT NULL,
    owner_id bigint
);


--
-- Name: circuits_provideraccount_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.circuits_provideraccount ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.circuits_provideraccount_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: circuits_providernetwork; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.circuits_providernetwork (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    provider_id bigint NOT NULL,
    service_id character varying(100) NOT NULL,
    owner_id bigint
);


--
-- Name: circuits_providernetwork_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.circuits_providernetwork ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.circuits_providernetwork_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: circuits_virtualcircuit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.circuits_virtualcircuit (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    cid character varying(100) NOT NULL,
    status character varying(50) NOT NULL,
    provider_account_id bigint,
    provider_network_id bigint NOT NULL,
    type_id bigint NOT NULL,
    tenant_id bigint,
    owner_id bigint
);


--
-- Name: circuits_virtualcircuit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.circuits_virtualcircuit ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.circuits_virtualcircuit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: circuits_virtualcircuittermination; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.circuits_virtualcircuittermination (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    role character varying(50) NOT NULL,
    description character varying(200) NOT NULL,
    interface_id bigint NOT NULL,
    virtual_circuit_id bigint NOT NULL
);


--
-- Name: circuits_virtualcircuittermination_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.circuits_virtualcircuittermination ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.circuits_virtualcircuittermination_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: circuits_virtualcircuittype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.circuits_virtualcircuittype (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    color character varying(6) NOT NULL,
    owner_id bigint,
    comments text NOT NULL
);


--
-- Name: circuits_virtualcircuittype_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.circuits_virtualcircuittype ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.circuits_virtualcircuittype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_autosyncrecord; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_autosyncrecord (
    id bigint NOT NULL,
    object_id bigint NOT NULL,
    datafile_id bigint NOT NULL,
    object_type_id integer NOT NULL,
    CONSTRAINT core_autosyncrecord_object_id_check CHECK ((object_id >= 0))
);


--
-- Name: core_autosyncrecord_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_autosyncrecord ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_autosyncrecord_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_configrevision; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_configrevision (
    id bigint CONSTRAINT extras_configrevision_id_not_null NOT NULL,
    created timestamp with time zone CONSTRAINT extras_configrevision_created_not_null NOT NULL,
    comment character varying(200) CONSTRAINT extras_configrevision_comment_not_null NOT NULL,
    data jsonb,
    active boolean NOT NULL
);


--
-- Name: core_datafile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_datafile (
    id bigint NOT NULL,
    created timestamp with time zone NOT NULL,
    last_updated timestamp with time zone NOT NULL,
    path character varying(1000) NOT NULL,
    size integer NOT NULL,
    hash character varying(64) NOT NULL,
    data bytea NOT NULL,
    source_id bigint NOT NULL,
    CONSTRAINT core_datafile_size_check CHECK ((size >= 0))
);


--
-- Name: core_datafile_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_datafile ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_datafile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_datasource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_datasource (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    source_url character varying(200) NOT NULL,
    status character varying(50) NOT NULL,
    enabled boolean NOT NULL,
    ignore_rules text NOT NULL,
    parameters jsonb,
    last_synced timestamp with time zone,
    sync_interval smallint,
    owner_id bigint,
    CONSTRAINT core_datasource_sync_interval_check CHECK ((sync_interval >= 0))
);


--
-- Name: core_datasource_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_datasource ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_datasource_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_job; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_job (
    id bigint NOT NULL,
    object_id bigint,
    name character varying(200) NOT NULL,
    created timestamp with time zone NOT NULL,
    scheduled timestamp with time zone,
    "interval" integer,
    started timestamp with time zone,
    completed timestamp with time zone,
    status character varying(30) NOT NULL,
    data jsonb,
    job_id uuid NOT NULL,
    object_type_id integer,
    user_id bigint,
    error text NOT NULL,
    log_entries jsonb[] NOT NULL,
    queue_name character varying(100) NOT NULL,
    notifications character varying(30) NOT NULL,
    execution_time interval,
    CONSTRAINT core_job_interval_check CHECK (("interval" >= 0)),
    CONSTRAINT core_job_object_id_check CHECK ((object_id >= 0))
);


--
-- Name: core_job_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_job ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_managedfile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_managedfile (
    id bigint NOT NULL,
    data_path character varying(1000) NOT NULL,
    data_synced timestamp with time zone,
    created timestamp with time zone NOT NULL,
    last_updated timestamp with time zone,
    file_root character varying(1000) NOT NULL,
    file_path character varying(100) NOT NULL,
    data_file_id bigint,
    data_source_id bigint,
    auto_sync_enabled boolean NOT NULL
);


--
-- Name: core_managedfile_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_managedfile ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_managedfile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_objectchange; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_objectchange (
    id bigint CONSTRAINT extras_objectchange_id_not_null NOT NULL,
    "time" timestamp with time zone CONSTRAINT extras_objectchange_time_not_null NOT NULL,
    user_name character varying(150) CONSTRAINT extras_objectchange_user_name_not_null NOT NULL,
    request_id uuid CONSTRAINT extras_objectchange_request_id_not_null NOT NULL,
    action character varying(50) CONSTRAINT extras_objectchange_action_not_null NOT NULL,
    changed_object_id bigint CONSTRAINT extras_objectchange_changed_object_id_not_null NOT NULL,
    related_object_id bigint,
    object_repr character varying(200) CONSTRAINT extras_objectchange_object_repr_not_null NOT NULL,
    prechange_data jsonb,
    postchange_data jsonb,
    changed_object_type_id integer CONSTRAINT extras_objectchange_changed_object_type_id_not_null NOT NULL,
    related_object_type_id integer,
    user_id bigint,
    message character varying(200) NOT NULL,
    CONSTRAINT core_objectchange_changed_object_id_check CHECK ((changed_object_id >= 0)),
    CONSTRAINT core_objectchange_related_object_id_check CHECK ((related_object_id >= 0))
);


--
-- Name: core_objectchange_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_objectchange ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_objectchange_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_objecttype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_objecttype (
    contenttype_ptr_id integer NOT NULL,
    public boolean NOT NULL,
    features character varying(50)[] NOT NULL
);


--
-- Name: dcim_cable; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_cable (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    type character varying(50),
    status character varying(50) NOT NULL,
    label character varying(100) NOT NULL,
    color character varying(6) NOT NULL,
    length numeric(8,2),
    length_unit character varying(50),
    _abs_length numeric(14,4),
    tenant_id bigint,
    comments text NOT NULL,
    description character varying(200) NOT NULL,
    owner_id bigint,
    profile character varying(50) NOT NULL,
    bundle_id bigint
);


--
-- Name: dcim_cable_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_cable ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_cable_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_cablebundle; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_cablebundle (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL,
    owner_id bigint
);


--
-- Name: dcim_cablebundle_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_cablebundle ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_cablebundle_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_cablepath; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_cablepath (
    id bigint NOT NULL,
    _nodes character varying(40)[] CONSTRAINT dcim_cablepath_path_not_null NOT NULL,
    is_active boolean NOT NULL,
    is_split boolean NOT NULL,
    path jsonb CONSTRAINT dcim_cablepath_path_not_null1 NOT NULL,
    is_complete boolean NOT NULL
);


--
-- Name: dcim_cablepath_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_cablepath ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_cablepath_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_cabletermination; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_cabletermination (
    id bigint NOT NULL,
    cable_end character varying(1) NOT NULL,
    termination_id bigint NOT NULL,
    cable_id bigint NOT NULL,
    termination_type_id integer NOT NULL,
    _device_id bigint,
    _rack_id bigint,
    _location_id bigint,
    _site_id bigint,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    connector smallint,
    positions smallint[],
    CONSTRAINT dcim_cabletermination_connector_check CHECK ((connector >= 0)),
    CONSTRAINT dcim_cabletermination_termination_id_check CHECK ((termination_id >= 0))
);


--
-- Name: dcim_cabletermination_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_cabletermination ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_cabletermination_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_consoleport; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_consoleport (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    mark_connected boolean NOT NULL,
    type character varying(50),
    speed integer,
    _path_id bigint,
    cable_id bigint,
    device_id bigint NOT NULL,
    module_id bigint,
    cable_end character varying(1),
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint,
    owner_id bigint,
    cable_connector smallint,
    cable_positions smallint[],
    CONSTRAINT dcim_consoleport_cable_connector_check CHECK ((cable_connector >= 0)),
    CONSTRAINT dcim_consoleport_speed_check CHECK ((speed >= 0))
);


--
-- Name: dcim_consoleport_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_consoleport ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_consoleport_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_consoleporttemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_consoleporttemplate (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(50),
    device_type_id bigint,
    module_type_id bigint
);


--
-- Name: dcim_consoleporttemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_consoleporttemplate ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_consoleporttemplate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_consoleserverport; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_consoleserverport (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    mark_connected boolean NOT NULL,
    type character varying(50),
    speed integer,
    _path_id bigint,
    cable_id bigint,
    device_id bigint NOT NULL,
    module_id bigint,
    cable_end character varying(1),
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint,
    owner_id bigint,
    cable_connector smallint,
    cable_positions smallint[],
    CONSTRAINT dcim_consoleserverport_cable_connector_check CHECK ((cable_connector >= 0)),
    CONSTRAINT dcim_consoleserverport_speed_check CHECK ((speed >= 0))
);


--
-- Name: dcim_consoleserverport_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_consoleserverport ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_consoleserverport_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_consoleserverporttemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_consoleserverporttemplate (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(50),
    device_type_id bigint,
    module_type_id bigint
);


--
-- Name: dcim_consoleserverporttemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_consoleserverporttemplate ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_consoleserverporttemplate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_coolingfeed; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_coolingfeed (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    max_flow numeric(8,2),
    max_flow_unit character varying(50),
    _abs_max_flow numeric(13,4),
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    status character varying(50) NOT NULL,
    cooling_capacity numeric(10,2),
    owner_id bigint,
    rack_id bigint,
    tenant_id bigint,
    cooling_source_id bigint NOT NULL
);


--
-- Name: dcim_coolingfeed_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_coolingfeed ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_coolingfeed_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_coolingintake; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_coolingintake (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    diameter numeric(8,2),
    diameter_unit character varying(50),
    _abs_diameter numeric(13,4),
    max_flow numeric(8,2),
    max_flow_unit character varying(50),
    _abs_max_flow numeric(13,4),
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(50),
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint,
    device_id bigint NOT NULL,
    module_id bigint,
    owner_id bigint,
    cooling_outflow_id bigint
);


--
-- Name: dcim_coolingintake_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_coolingintake ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_coolingintake_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_coolingintaketemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_coolingintaketemplate (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    diameter numeric(8,2),
    diameter_unit character varying(50),
    _abs_diameter numeric(13,4),
    max_flow numeric(8,2),
    max_flow_unit character varying(50),
    _abs_max_flow numeric(13,4),
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(50),
    device_type_id bigint,
    module_type_id bigint
);


--
-- Name: dcim_coolingintaketemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_coolingintaketemplate ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_coolingintaketemplate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_coolingoutflow; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_coolingoutflow (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    diameter numeric(8,2),
    diameter_unit character varying(50),
    _abs_diameter numeric(13,4),
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(50),
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint,
    device_id bigint NOT NULL,
    module_id bigint,
    owner_id bigint,
    cooling_intake_id bigint
);


--
-- Name: dcim_coolingoutflow_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_coolingoutflow ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_coolingoutflow_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_coolingoutflowtemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_coolingoutflowtemplate (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    diameter numeric(8,2),
    diameter_unit character varying(50),
    _abs_diameter numeric(13,4),
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(50),
    device_type_id bigint,
    module_type_id bigint,
    cooling_intake_id bigint
);


--
-- Name: dcim_coolingoutflowtemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_coolingoutflowtemplate ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_coolingoutflowtemplate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_coolingsource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_coolingsource (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    type character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    fluid_type character varying(50),
    cooling_capacity numeric(10,2),
    location_id bigint,
    owner_id bigint,
    site_id bigint NOT NULL
);


--
-- Name: dcim_coolingsource_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_coolingsource ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_coolingsource_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_device; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_device (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    local_context_data jsonb,
    name character varying(64) COLLATE public.natural_sort,
    serial character varying(50) NOT NULL,
    asset_tag character varying(50),
    "position" numeric(4,1),
    face character varying(50),
    status character varying(50) NOT NULL,
    vc_position integer,
    vc_priority smallint,
    comments text NOT NULL,
    cluster_id bigint,
    role_id bigint CONSTRAINT dcim_device_device_role_id_not_null NOT NULL,
    device_type_id bigint NOT NULL,
    location_id bigint,
    platform_id bigint,
    primary_ip4_id bigint,
    primary_ip6_id bigint,
    rack_id bigint,
    site_id bigint NOT NULL,
    tenant_id bigint,
    virtual_chassis_id bigint,
    airflow character varying(50),
    description character varying(200) NOT NULL,
    config_template_id bigint,
    latitude numeric(8,6),
    longitude numeric(9,6),
    oob_ip_id bigint,
    console_port_count bigint NOT NULL,
    console_server_port_count bigint NOT NULL,
    power_port_count bigint NOT NULL,
    power_outlet_count bigint NOT NULL,
    interface_count bigint NOT NULL,
    front_port_count bigint NOT NULL,
    rear_port_count bigint NOT NULL,
    device_bay_count bigint NOT NULL,
    module_bay_count bigint NOT NULL,
    inventory_item_count bigint NOT NULL,
    owner_id bigint,
    _config_context_data jsonb,
    _config_context_generation bigint NOT NULL,
    cooling_method character varying(50),
    cooling_outflow_count bigint NOT NULL,
    cooling_intake_count bigint NOT NULL,
    CONSTRAINT dcim_device__config_context_generation_check CHECK ((_config_context_generation >= 0)),
    CONSTRAINT dcim_device_vc_position_check CHECK ((vc_position >= 0)),
    CONSTRAINT dcim_device_vc_priority_check CHECK ((vc_priority >= 0))
);


--
-- Name: dcim_device_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_device ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_device_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_devicebay; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_devicebay (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    device_id bigint NOT NULL,
    installed_device_id bigint,
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint,
    owner_id bigint,
    enabled boolean NOT NULL
);


--
-- Name: dcim_devicebay_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_devicebay ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_devicebay_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_devicebaytemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_devicebaytemplate (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    device_type_id bigint NOT NULL,
    enabled boolean NOT NULL
);


--
-- Name: dcim_devicebaytemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_devicebaytemplate ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_devicebaytemplate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_devicerole; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_devicerole (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    color character varying(6) NOT NULL,
    vm_role boolean NOT NULL,
    description character varying(200) NOT NULL,
    config_template_id bigint,
    parent_id bigint,
    comments text NOT NULL,
    owner_id bigint,
    path public.ltree NOT NULL,
    sort_path text NOT NULL
);


--
-- Name: dcim_devicerole_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_devicerole ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_devicerole_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_devicetype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_devicetype (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    model character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    part_number character varying(50) NOT NULL,
    u_height numeric(4,1) NOT NULL,
    is_full_depth boolean NOT NULL,
    subdevice_role character varying(50),
    front_image character varying(100) NOT NULL,
    rear_image character varying(100) NOT NULL,
    comments text NOT NULL,
    manufacturer_id bigint NOT NULL,
    airflow character varying(50),
    weight numeric(8,2),
    weight_unit character varying(50),
    _abs_weight bigint,
    description character varying(200) NOT NULL,
    default_platform_id bigint,
    console_port_template_count bigint NOT NULL,
    console_server_port_template_count bigint NOT NULL,
    power_port_template_count bigint NOT NULL,
    power_outlet_template_count bigint NOT NULL,
    interface_template_count bigint NOT NULL,
    front_port_template_count bigint NOT NULL,
    rear_port_template_count bigint NOT NULL,
    device_bay_template_count bigint NOT NULL,
    module_bay_template_count bigint NOT NULL,
    inventory_item_template_count bigint NOT NULL,
    exclude_from_utilization boolean NOT NULL,
    owner_id bigint,
    device_count bigint NOT NULL,
    end_of_life date,
    cooling_method character varying(50),
    cooling_outflow_template_count bigint NOT NULL,
    cooling_intake_template_count bigint NOT NULL,
    CONSTRAINT dcim_devicetype__abs_weight_check CHECK ((_abs_weight >= 0))
);


--
-- Name: dcim_devicetype_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_devicetype ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_devicetype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_frontport; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_frontport (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    mark_connected boolean NOT NULL,
    type character varying(50) NOT NULL,
    cable_id bigint,
    device_id bigint NOT NULL,
    color character varying(6) NOT NULL,
    module_id bigint,
    cable_end character varying(1),
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint,
    owner_id bigint,
    cable_connector smallint,
    cable_positions smallint[],
    positions smallint NOT NULL,
    CONSTRAINT dcim_frontport_cable_connector_check CHECK ((cable_connector >= 0)),
    CONSTRAINT dcim_frontport_positions_check CHECK ((positions >= 0))
);


--
-- Name: dcim_frontport_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_frontport ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_frontport_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_frontporttemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_frontporttemplate (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(50) NOT NULL,
    device_type_id bigint,
    color character varying(6) NOT NULL,
    module_type_id bigint,
    positions smallint NOT NULL,
    CONSTRAINT dcim_frontporttemplate_positions_check CHECK ((positions >= 0))
);


--
-- Name: dcim_frontporttemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_frontporttemplate ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_frontporttemplate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_interface; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_interface (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    mark_connected boolean NOT NULL,
    enabled boolean NOT NULL,
    mtu integer,
    mode character varying(50),
    _name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    mgmt_only boolean NOT NULL,
    _path_id bigint,
    cable_id bigint,
    device_id bigint NOT NULL,
    lag_id bigint,
    parent_id bigint,
    untagged_vlan_id bigint,
    wwn macaddr8,
    bridge_id bigint,
    rf_role character varying(30),
    rf_channel character varying(50),
    rf_channel_frequency numeric(8,3),
    rf_channel_width numeric(7,3),
    tx_power smallint,
    wireless_link_id bigint,
    module_id bigint,
    vrf_id bigint,
    duplex character varying(50),
    speed bigint,
    poe_mode character varying(50),
    poe_type character varying(50),
    cable_end character varying(1),
    vlan_translation_policy_id bigint,
    qinq_svlan_id bigint,
    primary_mac_address_id bigint,
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint,
    owner_id bigint,
    cable_connector smallint,
    cable_positions smallint[],
    channel_id smallint,
    channels smallint,
    CONSTRAINT dcim_interface_cable_connector_check CHECK ((cable_connector >= 0)),
    CONSTRAINT dcim_interface_channel_id_check CHECK ((channel_id >= 0)),
    CONSTRAINT dcim_interface_channels_check CHECK ((channels >= 0)),
    CONSTRAINT dcim_interface_mtu_check CHECK ((mtu >= 0)),
    CONSTRAINT dcim_interface_speed_check CHECK ((speed >= 0))
);


--
-- Name: dcim_interface_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_interface ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_interface_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_interface_tagged_vlans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_interface_tagged_vlans (
    id bigint NOT NULL,
    interface_id bigint NOT NULL,
    vlan_id bigint NOT NULL
);


--
-- Name: dcim_interface_tagged_vlans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_interface_tagged_vlans ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_interface_tagged_vlans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_interface_vdcs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_interface_vdcs (
    id bigint NOT NULL,
    interface_id bigint NOT NULL,
    virtualdevicecontext_id bigint NOT NULL
);


--
-- Name: dcim_interface_vdcs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_interface_vdcs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_interface_vdcs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_interface_wireless_lans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_interface_wireless_lans (
    id bigint NOT NULL,
    interface_id bigint NOT NULL,
    wirelesslan_id bigint NOT NULL
);


--
-- Name: dcim_interface_wireless_lans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_interface_wireless_lans ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_interface_wireless_lans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_interfacetemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_interfacetemplate (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    _name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    mgmt_only boolean NOT NULL,
    device_type_id bigint,
    module_type_id bigint,
    poe_mode character varying(50),
    poe_type character varying(50),
    enabled boolean NOT NULL,
    bridge_id bigint,
    rf_role character varying(30),
    parent_id bigint,
    channel_id smallint,
    channels smallint,
    CONSTRAINT dcim_interfacetemplate_channel_id_check CHECK ((channel_id >= 0)),
    CONSTRAINT dcim_interfacetemplate_channels_check CHECK ((channels >= 0))
);


--
-- Name: dcim_interfacetemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_interfacetemplate ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_interfacetemplate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_inventoryitem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_inventoryitem (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    part_id character varying(50) NOT NULL,
    serial character varying(50) NOT NULL,
    asset_tag character varying(50),
    discovered boolean NOT NULL,
    device_id bigint NOT NULL,
    manufacturer_id bigint,
    parent_id bigint,
    role_id bigint,
    component_id bigint,
    component_type_id integer,
    status character varying(50) NOT NULL,
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint,
    owner_id bigint,
    path public.ltree NOT NULL,
    CONSTRAINT dcim_inventoryitem_component_id_check CHECK ((component_id >= 0))
);


--
-- Name: dcim_inventoryitem_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_inventoryitem ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_inventoryitem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_inventoryitemrole; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_inventoryitemrole (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    color character varying(6) NOT NULL,
    description character varying(200) NOT NULL,
    owner_id bigint,
    comments text NOT NULL
);


--
-- Name: dcim_inventoryitemrole_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_inventoryitemrole ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_inventoryitemrole_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_inventoryitemtemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_inventoryitemtemplate (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    component_id bigint,
    part_id character varying(50) NOT NULL,
    component_type_id integer,
    device_type_id bigint NOT NULL,
    manufacturer_id bigint,
    parent_id bigint,
    role_id bigint,
    path public.ltree NOT NULL,
    CONSTRAINT dcim_inventoryitemtemplate_component_id_check CHECK ((component_id >= 0))
);


--
-- Name: dcim_inventoryitemtemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_inventoryitemtemplate ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_inventoryitemtemplate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_location; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_location (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    parent_id bigint,
    site_id bigint NOT NULL,
    tenant_id bigint,
    status character varying(50) NOT NULL,
    facility character varying(50) NOT NULL,
    comments text NOT NULL,
    owner_id bigint,
    path public.ltree NOT NULL,
    sort_path text NOT NULL
);


--
-- Name: dcim_location_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_location ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_location_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_macaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_macaddress (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    mac_address macaddr NOT NULL,
    assigned_object_id bigint,
    assigned_object_type_id integer,
    owner_id bigint,
    CONSTRAINT dcim_macaddress_assigned_object_id_check CHECK ((assigned_object_id >= 0))
);


--
-- Name: dcim_macaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_macaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_macaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_manufacturer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_manufacturer (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    owner_id bigint,
    comments text NOT NULL
);


--
-- Name: dcim_manufacturer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_manufacturer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_manufacturer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_module; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_module (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    serial character varying(50) NOT NULL,
    asset_tag character varying(50),
    comments text NOT NULL,
    device_id bigint NOT NULL,
    module_bay_id bigint NOT NULL,
    module_type_id bigint NOT NULL,
    description character varying(200) NOT NULL,
    status character varying(50) NOT NULL,
    owner_id bigint
);


--
-- Name: dcim_module_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_module ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_module_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_modulebay; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_modulebay (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    "position" character varying(30) NOT NULL,
    description character varying(200) NOT NULL,
    device_id bigint NOT NULL,
    module_id bigint,
    parent_id bigint,
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint,
    owner_id bigint,
    enabled boolean NOT NULL,
    path public.ltree NOT NULL,
    sort_path text NOT NULL COLLATE public.natural_sort
);


--
-- Name: dcim_modulebay_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_modulebay ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_modulebay_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_modulebay_module_bay_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_modulebay_module_bay_types (
    id bigint NOT NULL,
    modulebay_id bigint NOT NULL,
    modulebaytype_id bigint NOT NULL
);


--
-- Name: dcim_modulebay_module_bay_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_modulebay_module_bay_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_modulebay_module_bay_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_modulebaytemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_modulebaytemplate (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    "position" character varying(30) NOT NULL,
    description character varying(200) NOT NULL,
    device_type_id bigint,
    module_type_id bigint,
    enabled boolean NOT NULL
);


--
-- Name: dcim_modulebaytemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_modulebaytemplate ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_modulebaytemplate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_modulebaytemplate_module_bay_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_modulebaytemplate_module_bay_types (
    id bigint NOT NULL,
    modulebaytemplate_id bigint CONSTRAINT dcim_modulebaytemplate_module_bay_modulebaytemplate_id_not_null NOT NULL,
    modulebaytype_id bigint CONSTRAINT dcim_modulebaytemplate_module_bay_typ_modulebaytype_id_not_null NOT NULL
);


--
-- Name: dcim_modulebaytemplate_module_bay_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_modulebaytemplate_module_bay_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_modulebaytemplate_module_bay_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_modulebaytype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_modulebaytype (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    color character varying(6) NOT NULL,
    manufacturer_id bigint,
    owner_id bigint
);


--
-- Name: dcim_modulebaytype_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_modulebaytype ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_modulebaytype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_moduletype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_moduletype (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    model character varying(100) NOT NULL,
    part_number character varying(50) NOT NULL,
    comments text NOT NULL,
    manufacturer_id bigint NOT NULL,
    weight numeric(8,2),
    weight_unit character varying(50),
    _abs_weight bigint,
    description character varying(200) NOT NULL,
    airflow character varying(50),
    attribute_data jsonb,
    profile_id bigint,
    owner_id bigint,
    module_count bigint NOT NULL,
    console_port_template_count bigint NOT NULL,
    console_server_port_template_count bigint NOT NULL,
    front_port_template_count bigint NOT NULL,
    interface_template_count bigint NOT NULL,
    module_bay_template_count bigint NOT NULL,
    power_outlet_template_count bigint NOT NULL,
    power_port_template_count bigint NOT NULL,
    rear_port_template_count bigint NOT NULL,
    end_of_life date,
    cooling_method character varying(50),
    cooling_outflow_template_count bigint NOT NULL,
    cooling_intake_template_count bigint NOT NULL,
    CONSTRAINT dcim_moduletype__abs_weight_check CHECK ((_abs_weight >= 0))
);


--
-- Name: dcim_moduletype_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_moduletype ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_moduletype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_moduletype_module_bay_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_moduletype_module_bay_types (
    id bigint NOT NULL,
    moduletype_id bigint NOT NULL,
    modulebaytype_id bigint NOT NULL
);


--
-- Name: dcim_moduletype_module_bay_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_moduletype_module_bay_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_moduletype_module_bay_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_moduletypeprofile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_moduletypeprofile (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL,
    schema jsonb,
    owner_id bigint
);


--
-- Name: dcim_moduletypeprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_moduletypeprofile ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_moduletypeprofile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_platform; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_platform (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    manufacturer_id bigint,
    config_template_id bigint,
    parent_id bigint,
    comments text NOT NULL,
    owner_id bigint,
    path public.ltree NOT NULL,
    sort_path text NOT NULL
);


--
-- Name: dcim_platform_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_platform ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_platform_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_portmapping; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_portmapping (
    id bigint NOT NULL,
    front_port_position smallint NOT NULL,
    rear_port_position smallint NOT NULL,
    device_id bigint NOT NULL,
    front_port_id bigint NOT NULL,
    rear_port_id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    CONSTRAINT dcim_portmapping_front_port_position_check CHECK ((front_port_position >= 0)),
    CONSTRAINT dcim_portmapping_rear_port_position_check CHECK ((rear_port_position >= 0))
);


--
-- Name: dcim_portmapping_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_portmapping ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_portmapping_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_porttemplatemapping; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_porttemplatemapping (
    id bigint NOT NULL,
    front_port_position smallint NOT NULL,
    rear_port_position smallint NOT NULL,
    device_type_id bigint,
    module_type_id bigint,
    front_port_id bigint NOT NULL,
    rear_port_id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    CONSTRAINT dcim_porttemplatemapping_front_port_position_check CHECK ((front_port_position >= 0)),
    CONSTRAINT dcim_porttemplatemapping_rear_port_position_check CHECK ((rear_port_position >= 0))
);


--
-- Name: dcim_porttemplatemapping_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_porttemplatemapping ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_porttemplatemapping_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_powerfeed; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_powerfeed (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    mark_connected boolean NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    status character varying(50) NOT NULL,
    type character varying(50) NOT NULL,
    supply character varying(50) NOT NULL,
    phase character varying(50) NOT NULL,
    voltage smallint NOT NULL,
    amperage smallint NOT NULL,
    max_utilization smallint NOT NULL,
    available_power integer NOT NULL,
    comments text NOT NULL,
    _path_id bigint,
    cable_id bigint,
    power_panel_id bigint NOT NULL,
    rack_id bigint,
    cable_end character varying(1),
    description character varying(200) NOT NULL,
    tenant_id bigint,
    owner_id bigint,
    cable_connector smallint,
    cable_positions smallint[],
    CONSTRAINT dcim_powerfeed_amperage_check CHECK ((amperage >= 0)),
    CONSTRAINT dcim_powerfeed_available_power_check CHECK ((available_power >= 0)),
    CONSTRAINT dcim_powerfeed_cable_connector_check CHECK ((cable_connector >= 0)),
    CONSTRAINT dcim_powerfeed_max_utilization_check CHECK ((max_utilization >= 0))
);


--
-- Name: dcim_powerfeed_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_powerfeed ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_powerfeed_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_poweroutlet; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_poweroutlet (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    mark_connected boolean NOT NULL,
    type character varying(50),
    feed_leg character varying(50),
    _path_id bigint,
    cable_id bigint,
    device_id bigint NOT NULL,
    power_port_id bigint,
    module_id bigint,
    cable_end character varying(1),
    color character varying(6) NOT NULL,
    status character varying(50) NOT NULL,
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint,
    owner_id bigint,
    cable_connector smallint,
    cable_positions smallint[],
    CONSTRAINT dcim_poweroutlet_cable_connector_check CHECK ((cable_connector >= 0))
);


--
-- Name: dcim_poweroutlet_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_poweroutlet ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_poweroutlet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_poweroutlettemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_poweroutlettemplate (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(50),
    feed_leg character varying(50),
    device_type_id bigint,
    power_port_id bigint,
    module_type_id bigint,
    color character varying(6) NOT NULL
);


--
-- Name: dcim_poweroutlettemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_poweroutlettemplate ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_poweroutlettemplate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_powerpanel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_powerpanel (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    location_id bigint,
    site_id bigint NOT NULL,
    comments text NOT NULL,
    description character varying(200) NOT NULL,
    owner_id bigint
);


--
-- Name: dcim_powerpanel_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_powerpanel ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_powerpanel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_powerport; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_powerport (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    mark_connected boolean NOT NULL,
    type character varying(50),
    maximum_draw integer,
    allocated_draw integer,
    _path_id bigint,
    cable_id bigint,
    device_id bigint NOT NULL,
    module_id bigint,
    cable_end character varying(1),
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint,
    owner_id bigint,
    cable_connector smallint,
    cable_positions smallint[],
    CONSTRAINT dcim_powerport_allocated_draw_check CHECK ((allocated_draw >= 0)),
    CONSTRAINT dcim_powerport_cable_connector_check CHECK ((cable_connector >= 0)),
    CONSTRAINT dcim_powerport_maximum_draw_check CHECK ((maximum_draw >= 0))
);


--
-- Name: dcim_powerport_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_powerport ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_powerport_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_powerporttemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_powerporttemplate (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(50),
    maximum_draw integer,
    allocated_draw integer,
    device_type_id bigint,
    module_type_id bigint,
    CONSTRAINT dcim_powerporttemplate_allocated_draw_check CHECK ((allocated_draw >= 0)),
    CONSTRAINT dcim_powerporttemplate_maximum_draw_check CHECK ((maximum_draw >= 0))
);


--
-- Name: dcim_powerporttemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_powerporttemplate ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_powerporttemplate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_rack; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_rack (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    facility_id character varying(50),
    status character varying(50) NOT NULL,
    serial character varying(50) NOT NULL,
    asset_tag character varying(50),
    form_factor character varying(50),
    width smallint NOT NULL,
    u_height smallint NOT NULL,
    desc_units boolean NOT NULL,
    outer_width smallint,
    outer_depth smallint,
    outer_unit character varying(50),
    comments text NOT NULL,
    location_id bigint,
    role_id bigint,
    site_id bigint NOT NULL,
    tenant_id bigint,
    weight numeric(8,2),
    max_weight integer,
    weight_unit character varying(50),
    _abs_weight bigint,
    _abs_max_weight bigint,
    mounting_depth smallint,
    description character varying(200) NOT NULL,
    starting_unit smallint NOT NULL,
    rack_type_id bigint,
    airflow character varying(50),
    outer_height smallint,
    owner_id bigint,
    group_id bigint,
    cooling_capability character varying(50),
    cooling_capacity numeric(10,2),
    CONSTRAINT dcim_rack__abs_max_weight_check CHECK ((_abs_max_weight >= 0)),
    CONSTRAINT dcim_rack__abs_weight_check CHECK ((_abs_weight >= 0)),
    CONSTRAINT dcim_rack_max_weight_check CHECK ((max_weight >= 0)),
    CONSTRAINT dcim_rack_mounting_depth_check CHECK ((mounting_depth >= 0)),
    CONSTRAINT dcim_rack_outer_depth_check CHECK ((outer_depth >= 0)),
    CONSTRAINT dcim_rack_outer_height_check CHECK ((outer_height >= 0)),
    CONSTRAINT dcim_rack_outer_width_check CHECK ((outer_width >= 0)),
    CONSTRAINT dcim_rack_starting_unit_check CHECK ((starting_unit >= 0)),
    CONSTRAINT dcim_rack_u_height_check CHECK ((u_height >= 0)),
    CONSTRAINT dcim_rack_width_check CHECK ((width >= 0))
);


--
-- Name: dcim_rack_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_rack ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_rack_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_rackgroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_rackgroup (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    owner_id bigint
);


--
-- Name: dcim_rackgroup_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_rackgroup ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_rackgroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_rackreservation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_rackreservation (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    units smallint[] NOT NULL,
    description character varying(200) NOT NULL,
    rack_id bigint NOT NULL,
    tenant_id bigint,
    user_id bigint NOT NULL,
    comments text NOT NULL,
    status character varying(50) NOT NULL,
    owner_id bigint
);


--
-- Name: dcim_rackreservation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_rackreservation ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_rackreservation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_rackrole; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_rackrole (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    color character varying(6) NOT NULL,
    description character varying(200) NOT NULL,
    owner_id bigint,
    comments text NOT NULL
);


--
-- Name: dcim_rackrole_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_rackrole ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_rackrole_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_racktype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_racktype (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    weight numeric(8,2),
    weight_unit character varying(50),
    _abs_weight bigint,
    manufacturer_id bigint NOT NULL,
    model character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    form_factor character varying(50) NOT NULL,
    width smallint NOT NULL,
    u_height smallint NOT NULL,
    starting_unit smallint NOT NULL,
    desc_units boolean NOT NULL,
    outer_width smallint,
    outer_depth smallint,
    outer_unit character varying(50),
    max_weight integer,
    _abs_max_weight bigint,
    mounting_depth smallint,
    outer_height smallint,
    owner_id bigint,
    rack_count bigint NOT NULL,
    cooling_capability character varying(50),
    cooling_capacity numeric(10,2),
    CONSTRAINT dcim_racktype__abs_max_weight_check CHECK ((_abs_max_weight >= 0)),
    CONSTRAINT dcim_racktype__abs_weight_check CHECK ((_abs_weight >= 0)),
    CONSTRAINT dcim_racktype_max_weight_check CHECK ((max_weight >= 0)),
    CONSTRAINT dcim_racktype_mounting_depth_check CHECK ((mounting_depth >= 0)),
    CONSTRAINT dcim_racktype_outer_depth_check CHECK ((outer_depth >= 0)),
    CONSTRAINT dcim_racktype_outer_height_check CHECK ((outer_height >= 0)),
    CONSTRAINT dcim_racktype_outer_width_check CHECK ((outer_width >= 0)),
    CONSTRAINT dcim_racktype_starting_unit_check CHECK ((starting_unit >= 0)),
    CONSTRAINT dcim_racktype_u_height_check CHECK ((u_height >= 0)),
    CONSTRAINT dcim_racktype_width_check CHECK ((width >= 0))
);


--
-- Name: dcim_racktype_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_racktype ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_racktype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_rearport; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_rearport (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    mark_connected boolean NOT NULL,
    type character varying(50) NOT NULL,
    positions smallint NOT NULL,
    cable_id bigint,
    device_id bigint NOT NULL,
    color character varying(6) NOT NULL,
    module_id bigint,
    cable_end character varying(1),
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint,
    owner_id bigint,
    cable_connector smallint,
    cable_positions smallint[],
    CONSTRAINT dcim_rearport_cable_connector_check CHECK ((cable_connector >= 0)),
    CONSTRAINT dcim_rearport_positions_check CHECK ((positions >= 0))
);


--
-- Name: dcim_rearport_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_rearport ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_rearport_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_rearporttemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_rearporttemplate (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(50) NOT NULL,
    positions smallint NOT NULL,
    device_type_id bigint,
    color character varying(6) NOT NULL,
    module_type_id bigint,
    CONSTRAINT dcim_rearporttemplate_positions_check CHECK ((positions >= 0))
);


--
-- Name: dcim_rearporttemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_rearporttemplate ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_rearporttemplate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_region; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_region (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    parent_id bigint,
    comments text NOT NULL,
    owner_id bigint,
    path public.ltree NOT NULL,
    sort_path text NOT NULL
);


--
-- Name: dcim_region_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_region ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_region_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_site; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_site (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    slug character varying(100) NOT NULL,
    status character varying(50) NOT NULL,
    facility character varying(50) NOT NULL,
    time_zone character varying(63),
    description character varying(200) NOT NULL,
    physical_address character varying(200) NOT NULL,
    shipping_address character varying(200) NOT NULL,
    latitude numeric(8,6),
    longitude numeric(9,6),
    comments text NOT NULL,
    group_id bigint,
    region_id bigint,
    tenant_id bigint,
    owner_id bigint
);


--
-- Name: dcim_site_asns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_site_asns (
    id bigint NOT NULL,
    site_id bigint NOT NULL,
    asn_id bigint NOT NULL
);


--
-- Name: dcim_site_asns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_site_asns ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_site_asns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_site_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_site ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_sitegroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_sitegroup (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    parent_id bigint,
    comments text NOT NULL,
    owner_id bigint,
    path public.ltree NOT NULL,
    sort_path text NOT NULL
);


--
-- Name: dcim_sitegroup_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_sitegroup ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_sitegroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_virtualchassis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_virtualchassis (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    domain character varying(30) NOT NULL,
    master_id bigint,
    comments text NOT NULL,
    description character varying(200) NOT NULL,
    member_count bigint NOT NULL,
    owner_id bigint
);


--
-- Name: dcim_virtualchassis_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_virtualchassis ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_virtualchassis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dcim_virtualdevicecontext; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dcim_virtualdevicecontext (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    status character varying(50) NOT NULL,
    identifier smallint,
    comments text NOT NULL,
    device_id bigint,
    primary_ip4_id bigint,
    primary_ip6_id bigint,
    tenant_id bigint,
    owner_id bigint,
    CONSTRAINT dcim_virtualdevicecontext_identifier_check CHECK ((identifier >= 0))
);


--
-- Name: dcim_virtualdevicecontext_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dcim_virtualdevicecontext ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dcim_virtualdevicecontext_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


--
-- Name: extras_bookmark; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_bookmark (
    id bigint NOT NULL,
    created timestamp with time zone NOT NULL,
    object_id bigint NOT NULL,
    object_type_id integer NOT NULL,
    user_id bigint NOT NULL,
    CONSTRAINT extras_bookmark_object_id_check CHECK ((object_id >= 0))
);


--
-- Name: extras_bookmark_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_bookmark ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_bookmark_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_cachedvalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_cachedvalue (
    id uuid NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    object_id bigint NOT NULL,
    field character varying(200) NOT NULL,
    type character varying(30) NOT NULL,
    value text NOT NULL,
    weight smallint NOT NULL,
    object_type_id integer NOT NULL,
    CONSTRAINT extras_cachedvalue_object_id_check CHECK ((object_id >= 0)),
    CONSTRAINT extras_cachedvalue_weight_check CHECK ((weight >= 0))
);


--
-- Name: extras_configcontext; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_configcontext (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    weight smallint NOT NULL,
    description character varying(200) NOT NULL,
    is_active boolean NOT NULL,
    data jsonb NOT NULL,
    data_file_id bigint,
    data_path character varying(1000) NOT NULL,
    data_source_id bigint,
    auto_sync_enabled boolean NOT NULL,
    data_synced timestamp with time zone,
    profile_id bigint,
    owner_id bigint,
    CONSTRAINT extras_configcontext_weight_check CHECK ((weight >= 0))
);


--
-- Name: extras_configcontext_cluster_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_configcontext_cluster_groups (
    id bigint NOT NULL,
    configcontext_id bigint NOT NULL,
    clustergroup_id bigint NOT NULL
);


--
-- Name: extras_configcontext_cluster_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_configcontext_cluster_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_configcontext_cluster_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_configcontext_cluster_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_configcontext_cluster_types (
    id bigint NOT NULL,
    configcontext_id bigint NOT NULL,
    clustertype_id bigint NOT NULL
);


--
-- Name: extras_configcontext_cluster_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_configcontext_cluster_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_configcontext_cluster_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_configcontext_clusters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_configcontext_clusters (
    id bigint NOT NULL,
    configcontext_id bigint NOT NULL,
    cluster_id bigint NOT NULL
);


--
-- Name: extras_configcontext_clusters_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_configcontext_clusters ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_configcontext_clusters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_configcontext_device_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_configcontext_device_types (
    id bigint NOT NULL,
    configcontext_id bigint NOT NULL,
    devicetype_id bigint NOT NULL
);


--
-- Name: extras_configcontext_device_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_configcontext_device_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_configcontext_device_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_configcontext_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_configcontext ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_configcontext_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_configcontext_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_configcontext_locations (
    id bigint NOT NULL,
    configcontext_id bigint NOT NULL,
    location_id bigint NOT NULL
);


--
-- Name: extras_configcontext_locations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_configcontext_locations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_configcontext_locations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_configcontext_platforms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_configcontext_platforms (
    id bigint NOT NULL,
    configcontext_id bigint NOT NULL,
    platform_id bigint NOT NULL
);


--
-- Name: extras_configcontext_platforms_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_configcontext_platforms ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_configcontext_platforms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_configcontext_regions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_configcontext_regions (
    id bigint NOT NULL,
    configcontext_id bigint NOT NULL,
    region_id bigint NOT NULL
);


--
-- Name: extras_configcontext_regions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_configcontext_regions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_configcontext_regions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_configcontext_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_configcontext_roles (
    id bigint NOT NULL,
    configcontext_id bigint NOT NULL,
    devicerole_id bigint NOT NULL
);


--
-- Name: extras_configcontext_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_configcontext_roles ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_configcontext_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_configcontext_site_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_configcontext_site_groups (
    id bigint NOT NULL,
    configcontext_id bigint NOT NULL,
    sitegroup_id bigint NOT NULL
);


--
-- Name: extras_configcontext_site_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_configcontext_site_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_configcontext_site_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_configcontext_sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_configcontext_sites (
    id bigint NOT NULL,
    configcontext_id bigint NOT NULL,
    site_id bigint NOT NULL
);


--
-- Name: extras_configcontext_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_configcontext_sites ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_configcontext_sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_configcontext_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_configcontext_tags (
    id bigint NOT NULL,
    configcontext_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


--
-- Name: extras_configcontext_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_configcontext_tags ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_configcontext_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_configcontext_tenant_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_configcontext_tenant_groups (
    id bigint NOT NULL,
    configcontext_id bigint NOT NULL,
    tenantgroup_id bigint NOT NULL
);


--
-- Name: extras_configcontext_tenant_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_configcontext_tenant_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_configcontext_tenant_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_configcontext_tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_configcontext_tenants (
    id bigint NOT NULL,
    configcontext_id bigint NOT NULL,
    tenant_id bigint NOT NULL
);


--
-- Name: extras_configcontext_tenants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_configcontext_tenants ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_configcontext_tenants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_configcontextprofile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_configcontextprofile (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    data_path character varying(1000) NOT NULL,
    auto_sync_enabled boolean NOT NULL,
    data_synced timestamp with time zone,
    comments text NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    schema jsonb,
    data_file_id bigint,
    data_source_id bigint,
    owner_id bigint
);


--
-- Name: extras_configcontextprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_configcontextprofile ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_configcontextprofile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_configrevision_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_configrevision ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_configrevision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_configtemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_configtemplate (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    data_path character varying(1000) NOT NULL,
    data_synced timestamp with time zone,
    name character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    template_code text NOT NULL,
    environment_params jsonb,
    data_file_id bigint,
    data_source_id bigint,
    auto_sync_enabled boolean NOT NULL,
    as_attachment boolean NOT NULL,
    file_extension character varying(15) NOT NULL,
    file_name character varying(200) NOT NULL,
    mime_type character varying(50) NOT NULL,
    owner_id bigint,
    debug boolean NOT NULL
);


--
-- Name: extras_configtemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_configtemplate ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_configtemplate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_customfield; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_customfield (
    id bigint NOT NULL,
    type character varying(50) NOT NULL,
    name character varying(50) NOT NULL,
    label character varying(50) NOT NULL,
    description character varying(200) NOT NULL,
    required boolean NOT NULL,
    filter_logic character varying(50) NOT NULL,
    "default" jsonb,
    weight smallint NOT NULL,
    validation_minimum numeric(16,4),
    validation_maximum numeric(16,4),
    validation_regex character varying(500) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    related_object_type_id integer,
    group_name character varying(50) NOT NULL,
    search_weight smallint NOT NULL,
    is_cloneable boolean NOT NULL,
    choice_set_id bigint,
    ui_editable character varying(50) NOT NULL,
    ui_visible character varying(50) NOT NULL,
    comments text NOT NULL,
    "unique" boolean NOT NULL,
    related_object_filter jsonb,
    owner_id bigint,
    validation_schema jsonb,
    nulls_first boolean NOT NULL,
    status character varying(50) NOT NULL,
    CONSTRAINT extras_customfield_search_weight_check CHECK ((search_weight >= 0)),
    CONSTRAINT extras_customfield_weight_check CHECK ((weight >= 0))
);


--
-- Name: extras_customfield_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_customfield ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_customfield_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_customfield_object_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_customfield_object_types (
    id bigint CONSTRAINT extras_customfield_content_types_id_not_null NOT NULL,
    customfield_id bigint CONSTRAINT extras_customfield_content_types_customfield_id_not_null NOT NULL,
    contenttype_id integer CONSTRAINT extras_customfield_content_types_contenttype_id_not_null NOT NULL
);


--
-- Name: extras_customfield_object_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_customfield_object_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_customfield_object_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_customfieldchoiceset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_customfieldchoiceset (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    name character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    base_choices character varying(50),
    extra_choices character varying(100)[],
    order_alphabetically boolean NOT NULL,
    owner_id bigint,
    choice_colors jsonb NOT NULL
);


--
-- Name: extras_customfieldchoiceset_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_customfieldchoiceset ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_customfieldchoiceset_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_customlink; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_customlink (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    link_text text NOT NULL,
    link_url text NOT NULL,
    weight smallint NOT NULL,
    group_name character varying(50) NOT NULL,
    button_class character varying(30) NOT NULL,
    new_window boolean NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    enabled boolean NOT NULL,
    owner_id bigint,
    CONSTRAINT extras_customlink_weight_check CHECK ((weight >= 0))
);


--
-- Name: extras_customlink_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_customlink ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_customlink_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_customlink_object_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_customlink_object_types (
    id bigint CONSTRAINT extras_customlink_content_types_id_not_null NOT NULL,
    customlink_id bigint CONSTRAINT extras_customlink_content_types_customlink_id_not_null NOT NULL,
    contenttype_id integer CONSTRAINT extras_customlink_content_types_contenttype_id_not_null NOT NULL
);


--
-- Name: extras_customlink_object_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_customlink_object_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_customlink_object_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_dashboard; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_dashboard (
    id bigint NOT NULL,
    layout jsonb NOT NULL,
    config jsonb NOT NULL,
    user_id bigint NOT NULL
);


--
-- Name: extras_dashboard_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_dashboard ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_dashboard_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_eventrule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_eventrule (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(150) NOT NULL,
    description character varying(200) NOT NULL,
    enabled boolean NOT NULL,
    conditions jsonb,
    action_type character varying(100) NOT NULL,
    action_object_id bigint,
    action_data jsonb,
    comments text NOT NULL,
    action_object_type_id integer,
    event_types character varying(50)[] NOT NULL,
    owner_id bigint,
    CONSTRAINT extras_eventrule_action_object_id_check CHECK ((action_object_id >= 0))
);


--
-- Name: extras_eventrule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_eventrule ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_eventrule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_eventrule_object_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_eventrule_object_types (
    id bigint CONSTRAINT extras_eventrule_content_types_id_not_null NOT NULL,
    eventrule_id bigint CONSTRAINT extras_eventrule_content_types_eventrule_id_not_null NOT NULL,
    contenttype_id integer CONSTRAINT extras_eventrule_content_types_contenttype_id_not_null NOT NULL
);


--
-- Name: extras_eventrule_object_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_eventrule_object_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_eventrule_object_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_exporttemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_exporttemplate (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    template_code text NOT NULL,
    mime_type character varying(50) NOT NULL,
    file_extension character varying(15) NOT NULL,
    as_attachment boolean NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    data_file_id bigint,
    data_path character varying(1000) NOT NULL,
    data_source_id bigint,
    auto_sync_enabled boolean NOT NULL,
    data_synced timestamp with time zone,
    file_name character varying(200) NOT NULL,
    environment_params jsonb,
    owner_id bigint
);


--
-- Name: extras_exporttemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_exporttemplate ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_exporttemplate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_exporttemplate_object_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_exporttemplate_object_types (
    id bigint CONSTRAINT extras_exporttemplate_content_types_id_not_null NOT NULL,
    exporttemplate_id bigint CONSTRAINT extras_exporttemplate_content_types_exporttemplate_id_not_null NOT NULL,
    contenttype_id integer CONSTRAINT extras_exporttemplate_content_types_contenttype_id_not_null NOT NULL
);


--
-- Name: extras_exporttemplate_object_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_exporttemplate_object_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_exporttemplate_object_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_imageattachment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_imageattachment (
    id bigint NOT NULL,
    object_id bigint NOT NULL,
    image character varying(100) NOT NULL,
    image_height smallint NOT NULL,
    image_width smallint NOT NULL,
    name character varying(50) NOT NULL,
    created timestamp with time zone,
    object_type_id integer CONSTRAINT extras_imageattachment_content_type_id_not_null NOT NULL,
    last_updated timestamp with time zone,
    description character varying(200) NOT NULL,
    image_size bigint,
    CONSTRAINT extras_imageattachment_image_height_check CHECK ((image_height >= 0)),
    CONSTRAINT extras_imageattachment_image_size_check CHECK ((image_size >= 0)),
    CONSTRAINT extras_imageattachment_image_width_check CHECK ((image_width >= 0)),
    CONSTRAINT extras_imageattachment_object_id_check CHECK ((object_id >= 0))
);


--
-- Name: extras_imageattachment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_imageattachment ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_imageattachment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_journalentry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_journalentry (
    last_updated timestamp with time zone,
    id bigint NOT NULL,
    assigned_object_id bigint NOT NULL,
    created timestamp with time zone,
    kind character varying(30) NOT NULL,
    comments text NOT NULL,
    assigned_object_type_id integer NOT NULL,
    created_by_id bigint,
    custom_field_data jsonb NOT NULL,
    CONSTRAINT extras_journalentry_assigned_object_id_check CHECK ((assigned_object_id >= 0))
);


--
-- Name: extras_journalentry_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_journalentry ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_journalentry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_notification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_notification (
    id bigint NOT NULL,
    created timestamp with time zone NOT NULL,
    read timestamp with time zone,
    object_id bigint NOT NULL,
    event_type character varying(50) NOT NULL,
    object_type_id integer NOT NULL,
    object_repr character varying(200) NOT NULL,
    user_id bigint NOT NULL,
    CONSTRAINT extras_notification_object_id_check CHECK ((object_id >= 0))
);


--
-- Name: extras_notification_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_notification ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_notification_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_notificationgroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_notificationgroup (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    name character varying(100) NOT NULL,
    description character varying(200) NOT NULL
);


--
-- Name: extras_notificationgroup_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_notificationgroup_groups (
    id bigint NOT NULL,
    notificationgroup_id bigint NOT NULL,
    group_id bigint NOT NULL
);


--
-- Name: extras_notificationgroup_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_notificationgroup_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_notificationgroup_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_notificationgroup_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_notificationgroup ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_notificationgroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_notificationgroup_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_notificationgroup_users (
    id bigint NOT NULL,
    notificationgroup_id bigint NOT NULL,
    user_id bigint NOT NULL
);


--
-- Name: extras_notificationgroup_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_notificationgroup_users ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_notificationgroup_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_savedfilter; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_savedfilter (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    weight smallint NOT NULL,
    enabled boolean NOT NULL,
    shared boolean NOT NULL,
    parameters jsonb NOT NULL,
    user_id bigint,
    owner_id bigint,
    CONSTRAINT extras_savedfilter_weight_check CHECK ((weight >= 0))
);


--
-- Name: extras_savedfilter_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_savedfilter ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_savedfilter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_savedfilter_object_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_savedfilter_object_types (
    id bigint CONSTRAINT extras_savedfilter_content_types_id_not_null NOT NULL,
    savedfilter_id bigint CONSTRAINT extras_savedfilter_content_types_savedfilter_id_not_null NOT NULL,
    contenttype_id integer CONSTRAINT extras_savedfilter_content_types_contenttype_id_not_null NOT NULL
);


--
-- Name: extras_savedfilter_object_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_savedfilter_object_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_savedfilter_object_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_script; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_script (
    id bigint NOT NULL,
    name character varying(79) NOT NULL,
    module_id bigint NOT NULL,
    is_executable boolean NOT NULL
);


--
-- Name: extras_script_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_script ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_script_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_subscription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_subscription (
    id bigint NOT NULL,
    created timestamp with time zone NOT NULL,
    object_id bigint NOT NULL,
    object_type_id integer NOT NULL,
    user_id bigint NOT NULL,
    CONSTRAINT extras_subscription_object_id_check CHECK ((object_id >= 0))
);


--
-- Name: extras_subscription_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_subscription ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_tableconfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_tableconfig (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    "table" character varying(100) NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    weight smallint NOT NULL,
    enabled boolean NOT NULL,
    shared boolean NOT NULL,
    columns character varying(100)[] NOT NULL,
    ordering character varying(100)[],
    object_type_id integer NOT NULL,
    user_id bigint,
    CONSTRAINT extras_tableconfig_weight_check CHECK ((weight >= 0))
);


--
-- Name: extras_tableconfig_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_tableconfig ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_tableconfig_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_tag (
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint NOT NULL,
    color character varying(6) NOT NULL,
    description character varying(200) NOT NULL,
    weight smallint NOT NULL,
    owner_id bigint,
    CONSTRAINT extras_tag_weight_check CHECK ((weight >= 0))
);


--
-- Name: extras_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_tag ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_tag_object_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_tag_object_types (
    id bigint NOT NULL,
    tag_id bigint NOT NULL,
    contenttype_id integer NOT NULL
);


--
-- Name: extras_tag_object_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_tag_object_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_tag_object_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_taggeditem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_taggeditem (
    object_id bigint NOT NULL,
    id bigint NOT NULL,
    content_type_id integer NOT NULL,
    tag_id bigint NOT NULL,
    CONSTRAINT extras_taggeditem_object_id_31b2aa77_check CHECK ((object_id >= 0))
);


--
-- Name: extras_taggeditem_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_taggeditem ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_taggeditem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_webhook; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.extras_webhook (
    id bigint NOT NULL,
    name character varying(150) NOT NULL,
    payload_url character varying(500) NOT NULL,
    http_method character varying(30) NOT NULL,
    http_content_type character varying(100) NOT NULL,
    additional_headers text NOT NULL,
    body_template text NOT NULL,
    secret character varying(255) NOT NULL,
    ssl_verification boolean NOT NULL,
    ca_file_path character varying(4096),
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    owner_id bigint,
    timeout smallint,
    CONSTRAINT extras_webhook_timeout_check CHECK ((timeout >= 0))
);


--
-- Name: extras_webhook_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.extras_webhook ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.extras_webhook_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_aggregate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_aggregate (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    prefix cidr NOT NULL,
    date_added date,
    description character varying(200) NOT NULL,
    rir_id bigint NOT NULL,
    tenant_id bigint,
    comments text NOT NULL,
    owner_id bigint
);


--
-- Name: ipam_aggregate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_aggregate ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_aggregate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_asn; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_asn (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    asn bigint NOT NULL,
    description character varying(200) NOT NULL,
    rir_id bigint NOT NULL,
    tenant_id bigint,
    comments text NOT NULL,
    owner_id bigint,
    role_id bigint
);


--
-- Name: ipam_asn_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_asn ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_asn_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_asnrange; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_asnrange (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    slug character varying(100) NOT NULL,
    start bigint NOT NULL,
    "end" bigint NOT NULL,
    rir_id bigint NOT NULL,
    tenant_id bigint,
    owner_id bigint,
    comments text NOT NULL
);


--
-- Name: ipam_asnrange_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_asnrange ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_asnrange_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_fhrpgroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_fhrpgroup (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    group_id smallint NOT NULL,
    protocol character varying(50) NOT NULL,
    auth_type character varying(50),
    auth_key character varying(255) NOT NULL,
    description character varying(200) NOT NULL,
    name character varying(100) NOT NULL,
    comments text NOT NULL,
    owner_id bigint,
    CONSTRAINT ipam_fhrpgroup_group_id_check CHECK ((group_id >= 0))
);


--
-- Name: ipam_fhrpgroup_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_fhrpgroup ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_fhrpgroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_fhrpgroupassignment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_fhrpgroupassignment (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint NOT NULL,
    interface_id bigint NOT NULL,
    priority smallint NOT NULL,
    group_id bigint NOT NULL,
    interface_type_id integer NOT NULL,
    CONSTRAINT ipam_fhrpgroupassignment_interface_id_check CHECK ((interface_id >= 0)),
    CONSTRAINT ipam_fhrpgroupassignment_priority_check CHECK ((priority >= 0))
);


--
-- Name: ipam_fhrpgroupassignment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_fhrpgroupassignment ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_fhrpgroupassignment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_ipaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_ipaddress (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    address inet NOT NULL,
    status character varying(50) NOT NULL,
    role character varying(50),
    assigned_object_id bigint,
    dns_name character varying(255) NOT NULL,
    description character varying(200) NOT NULL,
    assigned_object_type_id integer,
    nat_inside_id bigint,
    tenant_id bigint,
    vrf_id bigint,
    comments text NOT NULL,
    owner_id bigint,
    CONSTRAINT ipam_ipaddress_assigned_object_id_check CHECK ((assigned_object_id >= 0))
);


--
-- Name: ipam_ipaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_ipaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_ipaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_iprange; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_iprange (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    start_address inet NOT NULL,
    end_address inet NOT NULL,
    size integer NOT NULL,
    status character varying(50) NOT NULL,
    description character varying(200) NOT NULL,
    role_id bigint,
    tenant_id bigint,
    vrf_id bigint,
    comments text NOT NULL,
    mark_utilized boolean NOT NULL,
    mark_populated boolean NOT NULL,
    owner_id bigint,
    CONSTRAINT ipam_iprange_size_check CHECK ((size >= 0))
);


--
-- Name: ipam_iprange_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_iprange ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_iprange_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_prefix; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_prefix (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    prefix cidr NOT NULL,
    status character varying(50) NOT NULL,
    is_pool boolean NOT NULL,
    description character varying(200) NOT NULL,
    role_id bigint,
    tenant_id bigint,
    vlan_id bigint,
    vrf_id bigint,
    _children bigint NOT NULL,
    _depth smallint NOT NULL,
    mark_utilized boolean NOT NULL,
    comments text NOT NULL,
    scope_id bigint,
    scope_type_id integer,
    _location_id bigint,
    _region_id bigint,
    _site_id bigint,
    _site_group_id bigint,
    owner_id bigint,
    CONSTRAINT ipam_prefix__children_check CHECK ((_children >= 0)),
    CONSTRAINT ipam_prefix__depth_check CHECK ((_depth >= 0)),
    CONSTRAINT ipam_prefix_scope_id_check CHECK ((scope_id >= 0))
);


--
-- Name: ipam_prefix_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_prefix ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_prefix_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_rir; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_rir (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    is_private boolean NOT NULL,
    description character varying(200) NOT NULL,
    owner_id bigint,
    comments text NOT NULL
);


--
-- Name: ipam_rir_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_rir ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_rir_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_role (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    weight smallint NOT NULL,
    description character varying(200) NOT NULL,
    owner_id bigint,
    comments text NOT NULL,
    CONSTRAINT ipam_role_weight_check CHECK ((weight >= 0))
);


--
-- Name: ipam_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_role ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_routetarget; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_routetarget (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(21) NOT NULL COLLATE public.natural_sort,
    description character varying(200) NOT NULL,
    tenant_id bigint,
    comments text NOT NULL,
    owner_id bigint
);


--
-- Name: ipam_routetarget_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_routetarget ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_routetarget_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_service; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_service (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    parent_object_id bigint NOT NULL,
    parent_object_type_id integer NOT NULL,
    owner_id bigint,
    port_mappings character varying(63)[] NOT NULL,
    CONSTRAINT ipam_service_parent_object_id_check CHECK ((parent_object_id >= 0))
);


--
-- Name: ipam_service_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_service ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_service_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_service_ipaddresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_service_ipaddresses (
    id bigint NOT NULL,
    service_id bigint NOT NULL,
    ipaddress_id bigint NOT NULL
);


--
-- Name: ipam_service_ipaddresses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_service_ipaddresses ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_service_ipaddresses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_servicetemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_servicetemplate (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    name character varying(100) NOT NULL,
    comments text NOT NULL,
    owner_id bigint,
    port_mappings character varying(63)[] NOT NULL
);


--
-- Name: ipam_servicetemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_servicetemplate ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_servicetemplate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_vlan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_vlan (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    vid smallint NOT NULL,
    name character varying(64) NOT NULL,
    status character varying(50) NOT NULL,
    description character varying(200) NOT NULL,
    group_id bigint,
    role_id bigint,
    site_id bigint,
    tenant_id bigint,
    comments text NOT NULL,
    qinq_role character varying(50),
    qinq_svlan_id bigint,
    owner_id bigint,
    CONSTRAINT ipam_vlan_vid_check CHECK ((vid >= 0))
);


--
-- Name: ipam_vlan_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_vlan ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_vlan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_vlangroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_vlangroup (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    slug character varying(100) NOT NULL,
    scope_id bigint,
    description character varying(200) NOT NULL,
    scope_type_id integer,
    vid_ranges int4range[] NOT NULL,
    total_vlan_ids bigint CONSTRAINT ipam_vlangroup__total_vlan_ids_not_null NOT NULL,
    tenant_id bigint,
    owner_id bigint,
    comments text NOT NULL,
    CONSTRAINT ipam_vlangroup__total_vlan_ids_check CHECK ((total_vlan_ids >= 0)),
    CONSTRAINT ipam_vlangroup_scope_id_check CHECK ((scope_id >= 0))
);


--
-- Name: ipam_vlangroup_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_vlangroup ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_vlangroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_vlantranslationpolicy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_vlantranslationpolicy (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    owner_id bigint
);


--
-- Name: ipam_vlantranslationpolicy_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_vlantranslationpolicy ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_vlantranslationpolicy_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_vlantranslationrule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_vlantranslationrule (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    local_vid smallint NOT NULL,
    remote_vid smallint NOT NULL,
    policy_id bigint NOT NULL,
    description character varying(200) NOT NULL,
    CONSTRAINT ipam_vlantranslationrule_local_vid_check CHECK ((local_vid >= 0)),
    CONSTRAINT ipam_vlantranslationrule_remote_vid_check CHECK ((remote_vid >= 0))
);


--
-- Name: ipam_vlantranslationrule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_vlantranslationrule ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_vlantranslationrule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_vrf; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_vrf (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    rd character varying(21),
    enforce_unique boolean NOT NULL,
    description character varying(200) NOT NULL,
    tenant_id bigint,
    comments text NOT NULL,
    owner_id bigint
);


--
-- Name: ipam_vrf_export_targets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_vrf_export_targets (
    id bigint NOT NULL,
    vrf_id bigint NOT NULL,
    routetarget_id bigint NOT NULL
);


--
-- Name: ipam_vrf_export_targets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_vrf_export_targets ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_vrf_export_targets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_vrf_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_vrf ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_vrf_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ipam_vrf_import_targets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ipam_vrf_import_targets (
    id bigint NOT NULL,
    vrf_id bigint NOT NULL,
    routetarget_id bigint NOT NULL
);


--
-- Name: ipam_vrf_import_targets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ipam_vrf_import_targets ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ipam_vrf_import_targets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: social_auth_association; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_auth_association (
    id bigint NOT NULL,
    server_url character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    secret character varying(255) NOT NULL,
    issued integer NOT NULL,
    lifetime integer NOT NULL,
    assoc_type character varying(64) NOT NULL
);


--
-- Name: social_auth_association_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.social_auth_association ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.social_auth_association_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: social_auth_code; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_auth_code (
    id bigint NOT NULL,
    email character varying(254) NOT NULL,
    code character varying(32) NOT NULL,
    verified boolean NOT NULL,
    "timestamp" timestamp with time zone NOT NULL
);


--
-- Name: social_auth_code_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.social_auth_code ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.social_auth_code_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: social_auth_nonce; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_auth_nonce (
    id bigint NOT NULL,
    server_url character varying(255) NOT NULL,
    "timestamp" integer NOT NULL,
    salt character varying(65) NOT NULL
);


--
-- Name: social_auth_nonce_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.social_auth_nonce ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.social_auth_nonce_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: social_auth_partial; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_auth_partial (
    id bigint NOT NULL,
    token character varying(32) NOT NULL,
    next_step smallint NOT NULL,
    backend character varying(32) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    data jsonb CONSTRAINT social_auth_partial_data_new_not_null NOT NULL,
    CONSTRAINT social_auth_partial_next_step_check CHECK ((next_step >= 0))
);


--
-- Name: social_auth_partial_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.social_auth_partial ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.social_auth_partial_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: social_auth_usersocialauth; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_auth_usersocialauth (
    id bigint NOT NULL,
    provider character varying(32) NOT NULL,
    uid character varying(255) NOT NULL,
    user_id bigint NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    extra_data jsonb CONSTRAINT social_auth_usersocialauth_extra_data_new_not_null NOT NULL,
    CONSTRAINT user_social_auth_uid_required CHECK ((NOT ((uid)::text = ''::text)))
);


--
-- Name: social_auth_usersocialauth_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.social_auth_usersocialauth ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.social_auth_usersocialauth_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: taggit_tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taggit_tag (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL
);


--
-- Name: taggit_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.taggit_tag ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.taggit_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: taggit_taggeditem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taggit_taggeditem (
    id integer NOT NULL,
    object_id integer NOT NULL,
    content_type_id integer NOT NULL,
    tag_id integer NOT NULL
);


--
-- Name: taggit_taggeditem_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.taggit_taggeditem ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.taggit_taggeditem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tenancy_contact; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenancy_contact (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    title character varying(100) NOT NULL,
    phone character varying(50) NOT NULL,
    email character varying(254) NOT NULL,
    address character varying(200) NOT NULL,
    comments text NOT NULL,
    link character varying(200) NOT NULL,
    description character varying(200) NOT NULL,
    owner_id bigint
);


--
-- Name: tenancy_contact_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenancy_contact_groups (
    id bigint CONSTRAINT tenancy_contactgroupmembership_id_not_null NOT NULL,
    contact_id bigint CONSTRAINT tenancy_contactgroupmembership_contact_id_not_null NOT NULL,
    contactgroup_id bigint CONSTRAINT tenancy_contactgroupmembership_group_id_not_null NOT NULL
);


--
-- Name: tenancy_contact_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.tenancy_contact_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tenancy_contact_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tenancy_contact_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.tenancy_contact ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tenancy_contact_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tenancy_contactassignment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenancy_contactassignment (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    object_id bigint NOT NULL,
    priority character varying(50),
    contact_id bigint NOT NULL,
    object_type_id integer CONSTRAINT tenancy_contactassignment_content_type_id_not_null NOT NULL,
    role_id bigint NOT NULL,
    custom_field_data jsonb NOT NULL,
    CONSTRAINT tenancy_contactassignment_object_id_check CHECK ((object_id >= 0))
);


--
-- Name: tenancy_contactassignment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.tenancy_contactassignment ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tenancy_contactassignment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tenancy_contactgroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenancy_contactgroup (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    parent_id bigint,
    comments text NOT NULL,
    owner_id bigint,
    path public.ltree NOT NULL,
    sort_path text NOT NULL
);


--
-- Name: tenancy_contactgroup_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.tenancy_contactgroup ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tenancy_contactgroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tenancy_contactrole; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenancy_contactrole (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    owner_id bigint,
    comments text NOT NULL
);


--
-- Name: tenancy_contactrole_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.tenancy_contactrole ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tenancy_contactrole_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tenancy_tenant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenancy_tenant (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    group_id bigint,
    owner_id bigint
);


--
-- Name: tenancy_tenant_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.tenancy_tenant ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tenancy_tenant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tenancy_tenantgroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenancy_tenantgroup (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    parent_id bigint,
    comments text NOT NULL,
    owner_id bigint,
    path public.ltree NOT NULL,
    sort_path text NOT NULL COLLATE public.natural_sort
);


--
-- Name: tenancy_tenantgroup_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.tenancy_tenantgroup ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tenancy_tenantgroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: thumbnail_kvstore; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.thumbnail_kvstore (
    key character varying(200) NOT NULL,
    value text NOT NULL
);


--
-- Name: users_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_group (
    id bigint NOT NULL,
    name character varying(150) NOT NULL,
    description character varying(200) NOT NULL
);


--
-- Name: users_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.users_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_group_object_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_group_object_permissions (
    id bigint CONSTRAINT users_objectpermission_groups_id_not_null NOT NULL,
    objectpermission_id bigint CONSTRAINT users_objectpermission_groups_objectpermission_id_not_null NOT NULL,
    group_id bigint CONSTRAINT users_objectpermission_groups_group_id_not_null NOT NULL
);


--
-- Name: users_group_object_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.users_group_object_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_group_object_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_group_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_group_permissions (
    id bigint NOT NULL,
    group_id bigint NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: users_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.users_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_objectpermission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_objectpermission (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    enabled boolean NOT NULL,
    actions character varying(30)[] NOT NULL,
    constraints jsonb
);


--
-- Name: users_objectpermission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.users_objectpermission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_objectpermission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_objectpermission_object_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_objectpermission_object_types (
    id bigint NOT NULL,
    objectpermission_id bigint CONSTRAINT users_objectpermission_object_type_objectpermission_id_not_null NOT NULL,
    contenttype_id integer NOT NULL
);


--
-- Name: users_objectpermission_object_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.users_objectpermission_object_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_objectpermission_object_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_owner; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_owner (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    group_id bigint
);


--
-- Name: users_owner_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.users_owner ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_owner_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_owner_user_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_owner_user_groups (
    id bigint NOT NULL,
    owner_id bigint NOT NULL,
    group_id bigint NOT NULL
);


--
-- Name: users_owner_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.users_owner_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_owner_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_owner_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_owner_users (
    id bigint NOT NULL,
    owner_id bigint NOT NULL,
    user_id bigint NOT NULL
);


--
-- Name: users_owner_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.users_owner_users ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_owner_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_ownergroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_ownergroup (
    id bigint NOT NULL,
    description character varying(200) NOT NULL,
    name character varying(100) NOT NULL
);


--
-- Name: users_ownergroup_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.users_ownergroup ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_ownergroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_token (
    id bigint NOT NULL,
    created timestamp with time zone NOT NULL,
    expires timestamp with time zone,
    plaintext character varying(40),
    write_enabled boolean NOT NULL,
    description character varying(200) NOT NULL,
    user_id bigint NOT NULL,
    allowed_ips cidr[],
    last_used timestamp with time zone,
    enabled boolean NOT NULL,
    version smallint NOT NULL,
    key character varying(12),
    pepper_id smallint,
    hmac_digest character varying(64),
    CONSTRAINT enforce_version_dependent_fields CHECK ((((hmac_digest IS NULL) AND (key IS NULL) AND (pepper_id IS NULL) AND (plaintext IS NOT NULL) AND (version = 1)) OR ((hmac_digest IS NOT NULL) AND (key IS NOT NULL) AND (pepper_id IS NOT NULL) AND (plaintext IS NULL) AND (version = 2)))),
    CONSTRAINT users_token_pepper_id_check CHECK ((pepper_id >= 0)),
    CONSTRAINT users_token_version_check CHECK ((version >= 0))
);


--
-- Name: users_token_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.users_token ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_token_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_user (
    id bigint CONSTRAINT auth_user_id_not_null NOT NULL,
    password character varying(128) CONSTRAINT auth_user_password_not_null NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean CONSTRAINT auth_user_is_superuser_not_null NOT NULL,
    username character varying(150) CONSTRAINT auth_user_username_not_null NOT NULL,
    first_name character varying(150) CONSTRAINT auth_user_first_name_not_null NOT NULL,
    last_name character varying(150) CONSTRAINT auth_user_last_name_not_null NOT NULL,
    email character varying(254) CONSTRAINT auth_user_email_not_null NOT NULL,
    is_active boolean CONSTRAINT auth_user_is_active_not_null NOT NULL,
    date_joined timestamp with time zone CONSTRAINT auth_user_date_joined_not_null NOT NULL
);


--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_user_groups (
    id bigint CONSTRAINT auth_user_groups_id_not_null NOT NULL,
    user_id bigint CONSTRAINT auth_user_groups_user_id_not_null NOT NULL,
    group_id bigint CONSTRAINT auth_user_groups_group_id_not_null NOT NULL
);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.users_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.users_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_user_object_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_user_object_permissions (
    id bigint CONSTRAINT users_objectpermission_users_id_not_null NOT NULL,
    objectpermission_id bigint CONSTRAINT users_objectpermission_users_objectpermission_id_not_null NOT NULL,
    user_id bigint CONSTRAINT users_objectpermission_users_user_id_not_null NOT NULL
);


--
-- Name: users_user_object_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.users_user_object_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_user_object_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_user_user_permissions (
    id bigint CONSTRAINT auth_user_user_permissions_id_not_null NOT NULL,
    user_id bigint CONSTRAINT auth_user_user_permissions_user_id_not_null NOT NULL,
    permission_id integer CONSTRAINT auth_user_user_permissions_permission_id_not_null NOT NULL
);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.users_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_userconfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_userconfig (
    id bigint NOT NULL,
    data jsonb NOT NULL,
    user_id bigint NOT NULL
);


--
-- Name: users_userconfig_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.users_userconfig ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_userconfig_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: virtualization_cluster; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.virtualization_cluster (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    comments text NOT NULL,
    group_id bigint,
    tenant_id bigint,
    type_id bigint NOT NULL,
    status character varying(50) NOT NULL,
    description character varying(200) NOT NULL,
    scope_id bigint,
    scope_type_id integer,
    _location_id bigint,
    _region_id bigint,
    _site_id bigint,
    _site_group_id bigint,
    owner_id bigint,
    CONSTRAINT virtualization_cluster_scope_id_check CHECK ((scope_id >= 0))
);


--
-- Name: virtualization_cluster_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.virtualization_cluster ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.virtualization_cluster_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: virtualization_clustergroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.virtualization_clustergroup (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    owner_id bigint,
    comments text NOT NULL
);


--
-- Name: virtualization_clustergroup_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.virtualization_clustergroup ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.virtualization_clustergroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: virtualization_clustertype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.virtualization_clustertype (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    owner_id bigint,
    comments text NOT NULL
);


--
-- Name: virtualization_clustertype_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.virtualization_clustertype ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.virtualization_clustertype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: virtualization_virtualdisk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.virtualization_virtualdisk (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    description character varying(200) NOT NULL,
    size integer NOT NULL,
    virtual_machine_id bigint NOT NULL,
    owner_id bigint,
    CONSTRAINT virtualization_virtualdisk_size_check CHECK ((size >= 0))
);


--
-- Name: virtualization_virtualdisk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.virtualization_virtualdisk ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.virtualization_virtualdisk_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: virtualization_virtualmachine; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.virtualization_virtualmachine (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    local_context_data jsonb,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    status character varying(50) NOT NULL,
    vcpus numeric(6,2),
    memory integer,
    disk integer,
    comments text NOT NULL,
    cluster_id bigint,
    platform_id bigint,
    primary_ip4_id bigint,
    primary_ip6_id bigint,
    role_id bigint,
    tenant_id bigint,
    site_id bigint,
    device_id bigint,
    description character varying(200) NOT NULL,
    interface_count bigint NOT NULL,
    config_template_id bigint,
    virtual_disk_count bigint NOT NULL,
    serial character varying(50) NOT NULL,
    owner_id bigint,
    start_on_boot character varying(32) NOT NULL,
    virtual_machine_type_id bigint,
    _config_context_data jsonb,
    _config_context_generation bigint CONSTRAINT virtualization_virtualmachi__config_context_generation_not_null NOT NULL,
    CONSTRAINT virtualization_virtualmachine__config_context_generation_check CHECK ((_config_context_generation >= 0)),
    CONSTRAINT virtualization_virtualmachine_disk_check CHECK ((disk >= 0)),
    CONSTRAINT virtualization_virtualmachine_memory_check CHECK ((memory >= 0))
);


--
-- Name: virtualization_virtualmachine_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.virtualization_virtualmachine ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.virtualization_virtualmachine_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: virtualization_virtualmachinetype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.virtualization_virtualmachinetype (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    default_vcpus numeric(6,2),
    default_memory integer,
    virtual_machine_count bigint CONSTRAINT virtualization_virtualmachinetyp_virtual_machine_count_not_null NOT NULL,
    default_platform_id bigint,
    owner_id bigint,
    CONSTRAINT virtualization_virtualmachinetype_default_memory_check CHECK ((default_memory >= 0))
);


--
-- Name: virtualization_virtualmachinetype_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.virtualization_virtualmachinetype ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.virtualization_virtualmachinetype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: virtualization_vminterface; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.virtualization_vminterface (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint NOT NULL,
    enabled boolean NOT NULL,
    mtu integer,
    mode character varying(50),
    name character varying(64) NOT NULL,
    _name character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    parent_id bigint,
    untagged_vlan_id bigint,
    virtual_machine_id bigint NOT NULL,
    bridge_id bigint,
    vrf_id bigint,
    vlan_translation_policy_id bigint,
    qinq_svlan_id bigint,
    primary_mac_address_id bigint,
    owner_id bigint,
    CONSTRAINT virtualization_vminterface_mtu_check CHECK ((mtu >= 0))
);


--
-- Name: virtualization_vminterface_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.virtualization_vminterface ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.virtualization_vminterface_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: virtualization_vminterface_tagged_vlans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.virtualization_vminterface_tagged_vlans (
    id bigint NOT NULL,
    vminterface_id bigint NOT NULL,
    vlan_id bigint NOT NULL
);


--
-- Name: virtualization_vminterface_tagged_vlans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.virtualization_vminterface_tagged_vlans ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.virtualization_vminterface_tagged_vlans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vpn_ikepolicy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vpn_ikepolicy (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    version smallint NOT NULL,
    mode character varying,
    preshared_key text NOT NULL,
    owner_id bigint,
    CONSTRAINT vpn_ikepolicy_version_check CHECK ((version >= 0))
);


--
-- Name: vpn_ikepolicy_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.vpn_ikepolicy ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.vpn_ikepolicy_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vpn_ikepolicy_proposals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vpn_ikepolicy_proposals (
    id bigint NOT NULL,
    ikepolicy_id bigint NOT NULL,
    ikeproposal_id bigint NOT NULL
);


--
-- Name: vpn_ikepolicy_proposals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.vpn_ikepolicy_proposals ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.vpn_ikepolicy_proposals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vpn_ikeproposal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vpn_ikeproposal (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    authentication_method character varying NOT NULL,
    encryption_algorithm character varying NOT NULL,
    authentication_algorithm character varying,
    "group" smallint NOT NULL,
    sa_lifetime integer,
    owner_id bigint,
    CONSTRAINT vpn_ikeproposal_group_check CHECK (("group" >= 0)),
    CONSTRAINT vpn_ikeproposal_sa_lifetime_check CHECK ((sa_lifetime >= 0))
);


--
-- Name: vpn_ikeproposal_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.vpn_ikeproposal ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.vpn_ikeproposal_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vpn_ipsecpolicy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vpn_ipsecpolicy (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    pfs_group smallint,
    owner_id bigint,
    CONSTRAINT vpn_ipsecpolicy_pfs_group_check CHECK ((pfs_group >= 0))
);


--
-- Name: vpn_ipsecpolicy_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.vpn_ipsecpolicy ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.vpn_ipsecpolicy_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vpn_ipsecpolicy_proposals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vpn_ipsecpolicy_proposals (
    id bigint NOT NULL,
    ipsecpolicy_id bigint NOT NULL,
    ipsecproposal_id bigint NOT NULL
);


--
-- Name: vpn_ipsecpolicy_proposals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.vpn_ipsecpolicy_proposals ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.vpn_ipsecpolicy_proposals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vpn_ipsecprofile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vpn_ipsecprofile (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    mode character varying NOT NULL,
    ike_policy_id bigint NOT NULL,
    ipsec_policy_id bigint NOT NULL,
    owner_id bigint
);


--
-- Name: vpn_ipsecprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.vpn_ipsecprofile ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.vpn_ipsecprofile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vpn_ipsecproposal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vpn_ipsecproposal (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    encryption_algorithm character varying,
    authentication_algorithm character varying,
    sa_lifetime_seconds integer,
    sa_lifetime_data integer,
    owner_id bigint,
    CONSTRAINT vpn_ipsecproposal_sa_lifetime_data_check CHECK ((sa_lifetime_data >= 0)),
    CONSTRAINT vpn_ipsecproposal_sa_lifetime_seconds_check CHECK ((sa_lifetime_seconds >= 0))
);


--
-- Name: vpn_ipsecproposal_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.vpn_ipsecproposal ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.vpn_ipsecproposal_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vpn_l2vpn; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vpn_l2vpn (
    id bigint CONSTRAINT ipam_l2vpn_id_not_null NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb CONSTRAINT ipam_l2vpn_custom_field_data_not_null NOT NULL,
    name character varying(100) CONSTRAINT ipam_l2vpn_name_not_null NOT NULL COLLATE public.natural_sort,
    slug character varying(100) CONSTRAINT ipam_l2vpn_slug_not_null NOT NULL,
    type character varying(50) CONSTRAINT ipam_l2vpn_type_not_null NOT NULL,
    identifier bigint,
    description character varying(200) CONSTRAINT ipam_l2vpn_description_not_null NOT NULL,
    tenant_id bigint,
    comments text CONSTRAINT ipam_l2vpn_comments_not_null NOT NULL,
    status character varying(50) NOT NULL,
    owner_id bigint
);


--
-- Name: vpn_l2vpn_export_targets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vpn_l2vpn_export_targets (
    id bigint CONSTRAINT ipam_l2vpn_export_targets_id_not_null NOT NULL,
    l2vpn_id bigint CONSTRAINT ipam_l2vpn_export_targets_l2vpn_id_not_null NOT NULL,
    routetarget_id bigint CONSTRAINT ipam_l2vpn_export_targets_routetarget_id_not_null NOT NULL
);


--
-- Name: vpn_l2vpn_export_targets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.vpn_l2vpn_export_targets ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.vpn_l2vpn_export_targets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vpn_l2vpn_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.vpn_l2vpn ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.vpn_l2vpn_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vpn_l2vpn_import_targets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vpn_l2vpn_import_targets (
    id bigint CONSTRAINT ipam_l2vpn_import_targets_id_not_null NOT NULL,
    l2vpn_id bigint CONSTRAINT ipam_l2vpn_import_targets_l2vpn_id_not_null NOT NULL,
    routetarget_id bigint CONSTRAINT ipam_l2vpn_import_targets_routetarget_id_not_null NOT NULL
);


--
-- Name: vpn_l2vpn_import_targets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.vpn_l2vpn_import_targets ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.vpn_l2vpn_import_targets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vpn_l2vpntermination; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vpn_l2vpntermination (
    id bigint CONSTRAINT ipam_l2vpntermination_id_not_null NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb CONSTRAINT ipam_l2vpntermination_custom_field_data_not_null NOT NULL,
    assigned_object_id bigint CONSTRAINT ipam_l2vpntermination_assigned_object_id_not_null NOT NULL,
    assigned_object_type_id integer CONSTRAINT ipam_l2vpntermination_assigned_object_type_id_not_null NOT NULL,
    l2vpn_id bigint CONSTRAINT ipam_l2vpntermination_l2vpn_id_not_null NOT NULL,
    CONSTRAINT vpn_l2vpntermination_assigned_object_id_check CHECK ((assigned_object_id >= 0))
);


--
-- Name: vpn_l2vpntermination_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.vpn_l2vpntermination ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.vpn_l2vpntermination_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vpn_tunnel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vpn_tunnel (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    status character varying(50) NOT NULL,
    group_id bigint,
    encapsulation character varying(50) NOT NULL,
    tunnel_id bigint,
    ipsec_profile_id bigint,
    tenant_id bigint,
    owner_id bigint,
    CONSTRAINT vpn_tunnel_tunnel_id_check CHECK ((tunnel_id >= 0))
);


--
-- Name: vpn_tunnel_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.vpn_tunnel ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.vpn_tunnel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vpn_tunnelgroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vpn_tunnelgroup (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    owner_id bigint,
    comments text NOT NULL
);


--
-- Name: vpn_tunnelgroup_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.vpn_tunnelgroup ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.vpn_tunnelgroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vpn_tunneltermination; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vpn_tunneltermination (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    role character varying(50) NOT NULL,
    termination_id bigint,
    termination_type_id integer NOT NULL,
    outside_ip_id bigint,
    tunnel_id bigint NOT NULL,
    CONSTRAINT vpn_tunneltermination_termination_id_check CHECK ((termination_id >= 0))
);


--
-- Name: vpn_tunneltermination_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.vpn_tunneltermination ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.vpn_tunneltermination_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: wireless_wirelesslan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wireless_wirelesslan (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    ssid character varying(32) NOT NULL,
    group_id bigint,
    description character varying(200) NOT NULL,
    auth_cipher character varying(50),
    auth_psk character varying(64) NOT NULL,
    auth_type character varying(50),
    vlan_id bigint,
    tenant_id bigint,
    comments text NOT NULL,
    status character varying(50) NOT NULL,
    _location_id bigint,
    _region_id bigint,
    _site_id bigint,
    _site_group_id bigint,
    scope_id bigint,
    scope_type_id integer,
    owner_id bigint,
    CONSTRAINT wireless_wirelesslan_scope_id_check CHECK ((scope_id >= 0))
);


--
-- Name: wireless_wirelesslan_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.wireless_wirelesslan ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.wireless_wirelesslan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: wireless_wirelesslangroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wireless_wirelesslangroup (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    parent_id bigint,
    comments text NOT NULL,
    owner_id bigint,
    path public.ltree NOT NULL,
    sort_path text NOT NULL COLLATE public.natural_sort
);


--
-- Name: wireless_wirelesslangroup_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.wireless_wirelesslangroup ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.wireless_wirelesslangroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: wireless_wirelesslink; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wireless_wirelesslink (
    id bigint NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    ssid character varying(32) NOT NULL,
    status character varying(50) NOT NULL,
    description character varying(200) NOT NULL,
    auth_cipher character varying(50),
    auth_psk character varying(64) NOT NULL,
    auth_type character varying(50),
    _interface_a_device_id bigint,
    _interface_b_device_id bigint,
    interface_a_id bigint NOT NULL,
    interface_b_id bigint NOT NULL,
    tenant_id bigint,
    comments text NOT NULL,
    _abs_distance numeric(13,4),
    distance numeric(8,2),
    distance_unit character varying(50),
    owner_id bigint
);


--
-- Name: wireless_wirelesslink_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.wireless_wirelesslink ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.wireless_wirelesslink_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	14	add_permission
2	Can change permission	14	change_permission
3	Can delete permission	14	delete_permission
4	Can view permission	14	view_permission
5	Can add group	15	add_group
6	Can change group	15	change_group
7	Can delete group	15	delete_group
8	Can view group	15	view_group
9	Can add content type	16	add_contenttype
10	Can change content type	16	change_contenttype
11	Can delete content type	16	delete_contenttype
12	Can view content type	16	view_contenttype
13	Can add session	17	add_session
14	Can change session	17	change_session
15	Can delete session	17	delete_session
16	Can view session	17	view_session
17	Can add association	20	add_association
18	Can change association	20	change_association
19	Can delete association	20	delete_association
20	Can view association	20	view_association
21	Can add code	21	add_code
22	Can change code	21	change_code
23	Can delete code	21	delete_code
24	Can view code	21	view_code
25	Can add nonce	19	add_nonce
26	Can change nonce	19	change_nonce
27	Can delete nonce	19	delete_nonce
28	Can view nonce	19	view_nonce
29	Can add user social auth	18	add_usersocialauth
30	Can change user social auth	18	change_usersocialauth
31	Can delete user social auth	18	delete_usersocialauth
32	Can view user social auth	18	view_usersocialauth
33	Can add partial	22	add_partial
34	Can change partial	22	change_partial
35	Can delete partial	22	delete_partial
36	Can view partial	22	view_partial
37	Can add kv store	23	add_kvstore
38	Can change kv store	23	change_kvstore
39	Can delete kv store	23	delete_kvstore
40	Can view kv store	23	view_kvstore
41	Can add tag	24	add_tag
42	Can change tag	24	change_tag
43	Can delete tag	24	delete_tag
44	Can view tag	24	view_tag
45	Can add tagged item	25	add_taggeditem
46	Can change tagged item	25	change_taggeditem
47	Can delete tagged item	25	delete_taggeditem
48	Can view tagged item	25	view_taggeditem
49	Can add data source	29	add_datasource
50	Can change data source	29	change_datasource
51	Can delete data source	29	delete_datasource
52	Can view data source	29	view_datasource
53	Synchronize data from remote source	29	sync
54	Can add data file	30	add_datafile
55	Can change data file	30	change_datafile
56	Can delete data file	30	delete_datafile
57	Can view data file	30	view_datafile
58	Can add auto sync record	31	add_autosyncrecord
59	Can change auto sync record	31	change_autosyncrecord
60	Can delete auto sync record	31	delete_autosyncrecord
61	Can view auto sync record	31	view_autosyncrecord
62	Can add managed file	6	add_managedfile
63	Can change managed file	6	change_managedfile
64	Can delete managed file	6	delete_managedfile
65	Can view managed file	6	view_managedfile
66	Can add job	32	add_job
67	Can change job	32	change_job
68	Can delete job	32	delete_job
69	Can view job	32	view_job
70	Can add config revision	28	add_configrevision
71	Can change config revision	28	change_configrevision
72	Can delete config revision	28	delete_configrevision
73	Can view config revision	28	view_configrevision
74	Can add object change	27	add_objectchange
75	Can change object change	27	change_objectchange
76	Can delete object change	27	delete_objectchange
77	Can view object change	27	view_objectchange
78	Can add object type	26	add_objecttype
79	Can change object type	26	change_objecttype
80	Can delete object type	26	delete_objecttype
81	Can view object type	26	view_objecttype
82	Can add token	33	add_usertoken
83	Can change token	33	change_usertoken
84	Can delete token	33	delete_usertoken
85	Can view token	33	view_usertoken
86	Can add circuit	12	add_circuit
87	Can change circuit	12	change_circuit
88	Can delete circuit	12	delete_circuit
89	Can view circuit	12	view_circuit
90	Can add circuit termination	37	add_circuittermination
91	Can change circuit termination	37	change_circuittermination
92	Can delete circuit termination	37	delete_circuittermination
93	Can view circuit termination	37	view_circuittermination
94	Can add circuit type	34	add_circuittype
95	Can change circuit type	34	change_circuittype
96	Can delete circuit type	34	delete_circuittype
97	Can view circuit type	34	view_circuittype
98	Can add provider	38	add_provider
99	Can change provider	38	change_provider
100	Can delete provider	38	delete_provider
101	Can view provider	38	view_provider
102	Can add provider network	11	add_providernetwork
103	Can change provider network	11	change_providernetwork
104	Can delete provider network	11	delete_providernetwork
105	Can view provider network	11	view_providernetwork
106	Can add provider account	39	add_provideraccount
107	Can change provider account	39	change_provideraccount
108	Can delete provider account	39	delete_provideraccount
109	Can view provider account	39	view_provideraccount
110	Can add Circuit group	35	add_circuitgroup
111	Can change Circuit group	35	change_circuitgroup
112	Can delete Circuit group	35	delete_circuitgroup
113	Can view Circuit group	35	view_circuitgroup
114	Can add Circuit group assignment	36	add_circuitgroupassignment
115	Can change Circuit group assignment	36	change_circuitgroupassignment
116	Can delete Circuit group assignment	36	delete_circuitgroupassignment
117	Can view Circuit group assignment	36	view_circuitgroupassignment
118	Can add virtual circuit type	40	add_virtualcircuittype
119	Can change virtual circuit type	40	change_virtualcircuittype
120	Can delete virtual circuit type	40	delete_virtualcircuittype
121	Can view virtual circuit type	40	view_virtualcircuittype
122	Can add circuit	41	add_virtualcircuit
123	Can change circuit	41	change_virtualcircuit
124	Can delete circuit	41	delete_virtualcircuit
125	Can view circuit	41	view_virtualcircuit
126	Can add virtual circuit termination	42	add_virtualcircuittermination
127	Can change virtual circuit termination	42	change_virtualcircuittermination
128	Can delete virtual circuit termination	42	delete_virtualcircuittermination
129	Can view virtual circuit termination	42	view_virtualcircuittermination
130	Can add cable	57	add_cable
131	Can change cable	57	change_cable
132	Can delete cable	57	delete_cable
133	Can view cable	57	view_cable
134	Can add cable path	59	add_cablepath
135	Can change cable path	59	change_cablepath
136	Can delete cable path	59	delete_cablepath
137	Can view cable path	59	view_cablepath
138	Can add console port	43	add_consoleport
139	Can change console port	43	change_consoleport
140	Can delete console port	43	delete_consoleport
141	Can view console port	43	view_consoleport
142	Can add console port template	62	add_consoleporttemplate
143	Can change console port template	62	change_consoleporttemplate
144	Can delete console port template	62	delete_consoleporttemplate
145	Can view console port template	62	view_consoleporttemplate
146	Can add console server port	44	add_consoleserverport
147	Can change console server port	44	change_consoleserverport
148	Can delete console server port	44	delete_consoleserverport
149	Can view console server port	44	view_consoleserverport
150	Can add console server port template	63	add_consoleserverporttemplate
151	Can change console server port template	63	change_consoleserverporttemplate
152	Can delete console server port template	63	delete_consoleserverporttemplate
153	Can view console server port template	63	view_consoleserverporttemplate
154	Can add device	9	add_device
155	Can change device	9	change_device
156	Can delete device	9	delete_device
157	Can view device	9	view_device
158	Render configuration	9	render_config
159	Can add device bay	53	add_devicebay
160	Can change device bay	53	change_devicebay
161	Can delete device bay	53	delete_devicebay
162	Can view device bay	53	view_devicebay
163	Can add device bay template	73	add_devicebaytemplate
164	Can change device bay template	73	change_devicebaytemplate
165	Can delete device bay template	73	delete_devicebaytemplate
166	Can view device bay template	73	view_devicebaytemplate
167	Can add device role	81	add_devicerole
168	Can change device role	81	change_devicerole
169	Can delete device role	81	delete_devicerole
170	Can view device role	81	view_devicerole
171	Can add device type	80	add_devicetype
172	Can change device type	80	change_devicetype
173	Can delete device type	80	delete_devicetype
174	Can view device type	80	view_devicetype
175	Can add front port	50	add_frontport
176	Can change front port	50	change_frontport
177	Can delete front port	50	delete_frontport
178	Can view front port	50	view_frontport
179	Can add front port template	70	add_frontporttemplate
180	Can change front port template	70	change_frontporttemplate
181	Can delete front port template	70	delete_frontporttemplate
182	Can view front port template	70	view_frontporttemplate
183	Can add interface	8	add_interface
184	Can change interface	8	change_interface
185	Can delete interface	8	delete_interface
186	Can view interface	8	view_interface
187	Can add interface template	68	add_interfacetemplate
188	Can change interface template	68	change_interfacetemplate
189	Can delete interface template	68	delete_interfacetemplate
190	Can view interface template	68	view_interfacetemplate
191	Can add inventory item	55	add_inventoryitem
192	Can change inventory item	55	change_inventoryitem
193	Can delete inventory item	55	delete_inventoryitem
194	Can view inventory item	55	view_inventoryitem
195	Can add location	95	add_location
196	Can change location	95	change_location
197	Can delete location	95	delete_location
198	Can view location	95	view_location
199	Can add manufacturer	79	add_manufacturer
200	Can change manufacturer	79	change_manufacturer
201	Can delete manufacturer	79	delete_manufacturer
202	Can view manufacturer	79	view_manufacturer
203	Can add platform	82	add_platform
204	Can change platform	82	change_platform
205	Can delete platform	82	delete_platform
206	Can view platform	82	view_platform
207	Can add power feed	87	add_powerfeed
208	Can change power feed	87	change_powerfeed
209	Can delete power feed	87	delete_powerfeed
210	Can view power feed	87	view_powerfeed
211	Can add power outlet	46	add_poweroutlet
212	Can change power outlet	46	change_poweroutlet
213	Can delete power outlet	46	delete_poweroutlet
214	Can view power outlet	46	view_poweroutlet
215	Can add power outlet template	65	add_poweroutlettemplate
216	Can change power outlet template	65	change_poweroutlettemplate
217	Can delete power outlet template	65	delete_poweroutlettemplate
218	Can view power outlet template	65	view_poweroutlettemplate
219	Can add power panel	86	add_powerpanel
220	Can change power panel	86	change_powerpanel
221	Can delete power panel	86	delete_powerpanel
222	Can view power panel	86	view_powerpanel
223	Can add power port	45	add_powerport
224	Can change power port	45	change_powerport
225	Can delete power port	45	delete_powerport
226	Can view power port	45	view_powerport
227	Can add power port template	64	add_powerporttemplate
228	Can change power port template	64	change_powerporttemplate
229	Can delete power port template	64	delete_powerporttemplate
230	Can view power port template	64	view_powerporttemplate
231	Can add rack	91	add_rack
232	Can change rack	91	change_rack
233	Can delete rack	91	delete_rack
234	Can view rack	91	view_rack
235	Can add rack reservation	92	add_rackreservation
236	Can change rack reservation	92	change_rackreservation
237	Can delete rack reservation	92	delete_rackreservation
238	Can view rack reservation	92	view_rackreservation
239	Can add rack role	90	add_rackrole
240	Can change rack role	90	change_rackrole
241	Can delete rack role	90	delete_rackrole
242	Can view rack role	90	view_rackrole
243	Can add rear port	51	add_rearport
244	Can change rear port	51	change_rearport
245	Can delete rear port	51	delete_rearport
246	Can view rear port	51	view_rearport
247	Can add rear port template	71	add_rearporttemplate
248	Can change rear port template	71	change_rearporttemplate
249	Can delete rear port template	71	delete_rearporttemplate
250	Can view rear port template	71	view_rearporttemplate
251	Can add region	93	add_region
252	Can change region	93	change_region
253	Can delete region	93	delete_region
254	Can view region	93	view_region
255	Can add site	1	add_site
256	Can change site	1	change_site
257	Can delete site	1	delete_site
258	Can view site	1	view_site
259	Can add site group	94	add_sitegroup
260	Can change site group	94	change_sitegroup
261	Can delete site group	94	delete_sitegroup
262	Can view site group	94	view_sitegroup
263	Can add virtual chassis	83	add_virtualchassis
264	Can change virtual chassis	83	change_virtualchassis
265	Can delete virtual chassis	83	delete_virtualchassis
266	Can view virtual chassis	83	view_virtualchassis
267	Can add module type	77	add_moduletype
268	Can change module type	77	change_moduletype
269	Can delete module type	77	delete_moduletype
270	Can view module type	77	view_moduletype
271	Can add module bay	52	add_modulebay
272	Can change module bay	52	change_modulebay
273	Can delete module bay	52	delete_modulebay
274	Can view module bay	52	view_modulebay
275	Can add module	78	add_module
276	Can change module	78	change_module
277	Can delete module	78	delete_module
278	Can view module	78	view_module
279	Can add inventory item role	54	add_inventoryitemrole
280	Can change inventory item role	54	change_inventoryitemrole
281	Can delete inventory item role	54	delete_inventoryitemrole
282	Can view inventory item role	54	view_inventoryitemrole
283	Can add inventory item template	74	add_inventoryitemtemplate
284	Can change inventory item template	74	change_inventoryitemtemplate
285	Can delete inventory item template	74	delete_inventoryitemtemplate
286	Can view inventory item template	74	view_inventoryitemtemplate
287	Can add module bay template	72	add_modulebaytemplate
288	Can change module bay template	72	change_modulebaytemplate
289	Can delete module bay template	72	delete_modulebaytemplate
290	Can view module bay template	72	view_modulebaytemplate
291	Can add cable termination	58	add_cabletermination
292	Can change cable termination	58	change_cabletermination
293	Can delete cable termination	58	delete_cabletermination
294	Can view cable termination	58	view_cabletermination
295	Can add virtual device context	84	add_virtualdevicecontext
296	Can change virtual device context	84	change_virtualdevicecontext
297	Can delete virtual device context	84	delete_virtualdevicecontext
298	Can view virtual device context	84	view_virtualdevicecontext
299	Can add racktype	89	add_racktype
300	Can change racktype	89	change_racktype
301	Can delete racktype	89	delete_racktype
302	Can view racktype	89	view_racktype
303	Can add MAC address	85	add_macaddress
304	Can change MAC address	85	change_macaddress
305	Can delete MAC address	85	delete_macaddress
306	Can view MAC address	85	view_macaddress
307	Can add module type profile	76	add_moduletypeprofile
308	Can change module type profile	76	change_moduletypeprofile
309	Can delete module type profile	76	delete_moduletypeprofile
310	Can view module type profile	76	view_moduletypeprofile
311	Can add port template mapping	69	add_porttemplatemapping
312	Can change port template mapping	69	change_porttemplatemapping
313	Can delete port template mapping	69	delete_porttemplatemapping
314	Can view port template mapping	69	view_porttemplatemapping
315	Can add port mapping	49	add_portmapping
316	Can change port mapping	49	change_portmapping
317	Can delete port mapping	49	delete_portmapping
318	Can view port mapping	49	view_portmapping
319	Can add rack group	88	add_rackgroup
320	Can change rack group	88	change_rackgroup
321	Can delete rack group	88	delete_rackgroup
322	Can view rack group	88	view_rackgroup
323	Can add cable bundle	56	add_cablebundle
324	Can change cable bundle	56	change_cablebundle
325	Can delete cable bundle	56	delete_cablebundle
326	Can view cable bundle	56	view_cablebundle
327	Can add module bay type	75	add_modulebaytype
328	Can change module bay type	75	change_modulebaytype
329	Can delete module bay type	75	delete_modulebaytype
330	Can view module bay type	75	view_modulebaytype
331	Can add cooling intake	47	add_coolingintake
332	Can change cooling intake	47	change_coolingintake
333	Can delete cooling intake	47	delete_coolingintake
334	Can view cooling intake	47	view_coolingintake
335	Can add cooling outflow	48	add_coolingoutflow
336	Can change cooling outflow	48	change_coolingoutflow
337	Can delete cooling outflow	48	delete_coolingoutflow
338	Can view cooling outflow	48	view_coolingoutflow
339	Can add cooling intake template	66	add_coolingintaketemplate
340	Can change cooling intake template	66	change_coolingintaketemplate
341	Can delete cooling intake template	66	delete_coolingintaketemplate
342	Can view cooling intake template	66	view_coolingintaketemplate
343	Can add cooling outflow template	67	add_coolingoutflowtemplate
344	Can change cooling outflow template	67	change_coolingoutflowtemplate
345	Can delete cooling outflow template	67	delete_coolingoutflowtemplate
346	Can view cooling outflow template	67	view_coolingoutflowtemplate
347	Can add cooling source	60	add_coolingsource
348	Can change cooling source	60	change_coolingsource
349	Can delete cooling source	60	delete_coolingsource
350	Can view cooling source	60	view_coolingsource
351	Can add cooling feed	61	add_coolingfeed
352	Can change cooling feed	61	change_coolingfeed
353	Can delete cooling feed	61	delete_coolingfeed
354	Can view cooling feed	61	view_coolingfeed
355	Can add aggregate	101	add_aggregate
356	Can change aggregate	101	change_aggregate
357	Can delete aggregate	101	delete_aggregate
358	Can view aggregate	101	view_aggregate
359	Can add IP address	105	add_ipaddress
360	Can change IP address	105	change_ipaddress
361	Can delete IP address	105	delete_ipaddress
362	Can view IP address	105	view_ipaddress
363	Can add prefix	103	add_prefix
364	Can change prefix	103	change_prefix
365	Can delete prefix	103	delete_prefix
366	Can view prefix	103	view_prefix
367	Can add RIR	100	add_rir
368	Can change RIR	100	change_rir
369	Can delete RIR	100	delete_rir
370	Can view RIR	100	view_rir
371	Can add role	102	add_role
372	Can change role	102	change_role
373	Can delete role	102	delete_role
374	Can view role	102	view_role
375	Can add route target	113	add_routetarget
376	Can change route target	113	change_routetarget
377	Can delete route target	113	delete_routetarget
378	Can view route target	113	view_routetarget
379	Can add VRF	112	add_vrf
380	Can change VRF	112	change_vrf
381	Can delete VRF	112	delete_vrf
382	Can view VRF	112	view_vrf
383	Can add VLAN group	108	add_vlangroup
384	Can change VLAN group	108	change_vlangroup
385	Can delete VLAN group	108	delete_vlangroup
386	Can view VLAN group	108	view_vlangroup
387	Can add VLAN	109	add_vlan
388	Can change VLAN	109	change_vlan
389	Can delete VLAN	109	delete_vlan
390	Can view VLAN	109	view_vlan
391	Can add service	107	add_service
392	Can change service	107	change_service
393	Can delete service	107	delete_service
394	Can view service	107	view_service
395	Can add IP range	104	add_iprange
396	Can change IP range	104	change_iprange
397	Can delete IP range	104	delete_iprange
398	Can view IP range	104	view_iprange
399	Can add FHRP group	98	add_fhrpgroup
400	Can change FHRP group	98	change_fhrpgroup
401	Can delete FHRP group	98	delete_fhrpgroup
402	Can view FHRP group	98	view_fhrpgroup
403	Can add FHRP group assignment	99	add_fhrpgroupassignment
404	Can change FHRP group assignment	99	change_fhrpgroupassignment
405	Can delete FHRP group assignment	99	delete_fhrpgroupassignment
406	Can view FHRP group assignment	99	view_fhrpgroupassignment
407	Can add ASN	97	add_asn
408	Can change ASN	97	change_asn
409	Can delete ASN	97	delete_asn
410	Can view ASN	97	view_asn
411	Can add service template	106	add_servicetemplate
412	Can change service template	106	change_servicetemplate
413	Can delete service template	106	delete_servicetemplate
414	Can view service template	106	view_servicetemplate
415	Can add ASN range	96	add_asnrange
416	Can change ASN range	96	change_asnrange
417	Can delete ASN range	96	delete_asnrange
418	Can view ASN range	96	view_asnrange
419	Can add VLAN translation policy	110	add_vlantranslationpolicy
420	Can change VLAN translation policy	110	change_vlantranslationpolicy
421	Can delete VLAN translation policy	110	delete_vlantranslationpolicy
422	Can view VLAN translation policy	110	view_vlantranslationpolicy
423	Can add VLAN translation rule	111	add_vlantranslationrule
424	Can change VLAN translation rule	111	change_vlantranslationrule
425	Can delete VLAN translation rule	111	delete_vlantranslationrule
426	Can view VLAN translation rule	111	view_vlantranslationrule
427	Can add script	3	add_script
428	Can change script	3	change_script
429	Can delete script	3	delete_script
430	Can view script	3	view_script
431	Can add config context	117	add_configcontext
432	Can change config context	117	change_configcontext
433	Can delete config context	117	delete_configcontext
434	Can view config context	117	view_configcontext
435	Can add tag	114	add_tag
436	Can change tag	114	change_tag
437	Can delete tag	114	delete_tag
438	Can view tag	114	view_tag
439	Can add webhook	2	add_webhook
440	Can change webhook	2	change_webhook
441	Can delete webhook	2	delete_webhook
442	Can view webhook	2	view_webhook
443	Can add tagged item	115	add_taggeditem
444	Can change tagged item	115	change_taggeditem
445	Can delete tagged item	115	delete_taggeditem
446	Can view tagged item	115	view_taggeditem
447	Can add journal entry	128	add_journalentry
448	Can change journal entry	128	change_journalentry
449	Can delete journal entry	128	delete_journalentry
450	Can view journal entry	128	view_journalentry
451	Can add image attachment	127	add_imageattachment
452	Can change image attachment	127	change_imageattachment
453	Can delete image attachment	127	delete_imageattachment
454	Can view image attachment	127	view_imageattachment
455	Can add export template	124	add_exporttemplate
456	Can change export template	124	change_exporttemplate
457	Can delete export template	124	delete_exporttemplate
458	Can view export template	124	view_exporttemplate
459	Can add custom link	123	add_customlink
460	Can change custom link	123	change_customlink
461	Can delete custom link	123	delete_customlink
462	Can view custom link	123	view_customlink
463	Can add custom field	119	add_customfield
464	Can change custom field	119	change_customfield
465	Can delete custom field	119	delete_customfield
466	Can view custom field	119	view_customfield
467	Can add saved filter	125	add_savedfilter
468	Can change saved filter	125	change_savedfilter
469	Can delete saved filter	125	delete_savedfilter
470	Can view saved filter	125	view_savedfilter
471	Can add cached value	133	add_cachedvalue
472	Can change cached value	133	change_cachedvalue
473	Can delete cached value	133	delete_cachedvalue
474	Can view cached value	133	view_cachedvalue
475	Can add config template	118	add_configtemplate
476	Can change config template	118	change_configtemplate
477	Can delete config template	118	delete_configtemplate
478	Can view config template	118	view_configtemplate
479	Can add dashboard	121	add_dashboard
480	Can change dashboard	121	change_dashboard
481	Can delete dashboard	121	delete_dashboard
482	Can view dashboard	121	view_dashboard
483	Can add script module	4	add_scriptmodule
484	Can change script module	4	change_scriptmodule
485	Can delete script module	4	delete_scriptmodule
486	Can view script module	4	view_scriptmodule
487	Can add bookmark	129	add_bookmark
488	Can change bookmark	129	change_bookmark
489	Can delete bookmark	129	delete_bookmark
490	Can view bookmark	129	view_bookmark
491	Can add custom field choice set	120	add_customfieldchoiceset
492	Can change custom field choice set	120	change_customfieldchoiceset
493	Can delete custom field choice set	120	delete_customfieldchoiceset
494	Can view custom field choice set	120	view_customfieldchoiceset
495	Can add eventrule	122	add_eventrule
496	Can change eventrule	122	change_eventrule
497	Can delete eventrule	122	delete_eventrule
498	Can view eventrule	122	view_eventrule
499	Can add notification group	131	add_notificationgroup
500	Can change notification group	131	change_notificationgroup
501	Can delete notification group	131	delete_notificationgroup
502	Can view notification group	131	view_notificationgroup
503	Can add subscription	132	add_subscription
504	Can change subscription	132	change_subscription
505	Can delete subscription	132	delete_subscription
506	Can view subscription	132	view_subscription
507	Can add notification	130	add_notification
508	Can change notification	130	change_notification
509	Can delete notification	130	delete_notification
510	Can view notification	130	view_notification
511	Can add table config	126	add_tableconfig
512	Can change table config	126	change_tableconfig
513	Can delete table config	126	delete_tableconfig
514	Can view table config	126	view_tableconfig
515	Can add config context profile	116	add_configcontextprofile
516	Can change config context profile	116	change_configcontextprofile
517	Can delete config context profile	116	delete_configcontextprofile
518	Can view config context profile	116	view_configcontextprofile
519	Can add tenant group	138	add_tenantgroup
520	Can change tenant group	138	change_tenantgroup
521	Can delete tenant group	138	delete_tenantgroup
522	Can view tenant group	138	view_tenantgroup
523	Can add tenant	139	add_tenant
524	Can change tenant	139	change_tenant
525	Can delete tenant	139	delete_tenant
526	Can view tenant	139	view_tenant
527	Can add contact role	135	add_contactrole
528	Can change contact role	135	change_contactrole
529	Can delete contact role	135	delete_contactrole
530	Can view contact role	135	view_contactrole
531	Can add contact group	134	add_contactgroup
532	Can change contact group	134	change_contactgroup
533	Can delete contact group	134	delete_contactgroup
534	Can view contact group	134	view_contactgroup
535	Can add contact	136	add_contact
536	Can change contact	136	change_contact
537	Can delete contact	136	delete_contact
538	Can view contact	136	view_contact
539	Can add contact assignment	137	add_contactassignment
540	Can change contact assignment	137	change_contactassignment
541	Can delete contact assignment	137	delete_contactassignment
542	Can view contact assignment	137	view_contactassignment
543	Can add user	146	add_user
544	Can change user	146	change_user
545	Can delete user	146	delete_user
546	Can view user	146	view_user
547	Can add User Preferences	143	add_userconfig
548	Can change User Preferences	143	change_userconfig
549	Can delete User Preferences	143	delete_userconfig
550	Can view User Preferences	143	view_userconfig
551	Can add token	144	add_token
552	Can change token	144	change_token
553	Can delete token	144	delete_token
554	Can view token	144	view_token
555	Can add permission	142	add_objectpermission
556	Can change permission	142	change_objectpermission
557	Can delete permission	142	delete_objectpermission
558	Can view permission	142	view_objectpermission
559	Can add group	145	add_group
560	Can change group	145	change_group
561	Can delete group	145	delete_group
562	Can view group	145	view_group
563	Can add owner group	140	add_ownergroup
564	Can change owner group	140	change_ownergroup
565	Can delete owner group	140	delete_ownergroup
566	Can view owner group	140	view_ownergroup
567	Can add owner	141	add_owner
568	Can change owner	141	change_owner
569	Can delete owner	141	delete_owner
570	Can view owner	141	view_owner
571	Can add cluster	149	add_cluster
572	Can change cluster	149	change_cluster
573	Can delete cluster	149	delete_cluster
574	Can view cluster	149	view_cluster
575	Can add cluster group	148	add_clustergroup
576	Can change cluster group	148	change_clustergroup
577	Can delete cluster group	148	delete_clustergroup
578	Can view cluster group	148	view_clustergroup
579	Can add cluster type	147	add_clustertype
580	Can change cluster type	147	change_clustertype
581	Can delete cluster type	147	delete_clustertype
582	Can view cluster type	147	view_clustertype
583	Can add virtual machine	10	add_virtualmachine
584	Can change virtual machine	10	change_virtualmachine
585	Can delete virtual machine	10	delete_virtualmachine
586	Can view virtual machine	10	view_virtualmachine
587	Render configuration	10	render_config
588	Can add interface	7	add_vminterface
589	Can change interface	7	change_vminterface
590	Can delete interface	7	delete_vminterface
591	Can view interface	7	view_vminterface
592	Can add virtual disk	151	add_virtualdisk
593	Can change virtual disk	151	change_virtualdisk
594	Can delete virtual disk	151	delete_virtualdisk
595	Can view virtual disk	151	view_virtualdisk
596	Can add virtual machine type	150	add_virtualmachinetype
597	Can change virtual machine type	150	change_virtualmachinetype
598	Can delete virtual machine type	150	delete_virtualmachinetype
599	Can view virtual machine type	150	view_virtualmachinetype
600	Can add IKE proposal	152	add_ikeproposal
601	Can change IKE proposal	152	change_ikeproposal
602	Can delete IKE proposal	152	delete_ikeproposal
603	Can view IKE proposal	152	view_ikeproposal
604	Can add IKE policy	153	add_ikepolicy
605	Can change IKE policy	153	change_ikepolicy
606	Can delete IKE policy	153	delete_ikepolicy
607	Can view IKE policy	153	view_ikepolicy
608	Can add IPSec proposal	154	add_ipsecproposal
609	Can change IPSec proposal	154	change_ipsecproposal
610	Can delete IPSec proposal	154	delete_ipsecproposal
611	Can view IPSec proposal	154	view_ipsecproposal
612	Can add IPSec policy	155	add_ipsecpolicy
613	Can change IPSec policy	155	change_ipsecpolicy
614	Can delete IPSec policy	155	delete_ipsecpolicy
615	Can view IPSec policy	155	view_ipsecpolicy
616	Can add IPSec profile	156	add_ipsecprofile
617	Can change IPSec profile	156	change_ipsecprofile
618	Can delete IPSec profile	156	delete_ipsecprofile
619	Can view IPSec profile	156	view_ipsecprofile
620	Can add tunnel group	159	add_tunnelgroup
621	Can change tunnel group	159	change_tunnelgroup
622	Can delete tunnel group	159	delete_tunnelgroup
623	Can view tunnel group	159	view_tunnelgroup
624	Can add tunnel	160	add_tunnel
625	Can change tunnel	160	change_tunnel
626	Can delete tunnel	160	delete_tunnel
627	Can view tunnel	160	view_tunnel
628	Can add tunnel termination	161	add_tunneltermination
629	Can change tunnel termination	161	change_tunneltermination
630	Can delete tunnel termination	161	delete_tunneltermination
631	Can view tunnel termination	161	view_tunneltermination
632	Can add L2VPN	157	add_l2vpn
633	Can change L2VPN	157	change_l2vpn
634	Can delete L2VPN	157	delete_l2vpn
635	Can view L2VPN	157	view_l2vpn
636	Can add L2VPN termination	158	add_l2vpntermination
637	Can change L2VPN termination	158	change_l2vpntermination
638	Can delete L2VPN termination	158	delete_l2vpntermination
639	Can view L2VPN termination	158	view_l2vpntermination
640	Can add Wireless LAN Group	162	add_wirelesslangroup
641	Can change Wireless LAN Group	162	change_wirelesslangroup
642	Can delete Wireless LAN Group	162	delete_wirelesslangroup
643	Can view Wireless LAN Group	162	view_wirelesslangroup
644	Can add Wireless LAN	163	add_wirelesslan
645	Can change Wireless LAN	163	change_wirelesslan
646	Can delete Wireless LAN	163	delete_wirelesslan
647	Can view Wireless LAN	163	view_wirelesslan
648	Can add wireless link	164	add_wirelesslink
649	Can change wireless link	164	change_wirelesslink
650	Can delete wireless link	164	delete_wirelesslink
651	Can view wireless link	164	view_wirelesslink
652	Access admin page	13	admin
\.


--
-- Data for Name: circuits_circuit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.circuits_circuit (created, last_updated, custom_field_data, id, cid, status, install_date, commit_rate, description, comments, provider_id, tenant_id, termination_a_id, termination_z_id, type_id, termination_date, provider_account_id, _abs_distance, distance, distance_unit, owner_id) FROM stdin;
\.


--
-- Data for Name: circuits_circuitgroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.circuits_circuitgroup (id, created, last_updated, custom_field_data, name, slug, description, tenant_id, owner_id, comments) FROM stdin;
\.


--
-- Data for Name: circuits_circuitgroupassignment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.circuits_circuitgroupassignment (id, created, last_updated, custom_field_data, priority, member_id, group_id, member_type_id) FROM stdin;
\.


--
-- Data for Name: circuits_circuittermination; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.circuits_circuittermination (created, last_updated, id, mark_connected, term_side, port_speed, upstream_speed, xconnect_id, pp_info, description, cable_id, circuit_id, _provider_network_id, custom_field_data, cable_end, termination_id, termination_type_id, _location_id, _region_id, _site_id, _site_group_id, cable_connector, cable_positions) FROM stdin;
\.


--
-- Data for Name: circuits_circuittype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.circuits_circuittype (created, last_updated, custom_field_data, id, name, slug, description, color, owner_id, comments) FROM stdin;
\.


--
-- Data for Name: circuits_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.circuits_provider (created, last_updated, custom_field_data, id, name, slug, comments, description, owner_id) FROM stdin;
\.


--
-- Data for Name: circuits_provider_asns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.circuits_provider_asns (id, provider_id, asn_id) FROM stdin;
\.


--
-- Data for Name: circuits_provideraccount; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.circuits_provideraccount (id, created, last_updated, custom_field_data, description, comments, account, name, provider_id, owner_id) FROM stdin;
\.


--
-- Data for Name: circuits_providernetwork; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.circuits_providernetwork (created, last_updated, custom_field_data, id, name, description, comments, provider_id, service_id, owner_id) FROM stdin;
\.


--
-- Data for Name: circuits_virtualcircuit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.circuits_virtualcircuit (id, created, last_updated, custom_field_data, description, comments, cid, status, provider_account_id, provider_network_id, type_id, tenant_id, owner_id) FROM stdin;
\.


--
-- Data for Name: circuits_virtualcircuittermination; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.circuits_virtualcircuittermination (id, created, last_updated, custom_field_data, role, description, interface_id, virtual_circuit_id) FROM stdin;
\.


--
-- Data for Name: circuits_virtualcircuittype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.circuits_virtualcircuittype (id, created, last_updated, custom_field_data, name, slug, description, color, owner_id, comments) FROM stdin;
\.


--
-- Data for Name: core_autosyncrecord; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_autosyncrecord (id, object_id, datafile_id, object_type_id) FROM stdin;
\.


--
-- Data for Name: core_configrevision; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_configrevision (id, created, comment, data, active) FROM stdin;
\.


--
-- Data for Name: core_datafile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_datafile (id, created, last_updated, path, size, hash, data, source_id) FROM stdin;
\.


--
-- Data for Name: core_datasource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_datasource (id, created, last_updated, custom_field_data, description, comments, name, type, source_url, status, enabled, ignore_rules, parameters, last_synced, sync_interval, owner_id) FROM stdin;
\.


--
-- Data for Name: core_job; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_job (id, object_id, name, created, scheduled, "interval", started, completed, status, data, job_id, object_type_id, user_id, error, log_entries, queue_name, notifications, execution_time) FROM stdin;
\.


--
-- Data for Name: core_managedfile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_managedfile (id, data_path, data_synced, created, last_updated, file_root, file_path, data_file_id, data_source_id, auto_sync_enabled) FROM stdin;
\.


--
-- Data for Name: core_objectchange; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_objectchange (id, "time", user_name, request_id, action, changed_object_id, related_object_id, object_repr, prechange_data, postchange_data, changed_object_type_id, related_object_type_id, user_id, message) FROM stdin;
\.


--
-- Data for Name: core_objecttype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_objecttype (contenttype_ptr_id, public, features) FROM stdin;
14	f	{}
15	f	{}
16	f	{}
17	f	{}
18	f	{}
19	f	{}
20	f	{}
21	f	{}
22	f	{}
23	f	{}
24	f	{}
25	f	{}
26	t	{}
27	t	{}
28	t	{}
29	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,jobs,journaling,notifications,tags}
30	t	{}
31	f	{}
6	f	{synced_data}
32	t	{}
33	f	{}
34	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
12	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,image_attachments,journaling,notifications,tags}
35	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
36	t	{change_logging,custom_fields,custom_validation,event_rules,export_templates,tags}
37	t	{change_logging,custom_fields,custom_links,custom_validation,event_rules,export_templates,tags}
38	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
39	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
11	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
40	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
41	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
42	t	{change_logging,custom_fields,custom_links,custom_validation,event_rules,export_templates,tags}
43	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
44	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
45	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
46	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
47	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
48	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
8	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
49	f	{change_logging}
50	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
51	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
52	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
53	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
54	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
55	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
56	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
57	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
58	t	{change_logging,custom_validation,event_rules}
59	f	{}
137	t	{change_logging,custom_fields,custom_validation,event_rules,export_templates,tags}
60	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,image_attachments,journaling,notifications,tags}
61	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
62	t	{change_logging,custom_validation,event_rules}
63	t	{change_logging,custom_validation,event_rules}
64	t	{change_logging,custom_validation,event_rules}
65	t	{change_logging,custom_validation,event_rules}
66	t	{change_logging,custom_validation,event_rules}
67	t	{change_logging,custom_validation,event_rules}
68	t	{change_logging,custom_validation,event_rules}
69	f	{change_logging}
70	t	{change_logging,custom_validation,event_rules}
71	t	{change_logging,custom_validation,event_rules}
72	t	{change_logging,custom_validation,event_rules}
73	t	{change_logging,custom_validation,event_rules}
74	t	{change_logging,custom_validation,event_rules}
75	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
76	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
77	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,image_attachments,journaling,notifications,tags}
78	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
79	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
80	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,image_attachments,journaling,notifications,tags}
81	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
82	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
9	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,image_attachments,journaling,notifications,tags}
83	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
84	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
85	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
86	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,image_attachments,journaling,notifications,tags}
87	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
88	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
89	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,image_attachments,journaling,notifications,tags}
90	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
91	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,image_attachments,journaling,notifications,tags}
92	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
93	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
94	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
1	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,image_attachments,journaling,notifications,tags}
95	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,image_attachments,journaling,notifications,tags}
96	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
97	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
98	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
99	t	{change_logging,custom_validation,event_rules}
100	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
101	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
102	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
103	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
104	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
105	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
106	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
107	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
108	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
109	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
110	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
111	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
112	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
113	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
114	t	{change_logging,cloning,custom_validation,event_rules,export_templates}
115	f	{}
116	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,synced_data,tags}
117	t	{change_logging,cloning,custom_links,custom_validation,event_rules,synced_data}
118	t	{change_logging,custom_links,custom_validation,event_rules,export_templates,synced_data,tags}
119	t	{change_logging,cloning,custom_validation,event_rules,export_templates}
120	t	{change_logging,cloning,custom_validation,event_rules,export_templates}
121	t	{}
122	t	{change_logging,custom_fields,custom_validation,event_rules,export_templates,tags}
2	t	{change_logging,custom_fields,custom_validation,event_rules,export_templates,tags}
123	t	{change_logging,cloning,custom_validation,event_rules,export_templates}
124	t	{change_logging,cloning,custom_validation,event_rules,export_templates,synced_data}
125	t	{change_logging,cloning,custom_validation,event_rules,export_templates}
126	t	{change_logging,cloning,custom_validation,event_rules}
127	t	{change_logging,custom_validation,event_rules}
128	t	{change_logging,custom_fields,custom_links,custom_validation,event_rules,export_templates,tags}
129	t	{}
130	t	{}
131	t	{change_logging,custom_validation,event_rules}
132	t	{}
3	t	{event_rules,jobs}
4	f	{jobs,synced_data}
133	f	{}
134	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
135	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
136	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
138	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
139	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
140	t	{bookmarks,cloning,custom_links,custom_validation,event_rules,export_templates,notifications}
141	t	{bookmarks,cloning,custom_links,custom_validation,event_rules,export_templates,notifications}
142	t	{cloning}
143	f	{}
144	t	{}
145	t	{}
146	t	{}
147	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
148	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
149	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
150	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,image_attachments,journaling,notifications,tags}
10	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,image_attachments,journaling,notifications,tags}
7	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
151	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
152	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
153	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
154	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
155	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
156	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
157	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
158	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
159	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
160	t	{bookmarks,change_logging,cloning,contacts,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
161	t	{change_logging,custom_fields,custom_links,custom_validation,event_rules,tags}
162	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
163	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
164	t	{bookmarks,change_logging,cloning,custom_fields,custom_links,custom_validation,event_rules,export_templates,journaling,notifications,tags}
13	f	{}
\.


--
-- Data for Name: dcim_cable; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_cable (created, last_updated, custom_field_data, id, type, status, label, color, length, length_unit, _abs_length, tenant_id, comments, description, owner_id, profile, bundle_id) FROM stdin;
\.


--
-- Data for Name: dcim_cablebundle; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_cablebundle (id, created, last_updated, custom_field_data, description, comments, name, owner_id) FROM stdin;
\.


--
-- Data for Name: dcim_cablepath; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_cablepath (id, _nodes, is_active, is_split, path, is_complete) FROM stdin;
\.


--
-- Data for Name: dcim_cabletermination; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_cabletermination (id, cable_end, termination_id, cable_id, termination_type_id, _device_id, _rack_id, _location_id, _site_id, created, last_updated, connector, positions) FROM stdin;
\.


--
-- Data for Name: dcim_consoleport; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_consoleport (created, last_updated, custom_field_data, id, name, label, description, mark_connected, type, speed, _path_id, cable_id, device_id, module_id, cable_end, _location_id, _rack_id, _site_id, owner_id, cable_connector, cable_positions) FROM stdin;
\.


--
-- Data for Name: dcim_consoleporttemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_consoleporttemplate (created, last_updated, id, name, label, description, type, device_type_id, module_type_id) FROM stdin;
\.


--
-- Data for Name: dcim_consoleserverport; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_consoleserverport (created, last_updated, custom_field_data, id, name, label, description, mark_connected, type, speed, _path_id, cable_id, device_id, module_id, cable_end, _location_id, _rack_id, _site_id, owner_id, cable_connector, cable_positions) FROM stdin;
\.


--
-- Data for Name: dcim_consoleserverporttemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_consoleserverporttemplate (created, last_updated, id, name, label, description, type, device_type_id, module_type_id) FROM stdin;
\.


--
-- Data for Name: dcim_coolingfeed; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_coolingfeed (id, created, last_updated, custom_field_data, max_flow, max_flow_unit, _abs_max_flow, description, comments, name, status, cooling_capacity, owner_id, rack_id, tenant_id, cooling_source_id) FROM stdin;
\.


--
-- Data for Name: dcim_coolingintake; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_coolingintake (id, created, last_updated, custom_field_data, diameter, diameter_unit, _abs_diameter, max_flow, max_flow_unit, _abs_max_flow, name, label, description, type, _location_id, _rack_id, _site_id, device_id, module_id, owner_id, cooling_outflow_id) FROM stdin;
\.


--
-- Data for Name: dcim_coolingintaketemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_coolingintaketemplate (id, created, last_updated, diameter, diameter_unit, _abs_diameter, max_flow, max_flow_unit, _abs_max_flow, name, label, description, type, device_type_id, module_type_id) FROM stdin;
\.


--
-- Data for Name: dcim_coolingoutflow; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_coolingoutflow (id, created, last_updated, custom_field_data, diameter, diameter_unit, _abs_diameter, name, label, description, type, _location_id, _rack_id, _site_id, device_id, module_id, owner_id, cooling_intake_id) FROM stdin;
\.


--
-- Data for Name: dcim_coolingoutflowtemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_coolingoutflowtemplate (id, created, last_updated, diameter, diameter_unit, _abs_diameter, name, label, description, type, device_type_id, module_type_id, cooling_intake_id) FROM stdin;
\.


--
-- Data for Name: dcim_coolingsource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_coolingsource (id, created, last_updated, custom_field_data, description, comments, name, type, status, fluid_type, cooling_capacity, location_id, owner_id, site_id) FROM stdin;
\.


--
-- Data for Name: dcim_device; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_device (created, last_updated, custom_field_data, id, local_context_data, name, serial, asset_tag, "position", face, status, vc_position, vc_priority, comments, cluster_id, role_id, device_type_id, location_id, platform_id, primary_ip4_id, primary_ip6_id, rack_id, site_id, tenant_id, virtual_chassis_id, airflow, description, config_template_id, latitude, longitude, oob_ip_id, console_port_count, console_server_port_count, power_port_count, power_outlet_count, interface_count, front_port_count, rear_port_count, device_bay_count, module_bay_count, inventory_item_count, owner_id, _config_context_data, _config_context_generation, cooling_method, cooling_outflow_count, cooling_intake_count) FROM stdin;
\.


--
-- Data for Name: dcim_devicebay; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_devicebay (created, last_updated, custom_field_data, id, name, label, description, device_id, installed_device_id, _location_id, _rack_id, _site_id, owner_id, enabled) FROM stdin;
\.


--
-- Data for Name: dcim_devicebaytemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_devicebaytemplate (created, last_updated, id, name, label, description, device_type_id, enabled) FROM stdin;
\.


--
-- Data for Name: dcim_devicerole; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_devicerole (created, last_updated, custom_field_data, id, name, slug, color, vm_role, description, config_template_id, parent_id, comments, owner_id, path, sort_path) FROM stdin;
\.


--
-- Data for Name: dcim_devicetype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_devicetype (created, last_updated, custom_field_data, id, model, slug, part_number, u_height, is_full_depth, subdevice_role, front_image, rear_image, comments, manufacturer_id, airflow, weight, weight_unit, _abs_weight, description, default_platform_id, console_port_template_count, console_server_port_template_count, power_port_template_count, power_outlet_template_count, interface_template_count, front_port_template_count, rear_port_template_count, device_bay_template_count, module_bay_template_count, inventory_item_template_count, exclude_from_utilization, owner_id, device_count, end_of_life, cooling_method, cooling_outflow_template_count, cooling_intake_template_count) FROM stdin;
\.


--
-- Data for Name: dcim_frontport; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_frontport (created, last_updated, custom_field_data, id, name, label, description, mark_connected, type, cable_id, device_id, color, module_id, cable_end, _location_id, _rack_id, _site_id, owner_id, cable_connector, cable_positions, positions) FROM stdin;
\.


--
-- Data for Name: dcim_frontporttemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_frontporttemplate (created, last_updated, id, name, label, description, type, device_type_id, color, module_type_id, positions) FROM stdin;
\.


--
-- Data for Name: dcim_interface; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_interface (created, last_updated, custom_field_data, id, name, label, description, mark_connected, enabled, mtu, mode, _name, type, mgmt_only, _path_id, cable_id, device_id, lag_id, parent_id, untagged_vlan_id, wwn, bridge_id, rf_role, rf_channel, rf_channel_frequency, rf_channel_width, tx_power, wireless_link_id, module_id, vrf_id, duplex, speed, poe_mode, poe_type, cable_end, vlan_translation_policy_id, qinq_svlan_id, primary_mac_address_id, _location_id, _rack_id, _site_id, owner_id, cable_connector, cable_positions, channel_id, channels) FROM stdin;
\.


--
-- Data for Name: dcim_interface_tagged_vlans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_interface_tagged_vlans (id, interface_id, vlan_id) FROM stdin;
\.


--
-- Data for Name: dcim_interface_vdcs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_interface_vdcs (id, interface_id, virtualdevicecontext_id) FROM stdin;
\.


--
-- Data for Name: dcim_interface_wireless_lans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_interface_wireless_lans (id, interface_id, wirelesslan_id) FROM stdin;
\.


--
-- Data for Name: dcim_interfacetemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_interfacetemplate (created, last_updated, id, name, label, description, _name, type, mgmt_only, device_type_id, module_type_id, poe_mode, poe_type, enabled, bridge_id, rf_role, parent_id, channel_id, channels) FROM stdin;
\.


--
-- Data for Name: dcim_inventoryitem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_inventoryitem (created, last_updated, custom_field_data, id, name, label, description, part_id, serial, asset_tag, discovered, device_id, manufacturer_id, parent_id, role_id, component_id, component_type_id, status, _location_id, _rack_id, _site_id, owner_id, path) FROM stdin;
\.


--
-- Data for Name: dcim_inventoryitemrole; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_inventoryitemrole (id, created, last_updated, custom_field_data, name, slug, color, description, owner_id, comments) FROM stdin;
\.


--
-- Data for Name: dcim_inventoryitemtemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_inventoryitemtemplate (id, created, last_updated, name, label, description, component_id, part_id, component_type_id, device_type_id, manufacturer_id, parent_id, role_id, path) FROM stdin;
\.


--
-- Data for Name: dcim_location; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_location (created, last_updated, custom_field_data, id, name, slug, description, parent_id, site_id, tenant_id, status, facility, comments, owner_id, path, sort_path) FROM stdin;
\.


--
-- Data for Name: dcim_macaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_macaddress (id, created, last_updated, custom_field_data, description, comments, mac_address, assigned_object_id, assigned_object_type_id, owner_id) FROM stdin;
\.


--
-- Data for Name: dcim_manufacturer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_manufacturer (created, last_updated, custom_field_data, id, name, slug, description, owner_id, comments) FROM stdin;
\.


--
-- Data for Name: dcim_module; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_module (id, created, last_updated, custom_field_data, serial, asset_tag, comments, device_id, module_bay_id, module_type_id, description, status, owner_id) FROM stdin;
\.


--
-- Data for Name: dcim_modulebay; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_modulebay (id, created, last_updated, custom_field_data, name, label, "position", description, device_id, module_id, parent_id, _location_id, _rack_id, _site_id, owner_id, enabled, path, sort_path) FROM stdin;
\.


--
-- Data for Name: dcim_modulebay_module_bay_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_modulebay_module_bay_types (id, modulebay_id, modulebaytype_id) FROM stdin;
\.


--
-- Data for Name: dcim_modulebaytemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_modulebaytemplate (id, created, last_updated, name, label, "position", description, device_type_id, module_type_id, enabled) FROM stdin;
\.


--
-- Data for Name: dcim_modulebaytemplate_module_bay_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_modulebaytemplate_module_bay_types (id, modulebaytemplate_id, modulebaytype_id) FROM stdin;
\.


--
-- Data for Name: dcim_modulebaytype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_modulebaytype (id, created, last_updated, custom_field_data, description, comments, name, slug, color, manufacturer_id, owner_id) FROM stdin;
\.


--
-- Data for Name: dcim_moduletype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_moduletype (id, created, last_updated, custom_field_data, model, part_number, comments, manufacturer_id, weight, weight_unit, _abs_weight, description, airflow, attribute_data, profile_id, owner_id, module_count, console_port_template_count, console_server_port_template_count, front_port_template_count, interface_template_count, module_bay_template_count, power_outlet_template_count, power_port_template_count, rear_port_template_count, end_of_life, cooling_method, cooling_outflow_template_count, cooling_intake_template_count) FROM stdin;
\.


--
-- Data for Name: dcim_moduletype_module_bay_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_moduletype_module_bay_types (id, moduletype_id, modulebaytype_id) FROM stdin;
\.


--
-- Data for Name: dcim_moduletypeprofile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_moduletypeprofile (id, created, last_updated, custom_field_data, description, comments, name, schema, owner_id) FROM stdin;
1	2026-11-11 00:18:17.498253+00	2026-11-11 00:18:17.498273+00	{}			CPU	{"properties": {"cores": {"type": "integer", "description": "Number of cores present"}, "speed": {"type": "number", "title": "Speed", "description": "Clock speed in GHz"}, "architecture": {"type": "string", "title": "Architecture"}}}	\N
2	2026-11-11 00:18:17.498262+00	2026-11-11 00:18:17.498275+00	{}			Fan	{"properties": {"rpm": {"type": "integer", "title": "RPM", "description": "Fan speed (RPM)"}}}	\N
3	2026-11-11 00:18:17.498265+00	2026-11-11 00:18:17.498276+00	{}			GPU	{"required": ["memory"], "properties": {"gpu": {"type": "string", "title": "GPU"}, "memory": {"type": "integer", "title": "Memory (GB)", "description": "Total memory capacity (in GB)"}, "interface": {"enum": ["PCIe 4.0", "PCIe 4.0 x8", "PCIe 4.0 x16", "PCIe 5.0 x16"], "type": "string"}}}	\N
4	2026-11-11 00:18:17.498266+00	2026-11-11 00:18:17.498277+00	{}			Hard disk	{"required": ["size"], "properties": {"size": {"type": "integer", "title": "Size (GB)", "description": "Raw disk capacity"}, "type": {"enum": ["HD", "SSD", "NVME"], "type": "string", "title": "Disk type", "default": "SSD"}, "speed": {"type": "integer", "title": "Speed (RPM)"}}}	\N
5	2026-11-11 00:18:17.498267+00	2026-11-11 00:18:17.498279+00	{}			Memory	{"required": ["class", "size"], "properties": {"ecc": {"type": "boolean", "title": "ECC", "description": "Error-correcting code is enabled"}, "size": {"type": "integer", "title": "Size (GB)", "description": "Raw capacity of the module"}, "class": {"enum": ["DDR3", "DDR4", "DDR5"], "type": "string", "title": "Memory class", "default": "DDR5"}, "data_rate": {"type": "integer", "title": "Data rate", "description": "Speed in MT/s"}}}	\N
6	2026-11-11 00:18:17.498269+00	2026-11-11 00:18:17.49828+00	{}			Power supply	{"required": ["input_current", "input_voltage"], "properties": {"wattage": {"type": "integer", "description": "Available output power (watts)"}, "hot_swappable": {"type": "boolean", "title": "Hot-swappable", "default": false}, "input_current": {"enum": ["AC", "DC"], "type": "string", "title": "Current type", "default": "AC"}, "input_voltage": {"type": "integer", "title": "Voltage", "default": 120}}}	\N
7	2026-11-11 00:18:17.49827+00	2026-11-11 00:18:17.498281+00	{}			Expansion card	{"properties": {"bandwidth": {"type": "integer", "description": "Total Bandwidth for this module"}, "connector_type": {"type": "string", "description": "Connector type e.g. PCIe x4"}}}	\N
8	2026-11-11 00:18:17.498271+00	2026-11-11 00:18:17.498282+00	{}			Transceiver	{"properties": {"phy": {"type": "string", "title": "PHY", "description": "Physical layer standard e.g. 10GBASE-LR, 400ZR"}, "media": {"type": "string", "title": "Media", "description": "Physical media e.g. single-mode fiber, multimode fiber, DAC"}, "reach": {"type": "number", "title": "Maximum reach (m)", "description": "Maximum supported distance in meters, or fixed assembly length for DAC and AOC cables"}, "data_rate": {"type": "string", "title": "Data rate", "description": "Nominal line rate e.g. 10G, 400G"}, "form_factor": {"type": "string", "title": "Form factor", "description": "Physical form factor e.g. SFP+, QSFP28, OSFP"}, "connector_type": {"type": "string", "title": "Connector type", "description": "Connector type e.g. LC/UPC, MPO-12, 8P8C"}}}	\N
\.


--
-- Data for Name: dcim_platform; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_platform (created, last_updated, custom_field_data, id, name, slug, description, manufacturer_id, config_template_id, parent_id, comments, owner_id, path, sort_path) FROM stdin;
\.


--
-- Data for Name: dcim_portmapping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_portmapping (id, front_port_position, rear_port_position, device_id, front_port_id, rear_port_id, created, last_updated) FROM stdin;
\.


--
-- Data for Name: dcim_porttemplatemapping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_porttemplatemapping (id, front_port_position, rear_port_position, device_type_id, module_type_id, front_port_id, rear_port_id, created, last_updated) FROM stdin;
\.


--
-- Data for Name: dcim_powerfeed; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_powerfeed (created, last_updated, custom_field_data, id, mark_connected, name, status, type, supply, phase, voltage, amperage, max_utilization, available_power, comments, _path_id, cable_id, power_panel_id, rack_id, cable_end, description, tenant_id, owner_id, cable_connector, cable_positions) FROM stdin;
\.


--
-- Data for Name: dcim_poweroutlet; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_poweroutlet (created, last_updated, custom_field_data, id, name, label, description, mark_connected, type, feed_leg, _path_id, cable_id, device_id, power_port_id, module_id, cable_end, color, status, _location_id, _rack_id, _site_id, owner_id, cable_connector, cable_positions) FROM stdin;
\.


--
-- Data for Name: dcim_poweroutlettemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_poweroutlettemplate (created, last_updated, id, name, label, description, type, feed_leg, device_type_id, power_port_id, module_type_id, color) FROM stdin;
\.


--
-- Data for Name: dcim_powerpanel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_powerpanel (created, last_updated, custom_field_data, id, name, location_id, site_id, comments, description, owner_id) FROM stdin;
\.


--
-- Data for Name: dcim_powerport; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_powerport (created, last_updated, custom_field_data, id, name, label, description, mark_connected, type, maximum_draw, allocated_draw, _path_id, cable_id, device_id, module_id, cable_end, _location_id, _rack_id, _site_id, owner_id, cable_connector, cable_positions) FROM stdin;
\.


--
-- Data for Name: dcim_powerporttemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_powerporttemplate (created, last_updated, id, name, label, description, type, maximum_draw, allocated_draw, device_type_id, module_type_id) FROM stdin;
\.


--
-- Data for Name: dcim_rack; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_rack (created, last_updated, custom_field_data, id, name, facility_id, status, serial, asset_tag, form_factor, width, u_height, desc_units, outer_width, outer_depth, outer_unit, comments, location_id, role_id, site_id, tenant_id, weight, max_weight, weight_unit, _abs_weight, _abs_max_weight, mounting_depth, description, starting_unit, rack_type_id, airflow, outer_height, owner_id, group_id, cooling_capability, cooling_capacity) FROM stdin;
\.


--
-- Data for Name: dcim_rackgroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_rackgroup (id, created, last_updated, custom_field_data, name, slug, description, comments, owner_id) FROM stdin;
\.


--
-- Data for Name: dcim_rackreservation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_rackreservation (created, last_updated, custom_field_data, id, units, description, rack_id, tenant_id, user_id, comments, status, owner_id) FROM stdin;
\.


--
-- Data for Name: dcim_rackrole; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_rackrole (created, last_updated, custom_field_data, id, name, slug, color, description, owner_id, comments) FROM stdin;
\.


--
-- Data for Name: dcim_racktype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_racktype (id, created, last_updated, custom_field_data, description, comments, weight, weight_unit, _abs_weight, manufacturer_id, model, slug, form_factor, width, u_height, starting_unit, desc_units, outer_width, outer_depth, outer_unit, max_weight, _abs_max_weight, mounting_depth, outer_height, owner_id, rack_count, cooling_capability, cooling_capacity) FROM stdin;
\.


--
-- Data for Name: dcim_rearport; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_rearport (created, last_updated, custom_field_data, id, name, label, description, mark_connected, type, positions, cable_id, device_id, color, module_id, cable_end, _location_id, _rack_id, _site_id, owner_id, cable_connector, cable_positions) FROM stdin;
\.


--
-- Data for Name: dcim_rearporttemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_rearporttemplate (created, last_updated, id, name, label, description, type, positions, device_type_id, color, module_type_id) FROM stdin;
\.


--
-- Data for Name: dcim_region; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_region (created, last_updated, custom_field_data, id, name, slug, description, parent_id, comments, owner_id, path, sort_path) FROM stdin;
\.


--
-- Data for Name: dcim_site; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_site (created, last_updated, custom_field_data, id, name, slug, status, facility, time_zone, description, physical_address, shipping_address, latitude, longitude, comments, group_id, region_id, tenant_id, owner_id) FROM stdin;
\.


--
-- Data for Name: dcim_site_asns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_site_asns (id, site_id, asn_id) FROM stdin;
\.


--
-- Data for Name: dcim_sitegroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_sitegroup (created, last_updated, custom_field_data, id, name, slug, description, parent_id, comments, owner_id, path, sort_path) FROM stdin;
\.


--
-- Data for Name: dcim_virtualchassis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_virtualchassis (created, last_updated, custom_field_data, id, name, domain, master_id, comments, description, member_count, owner_id) FROM stdin;
\.


--
-- Data for Name: dcim_virtualdevicecontext; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dcim_virtualdevicecontext (id, created, last_updated, custom_field_data, description, name, status, identifier, comments, device_id, primary_ip4_id, primary_ip6_id, tenant_id, owner_id) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
14	auth	permission
15	auth	group
16	contenttypes	contenttype
17	sessions	session
18	social_django	usersocialauth
19	social_django	nonce
20	social_django	association
21	social_django	code
22	social_django	partial
23	thumbnail	kvstore
24	taggit	tag
25	taggit	taggeditem
26	core	objecttype
27	core	objectchange
28	core	configrevision
29	core	datasource
30	core	datafile
31	core	autosyncrecord
6	core	managedfile
32	core	job
33	account	usertoken
34	circuits	circuittype
12	circuits	circuit
35	circuits	circuitgroup
36	circuits	circuitgroupassignment
37	circuits	circuittermination
38	circuits	provider
39	circuits	provideraccount
11	circuits	providernetwork
40	circuits	virtualcircuittype
41	circuits	virtualcircuit
42	circuits	virtualcircuittermination
43	dcim	consoleport
44	dcim	consoleserverport
45	dcim	powerport
46	dcim	poweroutlet
47	dcim	coolingintake
48	dcim	coolingoutflow
8	dcim	interface
49	dcim	portmapping
50	dcim	frontport
51	dcim	rearport
52	dcim	modulebay
53	dcim	devicebay
54	dcim	inventoryitemrole
55	dcim	inventoryitem
56	dcim	cablebundle
57	dcim	cable
58	dcim	cabletermination
59	dcim	cablepath
60	dcim	coolingsource
61	dcim	coolingfeed
62	dcim	consoleporttemplate
63	dcim	consoleserverporttemplate
64	dcim	powerporttemplate
65	dcim	poweroutlettemplate
66	dcim	coolingintaketemplate
67	dcim	coolingoutflowtemplate
68	dcim	interfacetemplate
69	dcim	porttemplatemapping
70	dcim	frontporttemplate
71	dcim	rearporttemplate
72	dcim	modulebaytemplate
73	dcim	devicebaytemplate
74	dcim	inventoryitemtemplate
75	dcim	modulebaytype
76	dcim	moduletypeprofile
77	dcim	moduletype
78	dcim	module
79	dcim	manufacturer
80	dcim	devicetype
81	dcim	devicerole
82	dcim	platform
9	dcim	device
83	dcim	virtualchassis
84	dcim	virtualdevicecontext
85	dcim	macaddress
86	dcim	powerpanel
87	dcim	powerfeed
88	dcim	rackgroup
89	dcim	racktype
90	dcim	rackrole
91	dcim	rack
92	dcim	rackreservation
93	dcim	region
94	dcim	sitegroup
1	dcim	site
95	dcim	location
96	ipam	asnrange
97	ipam	asn
98	ipam	fhrpgroup
99	ipam	fhrpgroupassignment
100	ipam	rir
101	ipam	aggregate
102	ipam	role
103	ipam	prefix
104	ipam	iprange
105	ipam	ipaddress
106	ipam	servicetemplate
107	ipam	service
108	ipam	vlangroup
109	ipam	vlan
110	ipam	vlantranslationpolicy
111	ipam	vlantranslationrule
112	ipam	vrf
113	ipam	routetarget
114	extras	tag
115	extras	taggeditem
116	extras	configcontextprofile
117	extras	configcontext
118	extras	configtemplate
119	extras	customfield
120	extras	customfieldchoiceset
121	extras	dashboard
122	extras	eventrule
2	extras	webhook
123	extras	customlink
124	extras	exporttemplate
125	extras	savedfilter
126	extras	tableconfig
127	extras	imageattachment
128	extras	journalentry
129	extras	bookmark
130	extras	notification
131	extras	notificationgroup
132	extras	subscription
3	extras	script
4	extras	scriptmodule
133	extras	cachedvalue
134	tenancy	contactgroup
135	tenancy	contactrole
136	tenancy	contact
137	tenancy	contactassignment
138	tenancy	tenantgroup
139	tenancy	tenant
140	users	ownergroup
141	users	owner
142	users	objectpermission
143	users	userconfig
144	users	token
145	users	group
146	users	user
147	virtualization	clustertype
148	virtualization	clustergroup
149	virtualization	cluster
150	virtualization	virtualmachinetype
7	virtualization	vminterface
13	django_rq	dashboard
10	virtualization	virtualmachine
151	virtualization	virtualdisk
152	vpn	ikeproposal
153	vpn	ikepolicy
154	vpn	ipsecproposal
155	vpn	ipsecpolicy
156	vpn	ipsecprofile
157	vpn	l2vpn
158	vpn	l2vpntermination
159	vpn	tunnelgroup
160	vpn	tunnel
161	vpn	tunneltermination
162	wireless	wirelesslangroup
163	wireless	wirelesslan
164	wireless	wirelesslink
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2026-11-11 00:17:27.798617+00
2	contenttypes	0002_remove_content_type_name	2026-11-11 00:17:27.802728+00
3	auth	0001_initial	2026-11-11 00:17:27.811954+00
4	auth	0002_alter_permission_name_max_length	2026-11-11 00:17:27.81382+00
5	auth	0003_alter_user_email_max_length	2026-11-11 00:17:27.81555+00
6	auth	0004_alter_user_username_opts	2026-11-11 00:17:27.817146+00
7	auth	0005_alter_user_last_login_null	2026-11-11 00:17:27.818615+00
8	auth	0006_require_contenttypes_0002	2026-11-11 00:17:27.81903+00
9	auth	0007_alter_validators_add_error_messages	2026-11-11 00:17:27.820369+00
10	auth	0008_alter_user_username_max_length	2026-11-11 00:17:27.82177+00
11	auth	0009_alter_user_last_name_max_length	2026-11-11 00:17:27.823137+00
12	auth	0010_alter_group_name_max_length	2026-11-11 00:17:27.825244+00
13	auth	0011_update_proxy_permissions	2026-11-11 00:17:27.826992+00
14	auth	0012_alter_user_first_name_max_length	2026-11-11 00:17:27.828531+00
15	users	0001_api_tokens	2026-11-11 00:17:27.863524+00
16	users	0002_unicode_literals	2026-11-11 00:17:27.864113+00
17	users	0003_token_permissions	2026-11-11 00:17:27.864468+00
18	users	0004_standardize_description	2026-11-11 00:17:27.864892+00
19	users	0005_userconfig	2026-11-11 00:17:27.865299+00
20	users	0006_create_userconfigs	2026-11-11 00:17:27.865696+00
21	users	0007_proxy_group_user	2026-11-11 00:17:27.866049+00
22	users	0008_objectpermission	2026-11-11 00:17:27.866385+00
23	users	0009_replicate_permissions	2026-11-11 00:17:27.866711+00
24	users	0010_update_jsonfield	2026-11-11 00:17:27.86702+00
25	users	0011_standardize_models	2026-11-11 00:17:27.86728+00
26	users	0001_squashed_0011	2026-11-11 00:17:27.867531+00
27	users	0002_standardize_id_fields	2026-11-11 00:17:27.883721+00
28	users	0003_token_allowed_ips_last_used	2026-11-11 00:17:27.883987+00
29	users	0004_netboxgroup_netboxuser	2026-11-11 00:17:27.884152+00
30	users	0002_squashed_0004	2026-11-11 00:17:27.884286+00
31	account	0001_initial	2026-11-11 00:17:27.885632+00
32	extras	0001_initial	2026-11-11 00:17:27.962457+00
33	extras	0001_squashed	2026-11-11 00:17:27.963071+00
34	tenancy	0001_initial	2026-11-11 00:17:27.978676+00
35	tenancy	0002_tenant_group_optional	2026-11-11 00:17:27.979155+00
36	tenancy	0003_unicode_literals	2026-11-11 00:17:27.97953+00
37	tenancy	0004_tags	2026-11-11 00:17:27.979862+00
38	tenancy	0005_change_logging	2026-11-11 00:17:27.980182+00
39	tenancy	0006_custom_tag_models	2026-11-11 00:17:27.980452+00
40	tenancy	0007_nested_tenantgroups	2026-11-11 00:17:27.980728+00
41	tenancy	0008_nested_tenantgroups_rebuild	2026-11-11 00:17:27.981003+00
42	tenancy	0009_standardize_description	2026-11-11 00:17:27.981305+00
43	tenancy	0010_custom_field_data	2026-11-11 00:17:27.98162+00
44	tenancy	0011_standardize_name_length	2026-11-11 00:17:27.981904+00
45	tenancy	0012_standardize_models	2026-11-11 00:17:27.982225+00
46	tenancy	0001_squashed_0012	2026-11-11 00:17:27.982528+00
47	dcim	0001_initial	2026-11-11 00:17:28.103974+00
48	dcim	0001_squashed	2026-11-11 00:17:28.105+00
49	dcim	0002_auto_20160622_1821	2026-11-11 00:17:28.701109+00
50	dcim	0002_squashed	2026-11-11 00:17:28.701624+00
51	ipam	0001_initial	2026-11-11 00:17:28.794786+00
52	ipam	0001_squashed	2026-11-11 00:17:28.795468+00
53	virtualization	0001_virtualization	2026-11-11 00:17:28.946734+00
54	virtualization	0002_virtualmachine_add_status	2026-11-11 00:17:28.947389+00
55	virtualization	0003_cluster_add_site	2026-11-11 00:17:28.947816+00
56	virtualization	0004_virtualmachine_add_role	2026-11-11 00:17:28.948201+00
57	virtualization	0005_django2	2026-11-11 00:17:28.948691+00
58	virtualization	0006_tags	2026-11-11 00:17:28.949016+00
59	virtualization	0007_change_logging	2026-11-11 00:17:28.949258+00
60	virtualization	0008_virtualmachine_local_context_data	2026-11-11 00:17:28.949496+00
61	virtualization	0009_custom_tag_models	2026-11-11 00:17:28.949907+00
62	virtualization	0010_cluster_add_tenant	2026-11-11 00:17:28.950292+00
63	virtualization	0011_3569_virtualmachine_fields	2026-11-11 00:17:28.950626+00
64	virtualization	0012_vm_name_nonunique	2026-11-11 00:17:28.951147+00
65	virtualization	0013_deterministic_ordering	2026-11-11 00:17:28.951427+00
66	virtualization	0014_standardize_description	2026-11-11 00:17:28.951722+00
67	virtualization	0015_vminterface	2026-11-11 00:17:28.952047+00
68	virtualization	0016_replicate_interfaces	2026-11-11 00:17:28.952357+00
69	virtualization	0017_update_jsonfield	2026-11-11 00:17:28.952661+00
70	virtualization	0018_custom_field_data	2026-11-11 00:17:28.952985+00
71	virtualization	0019_standardize_name_length	2026-11-11 00:17:28.953223+00
72	virtualization	0020_standardize_models	2026-11-11 00:17:28.953463+00
73	virtualization	0021_virtualmachine_vcpus_decimal	2026-11-11 00:17:28.953732+00
74	virtualization	0022_vminterface_parent	2026-11-11 00:17:28.953962+00
75	virtualization	0001_squashed_0022	2026-11-11 00:17:28.95418+00
76	extras	0002_custom_fields	2026-11-11 00:17:29.318623+00
77	extras	0003_exporttemplate_add_description	2026-11-11 00:17:29.319232+00
78	extras	0004_topologymap_change_comma_to_semicolon	2026-11-11 00:17:29.319587+00
79	extras	0005_useraction_add_bulk_create	2026-11-11 00:17:29.319955+00
80	extras	0006_add_imageattachments	2026-11-11 00:17:29.320458+00
81	extras	0007_unicode_literals	2026-11-11 00:17:29.320994+00
82	extras	0008_reports	2026-11-11 00:17:29.321412+00
83	extras	0009_topologymap_type	2026-11-11 00:17:29.321706+00
84	extras	0010_customfield_filter_logic	2026-11-11 00:17:29.321947+00
85	extras	0011_django2	2026-11-11 00:17:29.322182+00
86	extras	0012_webhooks	2026-11-11 00:17:29.322399+00
87	extras	0013_objectchange	2026-11-11 00:17:29.322668+00
88	extras	0014_configcontexts	2026-11-11 00:17:29.322896+00
89	extras	0015_remove_useraction	2026-11-11 00:17:29.323116+00
90	extras	0016_exporttemplate_add_cable	2026-11-11 00:17:29.323321+00
91	extras	0017_exporttemplate_mime_type_length	2026-11-11 00:17:29.32353+00
92	extras	0018_exporttemplate_add_jinja2	2026-11-11 00:17:29.323762+00
93	extras	0019_tag_taggeditem	2026-11-11 00:17:29.323975+00
94	extras	0020_tag_data	2026-11-11 00:17:29.324184+00
95	extras	0021_add_color_comments_changelog_to_tag	2026-11-11 00:17:29.324387+00
96	extras	0022_custom_links	2026-11-11 00:17:29.324638+00
97	extras	0023_fix_tag_sequences	2026-11-11 00:17:29.324958+00
98	extras	0024_scripts	2026-11-11 00:17:29.32525+00
99	extras	0025_objectchange_time_index	2026-11-11 00:17:29.325497+00
100	extras	0026_webhook_ca_file_path	2026-11-11 00:17:29.325813+00
101	extras	0027_webhook_additional_headers	2026-11-11 00:17:29.326137+00
102	extras	0028_remove_topology_maps	2026-11-11 00:17:29.326379+00
103	extras	0029_3569_customfield_fields	2026-11-11 00:17:29.326673+00
104	extras	0030_3569_objectchange_fields	2026-11-11 00:17:29.326923+00
105	extras	0031_3569_exporttemplate_fields	2026-11-11 00:17:29.327153+00
106	extras	0032_3569_webhook_fields	2026-11-11 00:17:29.327411+00
107	extras	0033_graph_type_template_language	2026-11-11 00:17:29.327679+00
108	extras	0034_configcontext_tags	2026-11-11 00:17:29.327965+00
109	extras	0035_deterministic_ordering	2026-11-11 00:17:29.328253+00
110	extras	0036_contenttype_filters_to_q_objects	2026-11-11 00:17:29.328492+00
111	extras	0037_configcontexts_clusters	2026-11-11 00:17:29.328834+00
112	extras	0038_webhook_template_support	2026-11-11 00:17:29.329154+00
113	extras	0039_update_features_content_types	2026-11-11 00:17:29.329394+00
114	extras	0040_standardize_description	2026-11-11 00:17:29.329607+00
115	extras	0041_tag_description	2026-11-11 00:17:29.32984+00
116	extras	0042_customfield_manager	2026-11-11 00:17:29.33006+00
117	extras	0043_report	2026-11-11 00:17:29.330272+00
118	extras	0044_jobresult	2026-11-11 00:17:29.330476+00
119	extras	0045_configcontext_changelog	2026-11-11 00:17:29.330695+00
120	extras	0046_update_jsonfield	2026-11-11 00:17:29.330919+00
121	extras	0047_tag_ordering	2026-11-11 00:17:29.331144+00
122	extras	0048_exporttemplate_remove_template_language	2026-11-11 00:17:29.331359+00
123	extras	0049_remove_graph	2026-11-11 00:17:29.331565+00
124	extras	0050_customfield_changes	2026-11-11 00:17:29.331782+00
125	extras	0051_migrate_customfields	2026-11-11 00:17:29.332037+00
126	extras	0052_customfield_cleanup	2026-11-11 00:17:29.332289+00
127	extras	0053_rename_webhook_obj_type	2026-11-11 00:17:29.332515+00
128	extras	0054_standardize_models	2026-11-11 00:17:29.332753+00
129	extras	0055_objectchange_data	2026-11-11 00:17:29.332969+00
130	extras	0056_extend_configcontext	2026-11-11 00:17:29.333184+00
131	extras	0057_customlink_rename_fields	2026-11-11 00:17:29.333393+00
132	extras	0058_journalentry	2026-11-11 00:17:29.333646+00
133	extras	0059_exporttemplate_as_attachment	2026-11-11 00:17:29.333882+00
134	extras	0002_squashed_0059	2026-11-11 00:17:29.334093+00
135	dcim	0003_auto_20160628_1721	2026-11-11 00:17:31.046795+00
136	dcim	0004_auto_20160701_2049	2026-11-11 00:17:31.047586+00
137	dcim	0005_auto_20160706_1722	2026-11-11 00:17:31.0479+00
138	dcim	0006_add_device_primary_ip4_ip6	2026-11-11 00:17:31.04816+00
139	dcim	0007_device_copy_primary_ip	2026-11-11 00:17:31.048404+00
140	dcim	0008_device_remove_primary_ip	2026-11-11 00:17:31.048653+00
141	dcim	0009_site_32bit_asn_support	2026-11-11 00:17:31.048894+00
142	dcim	0010_devicebay_installed_device_set_null	2026-11-11 00:17:31.049114+00
143	dcim	0011_devicetype_part_number	2026-11-11 00:17:31.049335+00
144	dcim	0012_site_rack_device_add_tenant	2026-11-11 00:17:31.04962+00
145	dcim	0013_add_interface_form_factors	2026-11-11 00:17:31.0499+00
146	dcim	0014_rack_add_type_width	2026-11-11 00:17:31.050135+00
147	dcim	0015_rack_add_u_height_validator	2026-11-11 00:17:31.050354+00
148	dcim	0016_module_add_manufacturer	2026-11-11 00:17:31.050565+00
149	dcim	0017_rack_add_role	2026-11-11 00:17:31.050877+00
150	dcim	0018_device_add_asset_tag	2026-11-11 00:17:31.051241+00
151	dcim	0019_new_iface_form_factors	2026-11-11 00:17:31.051525+00
152	dcim	0020_rack_desc_units	2026-11-11 00:17:31.051794+00
153	dcim	0021_add_ff_flexstack	2026-11-11 00:17:31.052017+00
154	dcim	0022_color_names_to_rgb	2026-11-11 00:17:31.052239+00
155	dcim	0023_devicetype_comments	2026-11-11 00:17:31.052473+00
156	dcim	0024_site_add_contact_fields	2026-11-11 00:17:31.052721+00
157	dcim	0025_devicetype_add_interface_ordering	2026-11-11 00:17:31.052943+00
158	dcim	0026_add_rack_reservations	2026-11-11 00:17:31.053164+00
159	dcim	0027_device_add_site	2026-11-11 00:17:31.053387+00
160	dcim	0028_device_copy_rack_to_site	2026-11-11 00:17:31.053628+00
161	dcim	0029_allow_rackless_devices	2026-11-11 00:17:31.053862+00
162	dcim	0030_interface_add_lag	2026-11-11 00:17:31.054096+00
163	dcim	0031_regions	2026-11-11 00:17:31.054336+00
164	dcim	0032_device_increase_name_length	2026-11-11 00:17:31.054574+00
165	dcim	0033_rackreservation_rack_editable	2026-11-11 00:17:31.05483+00
166	dcim	0034_rename_module_to_inventoryitem	2026-11-11 00:17:31.05511+00
167	dcim	0035_device_expand_status_choices	2026-11-11 00:17:31.055349+00
168	dcim	0036_add_ff_juniper_vcp	2026-11-11 00:17:31.055602+00
169	dcim	0037_unicode_literals	2026-11-11 00:17:31.055875+00
170	dcim	0038_wireless_interfaces	2026-11-11 00:17:31.0561+00
171	dcim	0039_interface_add_enabled_mtu	2026-11-11 00:17:31.05632+00
172	dcim	0040_inventoryitem_add_asset_tag_description	2026-11-11 00:17:31.056534+00
173	dcim	0041_napalm_integration	2026-11-11 00:17:31.056762+00
174	dcim	0042_interface_ff_10ge_cx4	2026-11-11 00:17:31.05706+00
175	dcim	0043_device_component_name_lengths	2026-11-11 00:17:31.057304+00
176	dcim	0044_virtualization	2026-11-11 00:17:31.057517+00
177	dcim	0045_devicerole_vm_role	2026-11-11 00:17:31.057755+00
178	dcim	0046_rack_lengthen_facility_id	2026-11-11 00:17:31.057992+00
179	dcim	0047_more_100ge_form_factors	2026-11-11 00:17:31.058206+00
180	dcim	0048_rack_serial	2026-11-11 00:17:31.058412+00
181	dcim	0049_rackreservation_change_user	2026-11-11 00:17:31.058634+00
182	dcim	0050_interface_vlan_tagging	2026-11-11 00:17:31.058878+00
183	dcim	0051_rackreservation_tenant	2026-11-11 00:17:31.059125+00
184	dcim	0052_virtual_chassis	2026-11-11 00:17:31.059357+00
185	dcim	0053_platform_manufacturer	2026-11-11 00:17:31.0596+00
186	dcim	0054_site_status_timezone_description	2026-11-11 00:17:31.059834+00
187	dcim	0055_virtualchassis_ordering	2026-11-11 00:17:31.060057+00
188	dcim	0056_django2	2026-11-11 00:17:31.060284+00
189	dcim	0057_tags	2026-11-11 00:17:31.060517+00
190	dcim	0058_relax_rack_naming_constraints	2026-11-11 00:17:31.060744+00
191	dcim	0059_site_latitude_longitude	2026-11-11 00:17:31.060969+00
192	dcim	0060_change_logging	2026-11-11 00:17:31.061197+00
193	dcim	0061_platform_napalm_args	2026-11-11 00:17:31.061409+00
194	dcim	0062_interface_mtu	2026-11-11 00:17:31.061628+00
195	dcim	0063_device_local_context_data	2026-11-11 00:17:31.061829+00
196	dcim	0064_remove_platform_rpc_client	2026-11-11 00:17:31.062028+00
197	dcim	0065_front_rear_ports	2026-11-11 00:17:31.062228+00
198	dcim	0066_cables	2026-11-11 00:17:31.062425+00
199	dcim	0067_device_type_remove_qualifiers	2026-11-11 00:17:31.062701+00
200	dcim	0068_rack_new_fields	2026-11-11 00:17:31.062952+00
201	dcim	0069_deprecate_nullablecharfield	2026-11-11 00:17:31.063163+00
202	dcim	0070_custom_tag_models	2026-11-11 00:17:31.063377+00
203	dcim	0071_device_components_add_description	2026-11-11 00:17:31.063675+00
204	dcim	0072_powerfeeds	2026-11-11 00:17:31.064039+00
205	dcim	0073_interface_form_factor_to_type	2026-11-11 00:17:31.064289+00
206	dcim	0074_increase_field_length_platform_name_slug	2026-11-11 00:17:31.064533+00
207	dcim	0075_cable_devices	2026-11-11 00:17:31.064801+00
208	dcim	0076_console_port_types	2026-11-11 00:17:31.065066+00
209	dcim	0077_power_types	2026-11-11 00:17:31.065308+00
210	dcim	0078_3569_site_fields	2026-11-11 00:17:31.06559+00
211	dcim	0079_3569_rack_fields	2026-11-11 00:17:31.065875+00
212	dcim	0080_3569_devicetype_fields	2026-11-11 00:17:31.066103+00
213	dcim	0081_3569_device_fields	2026-11-11 00:17:31.066317+00
214	dcim	0082_3569_interface_fields	2026-11-11 00:17:31.066531+00
215	dcim	0082_3569_port_fields	2026-11-11 00:17:31.066791+00
216	dcim	0083_3569_cable_fields	2026-11-11 00:17:31.067074+00
217	dcim	0084_3569_powerfeed_fields	2026-11-11 00:17:31.067341+00
218	dcim	0085_3569_poweroutlet_fields	2026-11-11 00:17:31.067634+00
219	dcim	0086_device_name_nonunique	2026-11-11 00:17:31.067968+00
220	dcim	0087_role_descriptions	2026-11-11 00:17:31.068275+00
221	dcim	0088_powerfeed_available_power	2026-11-11 00:17:31.068569+00
222	dcim	0089_deterministic_ordering	2026-11-11 00:17:31.068858+00
223	dcim	0090_cable_termination_models	2026-11-11 00:17:31.069134+00
224	dcim	0091_interface_type_other	2026-11-11 00:17:31.069406+00
225	dcim	0092_fix_rack_outer_unit	2026-11-11 00:17:31.069686+00
226	dcim	0093_device_component_ordering	2026-11-11 00:17:31.069974+00
227	dcim	0094_device_component_template_ordering	2026-11-11 00:17:31.070228+00
228	dcim	0095_primary_model_ordering	2026-11-11 00:17:31.07047+00
229	dcim	0096_interface_ordering	2026-11-11 00:17:31.070902+00
230	dcim	0097_interfacetemplate_type_other	2026-11-11 00:17:31.071366+00
231	dcim	0098_devicetype_images	2026-11-11 00:17:31.071875+00
232	dcim	0099_powerfeed_negative_voltage	2026-11-11 00:17:31.072167+00
233	dcim	0100_mptt_remove_indexes	2026-11-11 00:17:31.072429+00
234	dcim	0101_nested_rackgroups	2026-11-11 00:17:31.072661+00
235	dcim	0102_nested_rackgroups_rebuild	2026-11-11 00:17:31.072966+00
236	dcim	0103_standardize_description	2026-11-11 00:17:31.073258+00
237	dcim	0104_correct_infiniband_types	2026-11-11 00:17:31.073525+00
238	dcim	0105_interface_name_collation	2026-11-11 00:17:31.073819+00
239	dcim	0106_role_default_color	2026-11-11 00:17:31.074109+00
240	dcim	0107_component_labels	2026-11-11 00:17:31.074366+00
241	dcim	0108_add_tags	2026-11-11 00:17:31.074642+00
242	dcim	0109_interface_remove_vm	2026-11-11 00:17:31.0749+00
243	dcim	0110_virtualchassis_name	2026-11-11 00:17:31.075163+00
244	dcim	0111_component_template_description	2026-11-11 00:17:31.075406+00
245	dcim	0112_standardize_components	2026-11-11 00:17:31.07568+00
246	dcim	0113_nullbooleanfield_to_booleanfield	2026-11-11 00:17:31.075957+00
247	dcim	0114_update_jsonfield	2026-11-11 00:17:31.076215+00
248	dcim	0115_rackreservation_order	2026-11-11 00:17:31.076512+00
249	dcim	0116_rearport_max_positions	2026-11-11 00:17:31.076802+00
250	dcim	0117_custom_field_data	2026-11-11 00:17:31.077088+00
251	dcim	0118_inventoryitem_mptt	2026-11-11 00:17:31.077359+00
252	dcim	0119_inventoryitem_mptt_rebuild	2026-11-11 00:17:31.07762+00
253	dcim	0120_cache_cable_peer	2026-11-11 00:17:31.077857+00
254	dcim	0121_cablepath	2026-11-11 00:17:31.078073+00
255	dcim	0122_standardize_name_length	2026-11-11 00:17:31.078309+00
256	dcim	0123_standardize_models	2026-11-11 00:17:31.078573+00
257	dcim	0124_mark_connected	2026-11-11 00:17:31.078855+00
258	dcim	0125_console_port_speed	2026-11-11 00:17:31.079115+00
259	dcim	0126_rename_rackgroup_location	2026-11-11 00:17:31.079379+00
260	dcim	0127_device_location	2026-11-11 00:17:31.079649+00
261	dcim	0128_device_location_populate	2026-11-11 00:17:31.079887+00
262	dcim	0129_interface_parent	2026-11-11 00:17:31.0801+00
263	dcim	0130_sitegroup	2026-11-11 00:17:31.080315+00
264	dcim	0003_squashed_0130	2026-11-11 00:17:31.080541+00
265	ipam	0002_vrf_add_enforce_unique	2026-11-11 00:17:31.582314+00
266	ipam	0003_ipam_add_vlangroups	2026-11-11 00:17:31.582971+00
267	ipam	0004_ipam_vlangroup_uniqueness	2026-11-11 00:17:31.583447+00
268	ipam	0005_auto_20160725_1842	2026-11-11 00:17:31.583856+00
269	ipam	0006_vrf_vlan_add_tenant	2026-11-11 00:17:31.584137+00
270	ipam	0007_prefix_ipaddress_add_tenant	2026-11-11 00:17:31.584368+00
271	ipam	0008_prefix_change_order	2026-11-11 00:17:31.58464+00
272	ipam	0009_ipaddress_add_status	2026-11-11 00:17:31.584955+00
273	ipam	0010_ipaddress_help_texts	2026-11-11 00:17:31.585272+00
274	ipam	0011_rir_add_is_private	2026-11-11 00:17:31.585539+00
275	ipam	0012_services	2026-11-11 00:17:31.585793+00
276	ipam	0013_prefix_add_is_pool	2026-11-11 00:17:31.586041+00
277	ipam	0014_ipaddress_status_add_deprecated	2026-11-11 00:17:31.586283+00
278	ipam	0015_global_vlans	2026-11-11 00:17:31.586521+00
279	ipam	0016_unicode_literals	2026-11-11 00:17:31.586777+00
280	ipam	0017_ipaddress_roles	2026-11-11 00:17:31.587024+00
281	ipam	0018_remove_service_uniqueness_constraint	2026-11-11 00:17:31.587241+00
282	ipam	0019_virtualization	2026-11-11 00:17:31.587454+00
283	ipam	0020_ipaddress_add_role_carp	2026-11-11 00:17:31.587682+00
284	ipam	0021_vrf_ordering	2026-11-11 00:17:31.587909+00
285	ipam	0022_tags	2026-11-11 00:17:31.588125+00
286	ipam	0023_change_logging	2026-11-11 00:17:31.588336+00
287	ipam	0024_vrf_allow_null_rd	2026-11-11 00:17:31.588575+00
288	ipam	0025_custom_tag_models	2026-11-11 00:17:31.588834+00
289	ipam	0026_prefix_ordering_vrf_nulls_first	2026-11-11 00:17:31.589121+00
290	ipam	0027_ipaddress_add_dns_name	2026-11-11 00:17:31.58936+00
291	ipam	0028_3569_prefix_fields	2026-11-11 00:17:31.589589+00
292	ipam	0029_3569_ipaddress_fields	2026-11-11 00:17:31.589821+00
293	ipam	0030_3569_vlan_fields	2026-11-11 00:17:31.590029+00
294	ipam	0031_3569_service_fields	2026-11-11 00:17:31.590239+00
295	ipam	0032_role_description	2026-11-11 00:17:31.590466+00
296	ipam	0033_deterministic_ordering	2026-11-11 00:17:31.59077+00
297	ipam	0034_fix_ipaddress_status_dhcp	2026-11-11 00:17:31.591006+00
298	ipam	0035_drop_ip_family	2026-11-11 00:17:31.591222+00
299	ipam	0036_standardize_description	2026-11-11 00:17:31.591432+00
300	ipam	0037_ipaddress_assignment	2026-11-11 00:17:31.591651+00
301	ipam	0038_custom_field_data	2026-11-11 00:17:31.591902+00
302	ipam	0039_service_ports_array	2026-11-11 00:17:31.592135+00
303	ipam	0040_service_drop_port	2026-11-11 00:17:31.592346+00
304	ipam	0041_routetarget	2026-11-11 00:17:31.592578+00
305	ipam	0042_standardize_name_length	2026-11-11 00:17:31.592918+00
509	ipam	0071_prefix_scope	2026-11-11 00:17:55.004107+00
306	ipam	0043_add_tenancy_to_aggregates	2026-11-11 00:17:31.593193+00
307	ipam	0044_standardize_models	2026-11-11 00:17:31.593494+00
308	ipam	0045_vlangroup_scope	2026-11-11 00:17:31.593808+00
309	ipam	0046_set_vlangroup_scope_types	2026-11-11 00:17:31.594098+00
310	ipam	0002_squashed_0046	2026-11-11 00:17:31.59435+00
311	ipam	0047_prefix_depth_children	2026-11-11 00:17:31.861202+00
312	ipam	0048_prefix_populate_depth_children	2026-11-11 00:17:31.861839+00
313	ipam	0049_prefix_mark_utilized	2026-11-11 00:17:31.862319+00
314	ipam	0050_iprange	2026-11-11 00:17:31.862744+00
315	ipam	0051_extend_tag_support	2026-11-11 00:17:31.863206+00
316	ipam	0052_fhrpgroup	2026-11-11 00:17:31.863599+00
317	ipam	0053_asn_model	2026-11-11 00:17:31.863931+00
318	ipam	0047_squashed_0053	2026-11-11 00:17:31.864229+00
319	tenancy	0002_tenant_ordering	2026-11-11 00:17:32.552329+00
320	tenancy	0003_contacts	2026-11-11 00:17:32.553001+00
321	tenancy	0004_extend_tag_support	2026-11-11 00:17:32.553376+00
322	tenancy	0005_standardize_id_fields	2026-11-11 00:17:32.553755+00
323	tenancy	0006_created_datetimefield	2026-11-11 00:17:32.554086+00
324	tenancy	0007_contact_link	2026-11-11 00:17:32.554359+00
325	tenancy	0008_unique_constraints	2026-11-11 00:17:32.554681+00
326	tenancy	0009_standardize_description_comments	2026-11-11 00:17:32.554944+00
327	tenancy	0010_tenant_relax_uniqueness	2026-11-11 00:17:32.555179+00
328	tenancy	0011_contactassignment_tags	2026-11-11 00:17:32.555393+00
329	tenancy	0002_squashed_0011	2026-11-11 00:17:32.555617+00
330	wireless	0001_wireless	2026-11-11 00:17:32.818845+00
331	wireless	0002_standardize_id_fields	2026-11-11 00:17:32.819448+00
332	wireless	0003_created_datetimefield	2026-11-11 00:17:32.819865+00
333	wireless	0004_wireless_tenancy	2026-11-11 00:17:32.820209+00
334	wireless	0005_wirelesslink_interface_types	2026-11-11 00:17:32.820562+00
335	wireless	0006_unique_constraints	2026-11-11 00:17:32.821038+00
336	wireless	0007_standardize_description_comments	2026-11-11 00:17:32.821406+00
337	wireless	0008_wirelesslan_status	2026-11-11 00:17:32.821805+00
338	wireless	0001_squashed_0008	2026-11-11 00:17:32.822238+00
339	dcim	0131_consoleport_speed	2026-11-11 00:17:39.157727+00
340	dcim	0132_cable_length	2026-11-11 00:17:39.159074+00
341	dcim	0133_port_colors	2026-11-11 00:17:39.159508+00
342	dcim	0134_interface_wwn_bridge	2026-11-11 00:17:39.15987+00
343	dcim	0135_tenancy_extensions	2026-11-11 00:17:39.160219+00
344	dcim	0136_device_airflow	2026-11-11 00:17:39.160583+00
345	dcim	0137_relax_uniqueness_constraints	2026-11-11 00:17:39.161152+00
346	dcim	0138_extend_tag_support	2026-11-11 00:17:39.16177+00
347	dcim	0139_rename_cable_peer	2026-11-11 00:17:39.16215+00
348	dcim	0140_wireless	2026-11-11 00:17:39.162491+00
349	dcim	0141_asn_model	2026-11-11 00:17:39.162777+00
350	dcim	0142_rename_128gfc_qsfp28	2026-11-11 00:17:39.163052+00
351	dcim	0143_remove_primary_for_related_name	2026-11-11 00:17:39.163318+00
352	dcim	0144_fix_cable_abs_length	2026-11-11 00:17:39.163635+00
353	dcim	0145_site_remove_deprecated_fields	2026-11-11 00:17:39.16397+00
354	dcim	0146_modules	2026-11-11 00:17:39.16423+00
355	dcim	0147_inventoryitemrole	2026-11-11 00:17:39.164468+00
356	dcim	0148_inventoryitem_component	2026-11-11 00:17:39.164701+00
357	dcim	0149_inventoryitem_templates	2026-11-11 00:17:39.164957+00
358	dcim	0150_interface_vrf	2026-11-11 00:17:39.165192+00
359	dcim	0151_interface_speed_duplex	2026-11-11 00:17:39.165415+00
360	dcim	0152_standardize_id_fields	2026-11-11 00:17:39.165641+00
361	dcim	0153_created_datetimefield	2026-11-11 00:17:39.165881+00
362	dcim	0154_half_height_rack_units	2026-11-11 00:17:39.166095+00
363	dcim	0155_interface_poe_mode_type	2026-11-11 00:17:39.166303+00
364	dcim	0156_location_status	2026-11-11 00:17:39.166536+00
365	dcim	0157_new_cabling_models	2026-11-11 00:17:39.166823+00
366	dcim	0158_populate_cable_terminations	2026-11-11 00:17:39.167079+00
367	dcim	0159_populate_cable_paths	2026-11-11 00:17:39.167308+00
368	dcim	0131_squashed_0159	2026-11-11 00:17:39.167557+00
369	circuits	0001_initial	2026-11-11 00:17:39.183146+00
370	circuits	0001_squashed	2026-11-11 00:17:39.183614+00
371	circuits	0002_auto_20160622_1821	2026-11-11 00:17:39.885428+00
372	circuits	0003_provider_32bit_asn_support	2026-11-11 00:17:39.886124+00
373	circuits	0004_circuit_add_tenant	2026-11-11 00:17:39.886896+00
374	circuits	0005_circuit_add_upstream_speed	2026-11-11 00:17:39.887378+00
375	circuits	0006_terminations	2026-11-11 00:17:39.887867+00
376	circuits	0007_circuit_add_description	2026-11-11 00:17:39.888174+00
377	circuits	0008_circuittermination_interface_protect_on_delete	2026-11-11 00:17:39.888459+00
378	circuits	0009_unicode_literals	2026-11-11 00:17:39.888793+00
379	circuits	0010_circuit_status	2026-11-11 00:17:39.88917+00
380	circuits	0011_tags	2026-11-11 00:17:39.889434+00
381	circuits	0012_change_logging	2026-11-11 00:17:39.889748+00
382	circuits	0013_cables	2026-11-11 00:17:39.890048+00
383	circuits	0014_circuittermination_description	2026-11-11 00:17:39.890363+00
384	circuits	0015_custom_tag_models	2026-11-11 00:17:39.890747+00
385	circuits	0016_3569_circuit_fields	2026-11-11 00:17:39.891105+00
386	circuits	0017_circuittype_description	2026-11-11 00:17:39.891416+00
387	circuits	0018_standardize_description	2026-11-11 00:17:39.891725+00
388	circuits	0019_nullbooleanfield_to_booleanfield	2026-11-11 00:17:39.891995+00
389	circuits	0020_custom_field_data	2026-11-11 00:17:39.892211+00
390	circuits	0021_cache_cable_peer	2026-11-11 00:17:39.892474+00
391	circuits	0022_cablepath	2026-11-11 00:17:39.892817+00
392	circuits	0023_circuittermination_port_speed_optional	2026-11-11 00:17:39.893103+00
393	circuits	0024_standardize_name_length	2026-11-11 00:17:39.89339+00
394	circuits	0025_standardize_models	2026-11-11 00:17:39.893686+00
395	circuits	0026_mark_connected	2026-11-11 00:17:39.893945+00
396	circuits	0027_providernetwork	2026-11-11 00:17:39.894166+00
397	circuits	0028_cache_circuit_terminations	2026-11-11 00:17:39.894374+00
398	circuits	0029_circuit_tracing	2026-11-11 00:17:39.894666+00
399	circuits	0002_squashed_0029	2026-11-11 00:17:39.894928+00
400	circuits	0003_extend_tag_support	2026-11-11 00:17:40.671585+00
401	circuits	0004_rename_cable_peer	2026-11-11 00:17:40.672523+00
402	circuits	0032_provider_service_id	2026-11-11 00:17:40.672999+00
403	circuits	0033_standardize_id_fields	2026-11-11 00:17:40.673419+00
404	circuits	0034_created_datetimefield	2026-11-11 00:17:40.673846+00
405	circuits	0035_provider_asns	2026-11-11 00:17:40.674225+00
406	circuits	0036_circuit_termination_date_tags_custom_fields	2026-11-11 00:17:40.674539+00
407	circuits	0037_new_cabling_models	2026-11-11 00:17:40.674813+00
707	dcim	0242_ltree_paths	2026-11-11 00:18:46.059983+00
408	circuits	0003_squashed_0037	2026-11-11 00:17:40.675088+00
409	dcim	0160_populate_cable_ends	2026-11-11 00:17:44.908782+00
410	dcim	0161_cabling_cleanup	2026-11-11 00:17:44.909416+00
411	dcim	0162_unique_constraints	2026-11-11 00:17:44.909868+00
412	dcim	0163_weight_fields	2026-11-11 00:17:44.910319+00
413	dcim	0164_rack_mounting_depth	2026-11-11 00:17:44.910698+00
414	dcim	0165_standardize_description_comments	2026-11-11 00:17:44.91105+00
415	dcim	0166_virtualdevicecontext	2026-11-11 00:17:44.9114+00
416	dcim	0160_squashed_0166	2026-11-11 00:17:44.911764+00
417	core	0001_initial	2026-11-11 00:17:45.201129+00
418	core	0002_managedfile	2026-11-11 00:17:45.201743+00
419	core	0003_job	2026-11-11 00:17:45.202198+00
420	core	0004_replicate_jobresults	2026-11-11 00:17:45.202602+00
421	core	0005_job_created_auto_now	2026-11-11 00:17:45.20299+00
422	core	0001_squashed_0005	2026-11-11 00:17:45.203341+00
423	circuits	0038_cabling_cleanup	2026-11-11 00:17:46.11319+00
424	circuits	0039_unique_constraints	2026-11-11 00:17:46.113788+00
425	circuits	0040_provider_remove_deprecated_fields	2026-11-11 00:17:46.114198+00
426	circuits	0041_standardize_description_comments	2026-11-11 00:17:46.114546+00
427	circuits	0042_provideraccount	2026-11-11 00:17:46.114907+00
428	circuits	0038_squashed_0042	2026-11-11 00:17:46.115257+00
429	extras	0060_customlink_button_class	2026-11-11 00:17:47.996895+00
430	extras	0061_extras_change_logging	2026-11-11 00:17:47.998157+00
431	extras	0062_clear_secrets_changelog	2026-11-11 00:17:47.998599+00
432	extras	0063_webhook_conditions	2026-11-11 00:17:47.998986+00
433	extras	0064_configrevision	2026-11-11 00:17:47.999373+00
434	extras	0065_imageattachment_change_logging	2026-11-11 00:17:47.9998+00
435	extras	0066_customfield_name_validation	2026-11-11 00:17:48.000184+00
436	extras	0067_customfield_min_max_values	2026-11-11 00:17:48.000532+00
437	extras	0068_configcontext_cluster_types	2026-11-11 00:17:48.000881+00
438	extras	0069_custom_object_field	2026-11-11 00:17:48.00121+00
439	extras	0070_customlink_enabled	2026-11-11 00:17:48.001646+00
440	extras	0071_standardize_id_fields	2026-11-11 00:17:48.002025+00
441	extras	0072_created_datetimefield	2026-11-11 00:17:48.002304+00
442	extras	0073_journalentry_tags_custom_fields	2026-11-11 00:17:48.002537+00
443	extras	0074_customfield_extensions	2026-11-11 00:17:48.002776+00
444	extras	0075_configcontext_locations	2026-11-11 00:17:48.00306+00
445	extras	0076_tag_slug_unicode	2026-11-11 00:17:48.003329+00
446	extras	0077_customlink_extend_text_and_url	2026-11-11 00:17:48.00364+00
447	extras	0078_unique_constraints	2026-11-11 00:17:48.003898+00
448	extras	0079_scheduled_jobs	2026-11-11 00:17:48.004141+00
449	extras	0080_customlink_content_types	2026-11-11 00:17:48.004373+00
450	extras	0081_exporttemplate_content_types	2026-11-11 00:17:48.004621+00
451	extras	0082_savedfilter	2026-11-11 00:17:48.004859+00
452	extras	0083_search	2026-11-11 00:17:48.005104+00
453	extras	0084_staging	2026-11-11 00:17:48.005315+00
454	extras	0085_synced_data	2026-11-11 00:17:48.00576+00
455	extras	0086_configtemplate	2026-11-11 00:17:48.006209+00
456	extras	0060_squashed_0086	2026-11-11 00:17:48.006521+00
457	extras	0087_dashboard	2026-11-11 00:17:48.459163+00
458	extras	0088_jobresult_webhooks	2026-11-11 00:17:48.45981+00
459	extras	0089_customfield_is_cloneable	2026-11-11 00:17:48.460535+00
460	extras	0090_objectchange_index_request_id	2026-11-11 00:17:48.460985+00
461	extras	0091_create_managedfiles	2026-11-11 00:17:48.46131+00
462	extras	0092_delete_jobresult	2026-11-11 00:17:48.461649+00
463	extras	0093_configrevision_ordering	2026-11-11 00:17:48.461982+00
464	extras	0094_tag_object_types	2026-11-11 00:17:48.462283+00
465	extras	0095_bookmarks	2026-11-11 00:17:48.462519+00
466	extras	0096_customfieldchoiceset	2026-11-11 00:17:48.462749+00
467	extras	0097_customfield_remove_choices	2026-11-11 00:17:48.462993+00
468	extras	0098_webhook_custom_field_data_webhook_tags	2026-11-11 00:17:48.46324+00
469	extras	0087_squashed_0098	2026-11-11 00:17:48.463712+00
470	virtualization	0023_virtualmachine_natural_ordering	2026-11-11 00:17:50.21109+00
471	virtualization	0024_cluster_relax_uniqueness	2026-11-11 00:17:50.211818+00
472	virtualization	0025_extend_tag_support	2026-11-11 00:17:50.212264+00
473	virtualization	0026_vminterface_bridge	2026-11-11 00:17:50.212697+00
474	virtualization	0027_standardize_id_fields	2026-11-11 00:17:50.213046+00
475	virtualization	0028_vminterface_vrf	2026-11-11 00:17:50.213359+00
476	virtualization	0029_created_datetimefield	2026-11-11 00:17:50.213689+00
477	virtualization	0030_cluster_status	2026-11-11 00:17:50.213948+00
478	virtualization	0031_virtualmachine_site_device	2026-11-11 00:17:50.214184+00
479	virtualization	0032_virtualmachine_update_sites	2026-11-11 00:17:50.214411+00
480	virtualization	0033_unique_constraints	2026-11-11 00:17:50.214643+00
481	virtualization	0034_standardize_description_comments	2026-11-11 00:17:50.214904+00
482	virtualization	0035_virtualmachine_interface_count	2026-11-11 00:17:50.215134+00
483	virtualization	0036_virtualmachine_config_template	2026-11-11 00:17:50.215352+00
484	virtualization	0023_squashed_0036	2026-11-11 00:17:50.215579+00
485	virtualization	0037_protect_child_interfaces	2026-11-11 00:17:50.259835+00
486	extras	0099_cachedvalue_ordering	2026-11-11 00:17:50.271829+00
487	virtualization	0038_virtualdisk	2026-11-11 00:17:50.434367+00
488	virtualization	0039_virtualmachine_serial_number	2026-11-11 00:17:50.479353+00
489	virtualization	0040_convert_disk_size	2026-11-11 00:17:50.52809+00
490	virtualization	0041_charfield_null_choices	2026-11-11 00:17:50.630987+00
491	ipam	0054_vlangroup_min_max_vids	2026-11-11 00:17:53.620062+00
492	ipam	0055_servicetemplate	2026-11-11 00:17:53.621291+00
493	ipam	0056_standardize_id_fields	2026-11-11 00:17:53.62159+00
494	ipam	0057_created_datetimefield	2026-11-11 00:17:53.621885+00
495	ipam	0058_ipaddress_nat_inside_nonunique	2026-11-11 00:17:53.622158+00
496	ipam	0059_l2vpn	2026-11-11 00:17:53.62239+00
497	ipam	0060_alter_l2vpn_slug	2026-11-11 00:17:53.622655+00
498	ipam	0061_fhrpgroup_name	2026-11-11 00:17:53.622929+00
499	ipam	0062_unique_constraints	2026-11-11 00:17:53.623177+00
500	ipam	0063_standardize_description_comments	2026-11-11 00:17:53.623404+00
501	ipam	0064_clear_search_cache	2026-11-11 00:17:53.62364+00
502	ipam	0065_asnrange	2026-11-11 00:17:53.623911+00
503	ipam	0066_iprange_mark_utilized	2026-11-11 00:17:53.624147+00
504	ipam	0067_ipaddress_index_host	2026-11-11 00:17:53.624367+00
505	ipam	0054_squashed_0067	2026-11-11 00:17:53.624589+00
506	ipam	0068_move_l2vpn	2026-11-11 00:17:54.520315+00
507	ipam	0069_gfk_indexes	2026-11-11 00:17:54.60421+00
508	ipam	0070_vlangroup_vlan_id_ranges	2026-11-11 00:17:54.841821+00
510	extras	0100_customfield_ui_attrs	2026-11-11 00:17:55.136588+00
511	extras	0101_eventrule	2026-11-11 00:17:55.896965+00
512	extras	0102_move_configrevision	2026-11-11 00:17:55.942075+00
513	extras	0103_gfk_indexes	2026-11-11 00:17:56.048532+00
514	extras	0104_stagedchange_remove_change_logging	2026-11-11 00:17:56.078241+00
515	extras	0105_customfield_min_max_values	2026-11-11 00:17:56.114714+00
516	extras	0106_bookmark_user_cascade_deletion	2026-11-11 00:17:56.16022+00
517	extras	0107_cachedvalue_extras_cachedvalue_object	2026-11-11 00:17:56.174067+00
518	extras	0108_convert_reports_to_scripts	2026-11-11 00:17:56.217142+00
519	extras	0109_script_model	2026-11-11 00:17:56.365883+00
520	extras	0110_remove_eventrule_action_parameters	2026-11-11 00:17:56.405467+00
521	core	0006_datasource_type_remove_choices	2026-11-11 00:17:56.437021+00
522	core	0007_job_add_error_field	2026-11-11 00:17:56.45295+00
523	core	0008_contenttype_proxy	2026-11-11 00:17:56.454919+00
524	core	0009_configrevision	2026-11-11 00:17:56.456798+00
525	core	0010_gfk_indexes	2026-11-11 00:17:56.477159+00
526	extras	0111_rename_content_types	2026-11-11 00:17:57.187281+00
527	extras	0112_tag_update_object_types	2026-11-11 00:17:57.250468+00
528	extras	0113_customfield_rename_object_type	2026-11-11 00:17:57.268231+00
529	users	0005_alter_user_table	2026-11-11 00:17:57.369391+00
530	users	0006_custom_group_model	2026-11-11 00:17:57.625401+00
531	users	0007_objectpermission_update_object_types	2026-11-11 00:17:57.698138+00
532	users	0008_flip_objectpermission_assignments	2026-11-11 00:17:57.962404+00
533	users	0009_update_group_perms	2026-11-11 00:17:58.103839+00
534	extras	0114_customfield_add_comments	2026-11-11 00:17:58.122187+00
535	extras	0115_convert_dashboard_widgets	2026-11-11 00:17:58.189877+00
536	extras	0116_custom_link_button_color	2026-11-11 00:17:58.286442+00
537	core	0011_move_objectchange	2026-11-11 00:17:58.36997+00
538	extras	0117_move_objectchange	2026-11-11 00:17:58.556442+00
539	extras	0118_customfield_uniqueness	2026-11-11 00:17:58.585336+00
540	extras	0119_notifications	2026-11-11 00:17:58.925167+00
541	extras	0120_eventrule_event_types	2026-11-11 00:17:59.281844+00
542	extras	0121_customfield_related_object_filter	2026-11-11 00:17:59.295975+00
543	dcim	0167_module_status	2026-11-11 00:18:01.384137+00
544	dcim	0168_interface_template_enabled	2026-11-11 00:18:01.384718+00
545	dcim	0169_devicetype_default_platform	2026-11-11 00:18:01.385018+00
546	dcim	0170_configtemplate	2026-11-11 00:18:01.385263+00
547	dcim	0171_cabletermination_change_logging	2026-11-11 00:18:01.385519+00
548	dcim	0172_larger_power_draw_values	2026-11-11 00:18:01.385801+00
549	dcim	0173_remove_napalm_fields	2026-11-11 00:18:01.386066+00
550	dcim	0174_device_latitude_device_longitude	2026-11-11 00:18:01.386301+00
551	dcim	0174_rack_starting_unit	2026-11-11 00:18:01.386547+00
552	dcim	0175_device_oob_ip	2026-11-11 00:18:01.386836+00
553	dcim	0176_device_component_counters	2026-11-11 00:18:01.387072+00
554	dcim	0177_devicetype_component_counters	2026-11-11 00:18:01.387341+00
555	dcim	0178_virtual_chassis_member_counter	2026-11-11 00:18:01.387611+00
556	dcim	0179_interfacetemplate_rf_role	2026-11-11 00:18:01.387879+00
557	dcim	0180_powerfeed_tenant	2026-11-11 00:18:01.38811+00
558	dcim	0181_rename_device_role_device_role	2026-11-11 00:18:01.388346+00
559	dcim	0182_zero_length_cable_fix	2026-11-11 00:18:01.38858+00
560	dcim	0167_squashed_0182	2026-11-11 00:18:01.388802+00
561	dcim	0183_devicetype_exclude_from_utilization	2026-11-11 00:18:01.447097+00
562	dcim	0184_protect_child_interfaces	2026-11-11 00:18:01.527829+00
563	dcim	0185_gfk_indexes	2026-11-11 00:18:01.656958+00
564	dcim	0186_location_facility	2026-11-11 00:18:01.709188+00
565	dcim	0187_alter_device_vc_position	2026-11-11 00:18:01.768942+00
566	dcim	0188_racktype	2026-11-11 00:18:02.079805+00
567	dcim	0189_moduletype_rack_airflow	2026-11-11 00:18:02.146697+00
568	dcim	0190_nested_modules	2026-11-11 00:18:02.551776+00
569	dcim	0191_module_bay_rebuild	2026-11-11 00:18:02.595825+00
570	dcim	0192_inventoryitem_status	2026-11-11 00:18:02.633246+00
571	dcim	0193_poweroutlet_color	2026-11-11 00:18:02.665942+00
572	ipam	0072_prefix_cached_relations	2026-11-11 00:18:03.177112+00
573	ipam	0073_charfield_null_choices	2026-11-11 00:18:03.298879+00
574	ipam	0074_vlantranslationpolicy_vlantranslationrule	2026-11-11 00:18:03.539705+00
575	virtualization	0042_vminterface_vlan_translation_policy	2026-11-11 00:18:03.628361+00
576	ipam	0075_vlan_qinq	2026-11-11 00:18:03.812976+00
577	virtualization	0043_qinq_svlan	2026-11-11 00:18:04.019981+00
578	virtualization	0044_cluster_scope	2026-11-11 00:18:04.231093+00
579	virtualization	0045_clusters_cached_relations	2026-11-11 00:18:04.822838+00
580	dcim	0194_charfield_null_choices	2026-11-11 00:18:06.862578+00
581	dcim	0195_interface_vlan_translation_policy	2026-11-11 00:18:06.935607+00
582	dcim	0196_qinq_svlan	2026-11-11 00:18:07.185095+00
583	virtualization	0046_alter_cluster__location_alter_cluster__region_and_more	2026-11-11 00:18:07.516281+00
584	dcim	0197_natural_sort_collation	2026-11-11 00:18:07.526625+00
585	virtualization	0047_natural_ordering	2026-11-11 00:18:07.952278+00
586	extras	0122_charfield_null_choices	2026-11-11 00:18:08.032005+00
587	dcim	0198_natural_ordering	2026-11-11 00:18:10.619582+00
588	dcim	0199_macaddress	2026-11-11 00:18:10.716828+00
589	virtualization	0048_populate_mac_addresses	2026-11-11 00:18:10.868591+00
590	users	0010_add_token_meta_ordering	2026-11-11 00:18:10.88371+00
591	users	0011_concrete_objecttype	2026-11-11 00:18:10.970257+00
592	users	0012_drop_django_admin_log_table	2026-11-11 00:18:10.972714+00
593	users	0013_user_remove_is_staff	2026-11-11 00:18:10.983186+00
594	users	0014_users_token_v2	2026-11-11 00:18:11.083224+00
595	users	0015_owner	2026-11-11 00:18:11.152894+00
596	virtualization	0049_owner	2026-11-11 00:18:11.615958+00
597	virtualization	0050_virtualmachine_start_on_boot	2026-11-11 00:18:11.673067+00
598	virtualization	0051_add_comments_to_organizationalmodel	2026-11-11 00:18:11.797944+00
599	tenancy	0012_contactassignment_custom_fields	2026-11-11 00:18:11.871826+00
600	tenancy	0013_gfk_indexes	2026-11-11 00:18:11.933495+00
601	tenancy	0014_contactassignment_ordering	2026-11-11 00:18:12.034988+00
602	tenancy	0015_contactassignment_rename_content_type	2026-11-11 00:18:12.225176+00
603	tenancy	0016_charfield_null_choices	2026-11-11 00:18:12.305485+00
604	tenancy	0017_natural_ordering	2026-11-11 00:18:12.432478+00
605	tenancy	0018_contact_groups	2026-11-11 00:18:12.710987+00
606	tenancy	0019_contactgroup_comments_tenantgroup_comments	2026-11-11 00:18:12.7817+00
607	tenancy	0020_remove_contactgroupmembership	2026-11-11 00:18:13.10394+00
608	tenancy	0021_owner	2026-11-11 00:18:13.372449+00
609	tenancy	0022_add_comments_to_organizationalmodel	2026-11-11 00:18:13.407111+00
610	extras	0123_journalentry_kind_default	2026-11-11 00:18:13.512876+00
611	extras	0124_remove_staging	2026-11-11 00:18:13.645115+00
612	extras	0125_alter_tag_options_tag_weight	2026-11-11 00:18:13.970936+00
613	extras	0126_exporttemplate_file_name	2026-11-11 00:18:13.990002+00
614	extras	0127_configtemplate_as_attachment_and_more	2026-11-11 00:18:14.145006+00
615	core	0012_job_object_type_optional	2026-11-11 00:18:14.252697+00
616	core	0013_job_data_encoder	2026-11-11 00:18:14.269796+00
617	core	0014_datasource_sync_interval	2026-11-11 00:18:14.304237+00
618	core	0015_remove_redundant_indexes	2026-11-11 00:18:14.34901+00
619	extras	0128_tableconfig	2026-11-11 00:18:14.409454+00
620	extras	0129_fix_script_paths	2026-11-11 00:18:14.542497+00
621	extras	0130_imageattachment_description	2026-11-11 00:18:14.557258+00
622	extras	0131_concrete_objecttype	2026-11-11 00:18:15.051014+00
623	core	0016_job_log_entries	2026-11-11 00:18:15.081475+00
624	core	0017_objectchange_message	2026-11-11 00:18:15.105283+00
625	core	0018_concrete_objecttype	2026-11-11 00:18:15.182534+00
626	extras	0132_configcontextprofile	2026-11-11 00:18:15.355524+00
627	extras	0133_make_cf_minmax_decimal	2026-11-11 00:18:15.395395+00
628	extras	0134_owner	2026-11-11 00:18:16.114304+00
629	dcim	0200_populate_mac_addresses	2026-11-11 00:18:16.250532+00
630	dcim	0201_add_power_outlet_status	2026-11-11 00:18:16.28729+00
631	dcim	0202_location_comments_region_comments_sitegroup_comments	2026-11-11 00:18:16.391085+00
632	dcim	0203_add_rack_outer_height	2026-11-11 00:18:16.457942+00
633	dcim	0203_device_role_nested	2026-11-11 00:18:17.090291+00
634	dcim	0204_device_role_rebuild	2026-11-11 00:18:17.141224+00
635	dcim	0205_moduletypeprofile	2026-11-11 00:18:17.444371+00
636	dcim	0206_load_module_type_profiles	2026-11-11 00:18:17.49982+00
637	dcim	0207_remove_redundant_indexes	2026-11-11 00:18:17.548733+00
638	dcim	0208_devicerole_uniqueness	2026-11-11 00:18:17.754923+00
639	dcim	0209_device_component_denorm_site_location	2026-11-11 00:18:20.687772+00
640	dcim	0210_macaddress_ordering	2026-11-11 00:18:20.743577+00
641	dcim	0211_platform_manufacturer_uniqueness	2026-11-11 00:18:21.326869+00
642	dcim	0212_interface_tx_power_negative	2026-11-11 00:18:21.372784+00
643	dcim	0213_platform_parent	2026-11-11 00:18:21.673223+00
644	dcim	0214_platform_rebuild	2026-11-11 00:18:21.729675+00
645	dcim	0215_rackreservation_status	2026-11-11 00:18:21.795543+00
646	dcim	0216_latitude_longitude_validators	2026-11-11 00:18:22.140896+00
647	dcim	0217_poweroutlettemplate_color	2026-11-11 00:18:22.155434+00
648	dcim	0218_owner	2026-11-11 00:18:25.280909+00
649	dcim	0219_devicetype_device_count	2026-11-11 00:18:25.57069+00
650	dcim	0220_cable_profile	2026-11-11 00:18:26.012372+00
651	dcim	0221_cable_connector_positions	2026-11-11 00:18:27.069283+00
652	dcim	0222_port_mappings	2026-11-11 00:18:27.535153+00
653	dcim	0223_frontport_positions	2026-11-11 00:18:27.997389+00
654	dcim	0224_add_comments_to_organizationalmodel	2026-11-11 00:18:28.221542+00
655	dcim	0225_gfk_indexes	2026-11-11 00:18:28.268985+00
656	virtualization	0052_gfk_indexes	2026-11-11 00:18:28.316438+00
657	tenancy	0023_add_mptt_tree_indexes	2026-11-11 00:18:28.398744+00
658	ipam	0076_natural_ordering	2026-11-11 00:18:28.571819+00
659	ipam	0077_vlangroup_tenant	2026-11-11 00:18:28.627122+00
660	ipam	0078_iprange_mark_utilized	2026-11-11 00:18:28.665849+00
661	ipam	0079_add_service_fhrp_group_parent_gfk	2026-11-11 00:18:28.758037+00
662	ipam	0080_populate_service_parent	2026-11-11 00:18:28.812915+00
663	ipam	0081_remove_service_device_virtual_machine_add_parent_gfk_index	2026-11-11 00:18:29.316164+00
664	ipam	0082_add_prefix_network_containment_indexes	2026-11-11 00:18:29.361764+00
665	ipam	0083_vlangroup_populate_total_vlan_ids	2026-11-11 00:18:29.415268+00
666	ipam	0084_owner	2026-11-11 00:18:30.76871+00
667	ipam	0085_add_comments_to_organizationalmodel	2026-11-11 00:18:31.061736+00
668	ipam	0086_gfk_indexes	2026-11-11 00:18:31.138868+00
669	ipam	0087_add_asn_role	2026-11-11 00:18:31.246147+00
670	ipam	0088_rename_vlangroup_total_vlan_ids	2026-11-11 00:18:31.340012+00
671	extras	0135_configtemplate_debug	2026-11-11 00:18:31.449825+00
672	dcim	0226_add_mptt_tree_indexes	2026-11-11 00:18:31.800254+00
673	dcim	0226_modulebay_rebuild_tree	2026-11-11 00:18:31.857995+00
674	dcim	0227_alter_interface_speed_bigint	2026-11-11 00:18:31.916164+00
675	dcim	0228_rack_group	2026-11-11 00:18:32.047841+00
676	dcim	0229_cable_bundle	2026-11-11 00:18:32.175403+00
677	virtualization	0053_virtualmachine_standalone_device_assignment	2026-11-11 00:18:32.321474+00
678	virtualization	0054_virtualmachinetype	2026-11-11 00:18:32.760007+00
679	extras	0136_customfield_validation_schema	2026-11-11 00:18:32.807354+00
680	dcim	0230_devicebay_modulebay_enabled	2026-11-11 00:18:32.960774+00
681	dcim	0231_interface_rf_channel_frequency_precision	2026-11-11 00:18:33.018937+00
682	dcim	0232_default_ordering_indexes	2026-11-11 00:18:33.734035+00
683	dcim	0233_device_render_config_permission	2026-11-11 00:18:33.815116+00
684	dcim	0234_cablepath_nodes_index	2026-11-11 00:18:33.825688+00
685	circuits	0043_circuittype_color	2026-11-11 00:18:33.907862+00
686	circuits	0044_circuit_groups	2026-11-11 00:18:34.199834+00
687	circuits	0045_circuit_distance	2026-11-11 00:18:34.42166+00
688	circuits	0046_charfield_null_choices	2026-11-11 00:18:34.716828+00
689	circuits	0047_circuittermination__termination	2026-11-11 00:18:34.985468+00
690	circuits	0048_circuitterminations_cached_relations	2026-11-11 00:18:35.434004+00
691	circuits	0049_natural_ordering	2026-11-11 00:18:35.534885+00
692	circuits	0050_virtual_circuits	2026-11-11 00:18:35.809872+00
693	circuits	0051_virtualcircuit_group_assignment	2026-11-11 00:18:36.587225+00
694	circuits	0052_extend_circuit_abs_distance_upper_limit	2026-11-11 00:18:36.632148+00
695	circuits	0053_owner	2026-11-11 00:18:37.528011+00
696	circuits	0054_cable_connector_positions	2026-11-11 00:18:37.670563+00
697	circuits	0055_add_comments_to_organizationalmodel	2026-11-11 00:18:37.899359+00
698	circuits	0056_gfk_indexes	2026-11-11 00:18:37.96699+00
699	circuits	0057_default_ordering_indexes	2026-11-11 00:18:38.277877+00
700	dcim	0235_cabletermination_circuit_site_cache	2026-11-11 00:18:38.381046+00
701	dcim	0236_moduletype_component_counts	2026-11-11 00:18:39.09487+00
702	dcim	0237_module_remove_local_context_data	2026-11-11 00:18:39.145562+00
703	dcim	0238_alter_cable__abs_length	2026-11-11 00:18:39.193514+00
704	dcim	0239_add_portmapping_objectchange	2026-11-11 00:18:39.258958+00
705	dcim	0240_clear_stale_cable_profile_data	2026-11-11 00:18:39.317531+00
706	dcim	0241_nullify_empty_cable_end	2026-11-11 00:18:39.374096+00
708	circuits	0058_clear_stale_cable_profile_data	2026-11-11 00:18:46.144802+00
709	circuits	0059_nullify_empty_cable_end	2026-11-11 00:18:46.240222+00
710	circuits	0060_denormalization_triggers	2026-11-11 00:18:46.244126+00
711	core	0019_configrevision_active	2026-11-11 00:18:46.345689+00
712	core	0020_owner	2026-11-11 00:18:46.449566+00
713	core	0021_job_queue_name	2026-11-11 00:18:46.519308+00
714	core	0022_default_ordering_indexes	2026-11-11 00:18:46.542072+00
715	core	0023_datasource_sync_permission	2026-11-11 00:18:46.589309+00
716	core	0024_job_notifications	2026-11-11 00:18:46.610034+00
717	core	0025_add_job_execution_time	2026-11-11 00:18:46.629418+00
718	core	0026_populate_job_execution_time	2026-11-11 00:18:46.689305+00
719	users	0016_default_ordering_indexes	2026-11-11 00:18:46.720009+00
720	extras	0137_default_ordering_indexes	2026-11-11 00:18:47.214696+00
721	tenancy	0024_default_ordering_indexes	2026-11-11 00:18:47.307284+00
722	tenancy	0025_ltree_paths	2026-11-11 00:18:49.320767+00
723	extras	0138_customfieldchoiceset_choice_colors	2026-11-11 00:18:49.381633+00
724	extras	0139_alter_customfieldchoiceset_extra_choices	2026-11-11 00:18:49.438038+00
725	extras	0140_imageattachment_image_size	2026-11-11 00:18:49.464912+00
726	extras	0141_custom_field_nulls_first	2026-11-11 00:18:49.546785+00
727	dcim	0243_denormalization_triggers	2026-11-11 00:18:49.563089+00
728	dcim	0244_device__config_context_data	2026-11-11 00:18:49.835217+00
729	dcim	0245_consolidate_unique_constraints	2026-11-11 00:18:51.898142+00
730	dcim	0246_add_devicetype_end_of_life	2026-11-11 00:18:52.042888+00
731	dcim	0247_modulebaytype	2026-11-11 00:18:52.698654+00
732	dcim	0248_interfacetemplate_channels	2026-11-11 00:18:52.837238+00
733	dcim	0249_interface_channels	2026-11-11 00:18:53.050061+00
734	dcim	0250_cooling_infrastructure	2026-11-11 00:18:55.06613+00
735	dcim	0251_fix_ltree_cascade_triggers	2026-11-11 00:18:55.080826+00
736	django_rq	0001_initial	2026-11-11 00:18:55.082852+00
737	django_rq	0002_delete_queue_create_dashboard	2026-11-11 00:18:55.14798+00
738	django_rq	0003_alter_dashboard_permission_names	2026-11-11 00:18:55.212775+00
739	extras	0142_webhook_timeout	2026-11-11 00:18:55.569613+00
740	extras	0143_event_rule_action_registry	2026-11-11 00:18:55.687746+00
741	extras	0144_customfield_status	2026-11-11 00:18:55.740133+00
742	extras	0145_taggeditem_object_id_bigint	2026-11-11 00:18:55.807131+00
743	ipam	0089_default_ordering_indexes	2026-11-11 00:18:56.437199+00
744	ipam	0090_vlangroup_recompute_total_vlan_ids	2026-11-11 00:18:56.531811+00
745	ipam	0091_alter_service_index_and_ordering	2026-11-11 00:18:57.847579+00
746	ipam	0092_iprange_host_indexes	2026-11-11 00:18:57.95473+00
747	ipam	0093_alter_prefix__region_alter_prefix__site_group	2026-11-11 00:18:58.146591+00
748	ipam	0094_ipaddress_host_index	2026-11-11 00:18:58.286859+00
749	ipam	0095_denormalization_triggers	2026-11-11 00:18:58.290221+00
750	ipam	0096_multi_protocol_services	2026-11-11 00:18:59.277019+00
751	ipam	0097_merge_ipaddress_host_index_and_multi_protocol_services	2026-11-11 00:18:59.27802+00
752	sessions	0001_initial	2026-11-11 00:18:59.28199+00
753	social_django	0001_initial	2026-11-11 00:18:59.370417+00
754	social_django	0002_add_related_name	2026-11-11 00:18:59.430511+00
755	social_django	0003_alter_email_max_length	2026-11-11 00:18:59.43553+00
756	social_django	0004_auto_20160423_0400	2026-11-11 00:18:59.444698+00
757	social_django	0005_auto_20160727_2333	2026-11-11 00:18:59.448159+00
758	social_django	0006_partial	2026-11-11 00:18:59.452261+00
759	social_django	0007_code_timestamp	2026-11-11 00:18:59.456145+00
760	social_django	0008_partial_timestamp	2026-11-11 00:18:59.459833+00
761	social_django	0009_auto_20191118_0520	2026-11-11 00:18:59.47915+00
762	social_django	0010_uid_db_index	2026-11-11 00:18:59.490482+00
763	social_django	0011_alter_id_fields	2026-11-11 00:18:59.526413+00
764	social_django	0012_usersocialauth_extra_data_new	2026-11-11 00:18:59.543343+00
765	social_django	0013_migrate_extra_data	2026-11-11 00:18:59.604604+00
766	social_django	0014_remove_usersocialauth_extra_data	2026-11-11 00:18:59.617799+00
767	social_django	0015_rename_extra_data_new_usersocialauth_extra_data	2026-11-11 00:18:59.631702+00
768	social_django	0016_alter_usersocialauth_extra_data	2026-11-11 00:18:59.641505+00
769	social_django	0017_usersocialauth_user_social_auth_uid_required	2026-11-11 00:18:59.650729+00
770	taggit	0001_initial	2026-11-11 00:18:59.723297+00
771	taggit	0002_auto_20150616_2121	2026-11-11 00:18:59.741666+00
772	taggit	0003_taggeditem_add_unique_index	2026-11-11 00:18:59.757865+00
773	taggit	0004_alter_taggeditem_content_type_alter_taggeditem_tag	2026-11-11 00:18:59.882171+00
774	taggit	0005_auto_20220424_2025	2026-11-11 00:18:59.886613+00
775	taggit	0006_rename_taggeditem_content_type_object_id_taggit_tagg_content_8fc721_idx	2026-11-11 00:19:00.211169+00
776	tenancy	0026_consolidate_unique_constraints	2026-11-11 00:19:00.564733+00
777	tenancy	0027_fix_ltree_cascade_triggers	2026-11-11 00:19:00.570657+00
778	thumbnail	0001_initial	2026-11-11 00:19:00.574077+00
779	virtualization	0055_default_ordering_indexes	2026-11-11 00:19:00.687971+00
780	virtualization	0056_virtualmachine_render_config_permission	2026-11-11 00:19:00.804251+00
781	virtualization	0057_alter_cluster__region_alter_cluster__site_group	2026-11-11 00:19:00.969718+00
782	virtualization	0058_denormalization_triggers	2026-11-11 00:19:00.973363+00
783	virtualization	0059_virtualmachine__config_context_data	2026-11-11 00:19:01.262008+00
784	virtualization	0060_consolidate_unique_constraints	2026-11-11 00:19:01.670786+00
785	vpn	0001_initial	2026-11-11 00:19:02.874467+00
786	vpn	0002_move_l2vpn	2026-11-11 00:19:03.120231+00
787	vpn	0003_ipaddress_multiple_tunnel_terminations	2026-11-11 00:19:03.195805+00
788	vpn	0004_alter_ikepolicy_mode	2026-11-11 00:19:03.247013+00
789	vpn	0005_rename_indexes	2026-11-11 00:19:03.266807+00
790	vpn	0006_charfield_null_choices	2026-11-11 00:19:03.868228+00
791	vpn	0007_natural_ordering	2026-11-11 00:19:04.426071+00
792	vpn	0008_add_l2vpn_status	2026-11-11 00:19:04.488784+00
793	vpn	0009_remove_redundant_indexes	2026-11-11 00:19:04.823663+00
794	vpn	0010_owner	2026-11-11 00:19:05.810142+00
795	vpn	0011_add_comments_to_organizationalmodel	2026-11-11 00:19:05.920471+00
796	vpn	0012_default_ordering_indexes	2026-11-11 00:19:06.006305+00
797	vpn	0013_consolidate_unique_constraints	2026-11-11 00:19:06.193441+00
798	wireless	0009_wirelesslink_distance	2026-11-11 00:19:06.454733+00
799	wireless	0010_charfield_null_choices	2026-11-11 00:19:06.974747+00
800	wireless	0011_wirelesslan__location_wirelesslan__region_and_more	2026-11-11 00:19:07.391063+00
801	wireless	0012_alter_wirelesslan__location_and_more	2026-11-11 00:19:07.922241+00
802	wireless	0013_natural_ordering	2026-11-11 00:19:07.981741+00
803	wireless	0014_wirelesslangroup_comments	2026-11-11 00:19:08.031268+00
804	wireless	0015_extend_wireless_link_abs_distance_upper_limit	2026-11-11 00:19:08.082936+00
805	wireless	0016_owner	2026-11-11 00:19:08.354116+00
806	wireless	0017_gfk_indexes	2026-11-11 00:19:08.441649+00
807	wireless	0018_add_mptt_tree_indexes	2026-11-11 00:19:08.538259+00
808	wireless	0019_default_ordering_indexes	2026-11-11 00:19:08.651868+00
809	wireless	0020_alter_wirelesslan__region_and_more	2026-11-11 00:19:08.885146+00
810	wireless	0021_ltree_paths	2026-11-11 00:19:10.047149+00
811	wireless	0022_denormalization_triggers	2026-11-11 00:19:10.051561+00
812	wireless	0023_wirelesslangroup_drop_unique_constraint	2026-11-11 00:19:10.141717+00
813	wireless	0024_fix_ltree_cascade_triggers	2026-11-11 00:19:10.145228+00
\.


--
-- Data for Name: extras_bookmark; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_bookmark (id, created, object_id, object_type_id, user_id) FROM stdin;
\.


--
-- Data for Name: extras_cachedvalue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_cachedvalue (id, "timestamp", object_id, field, type, value, weight, object_type_id) FROM stdin;
550c854a-d0d4-4ff3-8280-a8dc57de7663	2026-11-11 00:19:25.769721+00	1	name	str	CPU	100	76
a67ea7c5-d385-4f83-9e82-455c6e4f84a1	2026-11-11 00:19:25.769732+00	7	name	str	Expansion card	100	76
cbcab126-2f12-432a-b9b3-534f8465cd3b	2026-11-11 00:19:25.769737+00	2	name	str	Fan	100	76
0bc86f36-dd3b-4792-828c-878690e400cc	2026-11-11 00:19:25.769739+00	3	name	str	GPU	100	76
bd92ece3-d13b-4c5a-8335-d3b2d51f5f68	2026-11-11 00:19:25.76974+00	4	name	str	Hard disk	100	76
c670a86c-1df2-4f99-8b0d-0a89375d7c6e	2026-11-11 00:19:25.769742+00	5	name	str	Memory	100	76
ae852119-8a11-469a-8231-5f3f331dd046	2026-11-11 00:19:25.769744+00	6	name	str	Power supply	100	76
5ae90b1e-5d0c-42ec-b888-1d2f9aff8a7b	2026-11-11 00:19:25.769745+00	8	name	str	Transceiver	100	76
\.


--
-- Data for Name: extras_configcontext; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_configcontext (created, last_updated, id, name, weight, description, is_active, data, data_file_id, data_path, data_source_id, auto_sync_enabled, data_synced, profile_id, owner_id) FROM stdin;
\.


--
-- Data for Name: extras_configcontext_cluster_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_configcontext_cluster_groups (id, configcontext_id, clustergroup_id) FROM stdin;
\.


--
-- Data for Name: extras_configcontext_cluster_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_configcontext_cluster_types (id, configcontext_id, clustertype_id) FROM stdin;
\.


--
-- Data for Name: extras_configcontext_clusters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_configcontext_clusters (id, configcontext_id, cluster_id) FROM stdin;
\.


--
-- Data for Name: extras_configcontext_device_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_configcontext_device_types (id, configcontext_id, devicetype_id) FROM stdin;
\.


--
-- Data for Name: extras_configcontext_locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_configcontext_locations (id, configcontext_id, location_id) FROM stdin;
\.


--
-- Data for Name: extras_configcontext_platforms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_configcontext_platforms (id, configcontext_id, platform_id) FROM stdin;
\.


--
-- Data for Name: extras_configcontext_regions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_configcontext_regions (id, configcontext_id, region_id) FROM stdin;
\.


--
-- Data for Name: extras_configcontext_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_configcontext_roles (id, configcontext_id, devicerole_id) FROM stdin;
\.


--
-- Data for Name: extras_configcontext_site_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_configcontext_site_groups (id, configcontext_id, sitegroup_id) FROM stdin;
\.


--
-- Data for Name: extras_configcontext_sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_configcontext_sites (id, configcontext_id, site_id) FROM stdin;
\.


--
-- Data for Name: extras_configcontext_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_configcontext_tags (id, configcontext_id, tag_id) FROM stdin;
\.


--
-- Data for Name: extras_configcontext_tenant_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_configcontext_tenant_groups (id, configcontext_id, tenantgroup_id) FROM stdin;
\.


--
-- Data for Name: extras_configcontext_tenants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_configcontext_tenants (id, configcontext_id, tenant_id) FROM stdin;
\.


--
-- Data for Name: extras_configcontextprofile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_configcontextprofile (id, created, last_updated, custom_field_data, data_path, auto_sync_enabled, data_synced, comments, name, description, schema, data_file_id, data_source_id, owner_id) FROM stdin;
\.


--
-- Data for Name: extras_configtemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_configtemplate (id, created, last_updated, data_path, data_synced, name, description, template_code, environment_params, data_file_id, data_source_id, auto_sync_enabled, as_attachment, file_extension, file_name, mime_type, owner_id, debug) FROM stdin;
\.


--
-- Data for Name: extras_customfield; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_customfield (id, type, name, label, description, required, filter_logic, "default", weight, validation_minimum, validation_maximum, validation_regex, created, last_updated, related_object_type_id, group_name, search_weight, is_cloneable, choice_set_id, ui_editable, ui_visible, comments, "unique", related_object_filter, owner_id, validation_schema, nulls_first, status) FROM stdin;
\.


--
-- Data for Name: extras_customfield_object_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_customfield_object_types (id, customfield_id, contenttype_id) FROM stdin;
\.


--
-- Data for Name: extras_customfieldchoiceset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_customfieldchoiceset (id, created, last_updated, name, description, base_choices, extra_choices, order_alphabetically, owner_id, choice_colors) FROM stdin;
\.


--
-- Data for Name: extras_customlink; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_customlink (id, name, link_text, link_url, weight, group_name, button_class, new_window, created, last_updated, enabled, owner_id) FROM stdin;
\.


--
-- Data for Name: extras_customlink_object_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_customlink_object_types (id, customlink_id, contenttype_id) FROM stdin;
\.


--
-- Data for Name: extras_dashboard; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_dashboard (id, layout, config, user_id) FROM stdin;
\.


--
-- Data for Name: extras_eventrule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_eventrule (id, created, last_updated, custom_field_data, name, description, enabled, conditions, action_type, action_object_id, action_data, comments, action_object_type_id, event_types, owner_id) FROM stdin;
\.


--
-- Data for Name: extras_eventrule_object_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_eventrule_object_types (id, eventrule_id, contenttype_id) FROM stdin;
\.


--
-- Data for Name: extras_exporttemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_exporttemplate (id, name, description, template_code, mime_type, file_extension, as_attachment, created, last_updated, data_file_id, data_path, data_source_id, auto_sync_enabled, data_synced, file_name, environment_params, owner_id) FROM stdin;
\.


--
-- Data for Name: extras_exporttemplate_object_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_exporttemplate_object_types (id, exporttemplate_id, contenttype_id) FROM stdin;
\.


--
-- Data for Name: extras_imageattachment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_imageattachment (id, object_id, image, image_height, image_width, name, created, object_type_id, last_updated, description, image_size) FROM stdin;
\.


--
-- Data for Name: extras_journalentry; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_journalentry (last_updated, id, assigned_object_id, created, kind, comments, assigned_object_type_id, created_by_id, custom_field_data) FROM stdin;
\.


--
-- Data for Name: extras_notification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_notification (id, created, read, object_id, event_type, object_type_id, object_repr, user_id) FROM stdin;
\.


--
-- Data for Name: extras_notificationgroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_notificationgroup (id, created, last_updated, name, description) FROM stdin;
\.


--
-- Data for Name: extras_notificationgroup_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_notificationgroup_groups (id, notificationgroup_id, group_id) FROM stdin;
\.


--
-- Data for Name: extras_notificationgroup_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_notificationgroup_users (id, notificationgroup_id, user_id) FROM stdin;
\.


--
-- Data for Name: extras_savedfilter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_savedfilter (id, created, last_updated, name, slug, description, weight, enabled, shared, parameters, user_id, owner_id) FROM stdin;
\.


--
-- Data for Name: extras_savedfilter_object_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_savedfilter_object_types (id, savedfilter_id, contenttype_id) FROM stdin;
\.


--
-- Data for Name: extras_script; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_script (id, name, module_id, is_executable) FROM stdin;
\.


--
-- Data for Name: extras_subscription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_subscription (id, created, object_id, object_type_id, user_id) FROM stdin;
\.


--
-- Data for Name: extras_tableconfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_tableconfig (id, created, last_updated, "table", name, description, weight, enabled, shared, columns, ordering, object_type_id, user_id) FROM stdin;
\.


--
-- Data for Name: extras_tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_tag (name, slug, created, last_updated, id, color, description, weight, owner_id) FROM stdin;
\.


--
-- Data for Name: extras_tag_object_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_tag_object_types (id, tag_id, contenttype_id) FROM stdin;
\.


--
-- Data for Name: extras_taggeditem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_taggeditem (object_id, id, content_type_id, tag_id) FROM stdin;
\.


--
-- Data for Name: extras_webhook; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.extras_webhook (id, name, payload_url, http_method, http_content_type, additional_headers, body_template, secret, ssl_verification, ca_file_path, created, last_updated, custom_field_data, description, owner_id, timeout) FROM stdin;
\.


--
-- Data for Name: ipam_aggregate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_aggregate (created, last_updated, custom_field_data, id, prefix, date_added, description, rir_id, tenant_id, comments, owner_id) FROM stdin;
\.


--
-- Data for Name: ipam_asn; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_asn (created, last_updated, custom_field_data, id, asn, description, rir_id, tenant_id, comments, owner_id, role_id) FROM stdin;
\.


--
-- Data for Name: ipam_asnrange; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_asnrange (id, created, last_updated, custom_field_data, description, name, slug, start, "end", rir_id, tenant_id, owner_id, comments) FROM stdin;
\.


--
-- Data for Name: ipam_fhrpgroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_fhrpgroup (created, last_updated, custom_field_data, id, group_id, protocol, auth_type, auth_key, description, name, comments, owner_id) FROM stdin;
\.


--
-- Data for Name: ipam_fhrpgroupassignment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_fhrpgroupassignment (created, last_updated, id, interface_id, priority, group_id, interface_type_id) FROM stdin;
\.


--
-- Data for Name: ipam_ipaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_ipaddress (created, last_updated, custom_field_data, id, address, status, role, assigned_object_id, dns_name, description, assigned_object_type_id, nat_inside_id, tenant_id, vrf_id, comments, owner_id) FROM stdin;
\.


--
-- Data for Name: ipam_iprange; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_iprange (created, last_updated, custom_field_data, id, start_address, end_address, size, status, description, role_id, tenant_id, vrf_id, comments, mark_utilized, mark_populated, owner_id) FROM stdin;
\.


--
-- Data for Name: ipam_prefix; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_prefix (created, last_updated, custom_field_data, id, prefix, status, is_pool, description, role_id, tenant_id, vlan_id, vrf_id, _children, _depth, mark_utilized, comments, scope_id, scope_type_id, _location_id, _region_id, _site_id, _site_group_id, owner_id) FROM stdin;
\.


--
-- Data for Name: ipam_rir; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_rir (created, last_updated, custom_field_data, id, name, slug, is_private, description, owner_id, comments) FROM stdin;
\.


--
-- Data for Name: ipam_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_role (created, last_updated, custom_field_data, id, name, slug, weight, description, owner_id, comments) FROM stdin;
\.


--
-- Data for Name: ipam_routetarget; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_routetarget (created, last_updated, custom_field_data, id, name, description, tenant_id, comments, owner_id) FROM stdin;
\.


--
-- Data for Name: ipam_service; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_service (created, last_updated, custom_field_data, id, name, description, comments, parent_object_id, parent_object_type_id, owner_id, port_mappings) FROM stdin;
\.


--
-- Data for Name: ipam_service_ipaddresses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_service_ipaddresses (id, service_id, ipaddress_id) FROM stdin;
\.


--
-- Data for Name: ipam_servicetemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_servicetemplate (id, created, last_updated, custom_field_data, description, name, comments, owner_id, port_mappings) FROM stdin;
\.


--
-- Data for Name: ipam_vlan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_vlan (created, last_updated, custom_field_data, id, vid, name, status, description, group_id, role_id, site_id, tenant_id, comments, qinq_role, qinq_svlan_id, owner_id) FROM stdin;
\.


--
-- Data for Name: ipam_vlangroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_vlangroup (created, last_updated, custom_field_data, id, name, slug, scope_id, description, scope_type_id, vid_ranges, total_vlan_ids, tenant_id, owner_id, comments) FROM stdin;
\.


--
-- Data for Name: ipam_vlantranslationpolicy; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_vlantranslationpolicy (id, created, last_updated, custom_field_data, comments, name, description, owner_id) FROM stdin;
\.


--
-- Data for Name: ipam_vlantranslationrule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_vlantranslationrule (id, created, last_updated, custom_field_data, local_vid, remote_vid, policy_id, description) FROM stdin;
\.


--
-- Data for Name: ipam_vrf; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_vrf (created, last_updated, custom_field_data, id, name, rd, enforce_unique, description, tenant_id, comments, owner_id) FROM stdin;
\.


--
-- Data for Name: ipam_vrf_export_targets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_vrf_export_targets (id, vrf_id, routetarget_id) FROM stdin;
\.


--
-- Data for Name: ipam_vrf_import_targets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ipam_vrf_import_targets (id, vrf_id, routetarget_id) FROM stdin;
\.


--
-- Data for Name: social_auth_association; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_auth_association (id, server_url, handle, secret, issued, lifetime, assoc_type) FROM stdin;
\.


--
-- Data for Name: social_auth_code; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_auth_code (id, email, code, verified, "timestamp") FROM stdin;
\.


--
-- Data for Name: social_auth_nonce; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_auth_nonce (id, server_url, "timestamp", salt) FROM stdin;
\.


--
-- Data for Name: social_auth_partial; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_auth_partial (id, token, next_step, backend, "timestamp", data) FROM stdin;
\.


--
-- Data for Name: social_auth_usersocialauth; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_auth_usersocialauth (id, provider, uid, user_id, created, modified, extra_data) FROM stdin;
\.


--
-- Data for Name: taggit_tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.taggit_tag (id, name, slug) FROM stdin;
\.


--
-- Data for Name: taggit_taggeditem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.taggit_taggeditem (id, object_id, content_type_id, tag_id) FROM stdin;
\.


--
-- Data for Name: tenancy_contact; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenancy_contact (id, created, last_updated, custom_field_data, name, title, phone, email, address, comments, link, description, owner_id) FROM stdin;
\.


--
-- Data for Name: tenancy_contact_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenancy_contact_groups (id, contact_id, contactgroup_id) FROM stdin;
\.


--
-- Data for Name: tenancy_contactassignment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenancy_contactassignment (id, created, last_updated, object_id, priority, contact_id, object_type_id, role_id, custom_field_data) FROM stdin;
\.


--
-- Data for Name: tenancy_contactgroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenancy_contactgroup (id, created, last_updated, custom_field_data, name, slug, description, parent_id, comments, owner_id, path, sort_path) FROM stdin;
\.


--
-- Data for Name: tenancy_contactrole; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenancy_contactrole (id, created, last_updated, custom_field_data, name, slug, description, owner_id, comments) FROM stdin;
\.


--
-- Data for Name: tenancy_tenant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenancy_tenant (created, last_updated, custom_field_data, id, name, slug, description, comments, group_id, owner_id) FROM stdin;
\.


--
-- Data for Name: tenancy_tenantgroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenancy_tenantgroup (created, last_updated, custom_field_data, id, name, slug, description, parent_id, comments, owner_id, path, sort_path) FROM stdin;
\.


--
-- Data for Name: thumbnail_kvstore; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.thumbnail_kvstore (key, value) FROM stdin;
\.


--
-- Data for Name: users_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_group (id, name, description) FROM stdin;
\.


--
-- Data for Name: users_group_object_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_group_object_permissions (id, objectpermission_id, group_id) FROM stdin;
\.


--
-- Data for Name: users_group_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: users_objectpermission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_objectpermission (id, name, description, enabled, actions, constraints) FROM stdin;
\.


--
-- Data for Name: users_objectpermission_object_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_objectpermission_object_types (id, objectpermission_id, contenttype_id) FROM stdin;
\.


--
-- Data for Name: users_owner; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_owner (id, name, description, group_id) FROM stdin;
\.


--
-- Data for Name: users_owner_user_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_owner_user_groups (id, owner_id, group_id) FROM stdin;
\.


--
-- Data for Name: users_owner_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_owner_users (id, owner_id, user_id) FROM stdin;
\.


--
-- Data for Name: users_ownergroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_ownergroup (id, description, name) FROM stdin;
\.


--
-- Data for Name: users_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_token (id, created, expires, plaintext, write_enabled, description, user_id, allowed_ips, last_used, enabled, version, key, pepper_id, hmac_digest) FROM stdin;
1	2026-11-11 00:19:27.646721+00	\N	\N	t		1	\N	\N	t	2	ac6workshop0	1	0b827d3130a8683f717675ca890dc6c9de79b90fe6503e452a1e6c7fde2fec45
\.


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$1500000$vmhbT7ZLCLOE9n8PiBPbHP$4xJPVO1luHV8AO6+lUjK+HjOmYQ8plByQ1lVBVkSM0w=	\N	t	admin			admin@example.com	t	2026-11-11 00:19:27.503647+00
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: users_user_object_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_user_object_permissions (id, objectpermission_id, user_id) FROM stdin;
\.


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: users_userconfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_userconfig (id, data, user_id) FROM stdin;
1	{}	1
\.


--
-- Data for Name: virtualization_cluster; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.virtualization_cluster (created, last_updated, custom_field_data, id, name, comments, group_id, tenant_id, type_id, status, description, scope_id, scope_type_id, _location_id, _region_id, _site_id, _site_group_id, owner_id) FROM stdin;
\.


--
-- Data for Name: virtualization_clustergroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.virtualization_clustergroup (created, last_updated, custom_field_data, id, name, slug, description, owner_id, comments) FROM stdin;
\.


--
-- Data for Name: virtualization_clustertype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.virtualization_clustertype (created, last_updated, custom_field_data, id, name, slug, description, owner_id, comments) FROM stdin;
\.


--
-- Data for Name: virtualization_virtualdisk; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.virtualization_virtualdisk (id, created, last_updated, custom_field_data, name, description, size, virtual_machine_id, owner_id) FROM stdin;
\.


--
-- Data for Name: virtualization_virtualmachine; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.virtualization_virtualmachine (created, last_updated, custom_field_data, id, local_context_data, name, status, vcpus, memory, disk, comments, cluster_id, platform_id, primary_ip4_id, primary_ip6_id, role_id, tenant_id, site_id, device_id, description, interface_count, config_template_id, virtual_disk_count, serial, owner_id, start_on_boot, virtual_machine_type_id, _config_context_data, _config_context_generation) FROM stdin;
\.


--
-- Data for Name: virtualization_virtualmachinetype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.virtualization_virtualmachinetype (id, created, last_updated, custom_field_data, description, comments, name, slug, default_vcpus, default_memory, virtual_machine_count, default_platform_id, owner_id) FROM stdin;
\.


--
-- Data for Name: virtualization_vminterface; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.virtualization_vminterface (created, last_updated, custom_field_data, id, enabled, mtu, mode, name, _name, description, parent_id, untagged_vlan_id, virtual_machine_id, bridge_id, vrf_id, vlan_translation_policy_id, qinq_svlan_id, primary_mac_address_id, owner_id) FROM stdin;
\.


--
-- Data for Name: virtualization_vminterface_tagged_vlans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.virtualization_vminterface_tagged_vlans (id, vminterface_id, vlan_id) FROM stdin;
\.


--
-- Data for Name: vpn_ikepolicy; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vpn_ikepolicy (id, created, last_updated, custom_field_data, description, comments, name, version, mode, preshared_key, owner_id) FROM stdin;
\.


--
-- Data for Name: vpn_ikepolicy_proposals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vpn_ikepolicy_proposals (id, ikepolicy_id, ikeproposal_id) FROM stdin;
\.


--
-- Data for Name: vpn_ikeproposal; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vpn_ikeproposal (id, created, last_updated, custom_field_data, description, comments, name, authentication_method, encryption_algorithm, authentication_algorithm, "group", sa_lifetime, owner_id) FROM stdin;
\.


--
-- Data for Name: vpn_ipsecpolicy; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vpn_ipsecpolicy (id, created, last_updated, custom_field_data, description, comments, name, pfs_group, owner_id) FROM stdin;
\.


--
-- Data for Name: vpn_ipsecpolicy_proposals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vpn_ipsecpolicy_proposals (id, ipsecpolicy_id, ipsecproposal_id) FROM stdin;
\.


--
-- Data for Name: vpn_ipsecprofile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vpn_ipsecprofile (id, created, last_updated, custom_field_data, description, comments, name, mode, ike_policy_id, ipsec_policy_id, owner_id) FROM stdin;
\.


--
-- Data for Name: vpn_ipsecproposal; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vpn_ipsecproposal (id, created, last_updated, custom_field_data, description, comments, name, encryption_algorithm, authentication_algorithm, sa_lifetime_seconds, sa_lifetime_data, owner_id) FROM stdin;
\.


--
-- Data for Name: vpn_l2vpn; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vpn_l2vpn (id, created, last_updated, custom_field_data, name, slug, type, identifier, description, tenant_id, comments, status, owner_id) FROM stdin;
\.


--
-- Data for Name: vpn_l2vpn_export_targets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vpn_l2vpn_export_targets (id, l2vpn_id, routetarget_id) FROM stdin;
\.


--
-- Data for Name: vpn_l2vpn_import_targets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vpn_l2vpn_import_targets (id, l2vpn_id, routetarget_id) FROM stdin;
\.


--
-- Data for Name: vpn_l2vpntermination; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vpn_l2vpntermination (id, created, last_updated, custom_field_data, assigned_object_id, assigned_object_type_id, l2vpn_id) FROM stdin;
\.


--
-- Data for Name: vpn_tunnel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vpn_tunnel (id, created, last_updated, custom_field_data, description, comments, name, status, group_id, encapsulation, tunnel_id, ipsec_profile_id, tenant_id, owner_id) FROM stdin;
\.


--
-- Data for Name: vpn_tunnelgroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vpn_tunnelgroup (id, created, last_updated, custom_field_data, name, slug, description, owner_id, comments) FROM stdin;
\.


--
-- Data for Name: vpn_tunneltermination; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vpn_tunneltermination (id, created, last_updated, custom_field_data, role, termination_id, termination_type_id, outside_ip_id, tunnel_id) FROM stdin;
\.


--
-- Data for Name: wireless_wirelesslan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wireless_wirelesslan (id, created, last_updated, custom_field_data, ssid, group_id, description, auth_cipher, auth_psk, auth_type, vlan_id, tenant_id, comments, status, _location_id, _region_id, _site_id, _site_group_id, scope_id, scope_type_id, owner_id) FROM stdin;
\.


--
-- Data for Name: wireless_wirelesslangroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wireless_wirelesslangroup (id, created, last_updated, custom_field_data, name, slug, description, parent_id, comments, owner_id, path, sort_path) FROM stdin;
\.


--
-- Data for Name: wireless_wirelesslink; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wireless_wirelesslink (id, created, last_updated, custom_field_data, ssid, status, description, auth_cipher, auth_psk, auth_type, _interface_a_device_id, _interface_b_device_id, interface_a_id, interface_b_id, tenant_id, comments, _abs_distance, distance, distance_unit, owner_id) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 652, true);


--
-- Name: circuits_circuit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.circuits_circuit_id_seq', 1, false);


--
-- Name: circuits_circuitgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.circuits_circuitgroup_id_seq', 1, false);


--
-- Name: circuits_circuitgroupassignment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.circuits_circuitgroupassignment_id_seq', 1, false);


--
-- Name: circuits_circuittermination_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.circuits_circuittermination_id_seq', 1, false);


--
-- Name: circuits_circuittype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.circuits_circuittype_id_seq', 1, false);


--
-- Name: circuits_provider_asns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.circuits_provider_asns_id_seq', 1, false);


--
-- Name: circuits_provider_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.circuits_provider_id_seq', 1, false);


--
-- Name: circuits_provideraccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.circuits_provideraccount_id_seq', 1, false);


--
-- Name: circuits_providernetwork_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.circuits_providernetwork_id_seq', 1, false);


--
-- Name: circuits_virtualcircuit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.circuits_virtualcircuit_id_seq', 1, false);


--
-- Name: circuits_virtualcircuittermination_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.circuits_virtualcircuittermination_id_seq', 1, false);


--
-- Name: circuits_virtualcircuittype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.circuits_virtualcircuittype_id_seq', 1, false);


--
-- Name: core_autosyncrecord_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_autosyncrecord_id_seq', 1, false);


--
-- Name: core_datafile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_datafile_id_seq', 1, false);


--
-- Name: core_datasource_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_datasource_id_seq', 1, false);


--
-- Name: core_job_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_job_id_seq', 1, false);


--
-- Name: core_managedfile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_managedfile_id_seq', 1, false);


--
-- Name: core_objectchange_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_objectchange_id_seq', 1, false);


--
-- Name: dcim_cable_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_cable_id_seq', 1, false);


--
-- Name: dcim_cablebundle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_cablebundle_id_seq', 1, false);


--
-- Name: dcim_cablepath_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_cablepath_id_seq', 1, false);


--
-- Name: dcim_cabletermination_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_cabletermination_id_seq', 1, false);


--
-- Name: dcim_consoleport_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_consoleport_id_seq', 1, false);


--
-- Name: dcim_consoleporttemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_consoleporttemplate_id_seq', 1, false);


--
-- Name: dcim_consoleserverport_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_consoleserverport_id_seq', 1, false);


--
-- Name: dcim_consoleserverporttemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_consoleserverporttemplate_id_seq', 1, false);


--
-- Name: dcim_coolingfeed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_coolingfeed_id_seq', 1, false);


--
-- Name: dcim_coolingintake_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_coolingintake_id_seq', 1, false);


--
-- Name: dcim_coolingintaketemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_coolingintaketemplate_id_seq', 1, false);


--
-- Name: dcim_coolingoutflow_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_coolingoutflow_id_seq', 1, false);


--
-- Name: dcim_coolingoutflowtemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_coolingoutflowtemplate_id_seq', 1, false);


--
-- Name: dcim_coolingsource_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_coolingsource_id_seq', 1, false);


--
-- Name: dcim_device_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_device_id_seq', 1, false);


--
-- Name: dcim_devicebay_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_devicebay_id_seq', 1, false);


--
-- Name: dcim_devicebaytemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_devicebaytemplate_id_seq', 1, false);


--
-- Name: dcim_devicerole_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_devicerole_id_seq', 1, false);


--
-- Name: dcim_devicetype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_devicetype_id_seq', 1, false);


--
-- Name: dcim_frontport_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_frontport_id_seq', 1, false);


--
-- Name: dcim_frontporttemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_frontporttemplate_id_seq', 1, false);


--
-- Name: dcim_interface_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_interface_id_seq', 1, false);


--
-- Name: dcim_interface_tagged_vlans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_interface_tagged_vlans_id_seq', 1, false);


--
-- Name: dcim_interface_vdcs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_interface_vdcs_id_seq', 1, false);


--
-- Name: dcim_interface_wireless_lans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_interface_wireless_lans_id_seq', 1, false);


--
-- Name: dcim_interfacetemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_interfacetemplate_id_seq', 1, false);


--
-- Name: dcim_inventoryitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_inventoryitem_id_seq', 1, false);


--
-- Name: dcim_inventoryitemrole_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_inventoryitemrole_id_seq', 1, false);


--
-- Name: dcim_inventoryitemtemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_inventoryitemtemplate_id_seq', 1, false);


--
-- Name: dcim_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_location_id_seq', 1, false);


--
-- Name: dcim_macaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_macaddress_id_seq', 1, false);


--
-- Name: dcim_manufacturer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_manufacturer_id_seq', 1, false);


--
-- Name: dcim_module_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_module_id_seq', 1, false);


--
-- Name: dcim_modulebay_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_modulebay_id_seq', 1, false);


--
-- Name: dcim_modulebay_module_bay_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_modulebay_module_bay_types_id_seq', 1, false);


--
-- Name: dcim_modulebaytemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_modulebaytemplate_id_seq', 1, false);


--
-- Name: dcim_modulebaytemplate_module_bay_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_modulebaytemplate_module_bay_types_id_seq', 1, false);


--
-- Name: dcim_modulebaytype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_modulebaytype_id_seq', 1, false);


--
-- Name: dcim_moduletype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_moduletype_id_seq', 1, false);


--
-- Name: dcim_moduletype_module_bay_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_moduletype_module_bay_types_id_seq', 1, false);


--
-- Name: dcim_moduletypeprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_moduletypeprofile_id_seq', 8, true);


--
-- Name: dcim_platform_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_platform_id_seq', 1, false);


--
-- Name: dcim_portmapping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_portmapping_id_seq', 1, false);


--
-- Name: dcim_porttemplatemapping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_porttemplatemapping_id_seq', 1, false);


--
-- Name: dcim_powerfeed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_powerfeed_id_seq', 1, false);


--
-- Name: dcim_poweroutlet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_poweroutlet_id_seq', 1, false);


--
-- Name: dcim_poweroutlettemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_poweroutlettemplate_id_seq', 1, false);


--
-- Name: dcim_powerpanel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_powerpanel_id_seq', 1, false);


--
-- Name: dcim_powerport_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_powerport_id_seq', 1, false);


--
-- Name: dcim_powerporttemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_powerporttemplate_id_seq', 1, false);


--
-- Name: dcim_rack_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_rack_id_seq', 1, false);


--
-- Name: dcim_rackgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_rackgroup_id_seq', 1, false);


--
-- Name: dcim_rackreservation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_rackreservation_id_seq', 1, false);


--
-- Name: dcim_rackrole_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_rackrole_id_seq', 1, false);


--
-- Name: dcim_racktype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_racktype_id_seq', 1, false);


--
-- Name: dcim_rearport_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_rearport_id_seq', 1, false);


--
-- Name: dcim_rearporttemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_rearporttemplate_id_seq', 1, false);


--
-- Name: dcim_region_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_region_id_seq', 1, false);


--
-- Name: dcim_site_asns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_site_asns_id_seq', 1, false);


--
-- Name: dcim_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_site_id_seq', 1, false);


--
-- Name: dcim_sitegroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_sitegroup_id_seq', 1, false);


--
-- Name: dcim_virtualchassis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_virtualchassis_id_seq', 1, false);


--
-- Name: dcim_virtualdevicecontext_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dcim_virtualdevicecontext_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 164, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 813, true);


--
-- Name: extras_bookmark_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_bookmark_id_seq', 1, false);


--
-- Name: extras_configcontext_cluster_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_configcontext_cluster_groups_id_seq', 1, false);


--
-- Name: extras_configcontext_cluster_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_configcontext_cluster_types_id_seq', 1, false);


--
-- Name: extras_configcontext_clusters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_configcontext_clusters_id_seq', 1, false);


--
-- Name: extras_configcontext_device_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_configcontext_device_types_id_seq', 1, false);


--
-- Name: extras_configcontext_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_configcontext_id_seq', 1, false);


--
-- Name: extras_configcontext_locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_configcontext_locations_id_seq', 1, false);


--
-- Name: extras_configcontext_platforms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_configcontext_platforms_id_seq', 1, false);


--
-- Name: extras_configcontext_regions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_configcontext_regions_id_seq', 1, false);


--
-- Name: extras_configcontext_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_configcontext_roles_id_seq', 1, false);


--
-- Name: extras_configcontext_site_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_configcontext_site_groups_id_seq', 1, false);


--
-- Name: extras_configcontext_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_configcontext_sites_id_seq', 1, false);


--
-- Name: extras_configcontext_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_configcontext_tags_id_seq', 1, false);


--
-- Name: extras_configcontext_tenant_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_configcontext_tenant_groups_id_seq', 1, false);


--
-- Name: extras_configcontext_tenants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_configcontext_tenants_id_seq', 1, false);


--
-- Name: extras_configcontextprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_configcontextprofile_id_seq', 1, false);


--
-- Name: extras_configrevision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_configrevision_id_seq', 1, false);


--
-- Name: extras_configtemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_configtemplate_id_seq', 1, false);


--
-- Name: extras_customfield_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_customfield_id_seq', 1, false);


--
-- Name: extras_customfield_object_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_customfield_object_types_id_seq', 1, false);


--
-- Name: extras_customfieldchoiceset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_customfieldchoiceset_id_seq', 1, false);


--
-- Name: extras_customlink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_customlink_id_seq', 1, false);


--
-- Name: extras_customlink_object_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_customlink_object_types_id_seq', 1, false);


--
-- Name: extras_dashboard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_dashboard_id_seq', 1, false);


--
-- Name: extras_eventrule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_eventrule_id_seq', 1, false);


--
-- Name: extras_eventrule_object_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_eventrule_object_types_id_seq', 1, false);


--
-- Name: extras_exporttemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_exporttemplate_id_seq', 1, false);


--
-- Name: extras_exporttemplate_object_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_exporttemplate_object_types_id_seq', 1, false);


--
-- Name: extras_imageattachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_imageattachment_id_seq', 1, false);


--
-- Name: extras_journalentry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_journalentry_id_seq', 1, false);


--
-- Name: extras_notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_notification_id_seq', 1, false);


--
-- Name: extras_notificationgroup_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_notificationgroup_groups_id_seq', 1, false);


--
-- Name: extras_notificationgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_notificationgroup_id_seq', 1, false);


--
-- Name: extras_notificationgroup_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_notificationgroup_users_id_seq', 1, false);


--
-- Name: extras_savedfilter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_savedfilter_id_seq', 1, false);


--
-- Name: extras_savedfilter_object_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_savedfilter_object_types_id_seq', 1, false);


--
-- Name: extras_script_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_script_id_seq', 1, false);


--
-- Name: extras_subscription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_subscription_id_seq', 1, false);


--
-- Name: extras_tableconfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_tableconfig_id_seq', 1, false);


--
-- Name: extras_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_tag_id_seq', 1, false);


--
-- Name: extras_tag_object_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_tag_object_types_id_seq', 1, false);


--
-- Name: extras_taggeditem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_taggeditem_id_seq', 1, false);


--
-- Name: extras_webhook_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.extras_webhook_id_seq', 1, false);


--
-- Name: ipam_aggregate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_aggregate_id_seq', 1, false);


--
-- Name: ipam_asn_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_asn_id_seq', 1, false);


--
-- Name: ipam_asnrange_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_asnrange_id_seq', 1, false);


--
-- Name: ipam_fhrpgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_fhrpgroup_id_seq', 1, false);


--
-- Name: ipam_fhrpgroupassignment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_fhrpgroupassignment_id_seq', 1, false);


--
-- Name: ipam_ipaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_ipaddress_id_seq', 1, false);


--
-- Name: ipam_iprange_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_iprange_id_seq', 1, false);


--
-- Name: ipam_prefix_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_prefix_id_seq', 1, false);


--
-- Name: ipam_rir_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_rir_id_seq', 1, false);


--
-- Name: ipam_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_role_id_seq', 1, false);


--
-- Name: ipam_routetarget_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_routetarget_id_seq', 1, false);


--
-- Name: ipam_service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_service_id_seq', 1, false);


--
-- Name: ipam_service_ipaddresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_service_ipaddresses_id_seq', 1, false);


--
-- Name: ipam_servicetemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_servicetemplate_id_seq', 1, false);


--
-- Name: ipam_vlan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_vlan_id_seq', 1, false);


--
-- Name: ipam_vlangroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_vlangroup_id_seq', 1, false);


--
-- Name: ipam_vlantranslationpolicy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_vlantranslationpolicy_id_seq', 1, false);


--
-- Name: ipam_vlantranslationrule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_vlantranslationrule_id_seq', 1, false);


--
-- Name: ipam_vrf_export_targets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_vrf_export_targets_id_seq', 1, false);


--
-- Name: ipam_vrf_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_vrf_id_seq', 1, false);


--
-- Name: ipam_vrf_import_targets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ipam_vrf_import_targets_id_seq', 1, false);


--
-- Name: social_auth_association_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.social_auth_association_id_seq', 1, false);


--
-- Name: social_auth_code_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.social_auth_code_id_seq', 1, false);


--
-- Name: social_auth_nonce_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.social_auth_nonce_id_seq', 1, false);


--
-- Name: social_auth_partial_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.social_auth_partial_id_seq', 1, false);


--
-- Name: social_auth_usersocialauth_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.social_auth_usersocialauth_id_seq', 1, false);


--
-- Name: taggit_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.taggit_tag_id_seq', 1, false);


--
-- Name: taggit_taggeditem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.taggit_taggeditem_id_seq', 1, false);


--
-- Name: tenancy_contact_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tenancy_contact_groups_id_seq', 1, false);


--
-- Name: tenancy_contact_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tenancy_contact_id_seq', 1, false);


--
-- Name: tenancy_contactassignment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tenancy_contactassignment_id_seq', 1, false);


--
-- Name: tenancy_contactgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tenancy_contactgroup_id_seq', 1, false);


--
-- Name: tenancy_contactrole_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tenancy_contactrole_id_seq', 1, false);


--
-- Name: tenancy_tenant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tenancy_tenant_id_seq', 1, false);


--
-- Name: tenancy_tenantgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tenancy_tenantgroup_id_seq', 1, false);


--
-- Name: users_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_group_id_seq', 1, false);


--
-- Name: users_group_object_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_group_object_permissions_id_seq', 1, false);


--
-- Name: users_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_group_permissions_id_seq', 1, false);


--
-- Name: users_objectpermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_objectpermission_id_seq', 1, false);


--
-- Name: users_objectpermission_object_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_objectpermission_object_types_id_seq', 1, false);


--
-- Name: users_owner_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_owner_id_seq', 1, false);


--
-- Name: users_owner_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_owner_user_groups_id_seq', 1, false);


--
-- Name: users_owner_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_owner_users_id_seq', 1, false);


--
-- Name: users_ownergroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_ownergroup_id_seq', 1, false);


--
-- Name: users_token_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_token_id_seq', 1, true);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_user_id_seq', 1, true);


--
-- Name: users_user_object_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_user_object_permissions_id_seq', 1, false);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 1, false);


--
-- Name: users_userconfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_userconfig_id_seq', 1, true);


--
-- Name: virtualization_cluster_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.virtualization_cluster_id_seq', 1, false);


--
-- Name: virtualization_clustergroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.virtualization_clustergroup_id_seq', 1, false);


--
-- Name: virtualization_clustertype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.virtualization_clustertype_id_seq', 1, false);


--
-- Name: virtualization_virtualdisk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.virtualization_virtualdisk_id_seq', 1, false);


--
-- Name: virtualization_virtualmachine_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.virtualization_virtualmachine_id_seq', 1, false);


--
-- Name: virtualization_virtualmachinetype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.virtualization_virtualmachinetype_id_seq', 1, false);


--
-- Name: virtualization_vminterface_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.virtualization_vminterface_id_seq', 1, false);


--
-- Name: virtualization_vminterface_tagged_vlans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.virtualization_vminterface_tagged_vlans_id_seq', 1, false);


--
-- Name: vpn_ikepolicy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vpn_ikepolicy_id_seq', 1, false);


--
-- Name: vpn_ikepolicy_proposals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vpn_ikepolicy_proposals_id_seq', 1, false);


--
-- Name: vpn_ikeproposal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vpn_ikeproposal_id_seq', 1, false);


--
-- Name: vpn_ipsecpolicy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vpn_ipsecpolicy_id_seq', 1, false);


--
-- Name: vpn_ipsecpolicy_proposals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vpn_ipsecpolicy_proposals_id_seq', 1, false);


--
-- Name: vpn_ipsecprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vpn_ipsecprofile_id_seq', 1, false);


--
-- Name: vpn_ipsecproposal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vpn_ipsecproposal_id_seq', 1, false);


--
-- Name: vpn_l2vpn_export_targets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vpn_l2vpn_export_targets_id_seq', 1, false);


--
-- Name: vpn_l2vpn_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vpn_l2vpn_id_seq', 1, false);


--
-- Name: vpn_l2vpn_import_targets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vpn_l2vpn_import_targets_id_seq', 1, false);


--
-- Name: vpn_l2vpntermination_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vpn_l2vpntermination_id_seq', 1, false);


--
-- Name: vpn_tunnel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vpn_tunnel_id_seq', 1, false);


--
-- Name: vpn_tunnelgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vpn_tunnelgroup_id_seq', 1, false);


--
-- Name: vpn_tunneltermination_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vpn_tunneltermination_id_seq', 1, false);


--
-- Name: wireless_wirelesslan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wireless_wirelesslan_id_seq', 1, false);


--
-- Name: wireless_wirelesslangroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wireless_wirelesslangroup_id_seq', 1, false);


--
-- Name: wireless_wirelesslink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wireless_wirelesslink_id_seq', 1, false);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: circuits_circuit circuits_circuit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuit
    ADD CONSTRAINT circuits_circuit_pkey PRIMARY KEY (id);


--
-- Name: circuits_circuit circuits_circuit_unique_provider_cid; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuit
    ADD CONSTRAINT circuits_circuit_unique_provider_cid UNIQUE (provider_id, cid);


--
-- Name: circuits_circuit circuits_circuit_unique_provideraccount_cid; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuit
    ADD CONSTRAINT circuits_circuit_unique_provideraccount_cid UNIQUE (provider_account_id, cid);


--
-- Name: circuits_circuitgroup circuits_circuitgroup_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuitgroup
    ADD CONSTRAINT circuits_circuitgroup_name_key UNIQUE (name);


--
-- Name: circuits_circuitgroup circuits_circuitgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuitgroup
    ADD CONSTRAINT circuits_circuitgroup_pkey PRIMARY KEY (id);


--
-- Name: circuits_circuitgroup circuits_circuitgroup_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuitgroup
    ADD CONSTRAINT circuits_circuitgroup_slug_key UNIQUE (slug);


--
-- Name: circuits_circuitgroupassignment circuits_circuitgroupassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuitgroupassignment
    ADD CONSTRAINT circuits_circuitgroupassignment_pkey PRIMARY KEY (id);


--
-- Name: circuits_circuitgroupassignment circuits_circuitgroupassignment_unique_member_group; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuitgroupassignment
    ADD CONSTRAINT circuits_circuitgroupassignment_unique_member_group UNIQUE (member_type_id, member_id, group_id);


--
-- Name: circuits_circuittermination circuits_circuittermination_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuittermination
    ADD CONSTRAINT circuits_circuittermination_pkey PRIMARY KEY (id);


--
-- Name: circuits_circuittermination circuits_circuittermination_unique_circuit_term_side; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuittermination
    ADD CONSTRAINT circuits_circuittermination_unique_circuit_term_side UNIQUE (circuit_id, term_side);


--
-- Name: circuits_circuittype circuits_circuittype_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuittype
    ADD CONSTRAINT circuits_circuittype_name_key UNIQUE (name);


--
-- Name: circuits_circuittype circuits_circuittype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuittype
    ADD CONSTRAINT circuits_circuittype_pkey PRIMARY KEY (id);


--
-- Name: circuits_circuittype circuits_circuittype_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuittype
    ADD CONSTRAINT circuits_circuittype_slug_key UNIQUE (slug);


--
-- Name: circuits_provider_asns circuits_provider_asns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_provider_asns
    ADD CONSTRAINT circuits_provider_asns_pkey PRIMARY KEY (id);


--
-- Name: circuits_provider_asns circuits_provider_asns_provider_id_asn_id_6e573798_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_provider_asns
    ADD CONSTRAINT circuits_provider_asns_provider_id_asn_id_6e573798_uniq UNIQUE (provider_id, asn_id);


--
-- Name: circuits_provider circuits_provider_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_provider
    ADD CONSTRAINT circuits_provider_name_key UNIQUE (name);


--
-- Name: circuits_provider circuits_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_provider
    ADD CONSTRAINT circuits_provider_pkey PRIMARY KEY (id);


--
-- Name: circuits_provider circuits_provider_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_provider
    ADD CONSTRAINT circuits_provider_slug_key UNIQUE (slug);


--
-- Name: circuits_provideraccount circuits_provideraccount_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_provideraccount
    ADD CONSTRAINT circuits_provideraccount_pkey PRIMARY KEY (id);


--
-- Name: circuits_provideraccount circuits_provideraccount_unique_provider_account; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_provideraccount
    ADD CONSTRAINT circuits_provideraccount_unique_provider_account UNIQUE (provider_id, account);


--
-- Name: circuits_providernetwork circuits_providernetwork_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_providernetwork
    ADD CONSTRAINT circuits_providernetwork_pkey PRIMARY KEY (id);


--
-- Name: circuits_providernetwork circuits_providernetwork_unique_provider_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_providernetwork
    ADD CONSTRAINT circuits_providernetwork_unique_provider_name UNIQUE (provider_id, name);


--
-- Name: circuits_virtualcircuit circuits_virtualcircuit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_virtualcircuit
    ADD CONSTRAINT circuits_virtualcircuit_pkey PRIMARY KEY (id);


--
-- Name: circuits_virtualcircuit circuits_virtualcircuit_unique_provider_network_cid; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_virtualcircuit
    ADD CONSTRAINT circuits_virtualcircuit_unique_provider_network_cid UNIQUE (provider_network_id, cid);


--
-- Name: circuits_virtualcircuit circuits_virtualcircuit_unique_provideraccount_cid; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_virtualcircuit
    ADD CONSTRAINT circuits_virtualcircuit_unique_provideraccount_cid UNIQUE (provider_account_id, cid);


--
-- Name: circuits_virtualcircuittermination circuits_virtualcircuittermination_interface_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_virtualcircuittermination
    ADD CONSTRAINT circuits_virtualcircuittermination_interface_id_key UNIQUE (interface_id);


--
-- Name: circuits_virtualcircuittermination circuits_virtualcircuittermination_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_virtualcircuittermination
    ADD CONSTRAINT circuits_virtualcircuittermination_pkey PRIMARY KEY (id);


--
-- Name: circuits_virtualcircuittype circuits_virtualcircuittype_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_virtualcircuittype
    ADD CONSTRAINT circuits_virtualcircuittype_name_key UNIQUE (name);


--
-- Name: circuits_virtualcircuittype circuits_virtualcircuittype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_virtualcircuittype
    ADD CONSTRAINT circuits_virtualcircuittype_pkey PRIMARY KEY (id);


--
-- Name: circuits_virtualcircuittype circuits_virtualcircuittype_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_virtualcircuittype
    ADD CONSTRAINT circuits_virtualcircuittype_slug_key UNIQUE (slug);


--
-- Name: core_autosyncrecord core_autosyncrecord_object; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_autosyncrecord
    ADD CONSTRAINT core_autosyncrecord_object UNIQUE (object_type_id, object_id);


--
-- Name: core_autosyncrecord core_autosyncrecord_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_autosyncrecord
    ADD CONSTRAINT core_autosyncrecord_pkey PRIMARY KEY (id);


--
-- Name: core_datafile core_datafile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_datafile
    ADD CONSTRAINT core_datafile_pkey PRIMARY KEY (id);


--
-- Name: core_datafile core_datafile_unique_source_path; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_datafile
    ADD CONSTRAINT core_datafile_unique_source_path UNIQUE (source_id, path);


--
-- Name: core_datasource core_datasource_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_datasource
    ADD CONSTRAINT core_datasource_name_key UNIQUE (name);


--
-- Name: core_datasource core_datasource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_datasource
    ADD CONSTRAINT core_datasource_pkey PRIMARY KEY (id);


--
-- Name: core_job core_job_job_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_job
    ADD CONSTRAINT core_job_job_id_key UNIQUE (job_id);


--
-- Name: core_job core_job_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_job
    ADD CONSTRAINT core_job_pkey PRIMARY KEY (id);


--
-- Name: core_managedfile core_managedfile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_managedfile
    ADD CONSTRAINT core_managedfile_pkey PRIMARY KEY (id);


--
-- Name: core_managedfile core_managedfile_unique_root_path; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_managedfile
    ADD CONSTRAINT core_managedfile_unique_root_path UNIQUE (file_root, file_path);


--
-- Name: core_objectchange core_objectchange_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_objectchange
    ADD CONSTRAINT core_objectchange_pkey PRIMARY KEY (id);


--
-- Name: core_objecttype core_objecttype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_objecttype
    ADD CONSTRAINT core_objecttype_pkey PRIMARY KEY (contenttype_ptr_id);


--
-- Name: dcim_cable dcim_cable_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_cable
    ADD CONSTRAINT dcim_cable_pkey PRIMARY KEY (id);


--
-- Name: dcim_cablebundle dcim_cablebundle_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_cablebundle
    ADD CONSTRAINT dcim_cablebundle_name_key UNIQUE (name);


--
-- Name: dcim_cablebundle dcim_cablebundle_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_cablebundle
    ADD CONSTRAINT dcim_cablebundle_pkey PRIMARY KEY (id);


--
-- Name: dcim_cablepath dcim_cablepath_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_cablepath
    ADD CONSTRAINT dcim_cablepath_pkey PRIMARY KEY (id);


--
-- Name: dcim_cabletermination dcim_cabletermination_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_cabletermination
    ADD CONSTRAINT dcim_cabletermination_pkey PRIMARY KEY (id);


--
-- Name: dcim_cabletermination dcim_cabletermination_unique_connector; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_cabletermination
    ADD CONSTRAINT dcim_cabletermination_unique_connector UNIQUE (cable_id, cable_end, connector);


--
-- Name: dcim_cabletermination dcim_cabletermination_unique_termination; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_cabletermination
    ADD CONSTRAINT dcim_cabletermination_unique_termination UNIQUE (termination_type_id, termination_id);


--
-- Name: dcim_consoleport dcim_consoleport_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleport
    ADD CONSTRAINT dcim_consoleport_pkey PRIMARY KEY (id);


--
-- Name: dcim_consoleport dcim_consoleport_unique_device_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleport
    ADD CONSTRAINT dcim_consoleport_unique_device_name UNIQUE (device_id, name);


--
-- Name: dcim_consoleporttemplate dcim_consoleporttemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleporttemplate
    ADD CONSTRAINT dcim_consoleporttemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_consoleporttemplate dcim_consoleporttemplate_unique_device_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleporttemplate
    ADD CONSTRAINT dcim_consoleporttemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_consoleporttemplate dcim_consoleporttemplate_unique_module_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleporttemplate
    ADD CONSTRAINT dcim_consoleporttemplate_unique_module_type_name UNIQUE (module_type_id, name);


--
-- Name: dcim_consoleserverport dcim_consoleserverport_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleserverport
    ADD CONSTRAINT dcim_consoleserverport_pkey PRIMARY KEY (id);


--
-- Name: dcim_consoleserverport dcim_consoleserverport_unique_device_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleserverport
    ADD CONSTRAINT dcim_consoleserverport_unique_device_name UNIQUE (device_id, name);


--
-- Name: dcim_consoleserverporttemplate dcim_consoleserverporttemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleserverporttemplate
    ADD CONSTRAINT dcim_consoleserverporttemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_consoleserverporttemplate dcim_consoleserverporttemplate_unique_device_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleserverporttemplate
    ADD CONSTRAINT dcim_consoleserverporttemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_consoleserverporttemplate dcim_consoleserverporttemplate_unique_module_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleserverporttemplate
    ADD CONSTRAINT dcim_consoleserverporttemplate_unique_module_type_name UNIQUE (module_type_id, name);


--
-- Name: dcim_coolingfeed dcim_coolingfeed_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingfeed
    ADD CONSTRAINT dcim_coolingfeed_pkey PRIMARY KEY (id);


--
-- Name: dcim_coolingfeed dcim_coolingfeed_unique_cooling_source_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingfeed
    ADD CONSTRAINT dcim_coolingfeed_unique_cooling_source_name UNIQUE (cooling_source_id, name);


--
-- Name: dcim_coolingintake dcim_coolingintake_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingintake
    ADD CONSTRAINT dcim_coolingintake_pkey PRIMARY KEY (id);


--
-- Name: dcim_coolingintake dcim_coolingintake_unique_device_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingintake
    ADD CONSTRAINT dcim_coolingintake_unique_device_name UNIQUE (device_id, name);


--
-- Name: dcim_coolingintaketemplate dcim_coolingintaketemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingintaketemplate
    ADD CONSTRAINT dcim_coolingintaketemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_coolingintaketemplate dcim_coolingintaketemplate_unique_device_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingintaketemplate
    ADD CONSTRAINT dcim_coolingintaketemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_coolingintaketemplate dcim_coolingintaketemplate_unique_module_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingintaketemplate
    ADD CONSTRAINT dcim_coolingintaketemplate_unique_module_type_name UNIQUE (module_type_id, name);


--
-- Name: dcim_coolingoutflow dcim_coolingoutflow_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingoutflow
    ADD CONSTRAINT dcim_coolingoutflow_pkey PRIMARY KEY (id);


--
-- Name: dcim_coolingoutflow dcim_coolingoutflow_unique_device_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingoutflow
    ADD CONSTRAINT dcim_coolingoutflow_unique_device_name UNIQUE (device_id, name);


--
-- Name: dcim_coolingoutflowtemplate dcim_coolingoutflowtemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingoutflowtemplate
    ADD CONSTRAINT dcim_coolingoutflowtemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_coolingoutflowtemplate dcim_coolingoutflowtemplate_unique_device_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingoutflowtemplate
    ADD CONSTRAINT dcim_coolingoutflowtemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_coolingoutflowtemplate dcim_coolingoutflowtemplate_unique_module_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingoutflowtemplate
    ADD CONSTRAINT dcim_coolingoutflowtemplate_unique_module_type_name UNIQUE (module_type_id, name);


--
-- Name: dcim_coolingsource dcim_coolingsource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingsource
    ADD CONSTRAINT dcim_coolingsource_pkey PRIMARY KEY (id);


--
-- Name: dcim_coolingsource dcim_coolingsource_unique_site_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingsource
    ADD CONSTRAINT dcim_coolingsource_unique_site_name UNIQUE (site_id, name);


--
-- Name: dcim_device dcim_device_asset_tag_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_asset_tag_key UNIQUE (asset_tag);


--
-- Name: dcim_device dcim_device_oob_ip_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_oob_ip_id_key UNIQUE (oob_ip_id);


--
-- Name: dcim_device dcim_device_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_pkey PRIMARY KEY (id);


--
-- Name: dcim_device dcim_device_primary_ip4_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_primary_ip4_id_key UNIQUE (primary_ip4_id);


--
-- Name: dcim_device dcim_device_primary_ip6_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_primary_ip6_id_key UNIQUE (primary_ip6_id);


--
-- Name: dcim_device dcim_device_unique_rack_position_face; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_unique_rack_position_face UNIQUE (rack_id, "position", face);


--
-- Name: dcim_device dcim_device_unique_virtual_chassis_vc_position; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_unique_virtual_chassis_vc_position UNIQUE (virtual_chassis_id, vc_position);


--
-- Name: dcim_devicebay dcim_devicebay_installed_device_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicebay
    ADD CONSTRAINT dcim_devicebay_installed_device_id_key UNIQUE (installed_device_id);


--
-- Name: dcim_devicebay dcim_devicebay_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicebay
    ADD CONSTRAINT dcim_devicebay_pkey PRIMARY KEY (id);


--
-- Name: dcim_devicebay dcim_devicebay_unique_device_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicebay
    ADD CONSTRAINT dcim_devicebay_unique_device_name UNIQUE (device_id, name);


--
-- Name: dcim_devicebaytemplate dcim_devicebaytemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicebaytemplate
    ADD CONSTRAINT dcim_devicebaytemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_devicebaytemplate dcim_devicebaytemplate_unique_device_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicebaytemplate
    ADD CONSTRAINT dcim_devicebaytemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_devicerole dcim_devicerole_parent_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicerole
    ADD CONSTRAINT dcim_devicerole_parent_name UNIQUE NULLS NOT DISTINCT (parent_id, name);


--
-- Name: dcim_devicerole dcim_devicerole_parent_slug; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicerole
    ADD CONSTRAINT dcim_devicerole_parent_slug UNIQUE NULLS NOT DISTINCT (parent_id, slug);


--
-- Name: dcim_devicerole dcim_devicerole_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicerole
    ADD CONSTRAINT dcim_devicerole_pkey PRIMARY KEY (id);


--
-- Name: dcim_devicetype dcim_devicetype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicetype
    ADD CONSTRAINT dcim_devicetype_pkey PRIMARY KEY (id);


--
-- Name: dcim_devicetype dcim_devicetype_unique_manufacturer_model; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicetype
    ADD CONSTRAINT dcim_devicetype_unique_manufacturer_model UNIQUE (manufacturer_id, model);


--
-- Name: dcim_devicetype dcim_devicetype_unique_manufacturer_slug; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicetype
    ADD CONSTRAINT dcim_devicetype_unique_manufacturer_slug UNIQUE (manufacturer_id, slug);


--
-- Name: dcim_frontport dcim_frontport_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_frontport
    ADD CONSTRAINT dcim_frontport_pkey PRIMARY KEY (id);


--
-- Name: dcim_frontport dcim_frontport_unique_device_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_frontport
    ADD CONSTRAINT dcim_frontport_unique_device_name UNIQUE (device_id, name);


--
-- Name: dcim_frontporttemplate dcim_frontporttemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_frontporttemplate
    ADD CONSTRAINT dcim_frontporttemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_frontporttemplate dcim_frontporttemplate_unique_device_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_frontporttemplate
    ADD CONSTRAINT dcim_frontporttemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_frontporttemplate dcim_frontporttemplate_unique_module_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_frontporttemplate
    ADD CONSTRAINT dcim_frontporttemplate_unique_module_type_name UNIQUE (module_type_id, name);


--
-- Name: dcim_interface dcim_interface_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface_pkey PRIMARY KEY (id);


--
-- Name: dcim_interface dcim_interface_primary_mac_address_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface_primary_mac_address_id_key UNIQUE (primary_mac_address_id);


--
-- Name: dcim_interface_tagged_vlans dcim_interface_tagged_vlans_interface_id_vlan_id_0d55c576_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface_tagged_vlans
    ADD CONSTRAINT dcim_interface_tagged_vlans_interface_id_vlan_id_0d55c576_uniq UNIQUE (interface_id, vlan_id);


--
-- Name: dcim_interface_tagged_vlans dcim_interface_tagged_vlans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface_tagged_vlans
    ADD CONSTRAINT dcim_interface_tagged_vlans_pkey PRIMARY KEY (id);


--
-- Name: dcim_interface dcim_interface_unique_device_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface_unique_device_name UNIQUE (device_id, name);


--
-- Name: dcim_interface dcim_interface_unique_parent_channel_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface_unique_parent_channel_id UNIQUE (parent_id, channel_id);


--
-- Name: dcim_interface_vdcs dcim_interface_vdcs_interface_id_virtualdevi_cca9c2a6_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface_vdcs
    ADD CONSTRAINT dcim_interface_vdcs_interface_id_virtualdevi_cca9c2a6_uniq UNIQUE (interface_id, virtualdevicecontext_id);


--
-- Name: dcim_interface_vdcs dcim_interface_vdcs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface_vdcs
    ADD CONSTRAINT dcim_interface_vdcs_pkey PRIMARY KEY (id);


--
-- Name: dcim_interface_wireless_lans dcim_interface_wireless__interface_id_wirelesslan_b52fb3d8_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface_wireless_lans
    ADD CONSTRAINT dcim_interface_wireless__interface_id_wirelesslan_b52fb3d8_uniq UNIQUE (interface_id, wirelesslan_id);


--
-- Name: dcim_interface_wireless_lans dcim_interface_wireless_lans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface_wireless_lans
    ADD CONSTRAINT dcim_interface_wireless_lans_pkey PRIMARY KEY (id);


--
-- Name: dcim_interfacetemplate dcim_interfacetemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interfacetemplate
    ADD CONSTRAINT dcim_interfacetemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_interfacetemplate dcim_interfacetemplate_unique_device_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interfacetemplate
    ADD CONSTRAINT dcim_interfacetemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_interfacetemplate dcim_interfacetemplate_unique_module_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interfacetemplate
    ADD CONSTRAINT dcim_interfacetemplate_unique_module_type_name UNIQUE (module_type_id, name);


--
-- Name: dcim_interfacetemplate dcim_interfacetemplate_unique_parent_channel_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interfacetemplate
    ADD CONSTRAINT dcim_interfacetemplate_unique_parent_channel_id UNIQUE (parent_id, channel_id);


--
-- Name: dcim_inventoryitem dcim_inventoryitem_asset_tag_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitem
    ADD CONSTRAINT dcim_inventoryitem_asset_tag_key UNIQUE (asset_tag);


--
-- Name: dcim_inventoryitem dcim_inventoryitem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitem
    ADD CONSTRAINT dcim_inventoryitem_pkey PRIMARY KEY (id);


--
-- Name: dcim_inventoryitem dcim_inventoryitem_unique_device_parent_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitem
    ADD CONSTRAINT dcim_inventoryitem_unique_device_parent_name UNIQUE (device_id, parent_id, name);


--
-- Name: dcim_inventoryitemrole dcim_inventoryitemrole_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitemrole
    ADD CONSTRAINT dcim_inventoryitemrole_name_key UNIQUE (name);


--
-- Name: dcim_inventoryitemrole dcim_inventoryitemrole_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitemrole
    ADD CONSTRAINT dcim_inventoryitemrole_pkey PRIMARY KEY (id);


--
-- Name: dcim_inventoryitemrole dcim_inventoryitemrole_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitemrole
    ADD CONSTRAINT dcim_inventoryitemrole_slug_key UNIQUE (slug);


--
-- Name: dcim_inventoryitemtemplate dcim_inventoryitemtemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitemtemplate
    ADD CONSTRAINT dcim_inventoryitemtemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_inventoryitemtemplate dcim_inventoryitemtemplate_unique_device_type_parent_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitemtemplate
    ADD CONSTRAINT dcim_inventoryitemtemplate_unique_device_type_parent_name UNIQUE (device_type_id, parent_id, name);


--
-- Name: dcim_location dcim_location_parent_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_location
    ADD CONSTRAINT dcim_location_parent_name UNIQUE NULLS NOT DISTINCT (site_id, parent_id, name);


--
-- Name: dcim_location dcim_location_parent_slug; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_location
    ADD CONSTRAINT dcim_location_parent_slug UNIQUE NULLS NOT DISTINCT (site_id, parent_id, slug);


--
-- Name: dcim_location dcim_location_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_location
    ADD CONSTRAINT dcim_location_pkey PRIMARY KEY (id);


--
-- Name: dcim_macaddress dcim_macaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_macaddress
    ADD CONSTRAINT dcim_macaddress_pkey PRIMARY KEY (id);


--
-- Name: dcim_manufacturer dcim_manufacturer_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_manufacturer
    ADD CONSTRAINT dcim_manufacturer_name_key UNIQUE (name);


--
-- Name: dcim_manufacturer dcim_manufacturer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_manufacturer
    ADD CONSTRAINT dcim_manufacturer_pkey PRIMARY KEY (id);


--
-- Name: dcim_manufacturer dcim_manufacturer_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_manufacturer
    ADD CONSTRAINT dcim_manufacturer_slug_key UNIQUE (slug);


--
-- Name: dcim_module dcim_module_asset_tag_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_module
    ADD CONSTRAINT dcim_module_asset_tag_key UNIQUE (asset_tag);


--
-- Name: dcim_module dcim_module_module_bay_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_module
    ADD CONSTRAINT dcim_module_module_bay_id_key UNIQUE (module_bay_id);


--
-- Name: dcim_module dcim_module_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_module
    ADD CONSTRAINT dcim_module_pkey PRIMARY KEY (id);


--
-- Name: dcim_modulebay_module_bay_types dcim_modulebay_module_ba_modulebay_id_modulebayty_7ee2114b_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebay_module_bay_types
    ADD CONSTRAINT dcim_modulebay_module_ba_modulebay_id_modulebayty_7ee2114b_uniq UNIQUE (modulebay_id, modulebaytype_id);


--
-- Name: dcim_modulebay_module_bay_types dcim_modulebay_module_bay_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebay_module_bay_types
    ADD CONSTRAINT dcim_modulebay_module_bay_types_pkey PRIMARY KEY (id);


--
-- Name: dcim_modulebay dcim_modulebay_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebay
    ADD CONSTRAINT dcim_modulebay_pkey PRIMARY KEY (id);


--
-- Name: dcim_modulebay dcim_modulebay_unique_device_module_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebay
    ADD CONSTRAINT dcim_modulebay_unique_device_module_name UNIQUE (device_id, module_id, name);


--
-- Name: dcim_modulebaytemplate_module_bay_types dcim_modulebaytemplate_m_modulebaytemplate_id_mod_df45a237_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebaytemplate_module_bay_types
    ADD CONSTRAINT dcim_modulebaytemplate_m_modulebaytemplate_id_mod_df45a237_uniq UNIQUE (modulebaytemplate_id, modulebaytype_id);


--
-- Name: dcim_modulebaytemplate_module_bay_types dcim_modulebaytemplate_module_bay_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebaytemplate_module_bay_types
    ADD CONSTRAINT dcim_modulebaytemplate_module_bay_types_pkey PRIMARY KEY (id);


--
-- Name: dcim_modulebaytemplate dcim_modulebaytemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebaytemplate
    ADD CONSTRAINT dcim_modulebaytemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_modulebaytemplate dcim_modulebaytemplate_unique_device_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebaytemplate
    ADD CONSTRAINT dcim_modulebaytemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_modulebaytemplate dcim_modulebaytemplate_unique_module_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebaytemplate
    ADD CONSTRAINT dcim_modulebaytemplate_unique_module_type_name UNIQUE (module_type_id, name);


--
-- Name: dcim_modulebaytype dcim_modulebaytype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebaytype
    ADD CONSTRAINT dcim_modulebaytype_pkey PRIMARY KEY (id);


--
-- Name: dcim_modulebaytype dcim_modulebaytype_unique_manufacturer_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebaytype
    ADD CONSTRAINT dcim_modulebaytype_unique_manufacturer_name UNIQUE NULLS NOT DISTINCT (manufacturer_id, name);


--
-- Name: dcim_modulebaytype dcim_modulebaytype_unique_manufacturer_slug; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebaytype
    ADD CONSTRAINT dcim_modulebaytype_unique_manufacturer_slug UNIQUE NULLS NOT DISTINCT (manufacturer_id, slug);


--
-- Name: dcim_moduletype_module_bay_types dcim_moduletype_module_b_moduletype_id_modulebayt_7223f088_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_moduletype_module_bay_types
    ADD CONSTRAINT dcim_moduletype_module_b_moduletype_id_modulebayt_7223f088_uniq UNIQUE (moduletype_id, modulebaytype_id);


--
-- Name: dcim_moduletype_module_bay_types dcim_moduletype_module_bay_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_moduletype_module_bay_types
    ADD CONSTRAINT dcim_moduletype_module_bay_types_pkey PRIMARY KEY (id);


--
-- Name: dcim_moduletype dcim_moduletype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_moduletype
    ADD CONSTRAINT dcim_moduletype_pkey PRIMARY KEY (id);


--
-- Name: dcim_moduletype dcim_moduletype_unique_manufacturer_model; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_moduletype
    ADD CONSTRAINT dcim_moduletype_unique_manufacturer_model UNIQUE (manufacturer_id, model);


--
-- Name: dcim_moduletypeprofile dcim_moduletypeprofile_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_moduletypeprofile
    ADD CONSTRAINT dcim_moduletypeprofile_name_key UNIQUE (name);


--
-- Name: dcim_moduletypeprofile dcim_moduletypeprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_moduletypeprofile
    ADD CONSTRAINT dcim_moduletypeprofile_pkey PRIMARY KEY (id);


--
-- Name: dcim_platform dcim_platform_manufacturer_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_platform
    ADD CONSTRAINT dcim_platform_manufacturer_name UNIQUE NULLS NOT DISTINCT (manufacturer_id, name);


--
-- Name: dcim_platform dcim_platform_manufacturer_slug; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_platform
    ADD CONSTRAINT dcim_platform_manufacturer_slug UNIQUE NULLS NOT DISTINCT (manufacturer_id, slug);


--
-- Name: dcim_platform dcim_platform_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_platform
    ADD CONSTRAINT dcim_platform_pkey PRIMARY KEY (id);


--
-- Name: dcim_portmapping dcim_portmapping_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_portmapping
    ADD CONSTRAINT dcim_portmapping_pkey PRIMARY KEY (id);


--
-- Name: dcim_portmapping dcim_portmapping_unique_front_port_position; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_portmapping
    ADD CONSTRAINT dcim_portmapping_unique_front_port_position UNIQUE (front_port_id, front_port_position);


--
-- Name: dcim_portmapping dcim_portmapping_unique_rear_port_position; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_portmapping
    ADD CONSTRAINT dcim_portmapping_unique_rear_port_position UNIQUE (rear_port_id, rear_port_position);


--
-- Name: dcim_porttemplatemapping dcim_porttemplatemapping_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_porttemplatemapping
    ADD CONSTRAINT dcim_porttemplatemapping_pkey PRIMARY KEY (id);


--
-- Name: dcim_porttemplatemapping dcim_porttemplatemapping_unique_front_port_position; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_porttemplatemapping
    ADD CONSTRAINT dcim_porttemplatemapping_unique_front_port_position UNIQUE (front_port_id, front_port_position);


--
-- Name: dcim_porttemplatemapping dcim_porttemplatemapping_unique_rear_port_position; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_porttemplatemapping
    ADD CONSTRAINT dcim_porttemplatemapping_unique_rear_port_position UNIQUE (rear_port_id, rear_port_position);


--
-- Name: dcim_powerfeed dcim_powerfeed_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerfeed
    ADD CONSTRAINT dcim_powerfeed_pkey PRIMARY KEY (id);


--
-- Name: dcim_powerfeed dcim_powerfeed_unique_power_panel_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerfeed
    ADD CONSTRAINT dcim_powerfeed_unique_power_panel_name UNIQUE (power_panel_id, name);


--
-- Name: dcim_poweroutlet dcim_poweroutlet_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_poweroutlet
    ADD CONSTRAINT dcim_poweroutlet_pkey PRIMARY KEY (id);


--
-- Name: dcim_poweroutlet dcim_poweroutlet_unique_device_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_poweroutlet
    ADD CONSTRAINT dcim_poweroutlet_unique_device_name UNIQUE (device_id, name);


--
-- Name: dcim_poweroutlettemplate dcim_poweroutlettemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_poweroutlettemplate
    ADD CONSTRAINT dcim_poweroutlettemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_poweroutlettemplate dcim_poweroutlettemplate_unique_device_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_poweroutlettemplate
    ADD CONSTRAINT dcim_poweroutlettemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_poweroutlettemplate dcim_poweroutlettemplate_unique_module_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_poweroutlettemplate
    ADD CONSTRAINT dcim_poweroutlettemplate_unique_module_type_name UNIQUE (module_type_id, name);


--
-- Name: dcim_powerpanel dcim_powerpanel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerpanel
    ADD CONSTRAINT dcim_powerpanel_pkey PRIMARY KEY (id);


--
-- Name: dcim_powerpanel dcim_powerpanel_unique_site_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerpanel
    ADD CONSTRAINT dcim_powerpanel_unique_site_name UNIQUE (site_id, name);


--
-- Name: dcim_powerport dcim_powerport_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerport
    ADD CONSTRAINT dcim_powerport_pkey PRIMARY KEY (id);


--
-- Name: dcim_powerport dcim_powerport_unique_device_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerport
    ADD CONSTRAINT dcim_powerport_unique_device_name UNIQUE (device_id, name);


--
-- Name: dcim_powerporttemplate dcim_powerporttemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerporttemplate
    ADD CONSTRAINT dcim_powerporttemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_powerporttemplate dcim_powerporttemplate_unique_device_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerporttemplate
    ADD CONSTRAINT dcim_powerporttemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_powerporttemplate dcim_powerporttemplate_unique_module_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerporttemplate
    ADD CONSTRAINT dcim_powerporttemplate_unique_module_type_name UNIQUE (module_type_id, name);


--
-- Name: dcim_rack dcim_rack_asset_tag_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rack
    ADD CONSTRAINT dcim_rack_asset_tag_key UNIQUE (asset_tag);


--
-- Name: dcim_rack dcim_rack_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rack
    ADD CONSTRAINT dcim_rack_pkey PRIMARY KEY (id);


--
-- Name: dcim_rack dcim_rack_unique_location_facility_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rack
    ADD CONSTRAINT dcim_rack_unique_location_facility_id UNIQUE (location_id, facility_id);


--
-- Name: dcim_rack dcim_rack_unique_location_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rack
    ADD CONSTRAINT dcim_rack_unique_location_name UNIQUE (location_id, name);


--
-- Name: dcim_rackgroup dcim_rackgroup_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rackgroup
    ADD CONSTRAINT dcim_rackgroup_name_key UNIQUE (name);


--
-- Name: dcim_rackgroup dcim_rackgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rackgroup
    ADD CONSTRAINT dcim_rackgroup_pkey PRIMARY KEY (id);


--
-- Name: dcim_rackgroup dcim_rackgroup_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rackgroup
    ADD CONSTRAINT dcim_rackgroup_slug_key UNIQUE (slug);


--
-- Name: dcim_rackreservation dcim_rackreservation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rackreservation
    ADD CONSTRAINT dcim_rackreservation_pkey PRIMARY KEY (id);


--
-- Name: dcim_rackrole dcim_rackrole_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rackrole
    ADD CONSTRAINT dcim_rackrole_name_key UNIQUE (name);


--
-- Name: dcim_rackrole dcim_rackrole_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rackrole
    ADD CONSTRAINT dcim_rackrole_pkey PRIMARY KEY (id);


--
-- Name: dcim_rackrole dcim_rackrole_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rackrole
    ADD CONSTRAINT dcim_rackrole_slug_key UNIQUE (slug);


--
-- Name: dcim_racktype dcim_racktype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_racktype
    ADD CONSTRAINT dcim_racktype_pkey PRIMARY KEY (id);


--
-- Name: dcim_racktype dcim_racktype_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_racktype
    ADD CONSTRAINT dcim_racktype_slug_key UNIQUE (slug);


--
-- Name: dcim_racktype dcim_racktype_unique_manufacturer_model; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_racktype
    ADD CONSTRAINT dcim_racktype_unique_manufacturer_model UNIQUE (manufacturer_id, model);


--
-- Name: dcim_racktype dcim_racktype_unique_manufacturer_slug; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_racktype
    ADD CONSTRAINT dcim_racktype_unique_manufacturer_slug UNIQUE (manufacturer_id, slug);


--
-- Name: dcim_rearport dcim_rearport_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rearport
    ADD CONSTRAINT dcim_rearport_pkey PRIMARY KEY (id);


--
-- Name: dcim_rearport dcim_rearport_unique_device_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rearport
    ADD CONSTRAINT dcim_rearport_unique_device_name UNIQUE (device_id, name);


--
-- Name: dcim_rearporttemplate dcim_rearporttemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rearporttemplate
    ADD CONSTRAINT dcim_rearporttemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_rearporttemplate dcim_rearporttemplate_unique_device_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rearporttemplate
    ADD CONSTRAINT dcim_rearporttemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_rearporttemplate dcim_rearporttemplate_unique_module_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rearporttemplate
    ADD CONSTRAINT dcim_rearporttemplate_unique_module_type_name UNIQUE (module_type_id, name);


--
-- Name: dcim_region dcim_region_parent_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_region
    ADD CONSTRAINT dcim_region_parent_name UNIQUE NULLS NOT DISTINCT (parent_id, name);


--
-- Name: dcim_region dcim_region_parent_slug; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_region
    ADD CONSTRAINT dcim_region_parent_slug UNIQUE NULLS NOT DISTINCT (parent_id, slug);


--
-- Name: dcim_region dcim_region_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_region
    ADD CONSTRAINT dcim_region_pkey PRIMARY KEY (id);


--
-- Name: dcim_site_asns dcim_site_asns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_site_asns
    ADD CONSTRAINT dcim_site_asns_pkey PRIMARY KEY (id);


--
-- Name: dcim_site_asns dcim_site_asns_site_id_asn_id_1a5a6f23_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_site_asns
    ADD CONSTRAINT dcim_site_asns_site_id_asn_id_1a5a6f23_uniq UNIQUE (site_id, asn_id);


--
-- Name: dcim_site dcim_site_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_site
    ADD CONSTRAINT dcim_site_name_key UNIQUE (name);


--
-- Name: dcim_site dcim_site_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_site
    ADD CONSTRAINT dcim_site_pkey PRIMARY KEY (id);


--
-- Name: dcim_site dcim_site_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_site
    ADD CONSTRAINT dcim_site_slug_key UNIQUE (slug);


--
-- Name: dcim_sitegroup dcim_sitegroup_parent_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_sitegroup
    ADD CONSTRAINT dcim_sitegroup_parent_name UNIQUE NULLS NOT DISTINCT (parent_id, name);


--
-- Name: dcim_sitegroup dcim_sitegroup_parent_slug; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_sitegroup
    ADD CONSTRAINT dcim_sitegroup_parent_slug UNIQUE NULLS NOT DISTINCT (parent_id, slug);


--
-- Name: dcim_sitegroup dcim_sitegroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_sitegroup
    ADD CONSTRAINT dcim_sitegroup_pkey PRIMARY KEY (id);


--
-- Name: dcim_virtualchassis dcim_virtualchassis_master_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_virtualchassis
    ADD CONSTRAINT dcim_virtualchassis_master_id_key UNIQUE (master_id);


--
-- Name: dcim_virtualchassis dcim_virtualchassis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_virtualchassis
    ADD CONSTRAINT dcim_virtualchassis_pkey PRIMARY KEY (id);


--
-- Name: dcim_virtualdevicecontext dcim_virtualdevicecontext_device_identifier; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_virtualdevicecontext
    ADD CONSTRAINT dcim_virtualdevicecontext_device_identifier UNIQUE (device_id, identifier);


--
-- Name: dcim_virtualdevicecontext dcim_virtualdevicecontext_device_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_virtualdevicecontext
    ADD CONSTRAINT dcim_virtualdevicecontext_device_name UNIQUE (device_id, name);


--
-- Name: dcim_virtualdevicecontext dcim_virtualdevicecontext_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_virtualdevicecontext
    ADD CONSTRAINT dcim_virtualdevicecontext_pkey PRIMARY KEY (id);


--
-- Name: dcim_virtualdevicecontext dcim_virtualdevicecontext_primary_ip4_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_virtualdevicecontext
    ADD CONSTRAINT dcim_virtualdevicecontext_primary_ip4_id_key UNIQUE (primary_ip4_id);


--
-- Name: dcim_virtualdevicecontext dcim_virtualdevicecontext_primary_ip6_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_virtualdevicecontext
    ADD CONSTRAINT dcim_virtualdevicecontext_primary_ip6_id_key UNIQUE (primary_ip6_id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: extras_bookmark extras_bookmark_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_bookmark
    ADD CONSTRAINT extras_bookmark_pkey PRIMARY KEY (id);


--
-- Name: extras_bookmark extras_bookmark_unique_per_object_and_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_bookmark
    ADD CONSTRAINT extras_bookmark_unique_per_object_and_user UNIQUE (object_type_id, object_id, user_id);


--
-- Name: extras_cachedvalue extras_cachedvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_cachedvalue
    ADD CONSTRAINT extras_cachedvalue_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_clusters extras_configcontext_clu_configcontext_id_cluster_0c7e5d20_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_clusters
    ADD CONSTRAINT extras_configcontext_clu_configcontext_id_cluster_0c7e5d20_uniq UNIQUE (configcontext_id, cluster_id);


--
-- Name: extras_configcontext_cluster_types extras_configcontext_clu_configcontext_id_cluster_4a2d5e56_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_cluster_types
    ADD CONSTRAINT extras_configcontext_clu_configcontext_id_cluster_4a2d5e56_uniq UNIQUE (configcontext_id, clustertype_id);


--
-- Name: extras_configcontext_cluster_groups extras_configcontext_clu_configcontext_id_cluster_bc530192_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_cluster_groups
    ADD CONSTRAINT extras_configcontext_clu_configcontext_id_cluster_bc530192_uniq UNIQUE (configcontext_id, clustergroup_id);


--
-- Name: extras_configcontext_cluster_groups extras_configcontext_cluster_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_cluster_groups
    ADD CONSTRAINT extras_configcontext_cluster_groups_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_cluster_types extras_configcontext_cluster_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_cluster_types
    ADD CONSTRAINT extras_configcontext_cluster_types_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_clusters extras_configcontext_clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_clusters
    ADD CONSTRAINT extras_configcontext_clusters_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_device_types extras_configcontext_dev_configcontext_id_devicet_a0aaba6f_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_device_types
    ADD CONSTRAINT extras_configcontext_dev_configcontext_id_devicet_a0aaba6f_uniq UNIQUE (configcontext_id, devicetype_id);


--
-- Name: extras_configcontext_device_types extras_configcontext_device_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_device_types
    ADD CONSTRAINT extras_configcontext_device_types_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_locations extras_configcontext_loc_configcontext_id_locatio_15d9b342_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_locations
    ADD CONSTRAINT extras_configcontext_loc_configcontext_id_locatio_15d9b342_uniq UNIQUE (configcontext_id, location_id);


--
-- Name: extras_configcontext_locations extras_configcontext_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_locations
    ADD CONSTRAINT extras_configcontext_locations_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext extras_configcontext_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext
    ADD CONSTRAINT extras_configcontext_name_key UNIQUE (name);


--
-- Name: extras_configcontext extras_configcontext_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext
    ADD CONSTRAINT extras_configcontext_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_platforms extras_configcontext_pla_configcontext_id_platfor_3c67c104_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_platforms
    ADD CONSTRAINT extras_configcontext_pla_configcontext_id_platfor_3c67c104_uniq UNIQUE (configcontext_id, platform_id);


--
-- Name: extras_configcontext_platforms extras_configcontext_platforms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_platforms
    ADD CONSTRAINT extras_configcontext_platforms_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_regions extras_configcontext_reg_configcontext_id_region__d4a1d77f_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_regions
    ADD CONSTRAINT extras_configcontext_reg_configcontext_id_region__d4a1d77f_uniq UNIQUE (configcontext_id, region_id);


--
-- Name: extras_configcontext_regions extras_configcontext_regions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_regions
    ADD CONSTRAINT extras_configcontext_regions_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_roles extras_configcontext_rol_configcontext_id_devicer_4d8dbb50_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_roles
    ADD CONSTRAINT extras_configcontext_rol_configcontext_id_devicer_4d8dbb50_uniq UNIQUE (configcontext_id, devicerole_id);


--
-- Name: extras_configcontext_roles extras_configcontext_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_roles
    ADD CONSTRAINT extras_configcontext_roles_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_sites extras_configcontext_sit_configcontext_id_site_id_a4fe5f4f_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_sites
    ADD CONSTRAINT extras_configcontext_sit_configcontext_id_site_id_a4fe5f4f_uniq UNIQUE (configcontext_id, site_id);


--
-- Name: extras_configcontext_site_groups extras_configcontext_sit_configcontext_id_sitegro_4caa52ec_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_site_groups
    ADD CONSTRAINT extras_configcontext_sit_configcontext_id_sitegro_4caa52ec_uniq UNIQUE (configcontext_id, sitegroup_id);


--
-- Name: extras_configcontext_site_groups extras_configcontext_site_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_site_groups
    ADD CONSTRAINT extras_configcontext_site_groups_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_sites extras_configcontext_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_sites
    ADD CONSTRAINT extras_configcontext_sites_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_tags extras_configcontext_tags_configcontext_id_tag_id_f6c53016_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_tags
    ADD CONSTRAINT extras_configcontext_tags_configcontext_id_tag_id_f6c53016_uniq UNIQUE (configcontext_id, tag_id);


--
-- Name: extras_configcontext_tags extras_configcontext_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_tags
    ADD CONSTRAINT extras_configcontext_tags_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_tenants extras_configcontext_ten_configcontext_id_tenant__aefb257d_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_tenants
    ADD CONSTRAINT extras_configcontext_ten_configcontext_id_tenant__aefb257d_uniq UNIQUE (configcontext_id, tenant_id);


--
-- Name: extras_configcontext_tenant_groups extras_configcontext_ten_configcontext_id_tenantg_d6afc6f5_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_tenant_groups
    ADD CONSTRAINT extras_configcontext_ten_configcontext_id_tenantg_d6afc6f5_uniq UNIQUE (configcontext_id, tenantgroup_id);


--
-- Name: extras_configcontext_tenant_groups extras_configcontext_tenant_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_tenant_groups
    ADD CONSTRAINT extras_configcontext_tenant_groups_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_tenants extras_configcontext_tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_tenants
    ADD CONSTRAINT extras_configcontext_tenants_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontextprofile extras_configcontextprofile_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontextprofile
    ADD CONSTRAINT extras_configcontextprofile_name_key UNIQUE (name);


--
-- Name: extras_configcontextprofile extras_configcontextprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontextprofile
    ADD CONSTRAINT extras_configcontextprofile_pkey PRIMARY KEY (id);


--
-- Name: core_configrevision extras_configrevision_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_configrevision
    ADD CONSTRAINT extras_configrevision_pkey PRIMARY KEY (id);


--
-- Name: extras_configtemplate extras_configtemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configtemplate
    ADD CONSTRAINT extras_configtemplate_pkey PRIMARY KEY (id);


--
-- Name: extras_customfield_object_types extras_customfield_conte_customfield_id_contentty_51136c2b_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customfield_object_types
    ADD CONSTRAINT extras_customfield_conte_customfield_id_contentty_51136c2b_uniq UNIQUE (customfield_id, contenttype_id);


--
-- Name: extras_customfield_object_types extras_customfield_content_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customfield_object_types
    ADD CONSTRAINT extras_customfield_content_types_pkey PRIMARY KEY (id);


--
-- Name: extras_customfield extras_customfield_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customfield
    ADD CONSTRAINT extras_customfield_name_key UNIQUE (name);


--
-- Name: extras_customfield extras_customfield_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customfield
    ADD CONSTRAINT extras_customfield_pkey PRIMARY KEY (id);


--
-- Name: extras_customfieldchoiceset extras_customfieldchoiceset_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customfieldchoiceset
    ADD CONSTRAINT extras_customfieldchoiceset_name_key UNIQUE (name);


--
-- Name: extras_customfieldchoiceset extras_customfieldchoiceset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customfieldchoiceset
    ADD CONSTRAINT extras_customfieldchoiceset_pkey PRIMARY KEY (id);


--
-- Name: extras_customlink_object_types extras_customlink_conten_customlink_id_contenttyp_518ef1b8_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customlink_object_types
    ADD CONSTRAINT extras_customlink_conten_customlink_id_contenttyp_518ef1b8_uniq UNIQUE (customlink_id, contenttype_id);


--
-- Name: extras_customlink_object_types extras_customlink_content_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customlink_object_types
    ADD CONSTRAINT extras_customlink_content_types_pkey PRIMARY KEY (id);


--
-- Name: extras_customlink extras_customlink_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customlink
    ADD CONSTRAINT extras_customlink_name_key UNIQUE (name);


--
-- Name: extras_customlink extras_customlink_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customlink
    ADD CONSTRAINT extras_customlink_pkey PRIMARY KEY (id);


--
-- Name: extras_dashboard extras_dashboard_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_dashboard
    ADD CONSTRAINT extras_dashboard_pkey PRIMARY KEY (id);


--
-- Name: extras_dashboard extras_dashboard_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_dashboard
    ADD CONSTRAINT extras_dashboard_user_id_key UNIQUE (user_id);


--
-- Name: extras_eventrule_object_types extras_eventrule_content_eventrule_id_contenttype_4da93239_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_eventrule_object_types
    ADD CONSTRAINT extras_eventrule_content_eventrule_id_contenttype_4da93239_uniq UNIQUE (eventrule_id, contenttype_id);


--
-- Name: extras_eventrule_object_types extras_eventrule_content_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_eventrule_object_types
    ADD CONSTRAINT extras_eventrule_content_types_pkey PRIMARY KEY (id);


--
-- Name: extras_eventrule extras_eventrule_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_eventrule
    ADD CONSTRAINT extras_eventrule_name_key UNIQUE (name);


--
-- Name: extras_eventrule extras_eventrule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_eventrule
    ADD CONSTRAINT extras_eventrule_pkey PRIMARY KEY (id);


--
-- Name: extras_exporttemplate_object_types extras_exporttemplate_co_exporttemplate_id_conten_b4645653_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_exporttemplate_object_types
    ADD CONSTRAINT extras_exporttemplate_co_exporttemplate_id_conten_b4645653_uniq UNIQUE (exporttemplate_id, contenttype_id);


--
-- Name: extras_exporttemplate_object_types extras_exporttemplate_content_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_exporttemplate_object_types
    ADD CONSTRAINT extras_exporttemplate_content_types_pkey PRIMARY KEY (id);


--
-- Name: extras_exporttemplate extras_exporttemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_exporttemplate
    ADD CONSTRAINT extras_exporttemplate_pkey PRIMARY KEY (id);


--
-- Name: extras_imageattachment extras_imageattachment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_imageattachment
    ADD CONSTRAINT extras_imageattachment_pkey PRIMARY KEY (id);


--
-- Name: extras_journalentry extras_journalentry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_journalentry
    ADD CONSTRAINT extras_journalentry_pkey PRIMARY KEY (id);


--
-- Name: extras_notification extras_notification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_notification
    ADD CONSTRAINT extras_notification_pkey PRIMARY KEY (id);


--
-- Name: extras_notification extras_notification_unique_per_object_and_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_notification
    ADD CONSTRAINT extras_notification_unique_per_object_and_user UNIQUE (object_type_id, object_id, user_id);


--
-- Name: extras_notificationgroup_groups extras_notificationgroup_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_notificationgroup_groups
    ADD CONSTRAINT extras_notificationgroup_groups_pkey PRIMARY KEY (id);


--
-- Name: extras_notificationgroup extras_notificationgroup_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_notificationgroup
    ADD CONSTRAINT extras_notificationgroup_name_key UNIQUE (name);


--
-- Name: extras_notificationgroup_groups extras_notificationgroup_notificationgroup_id_gro_46702115_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_notificationgroup_groups
    ADD CONSTRAINT extras_notificationgroup_notificationgroup_id_gro_46702115_uniq UNIQUE (notificationgroup_id, group_id);


--
-- Name: extras_notificationgroup_users extras_notificationgroup_notificationgroup_id_use_9a79b7f8_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_notificationgroup_users
    ADD CONSTRAINT extras_notificationgroup_notificationgroup_id_use_9a79b7f8_uniq UNIQUE (notificationgroup_id, user_id);


--
-- Name: extras_notificationgroup extras_notificationgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_notificationgroup
    ADD CONSTRAINT extras_notificationgroup_pkey PRIMARY KEY (id);


--
-- Name: extras_notificationgroup_users extras_notificationgroup_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_notificationgroup_users
    ADD CONSTRAINT extras_notificationgroup_users_pkey PRIMARY KEY (id);


--
-- Name: extras_savedfilter_object_types extras_savedfilter_conte_savedfilter_id_contentty_133ba781_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_savedfilter_object_types
    ADD CONSTRAINT extras_savedfilter_conte_savedfilter_id_contentty_133ba781_uniq UNIQUE (savedfilter_id, contenttype_id);


--
-- Name: extras_savedfilter_object_types extras_savedfilter_content_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_savedfilter_object_types
    ADD CONSTRAINT extras_savedfilter_content_types_pkey PRIMARY KEY (id);


--
-- Name: extras_savedfilter extras_savedfilter_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_savedfilter
    ADD CONSTRAINT extras_savedfilter_name_key UNIQUE (name);


--
-- Name: extras_savedfilter extras_savedfilter_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_savedfilter
    ADD CONSTRAINT extras_savedfilter_pkey PRIMARY KEY (id);


--
-- Name: extras_savedfilter extras_savedfilter_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_savedfilter
    ADD CONSTRAINT extras_savedfilter_slug_key UNIQUE (slug);


--
-- Name: extras_script extras_script_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_script
    ADD CONSTRAINT extras_script_pkey PRIMARY KEY (id);


--
-- Name: extras_script extras_script_unique_name_module; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_script
    ADD CONSTRAINT extras_script_unique_name_module UNIQUE (name, module_id);


--
-- Name: extras_subscription extras_subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_subscription
    ADD CONSTRAINT extras_subscription_pkey PRIMARY KEY (id);


--
-- Name: extras_subscription extras_subscription_unique_per_object_and_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_subscription
    ADD CONSTRAINT extras_subscription_unique_per_object_and_user UNIQUE (object_type_id, object_id, user_id);


--
-- Name: extras_tableconfig extras_tableconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_tableconfig
    ADD CONSTRAINT extras_tableconfig_pkey PRIMARY KEY (id);


--
-- Name: extras_tag extras_tag_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_tag
    ADD CONSTRAINT extras_tag_name_key UNIQUE (name);


--
-- Name: extras_tag_object_types extras_tag_object_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_tag_object_types
    ADD CONSTRAINT extras_tag_object_types_pkey PRIMARY KEY (id);


--
-- Name: extras_tag_object_types extras_tag_object_types_tag_id_contenttype_id_2ff9910c_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_tag_object_types
    ADD CONSTRAINT extras_tag_object_types_tag_id_contenttype_id_2ff9910c_uniq UNIQUE (tag_id, contenttype_id);


--
-- Name: extras_tag extras_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_tag
    ADD CONSTRAINT extras_tag_pkey PRIMARY KEY (id);


--
-- Name: extras_tag extras_tag_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_tag
    ADD CONSTRAINT extras_tag_slug_key UNIQUE (slug);


--
-- Name: extras_taggeditem extras_taggeditem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_taggeditem
    ADD CONSTRAINT extras_taggeditem_pkey PRIMARY KEY (id);


--
-- Name: extras_webhook extras_webhook_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_webhook
    ADD CONSTRAINT extras_webhook_name_key UNIQUE (name);


--
-- Name: extras_webhook extras_webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_webhook
    ADD CONSTRAINT extras_webhook_pkey PRIMARY KEY (id);


--
-- Name: ipam_aggregate ipam_aggregate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_aggregate
    ADD CONSTRAINT ipam_aggregate_pkey PRIMARY KEY (id);


--
-- Name: ipam_asn ipam_asn_asn_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_asn
    ADD CONSTRAINT ipam_asn_asn_key UNIQUE (asn);


--
-- Name: ipam_asn ipam_asn_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_asn
    ADD CONSTRAINT ipam_asn_pkey PRIMARY KEY (id);


--
-- Name: ipam_asnrange ipam_asnrange_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_asnrange
    ADD CONSTRAINT ipam_asnrange_name_key UNIQUE (name);


--
-- Name: ipam_asnrange ipam_asnrange_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_asnrange
    ADD CONSTRAINT ipam_asnrange_pkey PRIMARY KEY (id);


--
-- Name: ipam_asnrange ipam_asnrange_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_asnrange
    ADD CONSTRAINT ipam_asnrange_slug_key UNIQUE (slug);


--
-- Name: ipam_fhrpgroup ipam_fhrpgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_fhrpgroup
    ADD CONSTRAINT ipam_fhrpgroup_pkey PRIMARY KEY (id);


--
-- Name: ipam_fhrpgroupassignment ipam_fhrpgroupassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_fhrpgroupassignment
    ADD CONSTRAINT ipam_fhrpgroupassignment_pkey PRIMARY KEY (id);


--
-- Name: ipam_fhrpgroupassignment ipam_fhrpgroupassignment_unique_interface_group; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_fhrpgroupassignment
    ADD CONSTRAINT ipam_fhrpgroupassignment_unique_interface_group UNIQUE (interface_type_id, interface_id, group_id);


--
-- Name: ipam_ipaddress ipam_ipaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_ipaddress
    ADD CONSTRAINT ipam_ipaddress_pkey PRIMARY KEY (id);


--
-- Name: ipam_iprange ipam_iprange_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_iprange
    ADD CONSTRAINT ipam_iprange_pkey PRIMARY KEY (id);


--
-- Name: vpn_l2vpn_export_targets ipam_l2vpn_export_targets_l2vpn_id_routetarget_id_eea90661_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_l2vpn_export_targets
    ADD CONSTRAINT ipam_l2vpn_export_targets_l2vpn_id_routetarget_id_eea90661_uniq UNIQUE (l2vpn_id, routetarget_id);


--
-- Name: vpn_l2vpn_export_targets ipam_l2vpn_export_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_l2vpn_export_targets
    ADD CONSTRAINT ipam_l2vpn_export_targets_pkey PRIMARY KEY (id);


--
-- Name: vpn_l2vpn_import_targets ipam_l2vpn_import_targets_l2vpn_id_routetarget_id_96af344c_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_l2vpn_import_targets
    ADD CONSTRAINT ipam_l2vpn_import_targets_l2vpn_id_routetarget_id_96af344c_uniq UNIQUE (l2vpn_id, routetarget_id);


--
-- Name: vpn_l2vpn_import_targets ipam_l2vpn_import_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_l2vpn_import_targets
    ADD CONSTRAINT ipam_l2vpn_import_targets_pkey PRIMARY KEY (id);


--
-- Name: ipam_prefix ipam_prefix_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_prefix
    ADD CONSTRAINT ipam_prefix_pkey PRIMARY KEY (id);


--
-- Name: ipam_rir ipam_rir_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_rir
    ADD CONSTRAINT ipam_rir_name_key UNIQUE (name);


--
-- Name: ipam_rir ipam_rir_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_rir
    ADD CONSTRAINT ipam_rir_pkey PRIMARY KEY (id);


--
-- Name: ipam_rir ipam_rir_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_rir
    ADD CONSTRAINT ipam_rir_slug_key UNIQUE (slug);


--
-- Name: ipam_role ipam_role_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_role
    ADD CONSTRAINT ipam_role_name_key UNIQUE (name);


--
-- Name: ipam_role ipam_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_role
    ADD CONSTRAINT ipam_role_pkey PRIMARY KEY (id);


--
-- Name: ipam_role ipam_role_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_role
    ADD CONSTRAINT ipam_role_slug_key UNIQUE (slug);


--
-- Name: ipam_routetarget ipam_routetarget_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_routetarget
    ADD CONSTRAINT ipam_routetarget_name_key UNIQUE (name);


--
-- Name: ipam_routetarget ipam_routetarget_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_routetarget
    ADD CONSTRAINT ipam_routetarget_pkey PRIMARY KEY (id);


--
-- Name: ipam_service_ipaddresses ipam_service_ipaddresses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_service_ipaddresses
    ADD CONSTRAINT ipam_service_ipaddresses_pkey PRIMARY KEY (id);


--
-- Name: ipam_service_ipaddresses ipam_service_ipaddresses_service_id_ipaddress_id_d019a805_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_service_ipaddresses
    ADD CONSTRAINT ipam_service_ipaddresses_service_id_ipaddress_id_d019a805_uniq UNIQUE (service_id, ipaddress_id);


--
-- Name: ipam_service ipam_service_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_service
    ADD CONSTRAINT ipam_service_pkey PRIMARY KEY (id);


--
-- Name: ipam_servicetemplate ipam_servicetemplate_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_servicetemplate
    ADD CONSTRAINT ipam_servicetemplate_name_key UNIQUE (name);


--
-- Name: ipam_servicetemplate ipam_servicetemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_servicetemplate
    ADD CONSTRAINT ipam_servicetemplate_pkey PRIMARY KEY (id);


--
-- Name: ipam_vlan ipam_vlan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlan
    ADD CONSTRAINT ipam_vlan_pkey PRIMARY KEY (id);


--
-- Name: ipam_vlan ipam_vlan_unique_group_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlan
    ADD CONSTRAINT ipam_vlan_unique_group_name UNIQUE (group_id, name);


--
-- Name: ipam_vlan ipam_vlan_unique_group_vid; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlan
    ADD CONSTRAINT ipam_vlan_unique_group_vid UNIQUE (group_id, vid);


--
-- Name: ipam_vlan ipam_vlan_unique_qinq_svlan_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlan
    ADD CONSTRAINT ipam_vlan_unique_qinq_svlan_name UNIQUE (qinq_svlan_id, name);


--
-- Name: ipam_vlan ipam_vlan_unique_qinq_svlan_vid; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlan
    ADD CONSTRAINT ipam_vlan_unique_qinq_svlan_vid UNIQUE (qinq_svlan_id, vid);


--
-- Name: ipam_vlangroup ipam_vlangroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlangroup
    ADD CONSTRAINT ipam_vlangroup_pkey PRIMARY KEY (id);


--
-- Name: ipam_vlangroup ipam_vlangroup_unique_scope_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlangroup
    ADD CONSTRAINT ipam_vlangroup_unique_scope_name UNIQUE (scope_type_id, scope_id, name);


--
-- Name: ipam_vlangroup ipam_vlangroup_unique_scope_slug; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlangroup
    ADD CONSTRAINT ipam_vlangroup_unique_scope_slug UNIQUE (scope_type_id, scope_id, slug);


--
-- Name: ipam_vlantranslationpolicy ipam_vlantranslationpolicy_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlantranslationpolicy
    ADD CONSTRAINT ipam_vlantranslationpolicy_name_key UNIQUE (name);


--
-- Name: ipam_vlantranslationpolicy ipam_vlantranslationpolicy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlantranslationpolicy
    ADD CONSTRAINT ipam_vlantranslationpolicy_pkey PRIMARY KEY (id);


--
-- Name: ipam_vlantranslationrule ipam_vlantranslationrule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlantranslationrule
    ADD CONSTRAINT ipam_vlantranslationrule_pkey PRIMARY KEY (id);


--
-- Name: ipam_vlantranslationrule ipam_vlantranslationrule_unique_policy_local_vid; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlantranslationrule
    ADD CONSTRAINT ipam_vlantranslationrule_unique_policy_local_vid UNIQUE (policy_id, local_vid);


--
-- Name: ipam_vlantranslationrule ipam_vlantranslationrule_unique_policy_remote_vid; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlantranslationrule
    ADD CONSTRAINT ipam_vlantranslationrule_unique_policy_remote_vid UNIQUE (policy_id, remote_vid);


--
-- Name: ipam_vrf_export_targets ipam_vrf_export_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vrf_export_targets
    ADD CONSTRAINT ipam_vrf_export_targets_pkey PRIMARY KEY (id);


--
-- Name: ipam_vrf_export_targets ipam_vrf_export_targets_vrf_id_routetarget_id_63ba8c62_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vrf_export_targets
    ADD CONSTRAINT ipam_vrf_export_targets_vrf_id_routetarget_id_63ba8c62_uniq UNIQUE (vrf_id, routetarget_id);


--
-- Name: ipam_vrf_import_targets ipam_vrf_import_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vrf_import_targets
    ADD CONSTRAINT ipam_vrf_import_targets_pkey PRIMARY KEY (id);


--
-- Name: ipam_vrf_import_targets ipam_vrf_import_targets_vrf_id_routetarget_id_399b155f_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vrf_import_targets
    ADD CONSTRAINT ipam_vrf_import_targets_vrf_id_routetarget_id_399b155f_uniq UNIQUE (vrf_id, routetarget_id);


--
-- Name: ipam_vrf ipam_vrf_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vrf
    ADD CONSTRAINT ipam_vrf_pkey PRIMARY KEY (id);


--
-- Name: ipam_vrf ipam_vrf_rd_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vrf
    ADD CONSTRAINT ipam_vrf_rd_key UNIQUE (rd);


--
-- Name: social_auth_association social_auth_association_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_auth_association
    ADD CONSTRAINT social_auth_association_pkey PRIMARY KEY (id);


--
-- Name: social_auth_association social_auth_association_server_url_handle_078befa2_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_auth_association
    ADD CONSTRAINT social_auth_association_server_url_handle_078befa2_uniq UNIQUE (server_url, handle);


--
-- Name: social_auth_code social_auth_code_email_code_801b2d02_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_auth_code
    ADD CONSTRAINT social_auth_code_email_code_801b2d02_uniq UNIQUE (email, code);


--
-- Name: social_auth_code social_auth_code_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_auth_code
    ADD CONSTRAINT social_auth_code_pkey PRIMARY KEY (id);


--
-- Name: social_auth_nonce social_auth_nonce_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_auth_nonce
    ADD CONSTRAINT social_auth_nonce_pkey PRIMARY KEY (id);


--
-- Name: social_auth_nonce social_auth_nonce_server_url_timestamp_salt_f6284463_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_auth_nonce
    ADD CONSTRAINT social_auth_nonce_server_url_timestamp_salt_f6284463_uniq UNIQUE (server_url, "timestamp", salt);


--
-- Name: social_auth_partial social_auth_partial_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_auth_partial
    ADD CONSTRAINT social_auth_partial_pkey PRIMARY KEY (id);


--
-- Name: social_auth_usersocialauth social_auth_usersocialauth_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_auth_usersocialauth
    ADD CONSTRAINT social_auth_usersocialauth_pkey PRIMARY KEY (id);


--
-- Name: social_auth_usersocialauth social_auth_usersocialauth_provider_uid_e6b5e668_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_auth_usersocialauth
    ADD CONSTRAINT social_auth_usersocialauth_provider_uid_e6b5e668_uniq UNIQUE (provider, uid);


--
-- Name: taggit_tag taggit_tag_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_tag
    ADD CONSTRAINT taggit_tag_name_key UNIQUE (name);


--
-- Name: taggit_tag taggit_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_tag
    ADD CONSTRAINT taggit_tag_pkey PRIMARY KEY (id);


--
-- Name: taggit_tag taggit_tag_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_tag
    ADD CONSTRAINT taggit_tag_slug_key UNIQUE (slug);


--
-- Name: taggit_taggeditem taggit_taggeditem_content_type_id_object_id_tag_id_4bb97a8e_uni; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_content_type_id_object_id_tag_id_4bb97a8e_uni UNIQUE (content_type_id, object_id, tag_id);


--
-- Name: taggit_taggeditem taggit_taggeditem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_pkey PRIMARY KEY (id);


--
-- Name: tenancy_contact_groups tenancy_contact_groups_contact_id_contactgroup_id_f4434f2c_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contact_groups
    ADD CONSTRAINT tenancy_contact_groups_contact_id_contactgroup_id_f4434f2c_uniq UNIQUE (contactgroup_id, contact_id);


--
-- Name: tenancy_contact_groups tenancy_contact_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contact_groups
    ADD CONSTRAINT tenancy_contact_groups_pkey PRIMARY KEY (id);


--
-- Name: tenancy_contact tenancy_contact_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contact
    ADD CONSTRAINT tenancy_contact_pkey PRIMARY KEY (id);


--
-- Name: tenancy_contactassignment tenancy_contactassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contactassignment
    ADD CONSTRAINT tenancy_contactassignment_pkey PRIMARY KEY (id);


--
-- Name: tenancy_contactassignment tenancy_contactassignment_unique_object_contact_role; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contactassignment
    ADD CONSTRAINT tenancy_contactassignment_unique_object_contact_role UNIQUE (object_type_id, object_id, contact_id, role_id);


--
-- Name: tenancy_contactgroup tenancy_contactgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contactgroup
    ADD CONSTRAINT tenancy_contactgroup_pkey PRIMARY KEY (id);


--
-- Name: tenancy_contactgroup tenancy_contactgroup_unique_parent_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contactgroup
    ADD CONSTRAINT tenancy_contactgroup_unique_parent_name UNIQUE (parent_id, name);


--
-- Name: tenancy_contactrole tenancy_contactrole_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contactrole
    ADD CONSTRAINT tenancy_contactrole_name_key UNIQUE (name);


--
-- Name: tenancy_contactrole tenancy_contactrole_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contactrole
    ADD CONSTRAINT tenancy_contactrole_pkey PRIMARY KEY (id);


--
-- Name: tenancy_contactrole tenancy_contactrole_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contactrole
    ADD CONSTRAINT tenancy_contactrole_slug_key UNIQUE (slug);


--
-- Name: tenancy_tenant tenancy_tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_tenant
    ADD CONSTRAINT tenancy_tenant_pkey PRIMARY KEY (id);


--
-- Name: tenancy_tenant tenancy_tenant_unique_group_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_tenant
    ADD CONSTRAINT tenancy_tenant_unique_group_name UNIQUE NULLS NOT DISTINCT (group_id, name);


--
-- Name: tenancy_tenant tenancy_tenant_unique_group_slug; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_tenant
    ADD CONSTRAINT tenancy_tenant_unique_group_slug UNIQUE NULLS NOT DISTINCT (group_id, slug);


--
-- Name: tenancy_tenantgroup tenancy_tenantgroup_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_tenantgroup
    ADD CONSTRAINT tenancy_tenantgroup_name_key UNIQUE (name);


--
-- Name: tenancy_tenantgroup tenancy_tenantgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_tenantgroup
    ADD CONSTRAINT tenancy_tenantgroup_pkey PRIMARY KEY (id);


--
-- Name: tenancy_tenantgroup tenancy_tenantgroup_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_tenantgroup
    ADD CONSTRAINT tenancy_tenantgroup_slug_key UNIQUE (slug);


--
-- Name: thumbnail_kvstore thumbnail_kvstore_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thumbnail_kvstore
    ADD CONSTRAINT thumbnail_kvstore_pkey PRIMARY KEY (key);


--
-- Name: users_group users_group_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_group
    ADD CONSTRAINT users_group_name_key UNIQUE (name);


--
-- Name: users_group_object_permissions users_group_object_permi_group_id_objectpermissio_db1f8cbe_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_group_object_permissions
    ADD CONSTRAINT users_group_object_permi_group_id_objectpermissio_db1f8cbe_uniq UNIQUE (objectpermission_id, group_id);


--
-- Name: users_group_object_permissions users_group_object_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_group_object_permissions
    ADD CONSTRAINT users_group_object_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_group_permissions users_group_permissions_group_id_permission_id_b740e518_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_group_permissions
    ADD CONSTRAINT users_group_permissions_group_id_permission_id_b740e518_uniq UNIQUE (group_id, permission_id);


--
-- Name: users_group_permissions users_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_group_permissions
    ADD CONSTRAINT users_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_group users_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_group
    ADD CONSTRAINT users_group_pkey PRIMARY KEY (id);


--
-- Name: users_objectpermission_object_types users_objectpermission_o_objectpermission_id_cont_7c40d31a_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_objectpermission_object_types
    ADD CONSTRAINT users_objectpermission_o_objectpermission_id_cont_7c40d31a_uniq UNIQUE (objectpermission_id, contenttype_id);


--
-- Name: users_objectpermission_object_types users_objectpermission_object_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_objectpermission_object_types
    ADD CONSTRAINT users_objectpermission_object_types_pkey PRIMARY KEY (id);


--
-- Name: users_objectpermission users_objectpermission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_objectpermission
    ADD CONSTRAINT users_objectpermission_pkey PRIMARY KEY (id);


--
-- Name: users_owner users_owner_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_owner
    ADD CONSTRAINT users_owner_name_key UNIQUE (name);


--
-- Name: users_owner users_owner_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_owner
    ADD CONSTRAINT users_owner_pkey PRIMARY KEY (id);


--
-- Name: users_owner_user_groups users_owner_user_groups_owner_id_group_id_2def19f4_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_owner_user_groups
    ADD CONSTRAINT users_owner_user_groups_owner_id_group_id_2def19f4_uniq UNIQUE (owner_id, group_id);


--
-- Name: users_owner_user_groups users_owner_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_owner_user_groups
    ADD CONSTRAINT users_owner_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_owner_users users_owner_users_owner_id_user_id_07c6d81d_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_owner_users
    ADD CONSTRAINT users_owner_users_owner_id_user_id_07c6d81d_uniq UNIQUE (owner_id, user_id);


--
-- Name: users_owner_users users_owner_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_owner_users
    ADD CONSTRAINT users_owner_users_pkey PRIMARY KEY (id);


--
-- Name: users_ownergroup users_ownergroup_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_ownergroup
    ADD CONSTRAINT users_ownergroup_name_key UNIQUE (name);


--
-- Name: users_ownergroup users_ownergroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_ownergroup
    ADD CONSTRAINT users_ownergroup_pkey PRIMARY KEY (id);


--
-- Name: users_token users_token_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_token
    ADD CONSTRAINT users_token_key_key UNIQUE (key);


--
-- Name: users_token users_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_token
    ADD CONSTRAINT users_token_pkey PRIMARY KEY (id);


--
-- Name: users_token users_token_plaintext_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_token
    ADD CONSTRAINT users_token_plaintext_key UNIQUE (plaintext);


--
-- Name: users_user_object_permissions users_user_object_permis_user_id_objectpermission_0a98550e_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_user_object_permissions
    ADD CONSTRAINT users_user_object_permis_user_id_objectpermission_0a98550e_uniq UNIQUE (objectpermission_id, user_id);


--
-- Name: users_user_object_permissions users_user_object_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_user_object_permissions
    ADD CONSTRAINT users_user_object_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user users_user_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_username_key UNIQUE (username);


--
-- Name: users_userconfig users_userconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_userconfig
    ADD CONSTRAINT users_userconfig_pkey PRIMARY KEY (id);


--
-- Name: users_userconfig users_userconfig_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_userconfig
    ADD CONSTRAINT users_userconfig_user_id_key UNIQUE (user_id);


--
-- Name: virtualization_cluster virtualization_cluster_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_cluster
    ADD CONSTRAINT virtualization_cluster_pkey PRIMARY KEY (id);


--
-- Name: virtualization_cluster virtualization_cluster_unique__site_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_cluster
    ADD CONSTRAINT virtualization_cluster_unique__site_name UNIQUE (_site_id, name);


--
-- Name: virtualization_cluster virtualization_cluster_unique_group_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_cluster
    ADD CONSTRAINT virtualization_cluster_unique_group_name UNIQUE (group_id, name);


--
-- Name: virtualization_clustergroup virtualization_clustergroup_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_clustergroup
    ADD CONSTRAINT virtualization_clustergroup_name_key UNIQUE (name);


--
-- Name: virtualization_clustergroup virtualization_clustergroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_clustergroup
    ADD CONSTRAINT virtualization_clustergroup_pkey PRIMARY KEY (id);


--
-- Name: virtualization_clustergroup virtualization_clustergroup_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_clustergroup
    ADD CONSTRAINT virtualization_clustergroup_slug_key UNIQUE (slug);


--
-- Name: virtualization_clustertype virtualization_clustertype_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_clustertype
    ADD CONSTRAINT virtualization_clustertype_name_key UNIQUE (name);


--
-- Name: virtualization_clustertype virtualization_clustertype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_clustertype
    ADD CONSTRAINT virtualization_clustertype_pkey PRIMARY KEY (id);


--
-- Name: virtualization_clustertype virtualization_clustertype_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_clustertype
    ADD CONSTRAINT virtualization_clustertype_slug_key UNIQUE (slug);


--
-- Name: virtualization_virtualdisk virtualization_virtualdisk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualdisk
    ADD CONSTRAINT virtualization_virtualdisk_pkey PRIMARY KEY (id);


--
-- Name: virtualization_virtualdisk virtualization_virtualdisk_unique_virtual_machine_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualdisk
    ADD CONSTRAINT virtualization_virtualdisk_unique_virtual_machine_name UNIQUE (virtual_machine_id, name);


--
-- Name: virtualization_virtualmachine virtualization_virtualmachine_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualmachine
    ADD CONSTRAINT virtualization_virtualmachine_pkey PRIMARY KEY (id);


--
-- Name: virtualization_virtualmachine virtualization_virtualmachine_primary_ip4_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualmachine
    ADD CONSTRAINT virtualization_virtualmachine_primary_ip4_id_key UNIQUE (primary_ip4_id);


--
-- Name: virtualization_virtualmachine virtualization_virtualmachine_primary_ip6_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualmachine
    ADD CONSTRAINT virtualization_virtualmachine_primary_ip6_id_key UNIQUE (primary_ip6_id);


--
-- Name: virtualization_virtualmachinetype virtualization_virtualmachinetype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualmachinetype
    ADD CONSTRAINT virtualization_virtualmachinetype_pkey PRIMARY KEY (id);


--
-- Name: virtualization_virtualmachinetype virtualization_virtualmachinetype_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualmachinetype
    ADD CONSTRAINT virtualization_virtualmachinetype_slug_key UNIQUE (slug);


--
-- Name: virtualization_vminterface_tagged_vlans virtualization_vminterfa_vminterface_id_vlan_id_27e907db_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_vminterface_tagged_vlans
    ADD CONSTRAINT virtualization_vminterfa_vminterface_id_vlan_id_27e907db_uniq UNIQUE (vminterface_id, vlan_id);


--
-- Name: virtualization_vminterface virtualization_vminterface_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_vminterface
    ADD CONSTRAINT virtualization_vminterface_pkey PRIMARY KEY (id);


--
-- Name: virtualization_vminterface virtualization_vminterface_primary_mac_address_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_vminterface
    ADD CONSTRAINT virtualization_vminterface_primary_mac_address_id_key UNIQUE (primary_mac_address_id);


--
-- Name: virtualization_vminterface_tagged_vlans virtualization_vminterface_tagged_vlans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_vminterface_tagged_vlans
    ADD CONSTRAINT virtualization_vminterface_tagged_vlans_pkey PRIMARY KEY (id);


--
-- Name: virtualization_vminterface virtualization_vminterface_unique_virtual_machine_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_vminterface
    ADD CONSTRAINT virtualization_vminterface_unique_virtual_machine_name UNIQUE (virtual_machine_id, name);


--
-- Name: vpn_ikepolicy vpn_ikepolicy_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ikepolicy
    ADD CONSTRAINT vpn_ikepolicy_name_key UNIQUE (name);


--
-- Name: vpn_ikepolicy vpn_ikepolicy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ikepolicy
    ADD CONSTRAINT vpn_ikepolicy_pkey PRIMARY KEY (id);


--
-- Name: vpn_ikepolicy_proposals vpn_ikepolicy_proposals_ikepolicy_id_ikeproposal_0c3baa9c_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ikepolicy_proposals
    ADD CONSTRAINT vpn_ikepolicy_proposals_ikepolicy_id_ikeproposal_0c3baa9c_uniq UNIQUE (ikepolicy_id, ikeproposal_id);


--
-- Name: vpn_ikepolicy_proposals vpn_ikepolicy_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ikepolicy_proposals
    ADD CONSTRAINT vpn_ikepolicy_proposals_pkey PRIMARY KEY (id);


--
-- Name: vpn_ikeproposal vpn_ikeproposal_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ikeproposal
    ADD CONSTRAINT vpn_ikeproposal_name_key UNIQUE (name);


--
-- Name: vpn_ikeproposal vpn_ikeproposal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ikeproposal
    ADD CONSTRAINT vpn_ikeproposal_pkey PRIMARY KEY (id);


--
-- Name: vpn_ipsecpolicy vpn_ipsecpolicy_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ipsecpolicy
    ADD CONSTRAINT vpn_ipsecpolicy_name_key UNIQUE (name);


--
-- Name: vpn_ipsecpolicy vpn_ipsecpolicy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ipsecpolicy
    ADD CONSTRAINT vpn_ipsecpolicy_pkey PRIMARY KEY (id);


--
-- Name: vpn_ipsecpolicy_proposals vpn_ipsecpolicy_proposal_ipsecpolicy_id_ipsecprop_72096768_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ipsecpolicy_proposals
    ADD CONSTRAINT vpn_ipsecpolicy_proposal_ipsecpolicy_id_ipsecprop_72096768_uniq UNIQUE (ipsecpolicy_id, ipsecproposal_id);


--
-- Name: vpn_ipsecpolicy_proposals vpn_ipsecpolicy_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ipsecpolicy_proposals
    ADD CONSTRAINT vpn_ipsecpolicy_proposals_pkey PRIMARY KEY (id);


--
-- Name: vpn_ipsecprofile vpn_ipsecprofile_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ipsecprofile
    ADD CONSTRAINT vpn_ipsecprofile_name_key UNIQUE (name);


--
-- Name: vpn_ipsecprofile vpn_ipsecprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ipsecprofile
    ADD CONSTRAINT vpn_ipsecprofile_pkey PRIMARY KEY (id);


--
-- Name: vpn_ipsecproposal vpn_ipsecproposal_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ipsecproposal
    ADD CONSTRAINT vpn_ipsecproposal_name_key UNIQUE (name);


--
-- Name: vpn_ipsecproposal vpn_ipsecproposal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ipsecproposal
    ADD CONSTRAINT vpn_ipsecproposal_pkey PRIMARY KEY (id);


--
-- Name: vpn_l2vpn vpn_l2vpn_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_l2vpn
    ADD CONSTRAINT vpn_l2vpn_name_key UNIQUE (name);


--
-- Name: vpn_l2vpn vpn_l2vpn_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_l2vpn
    ADD CONSTRAINT vpn_l2vpn_pkey PRIMARY KEY (id);


--
-- Name: vpn_l2vpn vpn_l2vpn_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_l2vpn
    ADD CONSTRAINT vpn_l2vpn_slug_key UNIQUE (slug);


--
-- Name: vpn_l2vpntermination vpn_l2vpntermination_assigned_object; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_l2vpntermination
    ADD CONSTRAINT vpn_l2vpntermination_assigned_object UNIQUE (assigned_object_type_id, assigned_object_id);


--
-- Name: vpn_l2vpntermination vpn_l2vpntermination_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_l2vpntermination
    ADD CONSTRAINT vpn_l2vpntermination_pkey PRIMARY KEY (id);


--
-- Name: vpn_tunnel vpn_tunnel_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_tunnel
    ADD CONSTRAINT vpn_tunnel_name_key UNIQUE (name);


--
-- Name: vpn_tunnel vpn_tunnel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_tunnel
    ADD CONSTRAINT vpn_tunnel_pkey PRIMARY KEY (id);


--
-- Name: vpn_tunnelgroup vpn_tunnelgroup_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_tunnelgroup
    ADD CONSTRAINT vpn_tunnelgroup_name_key UNIQUE (name);


--
-- Name: vpn_tunnelgroup vpn_tunnelgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_tunnelgroup
    ADD CONSTRAINT vpn_tunnelgroup_pkey PRIMARY KEY (id);


--
-- Name: vpn_tunnelgroup vpn_tunnelgroup_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_tunnelgroup
    ADD CONSTRAINT vpn_tunnelgroup_slug_key UNIQUE (slug);


--
-- Name: vpn_tunneltermination vpn_tunneltermination_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_tunneltermination
    ADD CONSTRAINT vpn_tunneltermination_pkey PRIMARY KEY (id);


--
-- Name: vpn_tunneltermination vpn_tunneltermination_termination; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_tunneltermination
    ADD CONSTRAINT vpn_tunneltermination_termination UNIQUE (termination_type_id, termination_id);


--
-- Name: wireless_wirelesslan wireless_wirelesslan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslan
    ADD CONSTRAINT wireless_wirelesslan_pkey PRIMARY KEY (id);


--
-- Name: wireless_wirelesslangroup wireless_wirelesslangroup_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslangroup
    ADD CONSTRAINT wireless_wirelesslangroup_name_key UNIQUE (name);


--
-- Name: wireless_wirelesslangroup wireless_wirelesslangroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslangroup
    ADD CONSTRAINT wireless_wirelesslangroup_pkey PRIMARY KEY (id);


--
-- Name: wireless_wirelesslangroup wireless_wirelesslangroup_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslangroup
    ADD CONSTRAINT wireless_wirelesslangroup_slug_key UNIQUE (slug);


--
-- Name: wireless_wirelesslink wireless_wirelesslink_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslink
    ADD CONSTRAINT wireless_wirelesslink_pkey PRIMARY KEY (id);


--
-- Name: wireless_wirelesslink wireless_wirelesslink_unique_interfaces; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslink
    ADD CONSTRAINT wireless_wirelesslink_unique_interfaces UNIQUE (interface_a_id, interface_b_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.users_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.users_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.users_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.users_user_user_permissions USING btree (user_id);


--
-- Name: circuits_ci_group_i_2f8327_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_ci_group_i_2f8327_idx ON public.circuits_circuitgroupassignment USING btree (group_id, member_type_id, member_id, priority, id);


--
-- Name: circuits_ci_provide_a0c42c_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_ci_provide_a0c42c_idx ON public.circuits_circuit USING btree (provider_id, provider_account_id, cid);


--
-- Name: circuits_ci_termina_505dda_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_ci_termina_505dda_idx ON public.circuits_circuittermination USING btree (termination_type_id, termination_id);


--
-- Name: circuits_circuit_owner_id_c330c2d0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuit_owner_id_c330c2d0 ON public.circuits_circuit USING btree (owner_id);


--
-- Name: circuits_circuit_provider_account_id_a7c8f61b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuit_provider_account_id_a7c8f61b ON public.circuits_circuit USING btree (provider_account_id);


--
-- Name: circuits_circuit_provider_id_d9195418; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuit_provider_id_d9195418 ON public.circuits_circuit USING btree (provider_id);


--
-- Name: circuits_circuit_tenant_id_812508a5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuit_tenant_id_812508a5 ON public.circuits_circuit USING btree (tenant_id);


--
-- Name: circuits_circuit_termination_a_id_f891adac; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuit_termination_a_id_f891adac ON public.circuits_circuit USING btree (termination_a_id);


--
-- Name: circuits_circuit_termination_z_id_377b8551; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuit_termination_z_id_377b8551 ON public.circuits_circuit USING btree (termination_z_id);


--
-- Name: circuits_circuit_type_id_1b9f485a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuit_type_id_1b9f485a ON public.circuits_circuit USING btree (type_id);


--
-- Name: circuits_circuitgroup_name_ec8ac1e5_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuitgroup_name_ec8ac1e5_like ON public.circuits_circuitgroup USING btree (name varchar_pattern_ops);


--
-- Name: circuits_circuitgroup_owner_id_1edf4d64; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuitgroup_owner_id_1edf4d64 ON public.circuits_circuitgroup USING btree (owner_id);


--
-- Name: circuits_circuitgroup_slug_61ca866b_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuitgroup_slug_61ca866b_like ON public.circuits_circuitgroup USING btree (slug varchar_pattern_ops);


--
-- Name: circuits_circuitgroup_tenant_id_5bafdc3f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuitgroup_tenant_id_5bafdc3f ON public.circuits_circuitgroup USING btree (tenant_id);


--
-- Name: circuits_circuitgroupassignment_group_id_1a7b6580; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuitgroupassignment_group_id_1a7b6580 ON public.circuits_circuitgroupassignment USING btree (group_id);


--
-- Name: circuits_circuitgroupassignment_member_type_id_779d1a13; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuitgroupassignment_member_type_id_779d1a13 ON public.circuits_circuitgroupassignment USING btree (member_type_id);


--
-- Name: circuits_circuittermination__location_id_4a578dca; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuittermination__location_id_4a578dca ON public.circuits_circuittermination USING btree (_location_id);


--
-- Name: circuits_circuittermination__region_id_1fa03379; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuittermination__region_id_1fa03379 ON public.circuits_circuittermination USING btree (_region_id);


--
-- Name: circuits_circuittermination__site_group_id_ec0c1998; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuittermination__site_group_id_ec0c1998 ON public.circuits_circuittermination USING btree (_site_group_id);


--
-- Name: circuits_circuittermination__site_id_84942491; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuittermination__site_id_84942491 ON public.circuits_circuittermination USING btree (_site_id);


--
-- Name: circuits_circuittermination_cable_id_35e9f703; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuittermination_cable_id_35e9f703 ON public.circuits_circuittermination USING btree (cable_id);


--
-- Name: circuits_circuittermination_circuit_id_257e87e7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuittermination_circuit_id_257e87e7 ON public.circuits_circuittermination USING btree (circuit_id);


--
-- Name: circuits_circuittermination_provider_network_id_b0c660f1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuittermination_provider_network_id_b0c660f1 ON public.circuits_circuittermination USING btree (_provider_network_id);


--
-- Name: circuits_circuittermination_termination_type_id_c9262c91; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuittermination_termination_type_id_c9262c91 ON public.circuits_circuittermination USING btree (termination_type_id);


--
-- Name: circuits_circuittype_name_8256ea9a_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuittype_name_8256ea9a_like ON public.circuits_circuittype USING btree (name varchar_pattern_ops);


--
-- Name: circuits_circuittype_owner_id_9c3200c2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuittype_owner_id_9c3200c2 ON public.circuits_circuittype USING btree (owner_id);


--
-- Name: circuits_circuittype_slug_9b4b3cf9_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_circuittype_slug_9b4b3cf9_like ON public.circuits_circuittype USING btree (slug varchar_pattern_ops);


--
-- Name: circuits_provider_asns_asn_id_0a6c53b3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_provider_asns_asn_id_0a6c53b3 ON public.circuits_provider_asns USING btree (asn_id);


--
-- Name: circuits_provider_asns_provider_id_becc3f7e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_provider_asns_provider_id_becc3f7e ON public.circuits_provider_asns USING btree (provider_id);


--
-- Name: circuits_provider_name_8f2514f5_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_provider_name_8f2514f5_like ON public.circuits_provider USING btree (name varchar_pattern_ops);


--
-- Name: circuits_provider_owner_id_9f9749b4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_provider_owner_id_9f9749b4 ON public.circuits_provider USING btree (owner_id);


--
-- Name: circuits_provider_slug_c3c0aa10_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_provider_slug_c3c0aa10_like ON public.circuits_provider USING btree (slug varchar_pattern_ops);


--
-- Name: circuits_provideraccount_owner_id_6dcd4819; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_provideraccount_owner_id_6dcd4819 ON public.circuits_provideraccount USING btree (owner_id);


--
-- Name: circuits_provideraccount_provider_id_4bcd7e50; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_provideraccount_provider_id_4bcd7e50 ON public.circuits_provideraccount USING btree (provider_id);


--
-- Name: circuits_provideraccount_unique_provider_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX circuits_provideraccount_unique_provider_name ON public.circuits_provideraccount USING btree (provider_id, name) WHERE (NOT ((name)::text = ''::text));


--
-- Name: circuits_providernetwork_owner_id_caa8afde; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_providernetwork_owner_id_caa8afde ON public.circuits_providernetwork USING btree (owner_id);


--
-- Name: circuits_providernetwork_provider_id_7992236c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_providernetwork_provider_id_7992236c ON public.circuits_providernetwork USING btree (provider_id);


--
-- Name: circuits_vi_provide_989efa_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_vi_provide_989efa_idx ON public.circuits_virtualcircuit USING btree (provider_network_id, provider_account_id, cid);


--
-- Name: circuits_vi_virtual_4b5c0c_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_vi_virtual_4b5c0c_idx ON public.circuits_virtualcircuittermination USING btree (virtual_circuit_id, role, id);


--
-- Name: circuits_virtualcircuit_owner_id_89564a1e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_virtualcircuit_owner_id_89564a1e ON public.circuits_virtualcircuit USING btree (owner_id);


--
-- Name: circuits_virtualcircuit_provider_account_id_d942f455; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_virtualcircuit_provider_account_id_d942f455 ON public.circuits_virtualcircuit USING btree (provider_account_id);


--
-- Name: circuits_virtualcircuit_provider_network_id_a902f409; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_virtualcircuit_provider_network_id_a902f409 ON public.circuits_virtualcircuit USING btree (provider_network_id);


--
-- Name: circuits_virtualcircuit_tenant_id_4458eca7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_virtualcircuit_tenant_id_4458eca7 ON public.circuits_virtualcircuit USING btree (tenant_id);


--
-- Name: circuits_virtualcircuit_type_id_8527d682; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_virtualcircuit_type_id_8527d682 ON public.circuits_virtualcircuit USING btree (type_id);


--
-- Name: circuits_virtualcircuittermination_virtual_circuit_id_ca588886; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_virtualcircuittermination_virtual_circuit_id_ca588886 ON public.circuits_virtualcircuittermination USING btree (virtual_circuit_id);


--
-- Name: circuits_virtualcircuittype_name_5184db16_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_virtualcircuittype_name_5184db16_like ON public.circuits_virtualcircuittype USING btree (name varchar_pattern_ops);


--
-- Name: circuits_virtualcircuittype_owner_id_12a50b80; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_virtualcircuittype_owner_id_12a50b80 ON public.circuits_virtualcircuittype USING btree (owner_id);


--
-- Name: circuits_virtualcircuittype_slug_75d5c661_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX circuits_virtualcircuittype_slug_75d5c661_like ON public.circuits_virtualcircuittype USING btree (slug varchar_pattern_ops);


--
-- Name: core_autosyncrecord_datafile_id_f2aad29e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_autosyncrecord_datafile_id_f2aad29e ON public.core_autosyncrecord USING btree (datafile_id);


--
-- Name: core_autosyncrecord_object_type_id_62506cf6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_autosyncrecord_object_type_id_62506cf6 ON public.core_autosyncrecord USING btree (object_type_id);


--
-- Name: core_config_created_ef9552_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_config_created_ef9552_idx ON public.core_configrevision USING btree (created DESC);


--
-- Name: core_datafile_source_id_8d675be2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_datafile_source_id_8d675be2 ON public.core_datafile USING btree (source_id);


--
-- Name: core_datasource_name_17788499_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_datasource_name_17788499_like ON public.core_datasource USING btree (name varchar_pattern_ops);


--
-- Name: core_datasource_owner_id_3f4e6ba5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_datasource_owner_id_3f4e6ba5 ON public.core_datasource USING btree (owner_id);


--
-- Name: core_job_created_efa7cb_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_job_created_efa7cb_idx ON public.core_job USING btree (created DESC);


--
-- Name: core_job_object__c664ac_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_job_object__c664ac_idx ON public.core_job USING btree (object_type_id, object_id);


--
-- Name: core_job_object_type_id_ea17469a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_job_object_type_id_ea17469a ON public.core_job USING btree (object_type_id);


--
-- Name: core_job_user_id_b69eefda; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_job_user_id_b69eefda ON public.core_job USING btree (user_id);


--
-- Name: core_managedfile_data_file_id_2b6fc95e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_managedfile_data_file_id_2b6fc95e ON public.core_managedfile USING btree (data_file_id);


--
-- Name: core_managedfile_data_source_id_647d5dbe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_managedfile_data_source_id_647d5dbe ON public.core_managedfile USING btree (data_source_id);


--
-- Name: core_object_feature_aec4de_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_object_feature_aec4de_gin ON public.core_objecttype USING gin (features);


--
-- Name: core_objectchange_changed_object_type_id_2070ade6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_objectchange_changed_object_type_id_2070ade6 ON public.core_objectchange USING btree (changed_object_type_id);


--
-- Name: core_objectchange_changed_object_type_id_cha_79a9ed1e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_objectchange_changed_object_type_id_cha_79a9ed1e ON public.core_objectchange USING btree (changed_object_type_id, changed_object_id);


--
-- Name: core_objectchange_related_object_type_id_b80958af; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_objectchange_related_object_type_id_b80958af ON public.core_objectchange USING btree (related_object_type_id);


--
-- Name: core_objectchange_related_object_type_id_rel_a71d604a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_objectchange_related_object_type_id_rel_a71d604a ON public.core_objectchange USING btree (related_object_type_id, related_object_id);


--
-- Name: core_objectchange_request_id_d9d160ac; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_objectchange_request_id_d9d160ac ON public.core_objectchange USING btree (request_id);


--
-- Name: core_objectchange_time_800f60a5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_objectchange_time_800f60a5 ON public.core_objectchange USING btree ("time");


--
-- Name: core_objectchange_user_id_2b2142be; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_objectchange_user_id_2b2142be ON public.core_objectchange USING btree (user_id);


--
-- Name: dcim_cable_bundle_id_f893f393; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_cable_bundle_id_f893f393 ON public.dcim_cable USING btree (bundle_id);


--
-- Name: dcim_cable_owner_id_9cea1430; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_cable_owner_id_9cea1430 ON public.dcim_cable USING btree (owner_id);


--
-- Name: dcim_cable_tenant_id_3a7fdbb8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_cable_tenant_id_3a7fdbb8 ON public.dcim_cable USING btree (tenant_id);


--
-- Name: dcim_cablebundle_name_8a6c0a17_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_cablebundle_name_8a6c0a17_like ON public.dcim_cablebundle USING btree (name varchar_pattern_ops);


--
-- Name: dcim_cablebundle_owner_id_8f2a8189; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_cablebundle_owner_id_8f2a8189 ON public.dcim_cablebundle USING btree (owner_id);


--
-- Name: dcim_cablep__nodes_b23b96_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_cablep__nodes_b23b96_gin ON public.dcim_cablepath USING gin (_nodes);


--
-- Name: dcim_cabletermination__device_id_f5884934; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_cabletermination__device_id_f5884934 ON public.dcim_cabletermination USING btree (_device_id);


--
-- Name: dcim_cabletermination__location_id_ff4be503; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_cabletermination__location_id_ff4be503 ON public.dcim_cabletermination USING btree (_location_id);


--
-- Name: dcim_cabletermination__rack_id_83a548e1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_cabletermination__rack_id_83a548e1 ON public.dcim_cabletermination USING btree (_rack_id);


--
-- Name: dcim_cabletermination__site_id_616962fa; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_cabletermination__site_id_616962fa ON public.dcim_cabletermination USING btree (_site_id);


--
-- Name: dcim_cabletermination_cable_id_b50010d1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_cabletermination_cable_id_b50010d1 ON public.dcim_cabletermination USING btree (cable_id);


--
-- Name: dcim_cabletermination_termination_type_id_20da439e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_cabletermination_termination_type_id_20da439e ON public.dcim_cabletermination USING btree (termination_type_id);


--
-- Name: dcim_consol_device__101ed5_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consol_device__101ed5_idx ON public.dcim_consoleporttemplate USING btree (device_type_id, module_type_id, name);


--
-- Name: dcim_consol_device__a901e6_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consol_device__a901e6_idx ON public.dcim_consoleserverporttemplate USING btree (device_type_id, module_type_id, name);


--
-- Name: dcim_consoleport__location_id_d0e7437b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleport__location_id_d0e7437b ON public.dcim_consoleport USING btree (_location_id);


--
-- Name: dcim_consoleport__path_id_e40a4436; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleport__path_id_e40a4436 ON public.dcim_consoleport USING btree (_path_id);


--
-- Name: dcim_consoleport__rack_id_71f16827; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleport__rack_id_71f16827 ON public.dcim_consoleport USING btree (_rack_id);


--
-- Name: dcim_consoleport__site_id_9652df9c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleport__site_id_9652df9c ON public.dcim_consoleport USING btree (_site_id);


--
-- Name: dcim_consoleport_cable_id_a9ae5465; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleport_cable_id_a9ae5465 ON public.dcim_consoleport USING btree (cable_id);


--
-- Name: dcim_consoleport_device_id_f2d90d3c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleport_device_id_f2d90d3c ON public.dcim_consoleport USING btree (device_id);


--
-- Name: dcim_consoleport_module_id_d17b2519; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleport_module_id_d17b2519 ON public.dcim_consoleport USING btree (module_id);


--
-- Name: dcim_consoleport_owner_id_0648eae1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleport_owner_id_0648eae1 ON public.dcim_consoleport USING btree (owner_id);


--
-- Name: dcim_consoleporttemplate_device_type_id_075d4015; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleporttemplate_device_type_id_075d4015 ON public.dcim_consoleporttemplate USING btree (device_type_id);


--
-- Name: dcim_consoleporttemplate_module_type_id_c0f35d97; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleporttemplate_module_type_id_c0f35d97 ON public.dcim_consoleporttemplate USING btree (module_type_id);


--
-- Name: dcim_consoleserverport__location_id_7525ec0e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleserverport__location_id_7525ec0e ON public.dcim_consoleserverport USING btree (_location_id);


--
-- Name: dcim_consoleserverport__path_id_dc5abe09; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleserverport__path_id_dc5abe09 ON public.dcim_consoleserverport USING btree (_path_id);


--
-- Name: dcim_consoleserverport__rack_id_3eea9f1b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleserverport__rack_id_3eea9f1b ON public.dcim_consoleserverport USING btree (_rack_id);


--
-- Name: dcim_consoleserverport__site_id_c500ac62; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleserverport__site_id_c500ac62 ON public.dcim_consoleserverport USING btree (_site_id);


--
-- Name: dcim_consoleserverport_cable_id_f2940dfd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleserverport_cable_id_f2940dfd ON public.dcim_consoleserverport USING btree (cable_id);


--
-- Name: dcim_consoleserverport_device_id_d9866581; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleserverport_device_id_d9866581 ON public.dcim_consoleserverport USING btree (device_id);


--
-- Name: dcim_consoleserverport_module_id_d060cfc8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleserverport_module_id_d060cfc8 ON public.dcim_consoleserverport USING btree (module_id);


--
-- Name: dcim_consoleserverport_owner_id_12b1a827; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleserverport_owner_id_12b1a827 ON public.dcim_consoleserverport USING btree (owner_id);


--
-- Name: dcim_consoleserverporttemplate_device_type_id_579bdc86; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleserverporttemplate_device_type_id_579bdc86 ON public.dcim_consoleserverporttemplate USING btree (device_type_id);


--
-- Name: dcim_consoleserverporttemplate_module_type_id_4abf751a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_consoleserverporttemplate_module_type_id_4abf751a ON public.dcim_consoleserverporttemplate USING btree (module_type_id);


--
-- Name: dcim_coolin_device__4d0859_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolin_device__4d0859_idx ON public.dcim_coolingoutflowtemplate USING btree (device_type_id, module_type_id, name);


--
-- Name: dcim_coolin_device__ee88f9_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolin_device__ee88f9_idx ON public.dcim_coolingintaketemplate USING btree (device_type_id, module_type_id, name);


--
-- Name: dcim_coolingfeed_cooling_source_id_f09a946f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingfeed_cooling_source_id_f09a946f ON public.dcim_coolingfeed USING btree (cooling_source_id);


--
-- Name: dcim_coolingfeed_owner_id_8d34da56; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingfeed_owner_id_8d34da56 ON public.dcim_coolingfeed USING btree (owner_id);


--
-- Name: dcim_coolingfeed_rack_id_c100ab11; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingfeed_rack_id_c100ab11 ON public.dcim_coolingfeed USING btree (rack_id);


--
-- Name: dcim_coolingfeed_tenant_id_db41c14e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingfeed_tenant_id_db41c14e ON public.dcim_coolingfeed USING btree (tenant_id);


--
-- Name: dcim_coolingintake__location_id_19e02a96; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingintake__location_id_19e02a96 ON public.dcim_coolingintake USING btree (_location_id);


--
-- Name: dcim_coolingintake__rack_id_53527d66; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingintake__rack_id_53527d66 ON public.dcim_coolingintake USING btree (_rack_id);


--
-- Name: dcim_coolingintake__site_id_8a7279a3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingintake__site_id_8a7279a3 ON public.dcim_coolingintake USING btree (_site_id);


--
-- Name: dcim_coolingintake_cooling_outflow_id_e1bd22b7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingintake_cooling_outflow_id_e1bd22b7 ON public.dcim_coolingintake USING btree (cooling_outflow_id);


--
-- Name: dcim_coolingintake_device_id_df1c3674; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingintake_device_id_df1c3674 ON public.dcim_coolingintake USING btree (device_id);


--
-- Name: dcim_coolingintake_module_id_5aa49e74; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingintake_module_id_5aa49e74 ON public.dcim_coolingintake USING btree (module_id);


--
-- Name: dcim_coolingintake_owner_id_91bcbf27; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingintake_owner_id_91bcbf27 ON public.dcim_coolingintake USING btree (owner_id);


--
-- Name: dcim_coolingintaketemplate_device_type_id_4fffffed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingintaketemplate_device_type_id_4fffffed ON public.dcim_coolingintaketemplate USING btree (device_type_id);


--
-- Name: dcim_coolingintaketemplate_module_type_id_b734e68e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingintaketemplate_module_type_id_b734e68e ON public.dcim_coolingintaketemplate USING btree (module_type_id);


--
-- Name: dcim_coolingoutflow__location_id_718fca97; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingoutflow__location_id_718fca97 ON public.dcim_coolingoutflow USING btree (_location_id);


--
-- Name: dcim_coolingoutflow__rack_id_5af2d149; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingoutflow__rack_id_5af2d149 ON public.dcim_coolingoutflow USING btree (_rack_id);


--
-- Name: dcim_coolingoutflow__site_id_ba7ee355; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingoutflow__site_id_ba7ee355 ON public.dcim_coolingoutflow USING btree (_site_id);


--
-- Name: dcim_coolingoutflow_cooling_intake_id_6ce03c77; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingoutflow_cooling_intake_id_6ce03c77 ON public.dcim_coolingoutflow USING btree (cooling_intake_id);


--
-- Name: dcim_coolingoutflow_device_id_74dd615f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingoutflow_device_id_74dd615f ON public.dcim_coolingoutflow USING btree (device_id);


--
-- Name: dcim_coolingoutflow_module_id_6a2cc4b3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingoutflow_module_id_6a2cc4b3 ON public.dcim_coolingoutflow USING btree (module_id);


--
-- Name: dcim_coolingoutflow_owner_id_b4cd9c02; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingoutflow_owner_id_b4cd9c02 ON public.dcim_coolingoutflow USING btree (owner_id);


--
-- Name: dcim_coolingoutflowtemplate_cooling_intake_id_616147e2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingoutflowtemplate_cooling_intake_id_616147e2 ON public.dcim_coolingoutflowtemplate USING btree (cooling_intake_id);


--
-- Name: dcim_coolingoutflowtemplate_device_type_id_f1ae955b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingoutflowtemplate_device_type_id_f1ae955b ON public.dcim_coolingoutflowtemplate USING btree (device_type_id);


--
-- Name: dcim_coolingoutflowtemplate_module_type_id_751812c7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingoutflowtemplate_module_type_id_751812c7 ON public.dcim_coolingoutflowtemplate USING btree (module_type_id);


--
-- Name: dcim_coolingsource_location_id_7490ac1d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingsource_location_id_7490ac1d ON public.dcim_coolingsource USING btree (location_id);


--
-- Name: dcim_coolingsource_owner_id_7499d734; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingsource_owner_id_7499d734 ON public.dcim_coolingsource USING btree (owner_id);


--
-- Name: dcim_coolingsource_site_id_95af0633; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_coolingsource_site_id_95af0633 ON public.dcim_coolingsource USING btree (site_id);


--
-- Name: dcim_device_asset_tag_8dac1079_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_device_asset_tag_8dac1079_like ON public.dcim_device USING btree (asset_tag varchar_pattern_ops);


--
-- Name: dcim_device_cc_null; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_device_cc_null ON public.dcim_device USING btree (id) WHERE (_config_context_data IS NULL);


--
-- Name: dcim_device_cluster_id_cf852f78; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_device_cluster_id_cf852f78 ON public.dcim_device USING btree (cluster_id);


--
-- Name: dcim_device_config_template_id_316328c4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_device_config_template_id_316328c4 ON public.dcim_device USING btree (config_template_id);


--
-- Name: dcim_device_device_role_id_682e8188; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_device_device_role_id_682e8188 ON public.dcim_device USING btree (role_id);


--
-- Name: dcim_device_device_type_id_d61b4086; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_device_device_type_id_d61b4086 ON public.dcim_device USING btree (device_type_id);


--
-- Name: dcim_device_location_id_11a7bedb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_device_location_id_11a7bedb ON public.dcim_device USING btree (location_id);


--
-- Name: dcim_device_name_c27913_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_device_name_c27913_idx ON public.dcim_device USING btree (name, id);


--
-- Name: dcim_device_owner_id_87378f76; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_device_owner_id_87378f76 ON public.dcim_device USING btree (owner_id);


--
-- Name: dcim_device_platform_id_468138f1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_device_platform_id_468138f1 ON public.dcim_device USING btree (platform_id);


--
-- Name: dcim_device_rack_id_23bde71f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_device_rack_id_23bde71f ON public.dcim_device USING btree (rack_id);


--
-- Name: dcim_device_site_id_ff897cf6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_device_site_id_ff897cf6 ON public.dcim_device USING btree (site_id);


--
-- Name: dcim_device_tenant_id_dcea7969; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_device_tenant_id_dcea7969 ON public.dcim_device USING btree (tenant_id);


--
-- Name: dcim_device_unique_name_site_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX dcim_device_unique_name_site_tenant ON public.dcim_device USING btree (lower((name)::text), site_id, tenant_id) NULLS NOT DISTINCT WHERE (name IS NOT NULL);


--
-- Name: dcim_device_virtual_chassis_id_aed51693; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_device_virtual_chassis_id_aed51693 ON public.dcim_device USING btree (virtual_chassis_id);


--
-- Name: dcim_devicebay__location_id_6c869a87; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_devicebay__location_id_6c869a87 ON public.dcim_devicebay USING btree (_location_id);


--
-- Name: dcim_devicebay__rack_id_75672431; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_devicebay__rack_id_75672431 ON public.dcim_devicebay USING btree (_rack_id);


--
-- Name: dcim_devicebay__site_id_8ddc30f4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_devicebay__site_id_8ddc30f4 ON public.dcim_devicebay USING btree (_site_id);


--
-- Name: dcim_devicebay_device_id_0c8a1218; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_devicebay_device_id_0c8a1218 ON public.dcim_devicebay USING btree (device_id);


--
-- Name: dcim_devicebay_owner_id_d7bcb3e6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_devicebay_owner_id_d7bcb3e6 ON public.dcim_devicebay USING btree (owner_id);


--
-- Name: dcim_devicebaytemplate_device_type_id_f4b24a29; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_devicebaytemplate_device_type_id_f4b24a29 ON public.dcim_devicebaytemplate USING btree (device_type_id);


--
-- Name: dcim_devicerole_config_template_id_5874002c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_devicerole_config_template_id_5874002c ON public.dcim_devicerole USING btree (config_template_id);


--
-- Name: dcim_devicerole_owner_id_fdcc527d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_devicerole_owner_id_fdcc527d ON public.dcim_devicerole USING btree (owner_id);


--
-- Name: dcim_devicerole_parent_id_7f9ccf87; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_devicerole_parent_id_7f9ccf87 ON public.dcim_devicerole USING btree (parent_id);


--
-- Name: dcim_devicerole_path_gist; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_devicerole_path_gist ON public.dcim_devicerole USING gist (path);


--
-- Name: dcim_devicerole_slug_7952643b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_devicerole_slug_7952643b ON public.dcim_devicerole USING btree (slug);


--
-- Name: dcim_devicerole_slug_7952643b_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_devicerole_slug_7952643b_like ON public.dcim_devicerole USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_devicerole_sort_path_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_devicerole_sort_path_idx ON public.dcim_devicerole USING btree (sort_path);


--
-- Name: dcim_devicetype_default_platform_id_1f6ff6ac; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_devicetype_default_platform_id_1f6ff6ac ON public.dcim_devicetype USING btree (default_platform_id);


--
-- Name: dcim_devicetype_manufacturer_id_a3e8029e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_devicetype_manufacturer_id_a3e8029e ON public.dcim_devicetype USING btree (manufacturer_id);


--
-- Name: dcim_devicetype_owner_id_243048ed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_devicetype_owner_id_243048ed ON public.dcim_devicetype USING btree (owner_id);


--
-- Name: dcim_devicetype_slug_448745bd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_devicetype_slug_448745bd ON public.dcim_devicetype USING btree (slug);


--
-- Name: dcim_devicetype_slug_448745bd_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_devicetype_slug_448745bd_like ON public.dcim_devicetype USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_frontp_device__ec2ffb_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_frontp_device__ec2ffb_idx ON public.dcim_frontporttemplate USING btree (device_type_id, module_type_id, name);


--
-- Name: dcim_frontport__location_id_dc0402e7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_frontport__location_id_dc0402e7 ON public.dcim_frontport USING btree (_location_id);


--
-- Name: dcim_frontport__rack_id_1ba6d11c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_frontport__rack_id_1ba6d11c ON public.dcim_frontport USING btree (_rack_id);


--
-- Name: dcim_frontport__site_id_51efdefe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_frontport__site_id_51efdefe ON public.dcim_frontport USING btree (_site_id);


--
-- Name: dcim_frontport_cable_id_04ff8aab; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_frontport_cable_id_04ff8aab ON public.dcim_frontport USING btree (cable_id);


--
-- Name: dcim_frontport_device_id_950557b5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_frontport_device_id_950557b5 ON public.dcim_frontport USING btree (device_id);


--
-- Name: dcim_frontport_module_id_952c3f9a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_frontport_module_id_952c3f9a ON public.dcim_frontport USING btree (module_id);


--
-- Name: dcim_frontport_owner_id_dfb61151; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_frontport_owner_id_dfb61151 ON public.dcim_frontport USING btree (owner_id);


--
-- Name: dcim_frontporttemplate_device_type_id_f088b952; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_frontporttemplate_device_type_id_f088b952 ON public.dcim_frontporttemplate USING btree (device_type_id);


--
-- Name: dcim_frontporttemplate_module_type_id_66851ff9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_frontporttemplate_module_type_id_66851ff9 ON public.dcim_frontporttemplate USING btree (module_type_id);


--
-- Name: dcim_interf_device__601012_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interf_device__601012_idx ON public.dcim_interfacetemplate USING btree (device_type_id, module_type_id, name);


--
-- Name: dcim_interface__location_id_72d5e107; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface__location_id_72d5e107 ON public.dcim_interface USING btree (_location_id);


--
-- Name: dcim_interface__path_id_f8f4f7f0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface__path_id_f8f4f7f0 ON public.dcim_interface USING btree (_path_id);


--
-- Name: dcim_interface__rack_id_0d3f84a6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface__rack_id_0d3f84a6 ON public.dcim_interface USING btree (_rack_id);


--
-- Name: dcim_interface__site_id_0fffd4ef; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface__site_id_0fffd4ef ON public.dcim_interface USING btree (_site_id);


--
-- Name: dcim_interface_bridge_id_f2a8df85; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface_bridge_id_f2a8df85 ON public.dcim_interface USING btree (bridge_id);


--
-- Name: dcim_interface_cable_id_1b264edb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface_cable_id_1b264edb ON public.dcim_interface USING btree (cable_id);


--
-- Name: dcim_interface_device_id_359c6115; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface_device_id_359c6115 ON public.dcim_interface USING btree (device_id);


--
-- Name: dcim_interface_lag_id_ea1a1d12; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface_lag_id_ea1a1d12 ON public.dcim_interface USING btree (lag_id);


--
-- Name: dcim_interface_module_id_05ca2da5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface_module_id_05ca2da5 ON public.dcim_interface USING btree (module_id);


--
-- Name: dcim_interface_owner_id_3ae797e2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface_owner_id_3ae797e2 ON public.dcim_interface USING btree (owner_id);


--
-- Name: dcim_interface_parent_id_3e2b159b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface_parent_id_3e2b159b ON public.dcim_interface USING btree (parent_id);


--
-- Name: dcim_interface_qinq_svlan_id_21189a58; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface_qinq_svlan_id_21189a58 ON public.dcim_interface USING btree (qinq_svlan_id);


--
-- Name: dcim_interface_tagged_vlans_interface_id_5870c9e9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface_tagged_vlans_interface_id_5870c9e9 ON public.dcim_interface_tagged_vlans USING btree (interface_id);


--
-- Name: dcim_interface_tagged_vlans_vlan_id_e027005c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface_tagged_vlans_vlan_id_e027005c ON public.dcim_interface_tagged_vlans USING btree (vlan_id);


--
-- Name: dcim_interface_untagged_vlan_id_838dc7be; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface_untagged_vlan_id_838dc7be ON public.dcim_interface USING btree (untagged_vlan_id);


--
-- Name: dcim_interface_vdcs_interface_id_6d58dbaf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface_vdcs_interface_id_6d58dbaf ON public.dcim_interface_vdcs USING btree (interface_id);


--
-- Name: dcim_interface_vdcs_virtualdevicecontext_id_af0bfd4b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface_vdcs_virtualdevicecontext_id_af0bfd4b ON public.dcim_interface_vdcs USING btree (virtualdevicecontext_id);


--
-- Name: dcim_interface_vlan_translation_policy_id_91060031; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface_vlan_translation_policy_id_91060031 ON public.dcim_interface USING btree (vlan_translation_policy_id);


--
-- Name: dcim_interface_vrf_id_a92e59b2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface_vrf_id_a92e59b2 ON public.dcim_interface USING btree (vrf_id);


--
-- Name: dcim_interface_wireless_lans_interface_id_80df3785; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface_wireless_lans_interface_id_80df3785 ON public.dcim_interface_wireless_lans USING btree (interface_id);


--
-- Name: dcim_interface_wireless_lans_wirelesslan_id_f081e278; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface_wireless_lans_wirelesslan_id_f081e278 ON public.dcim_interface_wireless_lans USING btree (wirelesslan_id);


--
-- Name: dcim_interface_wireless_link_id_bc91108f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interface_wireless_link_id_bc91108f ON public.dcim_interface USING btree (wireless_link_id);


--
-- Name: dcim_interfacetemplate_bridge_id_4e44355b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interfacetemplate_bridge_id_4e44355b ON public.dcim_interfacetemplate USING btree (bridge_id);


--
-- Name: dcim_interfacetemplate_device_type_id_4bfcbfab; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interfacetemplate_device_type_id_4bfcbfab ON public.dcim_interfacetemplate USING btree (device_type_id);


--
-- Name: dcim_interfacetemplate_module_type_id_f941f180; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interfacetemplate_module_type_id_f941f180 ON public.dcim_interfacetemplate USING btree (module_type_id);


--
-- Name: dcim_interfacetemplate_parent_id_1016cd00; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_interfacetemplate_parent_id_1016cd00 ON public.dcim_interfacetemplate USING btree (parent_id);


--
-- Name: dcim_inv_item_tmpl_path_gist; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inv_item_tmpl_path_gist ON public.dcim_inventoryitemtemplate USING gist (path);


--
-- Name: dcim_invent_compone_0560bb_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_invent_compone_0560bb_idx ON public.dcim_inventoryitem USING btree (component_type_id, component_id);


--
-- Name: dcim_invent_compone_77b5f8_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_invent_compone_77b5f8_idx ON public.dcim_inventoryitemtemplate USING btree (component_type_id, component_id);


--
-- Name: dcim_inventoryitem__location_id_05a23b33; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitem__location_id_05a23b33 ON public.dcim_inventoryitem USING btree (_location_id);


--
-- Name: dcim_inventoryitem__rack_id_25b80d23; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitem__rack_id_25b80d23 ON public.dcim_inventoryitem USING btree (_rack_id);


--
-- Name: dcim_inventoryitem__site_id_cd94573b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitem__site_id_cd94573b ON public.dcim_inventoryitem USING btree (_site_id);


--
-- Name: dcim_inventoryitem_asset_tag_d3289273_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitem_asset_tag_d3289273_like ON public.dcim_inventoryitem USING btree (asset_tag varchar_pattern_ops);


--
-- Name: dcim_inventoryitem_component_type_id_f0e4d83a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitem_component_type_id_f0e4d83a ON public.dcim_inventoryitem USING btree (component_type_id);


--
-- Name: dcim_inventoryitem_device_id_033d83f8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitem_device_id_033d83f8 ON public.dcim_inventoryitem USING btree (device_id);


--
-- Name: dcim_inventoryitem_manufacturer_id_dcd1b78a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitem_manufacturer_id_dcd1b78a ON public.dcim_inventoryitem USING btree (manufacturer_id);


--
-- Name: dcim_inventoryitem_owner_id_ad4332eb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitem_owner_id_ad4332eb ON public.dcim_inventoryitem USING btree (owner_id);


--
-- Name: dcim_inventoryitem_parent_id_7ebcd457; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitem_parent_id_7ebcd457 ON public.dcim_inventoryitem USING btree (parent_id);


--
-- Name: dcim_inventoryitem_path_gist; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitem_path_gist ON public.dcim_inventoryitem USING gist (path);


--
-- Name: dcim_inventoryitem_role_id_2bcfcb04; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitem_role_id_2bcfcb04 ON public.dcim_inventoryitem USING btree (role_id);


--
-- Name: dcim_inventoryitemrole_name_4c8cfe6d_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitemrole_name_4c8cfe6d_like ON public.dcim_inventoryitemrole USING btree (name varchar_pattern_ops);


--
-- Name: dcim_inventoryitemrole_owner_id_067442e9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitemrole_owner_id_067442e9 ON public.dcim_inventoryitemrole USING btree (owner_id);


--
-- Name: dcim_inventoryitemrole_slug_3556c227_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitemrole_slug_3556c227_like ON public.dcim_inventoryitemrole USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_inventoryitemtemplate_component_type_id_161623a2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitemtemplate_component_type_id_161623a2 ON public.dcim_inventoryitemtemplate USING btree (component_type_id);


--
-- Name: dcim_inventoryitemtemplate_device_type_id_6a1be904; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitemtemplate_device_type_id_6a1be904 ON public.dcim_inventoryitemtemplate USING btree (device_type_id);


--
-- Name: dcim_inventoryitemtemplate_manufacturer_id_b388c5d9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitemtemplate_manufacturer_id_b388c5d9 ON public.dcim_inventoryitemtemplate USING btree (manufacturer_id);


--
-- Name: dcim_inventoryitemtemplate_parent_id_0dac73bb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitemtemplate_parent_id_0dac73bb ON public.dcim_inventoryitemtemplate USING btree (parent_id);


--
-- Name: dcim_inventoryitemtemplate_role_id_292676e6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_inventoryitemtemplate_role_id_292676e6 ON public.dcim_inventoryitemtemplate USING btree (role_id);


--
-- Name: dcim_location_owner_id_919a8713; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_location_owner_id_919a8713 ON public.dcim_location USING btree (owner_id);


--
-- Name: dcim_location_parent_id_d77f3318; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_location_parent_id_d77f3318 ON public.dcim_location USING btree (parent_id);


--
-- Name: dcim_location_path_gist; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_location_path_gist ON public.dcim_location USING gist (path);


--
-- Name: dcim_location_site_id_b55e975f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_location_site_id_b55e975f ON public.dcim_location USING btree (site_id);


--
-- Name: dcim_location_slug_352c5472; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_location_slug_352c5472 ON public.dcim_location USING btree (slug);


--
-- Name: dcim_location_slug_352c5472_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_location_slug_352c5472_like ON public.dcim_location USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_location_sort_path_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_location_sort_path_idx ON public.dcim_location USING btree (sort_path);


--
-- Name: dcim_location_tenant_id_2c4df974; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_location_tenant_id_2c4df974 ON public.dcim_location USING btree (tenant_id);


--
-- Name: dcim_macadd_assigne_54115d_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_macadd_assigne_54115d_idx ON public.dcim_macaddress USING btree (assigned_object_type_id, assigned_object_id);


--
-- Name: dcim_macadd_mac_add_f2662a_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_macadd_mac_add_f2662a_idx ON public.dcim_macaddress USING btree (mac_address, id);


--
-- Name: dcim_macaddress_assigned_object_type_id_28814a20; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_macaddress_assigned_object_type_id_28814a20 ON public.dcim_macaddress USING btree (assigned_object_type_id);


--
-- Name: dcim_macaddress_owner_id_29ba2f60; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_macaddress_owner_id_29ba2f60 ON public.dcim_macaddress USING btree (owner_id);


--
-- Name: dcim_manufacturer_name_841fcd92_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_manufacturer_name_841fcd92_like ON public.dcim_manufacturer USING btree (name varchar_pattern_ops);


--
-- Name: dcim_manufacturer_owner_id_8d78661f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_manufacturer_owner_id_8d78661f ON public.dcim_manufacturer USING btree (owner_id);


--
-- Name: dcim_manufacturer_slug_00430749_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_manufacturer_slug_00430749_like ON public.dcim_manufacturer USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_module_asset_tag_2fd91eed_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_module_asset_tag_2fd91eed_like ON public.dcim_module USING btree (asset_tag varchar_pattern_ops);


--
-- Name: dcim_module_device__9eabad_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_module_device__9eabad_idx ON public.dcim_modulebaytemplate USING btree (device_type_id, module_type_id, name);


--
-- Name: dcim_module_device_id_53cfd5be; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_module_device_id_53cfd5be ON public.dcim_module USING btree (device_id);


--
-- Name: dcim_module_module_type_id_a50b39fc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_module_module_type_id_a50b39fc ON public.dcim_module USING btree (module_type_id);


--
-- Name: dcim_module_owner_id_ee6f1ef4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_module_owner_id_ee6f1ef4 ON public.dcim_module USING btree (owner_id);


--
-- Name: dcim_module_profile_868277_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_module_profile_868277_idx ON public.dcim_moduletype USING btree (profile_id, manufacturer_id, model);


--
-- Name: dcim_modulebay__location_id_17290069; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebay__location_id_17290069 ON public.dcim_modulebay USING btree (_location_id);


--
-- Name: dcim_modulebay__rack_id_673d8fb5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebay__rack_id_673d8fb5 ON public.dcim_modulebay USING btree (_rack_id);


--
-- Name: dcim_modulebay__site_id_cedd61bc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebay__site_id_cedd61bc ON public.dcim_modulebay USING btree (_site_id);


--
-- Name: dcim_modulebay_device_id_3526abc2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebay_device_id_3526abc2 ON public.dcim_modulebay USING btree (device_id);


--
-- Name: dcim_modulebay_module_bay_types_modulebay_id_1bb84f17; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebay_module_bay_types_modulebay_id_1bb84f17 ON public.dcim_modulebay_module_bay_types USING btree (modulebay_id);


--
-- Name: dcim_modulebay_module_bay_types_modulebaytype_id_35dd161c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebay_module_bay_types_modulebaytype_id_35dd161c ON public.dcim_modulebay_module_bay_types USING btree (modulebaytype_id);


--
-- Name: dcim_modulebay_module_id_a21ddd9a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebay_module_id_a21ddd9a ON public.dcim_modulebay USING btree (module_id);


--
-- Name: dcim_modulebay_owner_id_311f58c6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebay_owner_id_311f58c6 ON public.dcim_modulebay USING btree (owner_id);


--
-- Name: dcim_modulebay_parent_id_e483f9b7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebay_parent_id_e483f9b7 ON public.dcim_modulebay USING btree (parent_id);


--
-- Name: dcim_modulebay_path_gist; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebay_path_gist ON public.dcim_modulebay USING gist (path);


--
-- Name: dcim_modulebay_sort_path_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebay_sort_path_idx ON public.dcim_modulebay USING btree (sort_path);


--
-- Name: dcim_modulebaytemplate_device_type_id_9eaf9bd3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebaytemplate_device_type_id_9eaf9bd3 ON public.dcim_modulebaytemplate USING btree (device_type_id);


--
-- Name: dcim_modulebaytemplate_mod_modulebaytemplate_id_b0b99ce5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebaytemplate_mod_modulebaytemplate_id_b0b99ce5 ON public.dcim_modulebaytemplate_module_bay_types USING btree (modulebaytemplate_id);


--
-- Name: dcim_modulebaytemplate_mod_modulebaytype_id_13a3815a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebaytemplate_mod_modulebaytype_id_13a3815a ON public.dcim_modulebaytemplate_module_bay_types USING btree (modulebaytype_id);


--
-- Name: dcim_modulebaytemplate_module_type_id_2fdfb491; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebaytemplate_module_type_id_2fdfb491 ON public.dcim_modulebaytemplate USING btree (module_type_id);


--
-- Name: dcim_modulebaytype_manufacturer_id_699547c4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebaytype_manufacturer_id_699547c4 ON public.dcim_modulebaytype USING btree (manufacturer_id);


--
-- Name: dcim_modulebaytype_owner_id_2a0cf25d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebaytype_owner_id_2a0cf25d ON public.dcim_modulebaytype USING btree (owner_id);


--
-- Name: dcim_modulebaytype_slug_716b91a9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebaytype_slug_716b91a9 ON public.dcim_modulebaytype USING btree (slug);


--
-- Name: dcim_modulebaytype_slug_716b91a9_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_modulebaytype_slug_716b91a9_like ON public.dcim_modulebaytype USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_moduletype_manufacturer_id_7347392e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_moduletype_manufacturer_id_7347392e ON public.dcim_moduletype USING btree (manufacturer_id);


--
-- Name: dcim_moduletype_module_bay_types_modulebaytype_id_04c73693; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_moduletype_module_bay_types_modulebaytype_id_04c73693 ON public.dcim_moduletype_module_bay_types USING btree (modulebaytype_id);


--
-- Name: dcim_moduletype_module_bay_types_moduletype_id_4ff17f2d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_moduletype_module_bay_types_moduletype_id_4ff17f2d ON public.dcim_moduletype_module_bay_types USING btree (moduletype_id);


--
-- Name: dcim_moduletype_owner_id_2ea2fd3b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_moduletype_owner_id_2ea2fd3b ON public.dcim_moduletype USING btree (owner_id);


--
-- Name: dcim_moduletype_profile_id_62b5d02d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_moduletype_profile_id_62b5d02d ON public.dcim_moduletype USING btree (profile_id);


--
-- Name: dcim_moduletypeprofile_name_1709c36e_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_moduletypeprofile_name_1709c36e_like ON public.dcim_moduletypeprofile USING btree (name varchar_pattern_ops);


--
-- Name: dcim_moduletypeprofile_owner_id_c4488ff6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_moduletypeprofile_owner_id_c4488ff6 ON public.dcim_moduletypeprofile USING btree (owner_id);


--
-- Name: dcim_platform_config_template_id_013a4d3c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_platform_config_template_id_013a4d3c ON public.dcim_platform USING btree (config_template_id);


--
-- Name: dcim_platform_manufacturer_id_83f72d3d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_platform_manufacturer_id_83f72d3d ON public.dcim_platform USING btree (manufacturer_id);


--
-- Name: dcim_platform_owner_id_0990eb87; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_platform_owner_id_0990eb87 ON public.dcim_platform USING btree (owner_id);


--
-- Name: dcim_platform_parent_id_795c7101; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_platform_parent_id_795c7101 ON public.dcim_platform USING btree (parent_id);


--
-- Name: dcim_platform_path_gist; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_platform_path_gist ON public.dcim_platform USING gist (path);


--
-- Name: dcim_platform_slug_b0908ae4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_platform_slug_b0908ae4 ON public.dcim_platform USING btree (slug);


--
-- Name: dcim_platform_slug_b0908ae4_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_platform_slug_b0908ae4_like ON public.dcim_platform USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_platform_sort_path_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_platform_sort_path_idx ON public.dcim_platform USING btree (sort_path);


--
-- Name: dcim_portmapping_device_id_eb86e378; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_portmapping_device_id_eb86e378 ON public.dcim_portmapping USING btree (device_id);


--
-- Name: dcim_portmapping_front_port_id_d8413d45; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_portmapping_front_port_id_d8413d45 ON public.dcim_portmapping USING btree (front_port_id);


--
-- Name: dcim_portmapping_rear_port_id_dc3fb4b8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_portmapping_rear_port_id_dc3fb4b8 ON public.dcim_portmapping USING btree (rear_port_id);


--
-- Name: dcim_porttemplatemapping_device_type_id_dede0eeb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_porttemplatemapping_device_type_id_dede0eeb ON public.dcim_porttemplatemapping USING btree (device_type_id);


--
-- Name: dcim_porttemplatemapping_front_port_id_090c3c11; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_porttemplatemapping_front_port_id_090c3c11 ON public.dcim_porttemplatemapping USING btree (front_port_id);


--
-- Name: dcim_porttemplatemapping_module_type_id_3a84e529; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_porttemplatemapping_module_type_id_3a84e529 ON public.dcim_porttemplatemapping USING btree (module_type_id);


--
-- Name: dcim_porttemplatemapping_rear_port_id_93a9b08f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_porttemplatemapping_rear_port_id_93a9b08f ON public.dcim_porttemplatemapping USING btree (rear_port_id);


--
-- Name: dcim_powerfeed__path_id_a1ea1f28; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerfeed__path_id_a1ea1f28 ON public.dcim_powerfeed USING btree (_path_id);


--
-- Name: dcim_powerfeed_cable_id_ec44c4f8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerfeed_cable_id_ec44c4f8 ON public.dcim_powerfeed USING btree (cable_id);


--
-- Name: dcim_powerfeed_owner_id_97320081; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerfeed_owner_id_97320081 ON public.dcim_powerfeed USING btree (owner_id);


--
-- Name: dcim_powerfeed_power_panel_id_32bde3be; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerfeed_power_panel_id_32bde3be ON public.dcim_powerfeed USING btree (power_panel_id);


--
-- Name: dcim_powerfeed_rack_id_7abba090; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerfeed_rack_id_7abba090 ON public.dcim_powerfeed USING btree (rack_id);


--
-- Name: dcim_powerfeed_tenant_id_947bee85; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerfeed_tenant_id_947bee85 ON public.dcim_powerfeed USING btree (tenant_id);


--
-- Name: dcim_powero_device__b83a8f_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powero_device__b83a8f_idx ON public.dcim_poweroutlettemplate USING btree (device_type_id, module_type_id, name);


--
-- Name: dcim_poweroutlet__location_id_49563316; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_poweroutlet__location_id_49563316 ON public.dcim_poweroutlet USING btree (_location_id);


--
-- Name: dcim_poweroutlet__path_id_cbb47bb9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_poweroutlet__path_id_cbb47bb9 ON public.dcim_poweroutlet USING btree (_path_id);


--
-- Name: dcim_poweroutlet__rack_id_aca89672; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_poweroutlet__rack_id_aca89672 ON public.dcim_poweroutlet USING btree (_rack_id);


--
-- Name: dcim_poweroutlet__site_id_a956755e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_poweroutlet__site_id_a956755e ON public.dcim_poweroutlet USING btree (_site_id);


--
-- Name: dcim_poweroutlet_cable_id_8dbea1ec; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_poweroutlet_cable_id_8dbea1ec ON public.dcim_poweroutlet USING btree (cable_id);


--
-- Name: dcim_poweroutlet_device_id_286351d7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_poweroutlet_device_id_286351d7 ON public.dcim_poweroutlet USING btree (device_id);


--
-- Name: dcim_poweroutlet_module_id_032f5af2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_poweroutlet_module_id_032f5af2 ON public.dcim_poweroutlet USING btree (module_id);


--
-- Name: dcim_poweroutlet_owner_id_0806d01d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_poweroutlet_owner_id_0806d01d ON public.dcim_poweroutlet USING btree (owner_id);


--
-- Name: dcim_poweroutlet_power_port_id_9bdf4163; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_poweroutlet_power_port_id_9bdf4163 ON public.dcim_poweroutlet USING btree (power_port_id);


--
-- Name: dcim_poweroutlettemplate_device_type_id_26b2316c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_poweroutlettemplate_device_type_id_26b2316c ON public.dcim_poweroutlettemplate USING btree (device_type_id);


--
-- Name: dcim_poweroutlettemplate_module_type_id_6142b416; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_poweroutlettemplate_module_type_id_6142b416 ON public.dcim_poweroutlettemplate USING btree (module_type_id);


--
-- Name: dcim_poweroutlettemplate_power_port_id_c0fb0c42; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_poweroutlettemplate_power_port_id_c0fb0c42 ON public.dcim_poweroutlettemplate USING btree (power_port_id);


--
-- Name: dcim_powerp_device__6c25da_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerp_device__6c25da_idx ON public.dcim_powerporttemplate USING btree (device_type_id, module_type_id, name);


--
-- Name: dcim_powerpanel_location_id_474b60f8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerpanel_location_id_474b60f8 ON public.dcim_powerpanel USING btree (location_id);


--
-- Name: dcim_powerpanel_owner_id_11e7d421; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerpanel_owner_id_11e7d421 ON public.dcim_powerpanel USING btree (owner_id);


--
-- Name: dcim_powerpanel_site_id_c430bc89; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerpanel_site_id_c430bc89 ON public.dcim_powerpanel USING btree (site_id);


--
-- Name: dcim_powerport__location_id_ccf995e7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerport__location_id_ccf995e7 ON public.dcim_powerport USING btree (_location_id);


--
-- Name: dcim_powerport__path_id_9fe4af8f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerport__path_id_9fe4af8f ON public.dcim_powerport USING btree (_path_id);


--
-- Name: dcim_powerport__rack_id_4c1c316d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerport__rack_id_4c1c316d ON public.dcim_powerport USING btree (_rack_id);


--
-- Name: dcim_powerport__site_id_87bfa142; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerport__site_id_87bfa142 ON public.dcim_powerport USING btree (_site_id);


--
-- Name: dcim_powerport_cable_id_c9682ba2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerport_cable_id_c9682ba2 ON public.dcim_powerport USING btree (cable_id);


--
-- Name: dcim_powerport_device_id_ef7185ae; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerport_device_id_ef7185ae ON public.dcim_powerport USING btree (device_id);


--
-- Name: dcim_powerport_module_id_d0c27534; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerport_module_id_d0c27534 ON public.dcim_powerport USING btree (module_id);


--
-- Name: dcim_powerport_owner_id_b83ff931; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerport_owner_id_b83ff931 ON public.dcim_powerport USING btree (owner_id);


--
-- Name: dcim_powerporttemplate_device_type_id_1ddfbfcc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerporttemplate_device_type_id_1ddfbfcc ON public.dcim_powerporttemplate USING btree (device_type_id);


--
-- Name: dcim_powerporttemplate_module_type_id_93e26849; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_powerporttemplate_module_type_id_93e26849 ON public.dcim_powerporttemplate USING btree (module_type_id);


--
-- Name: dcim_rack_asset_tag_f88408e5_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rack_asset_tag_f88408e5_like ON public.dcim_rack USING btree (asset_tag varchar_pattern_ops);


--
-- Name: dcim_rack_group_id_44e90ea9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rack_group_id_44e90ea9 ON public.dcim_rack USING btree (group_id);


--
-- Name: dcim_rack_location_id_5f63ec31; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rack_location_id_5f63ec31 ON public.dcim_rack USING btree (location_id);


--
-- Name: dcim_rack_owner_id_7a5532fc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rack_owner_id_7a5532fc ON public.dcim_rack USING btree (owner_id);


--
-- Name: dcim_rack_rack_type_id_39433a22; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rack_rack_type_id_39433a22 ON public.dcim_rack USING btree (rack_type_id);


--
-- Name: dcim_rack_role_id_62d6919e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rack_role_id_62d6919e ON public.dcim_rack USING btree (role_id);


--
-- Name: dcim_rack_site_id_403c7b3a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rack_site_id_403c7b3a ON public.dcim_rack USING btree (site_id);


--
-- Name: dcim_rack_site_id_715040_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rack_site_id_715040_idx ON public.dcim_rack USING btree (site_id, location_id, name, id);


--
-- Name: dcim_rack_tenant_id_7cdf3725; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rack_tenant_id_7cdf3725 ON public.dcim_rack USING btree (tenant_id);


--
-- Name: dcim_rackgroup_name_6a84593a_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rackgroup_name_6a84593a_like ON public.dcim_rackgroup USING btree (name varchar_pattern_ops);


--
-- Name: dcim_rackgroup_owner_id_5484beb8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rackgroup_owner_id_5484beb8 ON public.dcim_rackgroup USING btree (owner_id);


--
-- Name: dcim_rackgroup_slug_3f4582a7_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rackgroup_slug_3f4582a7_like ON public.dcim_rackgroup USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_rackre_created_84f02e_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rackre_created_84f02e_idx ON public.dcim_rackreservation USING btree (created, id);


--
-- Name: dcim_rackreservation_owner_id_12c19e94; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rackreservation_owner_id_12c19e94 ON public.dcim_rackreservation USING btree (owner_id);


--
-- Name: dcim_rackreservation_rack_id_1ebbaa9b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rackreservation_rack_id_1ebbaa9b ON public.dcim_rackreservation USING btree (rack_id);


--
-- Name: dcim_rackreservation_tenant_id_eb5e045f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rackreservation_tenant_id_eb5e045f ON public.dcim_rackreservation USING btree (tenant_id);


--
-- Name: dcim_rackreservation_user_id_0785a527; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rackreservation_user_id_0785a527 ON public.dcim_rackreservation USING btree (user_id);


--
-- Name: dcim_rackrole_name_9077cfcc_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rackrole_name_9077cfcc_like ON public.dcim_rackrole USING btree (name varchar_pattern_ops);


--
-- Name: dcim_rackrole_owner_id_fb6f0b77; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rackrole_owner_id_fb6f0b77 ON public.dcim_rackrole USING btree (owner_id);


--
-- Name: dcim_rackrole_slug_40bbcd3a_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rackrole_slug_40bbcd3a_like ON public.dcim_rackrole USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_racktype_manufacturer_id_d46a05c6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_racktype_manufacturer_id_d46a05c6 ON public.dcim_racktype USING btree (manufacturer_id);


--
-- Name: dcim_racktype_owner_id_ce0a0d75; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_racktype_owner_id_ce0a0d75 ON public.dcim_racktype USING btree (owner_id);


--
-- Name: dcim_racktype_slug_6bbb384a_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_racktype_slug_6bbb384a_like ON public.dcim_racktype USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_rearpo_device__27f194_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rearpo_device__27f194_idx ON public.dcim_rearporttemplate USING btree (device_type_id, module_type_id, name);


--
-- Name: dcim_rearport__location_id_72554006; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rearport__location_id_72554006 ON public.dcim_rearport USING btree (_location_id);


--
-- Name: dcim_rearport__rack_id_9af9a402; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rearport__rack_id_9af9a402 ON public.dcim_rearport USING btree (_rack_id);


--
-- Name: dcim_rearport__site_id_35e05ccf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rearport__site_id_35e05ccf ON public.dcim_rearport USING btree (_site_id);


--
-- Name: dcim_rearport_cable_id_42c0e4e7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rearport_cable_id_42c0e4e7 ON public.dcim_rearport USING btree (cable_id);


--
-- Name: dcim_rearport_device_id_0bdfe9c0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rearport_device_id_0bdfe9c0 ON public.dcim_rearport USING btree (device_id);


--
-- Name: dcim_rearport_module_id_9a7b7e91; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rearport_module_id_9a7b7e91 ON public.dcim_rearport USING btree (module_id);


--
-- Name: dcim_rearport_owner_id_51174512; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rearport_owner_id_51174512 ON public.dcim_rearport USING btree (owner_id);


--
-- Name: dcim_rearporttemplate_device_type_id_6a02fd01; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rearporttemplate_device_type_id_6a02fd01 ON public.dcim_rearporttemplate USING btree (device_type_id);


--
-- Name: dcim_rearporttemplate_module_type_id_4d970e5b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_rearporttemplate_module_type_id_4d970e5b ON public.dcim_rearporttemplate USING btree (module_type_id);


--
-- Name: dcim_region_owner_id_7e9d3adf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_region_owner_id_7e9d3adf ON public.dcim_region USING btree (owner_id);


--
-- Name: dcim_region_parent_id_2486f5d4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_region_parent_id_2486f5d4 ON public.dcim_region USING btree (parent_id);


--
-- Name: dcim_region_path_gist; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_region_path_gist ON public.dcim_region USING gist (path);


--
-- Name: dcim_region_slug_ff078a66; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_region_slug_ff078a66 ON public.dcim_region USING btree (slug);


--
-- Name: dcim_region_slug_ff078a66_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_region_slug_ff078a66_like ON public.dcim_region USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_region_sort_path_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_region_sort_path_idx ON public.dcim_region USING btree (sort_path);


--
-- Name: dcim_site_asns_asn_id_3cfd0f00; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_site_asns_asn_id_3cfd0f00 ON public.dcim_site_asns USING btree (asn_id);


--
-- Name: dcim_site_asns_site_id_112ccacf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_site_asns_site_id_112ccacf ON public.dcim_site_asns USING btree (site_id);


--
-- Name: dcim_site_group_id_3910c975; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_site_group_id_3910c975 ON public.dcim_site USING btree (group_id);


--
-- Name: dcim_site_name_8fe66c76_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_site_name_8fe66c76_like ON public.dcim_site USING btree (name varchar_pattern_ops);


--
-- Name: dcim_site_owner_id_ef94687e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_site_owner_id_ef94687e ON public.dcim_site USING btree (owner_id);


--
-- Name: dcim_site_region_id_45210932; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_site_region_id_45210932 ON public.dcim_site USING btree (region_id);


--
-- Name: dcim_site_slug_4412c762_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_site_slug_4412c762_like ON public.dcim_site USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_site_tenant_id_15e7df63; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_site_tenant_id_15e7df63 ON public.dcim_site USING btree (tenant_id);


--
-- Name: dcim_sitegroup_owner_id_50283a64; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_sitegroup_owner_id_50283a64 ON public.dcim_sitegroup USING btree (owner_id);


--
-- Name: dcim_sitegroup_parent_id_533a5e44; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_sitegroup_parent_id_533a5e44 ON public.dcim_sitegroup USING btree (parent_id);


--
-- Name: dcim_sitegroup_path_gist; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_sitegroup_path_gist ON public.dcim_sitegroup USING gist (path);


--
-- Name: dcim_sitegroup_slug_a11d2b04; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_sitegroup_slug_a11d2b04 ON public.dcim_sitegroup USING btree (slug);


--
-- Name: dcim_sitegroup_slug_a11d2b04_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_sitegroup_slug_a11d2b04_like ON public.dcim_sitegroup USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_sitegroup_sort_path_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_sitegroup_sort_path_idx ON public.dcim_sitegroup USING btree (sort_path);


--
-- Name: dcim_virtua_name_079d4d_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_virtua_name_079d4d_idx ON public.dcim_virtualdevicecontext USING btree (name);


--
-- Name: dcim_virtua_name_2dc5cd_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_virtua_name_2dc5cd_idx ON public.dcim_virtualchassis USING btree (name);


--
-- Name: dcim_virtualchassis_owner_id_76116efe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_virtualchassis_owner_id_76116efe ON public.dcim_virtualchassis USING btree (owner_id);


--
-- Name: dcim_virtualdevicecontext_device_id_4f39274b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_virtualdevicecontext_device_id_4f39274b ON public.dcim_virtualdevicecontext USING btree (device_id);


--
-- Name: dcim_virtualdevicecontext_owner_id_33c19ef7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_virtualdevicecontext_owner_id_33c19ef7 ON public.dcim_virtualdevicecontext USING btree (owner_id);


--
-- Name: dcim_virtualdevicecontext_tenant_id_b6a21753; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dcim_virtualdevicecontext_tenant_id_b6a21753 ON public.dcim_virtualdevicecontext USING btree (tenant_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: extras_book_created_1cb4a5_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_book_created_1cb4a5_idx ON public.extras_bookmark USING btree (created, id);


--
-- Name: extras_book_object__2df6b4_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_book_object__2df6b4_idx ON public.extras_bookmark USING btree (object_type_id, object_id);


--
-- Name: extras_bookmark_object_type_id_18c4bb44; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_bookmark_object_type_id_18c4bb44 ON public.extras_bookmark USING btree (object_type_id);


--
-- Name: extras_bookmark_user_id_cb6c6677; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_bookmark_user_id_cb6c6677 ON public.extras_bookmark USING btree (user_id);


--
-- Name: extras_cachedvalue_object; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_cachedvalue_object ON public.extras_cachedvalue USING btree (object_type_id, object_id);


--
-- Name: extras_cachedvalue_object_type_id_6f47d444; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_cachedvalue_object_type_id_6f47d444 ON public.extras_cachedvalue USING btree (object_type_id);


--
-- Name: extras_conf_name_e276bf_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_conf_name_e276bf_idx ON public.extras_configtemplate USING btree (name);


--
-- Name: extras_conf_weight_ef9a81_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_conf_weight_ef9a81_idx ON public.extras_configcontext USING btree (weight, name);


--
-- Name: extras_configcontext_cluster_groups_clustergroup_id_f4322ce8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_cluster_groups_clustergroup_id_f4322ce8 ON public.extras_configcontext_cluster_groups USING btree (clustergroup_id);


--
-- Name: extras_configcontext_cluster_groups_configcontext_id_8f50b794; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_cluster_groups_configcontext_id_8f50b794 ON public.extras_configcontext_cluster_groups USING btree (configcontext_id);


--
-- Name: extras_configcontext_cluster_types_clustertype_id_fa493b64; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_cluster_types_clustertype_id_fa493b64 ON public.extras_configcontext_cluster_types USING btree (clustertype_id);


--
-- Name: extras_configcontext_cluster_types_configcontext_id_d549b6f2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_cluster_types_configcontext_id_d549b6f2 ON public.extras_configcontext_cluster_types USING btree (configcontext_id);


--
-- Name: extras_configcontext_clusters_cluster_id_6abd47a1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_clusters_cluster_id_6abd47a1 ON public.extras_configcontext_clusters USING btree (cluster_id);


--
-- Name: extras_configcontext_clusters_configcontext_id_ed579a40; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_clusters_configcontext_id_ed579a40 ON public.extras_configcontext_clusters USING btree (configcontext_id);


--
-- Name: extras_configcontext_data_file_id_8fdd620b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_data_file_id_8fdd620b ON public.extras_configcontext USING btree (data_file_id);


--
-- Name: extras_configcontext_data_source_id_1b2eb8af; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_data_source_id_1b2eb8af ON public.extras_configcontext USING btree (data_source_id);


--
-- Name: extras_configcontext_device_types_configcontext_id_55632923; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_device_types_configcontext_id_55632923 ON public.extras_configcontext_device_types USING btree (configcontext_id);


--
-- Name: extras_configcontext_device_types_devicetype_id_b8788c2d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_device_types_devicetype_id_b8788c2d ON public.extras_configcontext_device_types USING btree (devicetype_id);


--
-- Name: extras_configcontext_locations_configcontext_id_cc629ec1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_locations_configcontext_id_cc629ec1 ON public.extras_configcontext_locations USING btree (configcontext_id);


--
-- Name: extras_configcontext_locations_location_id_9e19eac9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_locations_location_id_9e19eac9 ON public.extras_configcontext_locations USING btree (location_id);


--
-- Name: extras_configcontext_name_4bbfe25d_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_name_4bbfe25d_like ON public.extras_configcontext USING btree (name varchar_pattern_ops);


--
-- Name: extras_configcontext_owner_id_6c8d9a06; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_owner_id_6c8d9a06 ON public.extras_configcontext USING btree (owner_id);


--
-- Name: extras_configcontext_platforms_configcontext_id_2a516699; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_platforms_configcontext_id_2a516699 ON public.extras_configcontext_platforms USING btree (configcontext_id);


--
-- Name: extras_configcontext_platforms_platform_id_3fdfedc0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_platforms_platform_id_3fdfedc0 ON public.extras_configcontext_platforms USING btree (platform_id);


--
-- Name: extras_configcontext_profile_id_48c7bc6a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_profile_id_48c7bc6a ON public.extras_configcontext USING btree (profile_id);


--
-- Name: extras_configcontext_regions_configcontext_id_73003dbc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_regions_configcontext_id_73003dbc ON public.extras_configcontext_regions USING btree (configcontext_id);


--
-- Name: extras_configcontext_regions_region_id_35c6ba9d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_regions_region_id_35c6ba9d ON public.extras_configcontext_regions USING btree (region_id);


--
-- Name: extras_configcontext_roles_configcontext_id_59b67386; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_roles_configcontext_id_59b67386 ON public.extras_configcontext_roles USING btree (configcontext_id);


--
-- Name: extras_configcontext_roles_devicerole_id_d3a84813; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_roles_devicerole_id_d3a84813 ON public.extras_configcontext_roles USING btree (devicerole_id);


--
-- Name: extras_configcontext_site_groups_configcontext_id_2e0f43cb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_site_groups_configcontext_id_2e0f43cb ON public.extras_configcontext_site_groups USING btree (configcontext_id);


--
-- Name: extras_configcontext_site_groups_sitegroup_id_3287c9e7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_site_groups_sitegroup_id_3287c9e7 ON public.extras_configcontext_site_groups USING btree (sitegroup_id);


--
-- Name: extras_configcontext_sites_configcontext_id_8c54feb9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_sites_configcontext_id_8c54feb9 ON public.extras_configcontext_sites USING btree (configcontext_id);


--
-- Name: extras_configcontext_sites_site_id_cbb76c96; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_sites_site_id_cbb76c96 ON public.extras_configcontext_sites USING btree (site_id);


--
-- Name: extras_configcontext_tags_configcontext_id_64a392b1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_tags_configcontext_id_64a392b1 ON public.extras_configcontext_tags USING btree (configcontext_id);


--
-- Name: extras_configcontext_tags_tag_id_129a5d87; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_tags_tag_id_129a5d87 ON public.extras_configcontext_tags USING btree (tag_id);


--
-- Name: extras_configcontext_tenant_groups_configcontext_id_92f68345; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_tenant_groups_configcontext_id_92f68345 ON public.extras_configcontext_tenant_groups USING btree (configcontext_id);


--
-- Name: extras_configcontext_tenant_groups_tenantgroup_id_0909688d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_tenant_groups_tenantgroup_id_0909688d ON public.extras_configcontext_tenant_groups USING btree (tenantgroup_id);


--
-- Name: extras_configcontext_tenants_configcontext_id_b53552a6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_tenants_configcontext_id_b53552a6 ON public.extras_configcontext_tenants USING btree (configcontext_id);


--
-- Name: extras_configcontext_tenants_tenant_id_8d0aa28e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontext_tenants_tenant_id_8d0aa28e ON public.extras_configcontext_tenants USING btree (tenant_id);


--
-- Name: extras_configcontextprofile_data_file_id_e0caf376; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontextprofile_data_file_id_e0caf376 ON public.extras_configcontextprofile USING btree (data_file_id);


--
-- Name: extras_configcontextprofile_data_source_id_b88dd849; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontextprofile_data_source_id_b88dd849 ON public.extras_configcontextprofile USING btree (data_source_id);


--
-- Name: extras_configcontextprofile_name_070de83b_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontextprofile_name_070de83b_like ON public.extras_configcontextprofile USING btree (name varchar_pattern_ops);


--
-- Name: extras_configcontextprofile_owner_id_6b1a975e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configcontextprofile_owner_id_6b1a975e ON public.extras_configcontextprofile USING btree (owner_id);


--
-- Name: extras_configtemplate_data_file_id_20c7cff4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configtemplate_data_file_id_20c7cff4 ON public.extras_configtemplate USING btree (data_file_id);


--
-- Name: extras_configtemplate_data_source_id_f9d26d5d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configtemplate_data_source_id_f9d26d5d ON public.extras_configtemplate USING btree (data_source_id);


--
-- Name: extras_configtemplate_owner_id_0925c336; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_configtemplate_owner_id_0925c336 ON public.extras_configtemplate USING btree (owner_id);


--
-- Name: extras_cust_group_n_40cb93_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_cust_group_n_40cb93_idx ON public.extras_customfield USING btree (group_name, weight, name);


--
-- Name: extras_cust_group_n_5a8be0_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_cust_group_n_5a8be0_idx ON public.extras_customlink USING btree (group_name, weight, name);


--
-- Name: extras_customfield_choice_set_id_5590efc2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_customfield_choice_set_id_5590efc2 ON public.extras_customfield USING btree (choice_set_id);


--
-- Name: extras_customfield_content_types_contenttype_id_2997ba90; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_customfield_content_types_contenttype_id_2997ba90 ON public.extras_customfield_object_types USING btree (contenttype_id);


--
-- Name: extras_customfield_content_types_customfield_id_3842aaf3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_customfield_content_types_customfield_id_3842aaf3 ON public.extras_customfield_object_types USING btree (customfield_id);


--
-- Name: extras_customfield_name_2fe72707_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_customfield_name_2fe72707_like ON public.extras_customfield USING btree (name varchar_pattern_ops);


--
-- Name: extras_customfield_object_type_id_489f2239; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_customfield_object_type_id_489f2239 ON public.extras_customfield USING btree (related_object_type_id);


--
-- Name: extras_customfield_owner_id_558f69a3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_customfield_owner_id_558f69a3 ON public.extras_customfield USING btree (owner_id);


--
-- Name: extras_customfieldchoiceset_name_963e63ea_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_customfieldchoiceset_name_963e63ea_like ON public.extras_customfieldchoiceset USING btree (name varchar_pattern_ops);


--
-- Name: extras_customfieldchoiceset_owner_id_02d6fc4d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_customfieldchoiceset_owner_id_02d6fc4d ON public.extras_customfieldchoiceset USING btree (owner_id);


--
-- Name: extras_customlink_content_types_contenttype_id_df5f34c2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_customlink_content_types_contenttype_id_df5f34c2 ON public.extras_customlink_object_types USING btree (contenttype_id);


--
-- Name: extras_customlink_content_types_customlink_id_229ba2bc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_customlink_content_types_customlink_id_229ba2bc ON public.extras_customlink_object_types USING btree (customlink_id);


--
-- Name: extras_customlink_name_daed2d18_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_customlink_name_daed2d18_like ON public.extras_customlink USING btree (name varchar_pattern_ops);


--
-- Name: extras_customlink_owner_id_b4449049; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_customlink_owner_id_b4449049 ON public.extras_customlink USING btree (owner_id);


--
-- Name: extras_even_action__d9e2af_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_even_action__d9e2af_idx ON public.extras_eventrule USING btree (action_object_type_id, action_object_id);


--
-- Name: extras_eventrule_action_object_type_id_1fe8a82e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_eventrule_action_object_type_id_1fe8a82e ON public.extras_eventrule USING btree (action_object_type_id);


--
-- Name: extras_eventrule_content_types_contenttype_id_a704fd34; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_eventrule_content_types_contenttype_id_a704fd34 ON public.extras_eventrule_object_types USING btree (contenttype_id);


--
-- Name: extras_eventrule_content_types_eventrule_id_c177fa54; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_eventrule_content_types_eventrule_id_c177fa54 ON public.extras_eventrule_object_types USING btree (eventrule_id);


--
-- Name: extras_eventrule_name_899453c6_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_eventrule_name_899453c6_like ON public.extras_eventrule USING btree (name varchar_pattern_ops);


--
-- Name: extras_eventrule_owner_id_a4c56a12; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_eventrule_owner_id_a4c56a12 ON public.extras_eventrule USING btree (owner_id);


--
-- Name: extras_expo_name_55a9af_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_expo_name_55a9af_idx ON public.extras_exporttemplate USING btree (name);


--
-- Name: extras_exporttemplate_content_types_contenttype_id_d80a5164; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_exporttemplate_content_types_contenttype_id_d80a5164 ON public.extras_exporttemplate_object_types USING btree (contenttype_id);


--
-- Name: extras_exporttemplate_content_types_exporttemplate_id_7645f081; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_exporttemplate_content_types_exporttemplate_id_7645f081 ON public.extras_exporttemplate_object_types USING btree (exporttemplate_id);


--
-- Name: extras_exporttemplate_data_file_id_40a91ef8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_exporttemplate_data_file_id_40a91ef8 ON public.extras_exporttemplate USING btree (data_file_id);


--
-- Name: extras_exporttemplate_data_source_id_d61d0feb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_exporttemplate_data_source_id_d61d0feb ON public.extras_exporttemplate USING btree (data_source_id);


--
-- Name: extras_exporttemplate_owner_id_a690b184; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_exporttemplate_owner_id_a690b184 ON public.extras_exporttemplate USING btree (owner_id);


--
-- Name: extras_imag_name_23cd9f_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_imag_name_23cd9f_idx ON public.extras_imageattachment USING btree (name, id);


--
-- Name: extras_imag_object__96bebc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_imag_object__96bebc_idx ON public.extras_imageattachment USING btree (object_type_id, object_id);


--
-- Name: extras_imageattachment_content_type_id_90e0643d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_imageattachment_content_type_id_90e0643d ON public.extras_imageattachment USING btree (object_type_id);


--
-- Name: extras_jour_assigne_76510f_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_jour_assigne_76510f_idx ON public.extras_journalentry USING btree (assigned_object_type_id, assigned_object_id);


--
-- Name: extras_jour_created_ec0fac_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_jour_created_ec0fac_idx ON public.extras_journalentry USING btree (created DESC);


--
-- Name: extras_journalentry_assigned_object_type_id_1bba9f68; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_journalentry_assigned_object_type_id_1bba9f68 ON public.extras_journalentry USING btree (assigned_object_type_id);


--
-- Name: extras_journalentry_created_by_id_8d4e4329; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_journalentry_created_by_id_8d4e4329 ON public.extras_journalentry USING btree (created_by_id);


--
-- Name: extras_noti_created_1d5146_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_noti_created_1d5146_idx ON public.extras_notification USING btree (created DESC, id);


--
-- Name: extras_noti_object__be74d5_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_noti_object__be74d5_idx ON public.extras_notification USING btree (object_type_id, object_id);


--
-- Name: extras_notification_object_type_id_2efeb525; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_notification_object_type_id_2efeb525 ON public.extras_notification USING btree (object_type_id);


--
-- Name: extras_notification_user_id_4d8c96f5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_notification_user_id_4d8c96f5 ON public.extras_notification USING btree (user_id);


--
-- Name: extras_notificationgroup_groups_group_id_af4b7b6c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_notificationgroup_groups_group_id_af4b7b6c ON public.extras_notificationgroup_groups USING btree (group_id);


--
-- Name: extras_notificationgroup_groups_notificationgroup_id_a41469f7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_notificationgroup_groups_notificationgroup_id_a41469f7 ON public.extras_notificationgroup_groups USING btree (notificationgroup_id);


--
-- Name: extras_notificationgroup_name_70b0a3f9_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_notificationgroup_name_70b0a3f9_like ON public.extras_notificationgroup USING btree (name varchar_pattern_ops);


--
-- Name: extras_notificationgroup_users_notificationgroup_id_0a8ec85c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_notificationgroup_users_notificationgroup_id_0a8ec85c ON public.extras_notificationgroup_users USING btree (notificationgroup_id);


--
-- Name: extras_notificationgroup_users_user_id_2c30da19; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_notificationgroup_users_user_id_2c30da19 ON public.extras_notificationgroup_users USING btree (user_id);


--
-- Name: extras_save_weight_c070c4_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_save_weight_c070c4_idx ON public.extras_savedfilter USING btree (weight, name);


--
-- Name: extras_savedfilter_content_types_contenttype_id_929cea22; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_savedfilter_content_types_contenttype_id_929cea22 ON public.extras_savedfilter_object_types USING btree (contenttype_id);


--
-- Name: extras_savedfilter_content_types_savedfilter_id_1631b88b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_savedfilter_content_types_savedfilter_id_1631b88b ON public.extras_savedfilter_object_types USING btree (savedfilter_id);


--
-- Name: extras_savedfilter_name_8a4bbd09_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_savedfilter_name_8a4bbd09_like ON public.extras_savedfilter USING btree (name varchar_pattern_ops);


--
-- Name: extras_savedfilter_owner_id_e022149a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_savedfilter_owner_id_e022149a ON public.extras_savedfilter USING btree (owner_id);


--
-- Name: extras_savedfilter_slug_4f93a959_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_savedfilter_slug_4f93a959_like ON public.extras_savedfilter USING btree (slug varchar_pattern_ops);


--
-- Name: extras_savedfilter_user_id_10502e81; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_savedfilter_user_id_10502e81 ON public.extras_savedfilter USING btree (user_id);


--
-- Name: extras_scri_module__8bd99c_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_scri_module__8bd99c_idx ON public.extras_script USING btree (module_id, name);


--
-- Name: extras_script_module_id_af9cffaa; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_script_module_id_af9cffaa ON public.extras_script USING btree (module_id);


--
-- Name: extras_subs_created_034618_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_subs_created_034618_idx ON public.extras_subscription USING btree (created DESC, user_id);


--
-- Name: extras_subs_object__37ef68_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_subs_object__37ef68_idx ON public.extras_subscription USING btree (object_type_id, object_id);


--
-- Name: extras_subscription_object_type_id_e53297d2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_subscription_object_type_id_e53297d2 ON public.extras_subscription USING btree (object_type_id);


--
-- Name: extras_subscription_user_id_37472a14; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_subscription_user_id_37472a14 ON public.extras_subscription USING btree (user_id);


--
-- Name: extras_tabl_weight_7c4bb6_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_tabl_weight_7c4bb6_idx ON public.extras_tableconfig USING btree (weight, name);


--
-- Name: extras_tableconfig_object_type_id_e43ad6ad; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_tableconfig_object_type_id_e43ad6ad ON public.extras_tableconfig USING btree (object_type_id);


--
-- Name: extras_tableconfig_user_id_0b525dff; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_tableconfig_user_id_0b525dff ON public.extras_tableconfig USING btree (user_id);


--
-- Name: extras_tag_name_9550b3d9_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_tag_name_9550b3d9_like ON public.extras_tag USING btree (name varchar_pattern_ops);


--
-- Name: extras_tag_object_types_contenttype_id_c1b220c3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_tag_object_types_contenttype_id_c1b220c3 ON public.extras_tag_object_types USING btree (contenttype_id);


--
-- Name: extras_tag_object_types_tag_id_2e1aab29; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_tag_object_types_tag_id_2e1aab29 ON public.extras_tag_object_types USING btree (tag_id);


--
-- Name: extras_tag_owner_id_ebb991ad; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_tag_owner_id_ebb991ad ON public.extras_tag USING btree (owner_id);


--
-- Name: extras_tag_slug_aaa5b7e9_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_tag_slug_aaa5b7e9_like ON public.extras_tag USING btree (slug varchar_pattern_ops);


--
-- Name: extras_tag_weight_d99f50_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_tag_weight_d99f50_idx ON public.extras_tag USING btree (weight, name);


--
-- Name: extras_tagg_content_717743_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_tagg_content_717743_idx ON public.extras_taggeditem USING btree (content_type_id, object_id);


--
-- Name: extras_taggeditem_content_type_id_ba5562ed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_taggeditem_content_type_id_ba5562ed ON public.extras_taggeditem USING btree (content_type_id);


--
-- Name: extras_taggeditem_object_id_31b2aa77; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_taggeditem_object_id_31b2aa77 ON public.extras_taggeditem USING btree (object_id);


--
-- Name: extras_taggeditem_tag_id_d48af7c7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_taggeditem_tag_id_d48af7c7 ON public.extras_taggeditem USING btree (tag_id);


--
-- Name: extras_webhook_name_82cf60b5_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_webhook_name_82cf60b5_like ON public.extras_webhook USING btree (name varchar_pattern_ops);


--
-- Name: extras_webhook_owner_id_bcf756a8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX extras_webhook_owner_id_bcf756a8 ON public.extras_webhook USING btree (owner_id);


--
-- Name: ipam_aggreg_prefix_89dd71_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_aggreg_prefix_89dd71_idx ON public.ipam_aggregate USING btree (prefix, id);


--
-- Name: ipam_aggregate_owner_id_fdaa939f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_aggregate_owner_id_fdaa939f ON public.ipam_aggregate USING btree (owner_id);


--
-- Name: ipam_aggregate_rir_id_ef7a27bd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_aggregate_rir_id_ef7a27bd ON public.ipam_aggregate USING btree (rir_id);


--
-- Name: ipam_aggregate_tenant_id_637dd1a1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_aggregate_tenant_id_637dd1a1 ON public.ipam_aggregate USING btree (tenant_id);


--
-- Name: ipam_asn_owner_id_2ab253b3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_asn_owner_id_2ab253b3 ON public.ipam_asn USING btree (owner_id);


--
-- Name: ipam_asn_rir_id_f5ad3cff; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_asn_rir_id_f5ad3cff ON public.ipam_asn USING btree (rir_id);


--
-- Name: ipam_asn_role_id_86d8acd4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_asn_role_id_86d8acd4 ON public.ipam_asn USING btree (role_id);


--
-- Name: ipam_asn_tenant_id_07e8188e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_asn_tenant_id_07e8188e ON public.ipam_asn USING btree (tenant_id);


--
-- Name: ipam_asnrange_name_c7585e73_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_asnrange_name_c7585e73_like ON public.ipam_asnrange USING btree (name varchar_pattern_ops);


--
-- Name: ipam_asnrange_owner_id_a943e984; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_asnrange_owner_id_a943e984 ON public.ipam_asnrange USING btree (owner_id);


--
-- Name: ipam_asnrange_rir_id_c9c31183; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_asnrange_rir_id_c9c31183 ON public.ipam_asnrange USING btree (rir_id);


--
-- Name: ipam_asnrange_slug_c8a7d8a1_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_asnrange_slug_c8a7d8a1_like ON public.ipam_asnrange USING btree (slug varchar_pattern_ops);


--
-- Name: ipam_asnrange_tenant_id_ed8f80b7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_asnrange_tenant_id_ed8f80b7 ON public.ipam_asnrange USING btree (tenant_id);


--
-- Name: ipam_fhrpgr_interfa_2acc3f_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_fhrpgr_interfa_2acc3f_idx ON public.ipam_fhrpgroupassignment USING btree (interface_type_id, interface_id);


--
-- Name: ipam_fhrpgr_priorit_b76335_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_fhrpgr_priorit_b76335_idx ON public.ipam_fhrpgroupassignment USING btree (priority DESC, id);


--
-- Name: ipam_fhrpgr_protoco_0445ae_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_fhrpgr_protoco_0445ae_idx ON public.ipam_fhrpgroup USING btree (protocol, group_id, id);


--
-- Name: ipam_fhrpgroup_owner_id_f5209119; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_fhrpgroup_owner_id_f5209119 ON public.ipam_fhrpgroup USING btree (owner_id);


--
-- Name: ipam_fhrpgroupassignment_group_id_19f15ca4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_fhrpgroupassignment_group_id_19f15ca4 ON public.ipam_fhrpgroupassignment USING btree (group_id);


--
-- Name: ipam_fhrpgroupassignment_interface_type_id_f3bcb487; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_fhrpgroupassignment_interface_type_id_f3bcb487 ON public.ipam_fhrpgroupassignment USING btree (interface_type_id);


--
-- Name: ipam_ipaddr_address_3ddeea_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_ipaddr_address_3ddeea_idx ON public.ipam_ipaddress USING btree (address, id);


--
-- Name: ipam_ipaddr_assigne_890ab8_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_ipaddr_assigne_890ab8_idx ON public.ipam_ipaddress USING btree (assigned_object_type_id, assigned_object_id);


--
-- Name: ipam_ipaddress_assigned_object_type_id_02354370; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_ipaddress_assigned_object_type_id_02354370 ON public.ipam_ipaddress USING btree (assigned_object_type_id);


--
-- Name: ipam_ipaddress_host; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_ipaddress_host ON public.ipam_ipaddress USING btree (((host(address))::inet), id);


--
-- Name: ipam_ipaddress_nat_inside_id_a45fb7c5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_ipaddress_nat_inside_id_a45fb7c5 ON public.ipam_ipaddress USING btree (nat_inside_id);


--
-- Name: ipam_ipaddress_owner_id_47736b63; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_ipaddress_owner_id_47736b63 ON public.ipam_ipaddress USING btree (owner_id);


--
-- Name: ipam_ipaddress_tenant_id_ac55acfd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_ipaddress_tenant_id_ac55acfd ON public.ipam_ipaddress USING btree (tenant_id);


--
-- Name: ipam_ipaddress_vrf_id_51fcc59b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_ipaddress_vrf_id_51fcc59b ON public.ipam_ipaddress USING btree (vrf_id);


--
-- Name: ipam_iprange_end_host; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_iprange_end_host ON public.ipam_iprange USING btree (((host(end_address))::inet));


--
-- Name: ipam_iprange_owner_id_b327afb7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_iprange_owner_id_b327afb7 ON public.ipam_iprange USING btree (owner_id);


--
-- Name: ipam_iprange_role_id_2782e864; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_iprange_role_id_2782e864 ON public.ipam_iprange USING btree (role_id);


--
-- Name: ipam_iprange_start_host; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_iprange_start_host ON public.ipam_iprange USING btree (((host(start_address))::inet));


--
-- Name: ipam_iprange_tenant_id_856027ea; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_iprange_tenant_id_856027ea ON public.ipam_iprange USING btree (tenant_id);


--
-- Name: ipam_iprange_vrf_id_613e9dd2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_iprange_vrf_id_613e9dd2 ON public.ipam_iprange USING btree (vrf_id);


--
-- Name: ipam_l2vpn_export_targets_l2vpn_id_8749bbe8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_l2vpn_export_targets_l2vpn_id_8749bbe8 ON public.vpn_l2vpn_export_targets USING btree (l2vpn_id);


--
-- Name: ipam_l2vpn_export_targets_routetarget_id_5ccb758b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_l2vpn_export_targets_routetarget_id_5ccb758b ON public.vpn_l2vpn_export_targets USING btree (routetarget_id);


--
-- Name: ipam_l2vpn_import_targets_l2vpn_id_731f5bb4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_l2vpn_import_targets_l2vpn_id_731f5bb4 ON public.vpn_l2vpn_import_targets USING btree (l2vpn_id);


--
-- Name: ipam_l2vpn_import_targets_routetarget_id_58a188b2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_l2vpn_import_targets_routetarget_id_58a188b2 ON public.vpn_l2vpn_import_targets USING btree (routetarget_id);


--
-- Name: ipam_prefix__location_id_f5925c42; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_prefix__location_id_f5925c42 ON public.ipam_prefix USING btree (_location_id);


--
-- Name: ipam_prefix__region_id_54aedc72; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_prefix__region_id_54aedc72 ON public.ipam_prefix USING btree (_region_id);


--
-- Name: ipam_prefix__site_group_id_8277120b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_prefix__site_group_id_8277120b ON public.ipam_prefix USING btree (_site_group_id);


--
-- Name: ipam_prefix__site_id_b479fb05; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_prefix__site_id_b479fb05 ON public.ipam_prefix USING btree (_site_id);


--
-- Name: ipam_prefix_gist_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_prefix_gist_idx ON public.ipam_prefix USING gist (prefix inet_ops);


--
-- Name: ipam_prefix_owner_id_12d43bc8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_prefix_owner_id_12d43bc8 ON public.ipam_prefix USING btree (owner_id);


--
-- Name: ipam_prefix_role_id_0a98d415; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_prefix_role_id_0a98d415 ON public.ipam_prefix USING btree (role_id);


--
-- Name: ipam_prefix_scope_t_fe84a6_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_prefix_scope_t_fe84a6_idx ON public.ipam_prefix USING btree (scope_type_id, scope_id);


--
-- Name: ipam_prefix_scope_type_id_413319e2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_prefix_scope_type_id_413319e2 ON public.ipam_prefix USING btree (scope_type_id);


--
-- Name: ipam_prefix_tenant_id_7ba1fcc4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_prefix_tenant_id_7ba1fcc4 ON public.ipam_prefix USING btree (tenant_id);


--
-- Name: ipam_prefix_vlan_id_1db91bff; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_prefix_vlan_id_1db91bff ON public.ipam_prefix USING btree (vlan_id);


--
-- Name: ipam_prefix_vrf_id_34f78ed0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_prefix_vrf_id_34f78ed0 ON public.ipam_prefix USING btree (vrf_id);


--
-- Name: ipam_rir_name_64a71982_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_rir_name_64a71982_like ON public.ipam_rir USING btree (name varchar_pattern_ops);


--
-- Name: ipam_rir_owner_id_172cc053; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_rir_owner_id_172cc053 ON public.ipam_rir USING btree (owner_id);


--
-- Name: ipam_rir_slug_ff1a369a_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_rir_slug_ff1a369a_like ON public.ipam_rir USING btree (slug varchar_pattern_ops);


--
-- Name: ipam_role_name_13784849_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_role_name_13784849_like ON public.ipam_role USING btree (name varchar_pattern_ops);


--
-- Name: ipam_role_owner_id_b42367ab; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_role_owner_id_b42367ab ON public.ipam_role USING btree (owner_id);


--
-- Name: ipam_role_slug_309ca14c_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_role_slug_309ca14c_like ON public.ipam_role USING btree (slug varchar_pattern_ops);


--
-- Name: ipam_role_weight_01396b_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_role_weight_01396b_idx ON public.ipam_role USING btree (weight, name);


--
-- Name: ipam_routetarget_name_212be79f_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_routetarget_name_212be79f_like ON public.ipam_routetarget USING btree (name varchar_pattern_ops);


--
-- Name: ipam_routetarget_owner_id_e968953a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_routetarget_owner_id_e968953a ON public.ipam_routetarget USING btree (owner_id);


--
-- Name: ipam_routetarget_tenant_id_5a0b35e8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_routetarget_tenant_id_5a0b35e8 ON public.ipam_routetarget USING btree (tenant_id);


--
-- Name: ipam_servic_name_b3260b_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_servic_name_b3260b_idx ON public.ipam_service USING btree (name, id);


--
-- Name: ipam_servic_parent__563d2b_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_servic_parent__563d2b_idx ON public.ipam_service USING btree (parent_object_type_id, parent_object_id);


--
-- Name: ipam_servic_port_ma_39e070_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_servic_port_ma_39e070_gin ON public.ipam_servicetemplate USING gin (port_mappings);


--
-- Name: ipam_servic_port_ma_a3d51d_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_servic_port_ma_a3d51d_gin ON public.ipam_service USING gin (port_mappings);


--
-- Name: ipam_service_ipaddresses_ipaddress_id_b4138c6d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_service_ipaddresses_ipaddress_id_b4138c6d ON public.ipam_service_ipaddresses USING btree (ipaddress_id);


--
-- Name: ipam_service_ipaddresses_service_id_ae26b9ab; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_service_ipaddresses_service_id_ae26b9ab ON public.ipam_service_ipaddresses USING btree (service_id);


--
-- Name: ipam_service_owner_id_ab1c827a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_service_owner_id_ab1c827a ON public.ipam_service USING btree (owner_id);


--
-- Name: ipam_service_parent_object_type_id_8e76bfb3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_service_parent_object_type_id_8e76bfb3 ON public.ipam_service USING btree (parent_object_type_id);


--
-- Name: ipam_servicetemplate_name_1a2f3410_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_servicetemplate_name_1a2f3410_like ON public.ipam_servicetemplate USING btree (name varchar_pattern_ops);


--
-- Name: ipam_servicetemplate_owner_id_bd152acb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_servicetemplate_owner_id_bd152acb ON public.ipam_servicetemplate USING btree (owner_id);


--
-- Name: ipam_vlan_group_id_88cbfa62; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vlan_group_id_88cbfa62 ON public.ipam_vlan USING btree (group_id);


--
-- Name: ipam_vlan_owner_id_ead15d2b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vlan_owner_id_ead15d2b ON public.ipam_vlan USING btree (owner_id);


--
-- Name: ipam_vlan_qinq_svlan_id_acbd7a5d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vlan_qinq_svlan_id_acbd7a5d ON public.ipam_vlan USING btree (qinq_svlan_id);


--
-- Name: ipam_vlan_role_id_f5015962; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vlan_role_id_f5015962 ON public.ipam_vlan USING btree (role_id);


--
-- Name: ipam_vlan_site_id_985573_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vlan_site_id_985573_idx ON public.ipam_vlan USING btree (site_id, group_id, vid, id);


--
-- Name: ipam_vlan_site_id_a59334e3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vlan_site_id_a59334e3 ON public.ipam_vlan USING btree (site_id);


--
-- Name: ipam_vlan_tenant_id_71a8290d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vlan_tenant_id_71a8290d ON public.ipam_vlan USING btree (tenant_id);


--
-- Name: ipam_vlangr_name_ffa83e_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vlangr_name_ffa83e_idx ON public.ipam_vlangroup USING btree (name, id);


--
-- Name: ipam_vlangr_scope_t_9da557_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vlangr_scope_t_9da557_idx ON public.ipam_vlangroup USING btree (scope_type_id, scope_id);


--
-- Name: ipam_vlangroup_owner_id_3a50b541; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vlangroup_owner_id_3a50b541 ON public.ipam_vlangroup USING btree (owner_id);


--
-- Name: ipam_vlangroup_scope_type_id_6606a755; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vlangroup_scope_type_id_6606a755 ON public.ipam_vlangroup USING btree (scope_type_id);


--
-- Name: ipam_vlangroup_slug_40abcf6b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vlangroup_slug_40abcf6b ON public.ipam_vlangroup USING btree (slug);


--
-- Name: ipam_vlangroup_slug_40abcf6b_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vlangroup_slug_40abcf6b_like ON public.ipam_vlangroup USING btree (slug varchar_pattern_ops);


--
-- Name: ipam_vlangroup_tenant_id_29197fca; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vlangroup_tenant_id_29197fca ON public.ipam_vlangroup USING btree (tenant_id);


--
-- Name: ipam_vlantranslationpolicy_name_17e0a007_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vlantranslationpolicy_name_17e0a007_like ON public.ipam_vlantranslationpolicy USING btree (name varchar_pattern_ops);


--
-- Name: ipam_vlantranslationpolicy_owner_id_f4e1cb82; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vlantranslationpolicy_owner_id_f4e1cb82 ON public.ipam_vlantranslationpolicy USING btree (owner_id);


--
-- Name: ipam_vlantranslationrule_policy_id_09157735; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vlantranslationrule_policy_id_09157735 ON public.ipam_vlantranslationrule USING btree (policy_id);


--
-- Name: ipam_vrf_export_targets_routetarget_id_8d9319f7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vrf_export_targets_routetarget_id_8d9319f7 ON public.ipam_vrf_export_targets USING btree (routetarget_id);


--
-- Name: ipam_vrf_export_targets_vrf_id_6f4875c4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vrf_export_targets_vrf_id_6f4875c4 ON public.ipam_vrf_export_targets USING btree (vrf_id);


--
-- Name: ipam_vrf_import_targets_routetarget_id_0e05b144; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vrf_import_targets_routetarget_id_0e05b144 ON public.ipam_vrf_import_targets USING btree (routetarget_id);


--
-- Name: ipam_vrf_import_targets_vrf_id_ed491b19; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vrf_import_targets_vrf_id_ed491b19 ON public.ipam_vrf_import_targets USING btree (vrf_id);


--
-- Name: ipam_vrf_name_ec911d_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vrf_name_ec911d_idx ON public.ipam_vrf USING btree (name, rd, id);


--
-- Name: ipam_vrf_owner_id_9b591781; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vrf_owner_id_9b591781 ON public.ipam_vrf USING btree (owner_id);


--
-- Name: ipam_vrf_rd_0ac1bde1_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vrf_rd_0ac1bde1_like ON public.ipam_vrf USING btree (rd varchar_pattern_ops);


--
-- Name: ipam_vrf_tenant_id_498b0051; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ipam_vrf_tenant_id_498b0051 ON public.ipam_vrf USING btree (tenant_id);


--
-- Name: social_auth_code_code_a2393167; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_auth_code_code_a2393167 ON public.social_auth_code USING btree (code);


--
-- Name: social_auth_code_code_a2393167_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_auth_code_code_a2393167_like ON public.social_auth_code USING btree (code varchar_pattern_ops);


--
-- Name: social_auth_code_timestamp_176b341f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_auth_code_timestamp_176b341f ON public.social_auth_code USING btree ("timestamp");


--
-- Name: social_auth_partial_timestamp_50f2119f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_auth_partial_timestamp_50f2119f ON public.social_auth_partial USING btree ("timestamp");


--
-- Name: social_auth_partial_token_3017fea3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_auth_partial_token_3017fea3 ON public.social_auth_partial USING btree (token);


--
-- Name: social_auth_partial_token_3017fea3_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_auth_partial_token_3017fea3_like ON public.social_auth_partial USING btree (token varchar_pattern_ops);


--
-- Name: social_auth_usersocialauth_uid_796e51dc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_auth_usersocialauth_uid_796e51dc ON public.social_auth_usersocialauth USING btree (uid);


--
-- Name: social_auth_usersocialauth_uid_796e51dc_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_auth_usersocialauth_uid_796e51dc_like ON public.social_auth_usersocialauth USING btree (uid varchar_pattern_ops);


--
-- Name: social_auth_usersocialauth_user_id_17d28448; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_auth_usersocialauth_user_id_17d28448 ON public.social_auth_usersocialauth USING btree (user_id);


--
-- Name: taggit_tag_name_58eb2ed9_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX taggit_tag_name_58eb2ed9_like ON public.taggit_tag USING btree (name varchar_pattern_ops);


--
-- Name: taggit_tag_slug_6be58b2c_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX taggit_tag_slug_6be58b2c_like ON public.taggit_tag USING btree (slug varchar_pattern_ops);


--
-- Name: taggit_tagg_content_8fc721_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX taggit_tagg_content_8fc721_idx ON public.taggit_taggeditem USING btree (content_type_id, object_id);


--
-- Name: taggit_taggeditem_content_type_id_9957a03c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX taggit_taggeditem_content_type_id_9957a03c ON public.taggit_taggeditem USING btree (content_type_id);


--
-- Name: taggit_taggeditem_object_id_e2d7d1df; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX taggit_taggeditem_object_id_e2d7d1df ON public.taggit_taggeditem USING btree (object_id);


--
-- Name: taggit_taggeditem_tag_id_f4f5b767; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX taggit_taggeditem_tag_id_f4f5b767 ON public.taggit_taggeditem USING btree (tag_id);


--
-- Name: tenancy_cg_sort_path_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_cg_sort_path_idx ON public.tenancy_contactgroup USING btree (sort_path);


--
-- Name: tenancy_con_contact_23011f_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_con_contact_23011f_idx ON public.tenancy_contactassignment USING btree (contact_id, priority, role_id, id);


--
-- Name: tenancy_con_name_c26153_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_con_name_c26153_idx ON public.tenancy_contact USING btree (name);


--
-- Name: tenancy_con_object__6f20f7_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_con_object__6f20f7_idx ON public.tenancy_contactassignment USING btree (object_type_id, object_id);


--
-- Name: tenancy_contact_groups_contact_id_84c9d84f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_contact_groups_contact_id_84c9d84f ON public.tenancy_contact_groups USING btree (contact_id);


--
-- Name: tenancy_contact_groups_contactgroup_id_5c8d6c5a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_contact_groups_contactgroup_id_5c8d6c5a ON public.tenancy_contact_groups USING btree (contactgroup_id);


--
-- Name: tenancy_contact_owner_id_9d93abff; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_contact_owner_id_9d93abff ON public.tenancy_contact USING btree (owner_id);


--
-- Name: tenancy_contactassignment_contact_id_5302baf0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_contactassignment_contact_id_5302baf0 ON public.tenancy_contactassignment USING btree (contact_id);


--
-- Name: tenancy_contactassignment_content_type_id_0c3f0c67; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_contactassignment_content_type_id_0c3f0c67 ON public.tenancy_contactassignment USING btree (object_type_id);


--
-- Name: tenancy_contactassignment_role_id_fc08bfb5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_contactassignment_role_id_fc08bfb5 ON public.tenancy_contactassignment USING btree (role_id);


--
-- Name: tenancy_contactgroup_owner_id_4bb044c2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_contactgroup_owner_id_4bb044c2 ON public.tenancy_contactgroup USING btree (owner_id);


--
-- Name: tenancy_contactgroup_parent_id_c087d69f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_contactgroup_parent_id_c087d69f ON public.tenancy_contactgroup USING btree (parent_id);


--
-- Name: tenancy_contactgroup_path_gist; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_contactgroup_path_gist ON public.tenancy_contactgroup USING gist (path);


--
-- Name: tenancy_contactgroup_slug_5b0f3e75; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_contactgroup_slug_5b0f3e75 ON public.tenancy_contactgroup USING btree (slug);


--
-- Name: tenancy_contactgroup_slug_5b0f3e75_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_contactgroup_slug_5b0f3e75_like ON public.tenancy_contactgroup USING btree (slug varchar_pattern_ops);


--
-- Name: tenancy_contactrole_name_44b01a1f_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_contactrole_name_44b01a1f_like ON public.tenancy_contactrole USING btree (name varchar_pattern_ops);


--
-- Name: tenancy_contactrole_owner_id_3677102e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_contactrole_owner_id_3677102e ON public.tenancy_contactrole USING btree (owner_id);


--
-- Name: tenancy_contactrole_slug_c5837d7d_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_contactrole_slug_c5837d7d_like ON public.tenancy_contactrole USING btree (slug varchar_pattern_ops);


--
-- Name: tenancy_tenant_group_id_7daef6f4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_tenant_group_id_7daef6f4 ON public.tenancy_tenant USING btree (group_id);


--
-- Name: tenancy_tenant_owner_id_02823f0b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_tenant_owner_id_02823f0b ON public.tenancy_tenant USING btree (owner_id);


--
-- Name: tenancy_tenant_slug_0716575e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_tenant_slug_0716575e ON public.tenancy_tenant USING btree (slug);


--
-- Name: tenancy_tenant_slug_0716575e_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_tenant_slug_0716575e_like ON public.tenancy_tenant USING btree (slug varchar_pattern_ops);


--
-- Name: tenancy_tenantgroup_name_53363199_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_tenantgroup_name_53363199_like ON public.tenancy_tenantgroup USING btree (name varchar_pattern_ops);


--
-- Name: tenancy_tenantgroup_owner_id_a4f64bbd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_tenantgroup_owner_id_a4f64bbd ON public.tenancy_tenantgroup USING btree (owner_id);


--
-- Name: tenancy_tenantgroup_parent_id_2542fc18; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_tenantgroup_parent_id_2542fc18 ON public.tenancy_tenantgroup USING btree (parent_id);


--
-- Name: tenancy_tenantgroup_path_gist; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_tenantgroup_path_gist ON public.tenancy_tenantgroup USING gist (path);


--
-- Name: tenancy_tenantgroup_slug_e2af1cb6_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_tenantgroup_slug_e2af1cb6_like ON public.tenancy_tenantgroup USING btree (slug varchar_pattern_ops);


--
-- Name: tenancy_tg_sort_path_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenancy_tg_sort_path_idx ON public.tenancy_tenantgroup USING btree (sort_path);


--
-- Name: thumbnail_kvstore_key_3f850178_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thumbnail_kvstore_key_3f850178_like ON public.thumbnail_kvstore USING btree (key varchar_pattern_ops);


--
-- Name: unique_active_config_revision; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_active_config_revision ON public.core_configrevision USING btree (active) WHERE active;


--
-- Name: users_group_name_5f613b12_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_group_name_5f613b12_like ON public.users_group USING btree (name varchar_pattern_ops);


--
-- Name: users_group_object_permissions_group_id_90dd183a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_group_object_permissions_group_id_90dd183a ON public.users_group_object_permissions USING btree (group_id);


--
-- Name: users_group_object_permissions_objectpermission_id_dd489dc4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_group_object_permissions_objectpermission_id_dd489dc4 ON public.users_group_object_permissions USING btree (objectpermission_id);


--
-- Name: users_group_permissions_group_id_d48652c3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_group_permissions_group_id_d48652c3 ON public.users_group_permissions USING btree (group_id);


--
-- Name: users_group_permissions_permission_id_d8b9c223; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_group_permissions_permission_id_d8b9c223 ON public.users_group_permissions USING btree (permission_id);


--
-- Name: users_objec_name_ca707b_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_objec_name_ca707b_idx ON public.users_objectpermission USING btree (name);


--
-- Name: users_objectpermission_obj_objectpermission_id_38c7d8f5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_objectpermission_obj_objectpermission_id_38c7d8f5 ON public.users_objectpermission_object_types USING btree (objectpermission_id);


--
-- Name: users_objectpermission_object_types_contenttype_id_594b1cc7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_objectpermission_object_types_contenttype_id_594b1cc7 ON public.users_objectpermission_object_types USING btree (contenttype_id);


--
-- Name: users_owner_group_id_197ecf75; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_owner_group_id_197ecf75 ON public.users_owner USING btree (group_id);


--
-- Name: users_owner_name_b9fd4685_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_owner_name_b9fd4685_like ON public.users_owner USING btree (name varchar_pattern_ops);


--
-- Name: users_owner_user_groups_group_id_7f7a78f5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_owner_user_groups_group_id_7f7a78f5 ON public.users_owner_user_groups USING btree (group_id);


--
-- Name: users_owner_user_groups_owner_id_1d847a5b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_owner_user_groups_owner_id_1d847a5b ON public.users_owner_user_groups USING btree (owner_id);


--
-- Name: users_owner_users_owner_id_efc9b423; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_owner_users_owner_id_efc9b423 ON public.users_owner_users USING btree (owner_id);


--
-- Name: users_owner_users_user_id_2b2e2446; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_owner_users_user_id_2b2e2446 ON public.users_owner_users USING btree (user_id);


--
-- Name: users_ownergroup_name_903b8fd1_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_ownergroup_name_903b8fd1_like ON public.users_ownergroup USING btree (name varchar_pattern_ops);


--
-- Name: users_token_created_1467b4_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_token_created_1467b4_idx ON public.users_token USING btree (created DESC);


--
-- Name: users_token_key_820deccd_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_token_key_820deccd_like ON public.users_token USING btree (key varchar_pattern_ops);


--
-- Name: users_token_plaintext_46c6f315_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_token_plaintext_46c6f315_like ON public.users_token USING btree (plaintext varchar_pattern_ops);


--
-- Name: users_token_user_id_af964690; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_token_user_id_af964690 ON public.users_token USING btree (user_id);


--
-- Name: users_user_object_permissions_objectpermission_id_29b431b4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_user_object_permissions_objectpermission_id_29b431b4 ON public.users_user_object_permissions USING btree (objectpermission_id);


--
-- Name: users_user_object_permissions_user_id_9d647aac; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_user_object_permissions_user_id_9d647aac ON public.users_user_object_permissions USING btree (user_id);


--
-- Name: users_user_username_06e46fe6_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_user_username_06e46fe6_like ON public.users_user USING btree (username varchar_pattern_ops);


--
-- Name: virtualizat_name_16033e_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualizat_name_16033e_idx ON public.virtualization_virtualmachine USING btree (name, id);


--
-- Name: virtualizat_name_6cff11_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualizat_name_6cff11_idx ON public.virtualization_virtualmachinetype USING btree (name);


--
-- Name: virtualizat_scope_t_fb3b6e_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualizat_scope_t_fb3b6e_idx ON public.virtualization_cluster USING btree (scope_type_id, scope_id);


--
-- Name: virtualization_cluster__location_id_f553e386; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_cluster__location_id_f553e386 ON public.virtualization_cluster USING btree (_location_id);


--
-- Name: virtualization_cluster__region_id_9244325e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_cluster__region_id_9244325e ON public.virtualization_cluster USING btree (_region_id);


--
-- Name: virtualization_cluster__site_group_id_7d9bff8f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_cluster__site_group_id_7d9bff8f ON public.virtualization_cluster USING btree (_site_group_id);


--
-- Name: virtualization_cluster__site_id_883df848; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_cluster__site_id_883df848 ON public.virtualization_cluster USING btree (_site_id);


--
-- Name: virtualization_cluster_group_id_de379828; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_cluster_group_id_de379828 ON public.virtualization_cluster USING btree (group_id);


--
-- Name: virtualization_cluster_owner_id_2ea44dea; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_cluster_owner_id_2ea44dea ON public.virtualization_cluster USING btree (owner_id);


--
-- Name: virtualization_cluster_scope_type_id_c49d797a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_cluster_scope_type_id_c49d797a ON public.virtualization_cluster USING btree (scope_type_id);


--
-- Name: virtualization_cluster_tenant_id_bc2868d0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_cluster_tenant_id_bc2868d0 ON public.virtualization_cluster USING btree (tenant_id);


--
-- Name: virtualization_cluster_type_id_4efafb0a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_cluster_type_id_4efafb0a ON public.virtualization_cluster USING btree (type_id);


--
-- Name: virtualization_clustergroup_name_4fcd26b4_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_clustergroup_name_4fcd26b4_like ON public.virtualization_clustergroup USING btree (name varchar_pattern_ops);


--
-- Name: virtualization_clustergroup_owner_id_a865db22; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_clustergroup_owner_id_a865db22 ON public.virtualization_clustergroup USING btree (owner_id);


--
-- Name: virtualization_clustergroup_slug_57ca1d23_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_clustergroup_slug_57ca1d23_like ON public.virtualization_clustergroup USING btree (slug varchar_pattern_ops);


--
-- Name: virtualization_clustertype_name_ea854d3d_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_clustertype_name_ea854d3d_like ON public.virtualization_clustertype USING btree (name varchar_pattern_ops);


--
-- Name: virtualization_clustertype_owner_id_7284f9e4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_clustertype_owner_id_7284f9e4 ON public.virtualization_clustertype USING btree (owner_id);


--
-- Name: virtualization_clustertype_slug_8ee4d0e0_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_clustertype_slug_8ee4d0e0_like ON public.virtualization_clustertype USING btree (slug varchar_pattern_ops);


--
-- Name: virtualization_virtualdisk_owner_id_2e14487d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_virtualdisk_owner_id_2e14487d ON public.virtualization_virtualdisk USING btree (owner_id);


--
-- Name: virtualization_virtualdisk_virtual_machine_id_7bc8b6c2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_virtualdisk_virtual_machine_id_7bc8b6c2 ON public.virtualization_virtualdisk USING btree (virtual_machine_id);


--
-- Name: virtualization_virtualmachine_cluster_id_6c9f9047; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_virtualmachine_cluster_id_6c9f9047 ON public.virtualization_virtualmachine USING btree (cluster_id);


--
-- Name: virtualization_virtualmachine_config_template_id_d7fc7874; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_virtualmachine_config_template_id_d7fc7874 ON public.virtualization_virtualmachine USING btree (config_template_id);


--
-- Name: virtualization_virtualmachine_device_id_5a49ed18; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_virtualmachine_device_id_5a49ed18 ON public.virtualization_virtualmachine USING btree (device_id);


--
-- Name: virtualization_virtualmachine_owner_id_f6593561; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_virtualmachine_owner_id_f6593561 ON public.virtualization_virtualmachine USING btree (owner_id);


--
-- Name: virtualization_virtualmachine_platform_id_a6c5ccb2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_virtualmachine_platform_id_a6c5ccb2 ON public.virtualization_virtualmachine USING btree (platform_id);


--
-- Name: virtualization_virtualmachine_role_id_0cc898f9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_virtualmachine_role_id_0cc898f9 ON public.virtualization_virtualmachine USING btree (role_id);


--
-- Name: virtualization_virtualmachine_site_id_54475a27; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_virtualmachine_site_id_54475a27 ON public.virtualization_virtualmachine USING btree (site_id);


--
-- Name: virtualization_virtualmachine_tenant_id_d00d1d77; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_virtualmachine_tenant_id_d00d1d77 ON public.virtualization_virtualmachine USING btree (tenant_id);


--
-- Name: virtualization_virtualmachine_unique_name_cluster_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX virtualization_virtualmachine_unique_name_cluster_tenant ON public.virtualization_virtualmachine USING btree (lower((name)::text), cluster_id, tenant_id) NULLS NOT DISTINCT WHERE (cluster_id IS NOT NULL);


--
-- Name: virtualization_virtualmachine_unique_name_device_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX virtualization_virtualmachine_unique_name_device_tenant ON public.virtualization_virtualmachine USING btree (lower((name)::text), device_id, tenant_id) NULLS NOT DISTINCT WHERE ((cluster_id IS NULL) AND (device_id IS NOT NULL));


--
-- Name: virtualization_virtualmachine_virtual_machine_type_id_bdf5b257; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_virtualmachine_virtual_machine_type_id_bdf5b257 ON public.virtualization_virtualmachine USING btree (virtual_machine_type_id);


--
-- Name: virtualization_virtualmachinetype_default_platform_id_6f32d2ac; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_virtualmachinetype_default_platform_id_6f32d2ac ON public.virtualization_virtualmachinetype USING btree (default_platform_id);


--
-- Name: virtualization_virtualmachinetype_owner_id_97b13507; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_virtualmachinetype_owner_id_97b13507 ON public.virtualization_virtualmachinetype USING btree (owner_id);


--
-- Name: virtualization_virtualmachinetype_slug_b0eb0a3f_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_virtualmachinetype_slug_b0eb0a3f_like ON public.virtualization_virtualmachinetype USING btree (slug varchar_pattern_ops);


--
-- Name: virtualization_virtualmachinetype_unique_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX virtualization_virtualmachinetype_unique_name ON public.virtualization_virtualmachinetype USING btree (lower((name)::text));


--
-- Name: virtualization_vm_cc_null; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_vm_cc_null ON public.virtualization_virtualmachine USING btree (id) WHERE (_config_context_data IS NULL);


--
-- Name: virtualization_vminterface_bridge_id_7462b91e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_vminterface_bridge_id_7462b91e ON public.virtualization_vminterface USING btree (bridge_id);


--
-- Name: virtualization_vminterface_owner_id_486754ee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_vminterface_owner_id_486754ee ON public.virtualization_vminterface USING btree (owner_id);


--
-- Name: virtualization_vminterface_parent_id_f86958e1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_vminterface_parent_id_f86958e1 ON public.virtualization_vminterface USING btree (parent_id);


--
-- Name: virtualization_vminterface_qinq_svlan_id_afacb024; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_vminterface_qinq_svlan_id_afacb024 ON public.virtualization_vminterface USING btree (qinq_svlan_id);


--
-- Name: virtualization_vminterface_tagged_vlans_vlan_id_4e77411e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_vminterface_tagged_vlans_vlan_id_4e77411e ON public.virtualization_vminterface_tagged_vlans USING btree (vlan_id);


--
-- Name: virtualization_vminterface_tagged_vlans_vminterface_id_904b12de; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_vminterface_tagged_vlans_vminterface_id_904b12de ON public.virtualization_vminterface_tagged_vlans USING btree (vminterface_id);


--
-- Name: virtualization_vminterface_untagged_vlan_id_aea4fc69; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_vminterface_untagged_vlan_id_aea4fc69 ON public.virtualization_vminterface USING btree (untagged_vlan_id);


--
-- Name: virtualization_vminterface_virtual_machine_id_e9f89829; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_vminterface_virtual_machine_id_e9f89829 ON public.virtualization_vminterface USING btree (virtual_machine_id);


--
-- Name: virtualization_vminterface_vlan_translation_policy_id_938e6637; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_vminterface_vlan_translation_policy_id_938e6637 ON public.virtualization_vminterface USING btree (vlan_translation_policy_id);


--
-- Name: virtualization_vminterface_vrf_id_4b570a8c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX virtualization_vminterface_vrf_id_4b570a8c ON public.virtualization_vminterface USING btree (vrf_id);


--
-- Name: vpn_ikepolicy_name_5124aa3b_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_ikepolicy_name_5124aa3b_like ON public.vpn_ikepolicy USING btree (name varchar_pattern_ops);


--
-- Name: vpn_ikepolicy_owner_id_dbcaf1bd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_ikepolicy_owner_id_dbcaf1bd ON public.vpn_ikepolicy USING btree (owner_id);


--
-- Name: vpn_ikepolicy_proposals_ikepolicy_id_1e1deaab; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_ikepolicy_proposals_ikepolicy_id_1e1deaab ON public.vpn_ikepolicy_proposals USING btree (ikepolicy_id);


--
-- Name: vpn_ikepolicy_proposals_ikeproposal_id_a9ead252; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_ikepolicy_proposals_ikeproposal_id_a9ead252 ON public.vpn_ikepolicy_proposals USING btree (ikeproposal_id);


--
-- Name: vpn_ikeproposal_name_254623b7_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_ikeproposal_name_254623b7_like ON public.vpn_ikeproposal USING btree (name varchar_pattern_ops);


--
-- Name: vpn_ikeproposal_owner_id_018a3e69; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_ikeproposal_owner_id_018a3e69 ON public.vpn_ikeproposal USING btree (owner_id);


--
-- Name: vpn_ipsecpolicy_name_cf28a1aa_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_ipsecpolicy_name_cf28a1aa_like ON public.vpn_ipsecpolicy USING btree (name varchar_pattern_ops);


--
-- Name: vpn_ipsecpolicy_owner_id_e976d198; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_ipsecpolicy_owner_id_e976d198 ON public.vpn_ipsecpolicy USING btree (owner_id);


--
-- Name: vpn_ipsecpolicy_proposals_ipsecpolicy_id_0e7771a1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_ipsecpolicy_proposals_ipsecpolicy_id_0e7771a1 ON public.vpn_ipsecpolicy_proposals USING btree (ipsecpolicy_id);


--
-- Name: vpn_ipsecpolicy_proposals_ipsecproposal_id_685fe509; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_ipsecpolicy_proposals_ipsecproposal_id_685fe509 ON public.vpn_ipsecpolicy_proposals USING btree (ipsecproposal_id);


--
-- Name: vpn_ipsecprofile_ike_policy_id_4eff5fb9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_ipsecprofile_ike_policy_id_4eff5fb9 ON public.vpn_ipsecprofile USING btree (ike_policy_id);


--
-- Name: vpn_ipsecprofile_ipsec_policy_id_e06f2323; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_ipsecprofile_ipsec_policy_id_e06f2323 ON public.vpn_ipsecprofile USING btree (ipsec_policy_id);


--
-- Name: vpn_ipsecprofile_name_3ac63c72_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_ipsecprofile_name_3ac63c72_like ON public.vpn_ipsecprofile USING btree (name varchar_pattern_ops);


--
-- Name: vpn_ipsecprofile_owner_id_d7ebc4a0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_ipsecprofile_owner_id_d7ebc4a0 ON public.vpn_ipsecprofile USING btree (owner_id);


--
-- Name: vpn_ipsecproposal_name_2fb98e2b_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_ipsecproposal_name_2fb98e2b_like ON public.vpn_ipsecproposal USING btree (name varchar_pattern_ops);


--
-- Name: vpn_ipsecproposal_owner_id_fdb3b755; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_ipsecproposal_owner_id_fdb3b755 ON public.vpn_ipsecproposal USING btree (owner_id);


--
-- Name: vpn_l2vpn_name_8824eda5_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_l2vpn_name_8824eda5_like ON public.vpn_l2vpn USING btree (name varchar_pattern_ops);


--
-- Name: vpn_l2vpn_owner_id_894bd11d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_l2vpn_owner_id_894bd11d ON public.vpn_l2vpn USING btree (owner_id);


--
-- Name: vpn_l2vpn_slug_76b5a174_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_l2vpn_slug_76b5a174_like ON public.vpn_l2vpn USING btree (slug varchar_pattern_ops);


--
-- Name: vpn_l2vpn_tenant_id_57ec8f92; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_l2vpn_tenant_id_57ec8f92 ON public.vpn_l2vpn USING btree (tenant_id);


--
-- Name: vpn_l2vpntermination_assigned_object_type_id_f063b865; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_l2vpntermination_assigned_object_type_id_f063b865 ON public.vpn_l2vpntermination USING btree (assigned_object_type_id);


--
-- Name: vpn_l2vpntermination_l2vpn_id_f5367bbe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_l2vpntermination_l2vpn_id_f5367bbe ON public.vpn_l2vpntermination USING btree (l2vpn_id);


--
-- Name: vpn_tunnel_group_id_56b1e7f7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_tunnel_group_id_56b1e7f7 ON public.vpn_tunnel USING btree (group_id);


--
-- Name: vpn_tunnel_ipsec_profile_id_fd0361c5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_tunnel_ipsec_profile_id_fd0361c5 ON public.vpn_tunnel USING btree (ipsec_profile_id);


--
-- Name: vpn_tunnel_name_f060beab_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_tunnel_name_f060beab_like ON public.vpn_tunnel USING btree (name varchar_pattern_ops);


--
-- Name: vpn_tunnel_owner_id_d04ee1fb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_tunnel_owner_id_d04ee1fb ON public.vpn_tunnel USING btree (owner_id);


--
-- Name: vpn_tunnel_tenant_id_f3df2ab3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_tunnel_tenant_id_f3df2ab3 ON public.vpn_tunnel USING btree (tenant_id);


--
-- Name: vpn_tunnelgroup_name_9f6ebf92_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_tunnelgroup_name_9f6ebf92_like ON public.vpn_tunnelgroup USING btree (name varchar_pattern_ops);


--
-- Name: vpn_tunnelgroup_owner_id_64609bfe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_tunnelgroup_owner_id_64609bfe ON public.vpn_tunnelgroup USING btree (owner_id);


--
-- Name: vpn_tunnelgroup_slug_9e614d62_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_tunnelgroup_slug_9e614d62_like ON public.vpn_tunnelgroup USING btree (slug varchar_pattern_ops);


--
-- Name: vpn_tunnelt_tunnel__f542d3_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_tunnelt_tunnel__f542d3_idx ON public.vpn_tunneltermination USING btree (tunnel_id, role, id);


--
-- Name: vpn_tunneltermination_outside_ip_id_2c6f3a7c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_tunneltermination_outside_ip_id_2c6f3a7c ON public.vpn_tunneltermination USING btree (outside_ip_id);


--
-- Name: vpn_tunneltermination_termination_type_id_e546f7a1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_tunneltermination_termination_type_id_e546f7a1 ON public.vpn_tunneltermination USING btree (termination_type_id);


--
-- Name: vpn_tunneltermination_tunnel_id_962efa25; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vpn_tunneltermination_tunnel_id_962efa25 ON public.vpn_tunneltermination USING btree (tunnel_id);


--
-- Name: wireless_lan_grp_path_gist; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_lan_grp_path_gist ON public.wireless_wirelesslangroup USING gist (path);


--
-- Name: wireless_lan_grp_sort_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_lan_grp_sort_idx ON public.wireless_wirelesslangroup USING btree (sort_path);


--
-- Name: wireless_wi_scope_t_6740a3_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wi_scope_t_6740a3_idx ON public.wireless_wirelesslan USING btree (scope_type_id, scope_id);


--
-- Name: wireless_wi_ssid_64a9ce_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wi_ssid_64a9ce_idx ON public.wireless_wirelesslan USING btree (ssid, id);


--
-- Name: wireless_wirelesslan__location_id_c742912f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslan__location_id_c742912f ON public.wireless_wirelesslan USING btree (_location_id);


--
-- Name: wireless_wirelesslan__region_id_fd2a93ee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslan__region_id_fd2a93ee ON public.wireless_wirelesslan USING btree (_region_id);


--
-- Name: wireless_wirelesslan__site_group_id_d61285cc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslan__site_group_id_d61285cc ON public.wireless_wirelesslan USING btree (_site_group_id);


--
-- Name: wireless_wirelesslan__site_id_5dce5f6f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslan__site_id_5dce5f6f ON public.wireless_wirelesslan USING btree (_site_id);


--
-- Name: wireless_wirelesslan_group_id_d9e3d67f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslan_group_id_d9e3d67f ON public.wireless_wirelesslan USING btree (group_id);


--
-- Name: wireless_wirelesslan_owner_id_9ea24eeb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslan_owner_id_9ea24eeb ON public.wireless_wirelesslan USING btree (owner_id);


--
-- Name: wireless_wirelesslan_scope_type_id_c3e37d35; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslan_scope_type_id_c3e37d35 ON public.wireless_wirelesslan USING btree (scope_type_id);


--
-- Name: wireless_wirelesslan_tenant_id_5dfee941; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslan_tenant_id_5dfee941 ON public.wireless_wirelesslan USING btree (tenant_id);


--
-- Name: wireless_wirelesslan_vlan_id_d7fa6ccc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslan_vlan_id_d7fa6ccc ON public.wireless_wirelesslan USING btree (vlan_id);


--
-- Name: wireless_wirelesslangroup_name_2ffd60c8_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslangroup_name_2ffd60c8_like ON public.wireless_wirelesslangroup USING btree (name varchar_pattern_ops);


--
-- Name: wireless_wirelesslangroup_owner_id_0ba5f844; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslangroup_owner_id_0ba5f844 ON public.wireless_wirelesslangroup USING btree (owner_id);


--
-- Name: wireless_wirelesslangroup_parent_id_37ca8b87; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslangroup_parent_id_37ca8b87 ON public.wireless_wirelesslangroup USING btree (parent_id);


--
-- Name: wireless_wirelesslangroup_slug_f5d59831_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslangroup_slug_f5d59831_like ON public.wireless_wirelesslangroup USING btree (slug varchar_pattern_ops);


--
-- Name: wireless_wirelesslink__interface_a_device_id_6c8e042e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslink__interface_a_device_id_6c8e042e ON public.wireless_wirelesslink USING btree (_interface_a_device_id);


--
-- Name: wireless_wirelesslink__interface_b_device_id_43d5101a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslink__interface_b_device_id_43d5101a ON public.wireless_wirelesslink USING btree (_interface_b_device_id);


--
-- Name: wireless_wirelesslink_interface_a_id_bc9e37fd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslink_interface_a_id_bc9e37fd ON public.wireless_wirelesslink USING btree (interface_a_id);


--
-- Name: wireless_wirelesslink_interface_b_id_a82fb2ee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslink_interface_b_id_a82fb2ee ON public.wireless_wirelesslink USING btree (interface_b_id);


--
-- Name: wireless_wirelesslink_owner_id_103f9be1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslink_owner_id_103f9be1 ON public.wireless_wirelesslink USING btree (owner_id);


--
-- Name: wireless_wirelesslink_tenant_id_4c0638ee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wireless_wirelesslink_tenant_id_4c0638ee ON public.wireless_wirelesslink USING btree (tenant_id);


--
-- Name: dcim_location circuits_circuittermination_denorm_from_dcim_location; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER circuits_circuittermination_denorm_from_dcim_location AFTER UPDATE OF site_id ON public.dcim_location FOR EACH ROW WHEN ((old.site_id IS DISTINCT FROM new.site_id)) EXECUTE FUNCTION public.circuits_circuittermination_denorm_from_dcim_location_fn();


--
-- Name: dcim_site circuits_circuittermination_denorm_from_dcim_site; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER circuits_circuittermination_denorm_from_dcim_site AFTER UPDATE OF region_id, group_id ON public.dcim_site FOR EACH ROW WHEN (((old.region_id IS DISTINCT FROM new.region_id) OR (old.group_id IS DISTINCT FROM new.group_id))) EXECUTE FUNCTION public.circuits_circuittermination_denorm_from_dcim_site_fn();


--
-- Name: dcim_device dcim_cabletermination_denorm_from_dcim_device; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_cabletermination_denorm_from_dcim_device AFTER UPDATE OF rack_id, location_id, site_id ON public.dcim_device FOR EACH ROW WHEN (((old.rack_id IS DISTINCT FROM new.rack_id) OR (old.location_id IS DISTINCT FROM new.location_id) OR (old.site_id IS DISTINCT FROM new.site_id))) EXECUTE FUNCTION public.dcim_cabletermination_denorm_from_dcim_device_fn();


--
-- Name: dcim_location dcim_cabletermination_denorm_from_dcim_location; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_cabletermination_denorm_from_dcim_location AFTER UPDATE OF site_id ON public.dcim_location FOR EACH ROW WHEN ((old.site_id IS DISTINCT FROM new.site_id)) EXECUTE FUNCTION public.dcim_cabletermination_denorm_from_dcim_location_fn();


--
-- Name: dcim_rack dcim_cabletermination_denorm_from_dcim_rack; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_cabletermination_denorm_from_dcim_rack AFTER UPDATE OF location_id, site_id ON public.dcim_rack FOR EACH ROW WHEN (((old.location_id IS DISTINCT FROM new.location_id) OR (old.site_id IS DISTINCT FROM new.site_id))) EXECUTE FUNCTION public.dcim_cabletermination_denorm_from_dcim_rack_fn();


--
-- Name: dcim_device dcim_consoleport_denorm_from_dcim_device; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_consoleport_denorm_from_dcim_device AFTER UPDATE OF site_id, location_id, rack_id ON public.dcim_device FOR EACH ROW WHEN (((old.site_id IS DISTINCT FROM new.site_id) OR (old.location_id IS DISTINCT FROM new.location_id) OR (old.rack_id IS DISTINCT FROM new.rack_id))) EXECUTE FUNCTION public.dcim_consoleport_denorm_from_dcim_device_fn();


--
-- Name: dcim_device dcim_consoleserverport_denorm_from_dcim_device; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_consoleserverport_denorm_from_dcim_device AFTER UPDATE OF site_id, location_id, rack_id ON public.dcim_device FOR EACH ROW WHEN (((old.site_id IS DISTINCT FROM new.site_id) OR (old.location_id IS DISTINCT FROM new.location_id) OR (old.rack_id IS DISTINCT FROM new.rack_id))) EXECUTE FUNCTION public.dcim_consoleserverport_denorm_from_dcim_device_fn();


--
-- Name: dcim_device dcim_coolingintake_denorm_from_dcim_device; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_coolingintake_denorm_from_dcim_device AFTER UPDATE OF site_id, location_id, rack_id ON public.dcim_device FOR EACH ROW WHEN (((old.site_id IS DISTINCT FROM new.site_id) OR (old.location_id IS DISTINCT FROM new.location_id) OR (old.rack_id IS DISTINCT FROM new.rack_id))) EXECUTE FUNCTION public.dcim_coolingintake_denorm_from_dcim_device_fn();


--
-- Name: dcim_device dcim_coolingoutflow_denorm_from_dcim_device; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_coolingoutflow_denorm_from_dcim_device AFTER UPDATE OF site_id, location_id, rack_id ON public.dcim_device FOR EACH ROW WHEN (((old.site_id IS DISTINCT FROM new.site_id) OR (old.location_id IS DISTINCT FROM new.location_id) OR (old.rack_id IS DISTINCT FROM new.rack_id))) EXECUTE FUNCTION public.dcim_coolingoutflow_denorm_from_dcim_device_fn();


--
-- Name: dcim_device dcim_devicebay_denorm_from_dcim_device; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_devicebay_denorm_from_dcim_device AFTER UPDATE OF site_id, location_id, rack_id ON public.dcim_device FOR EACH ROW WHEN (((old.site_id IS DISTINCT FROM new.site_id) OR (old.location_id IS DISTINCT FROM new.location_id) OR (old.rack_id IS DISTINCT FROM new.rack_id))) EXECUTE FUNCTION public.dcim_devicebay_denorm_from_dcim_device_fn();


--
-- Name: dcim_devicerole dcim_devicerole_ltree_cascade_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_devicerole_ltree_cascade_path AFTER UPDATE OF parent_id, name ON public.dcim_devicerole FOR EACH ROW WHEN ((((old.path)::text IS DISTINCT FROM (new.path)::text) OR (old.sort_path IS DISTINCT FROM new.sort_path))) EXECUTE FUNCTION public.dcim_devicerole_ltree_cascade_path_fn();


--
-- Name: dcim_devicerole dcim_devicerole_ltree_compute_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_devicerole_ltree_compute_path BEFORE INSERT OR UPDATE OF parent_id, name ON public.dcim_devicerole FOR EACH ROW EXECUTE FUNCTION public.dcim_devicerole_ltree_compute_path_fn();


--
-- Name: dcim_device dcim_frontport_denorm_from_dcim_device; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_frontport_denorm_from_dcim_device AFTER UPDATE OF site_id, location_id, rack_id ON public.dcim_device FOR EACH ROW WHEN (((old.site_id IS DISTINCT FROM new.site_id) OR (old.location_id IS DISTINCT FROM new.location_id) OR (old.rack_id IS DISTINCT FROM new.rack_id))) EXECUTE FUNCTION public.dcim_frontport_denorm_from_dcim_device_fn();


--
-- Name: dcim_device dcim_interface_denorm_from_dcim_device; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_interface_denorm_from_dcim_device AFTER UPDATE OF site_id, location_id, rack_id ON public.dcim_device FOR EACH ROW WHEN (((old.site_id IS DISTINCT FROM new.site_id) OR (old.location_id IS DISTINCT FROM new.location_id) OR (old.rack_id IS DISTINCT FROM new.rack_id))) EXECUTE FUNCTION public.dcim_interface_denorm_from_dcim_device_fn();


--
-- Name: dcim_device dcim_inventoryitem_denorm_from_dcim_device; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_inventoryitem_denorm_from_dcim_device AFTER UPDATE OF site_id, location_id, rack_id ON public.dcim_device FOR EACH ROW WHEN (((old.site_id IS DISTINCT FROM new.site_id) OR (old.location_id IS DISTINCT FROM new.location_id) OR (old.rack_id IS DISTINCT FROM new.rack_id))) EXECUTE FUNCTION public.dcim_inventoryitem_denorm_from_dcim_device_fn();


--
-- Name: dcim_inventoryitem dcim_inventoryitem_ltree_cascade_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_inventoryitem_ltree_cascade_path AFTER UPDATE OF parent_id ON public.dcim_inventoryitem FOR EACH ROW WHEN (((old.path)::text IS DISTINCT FROM (new.path)::text)) EXECUTE FUNCTION public.dcim_inventoryitem_ltree_cascade_path_fn();


--
-- Name: dcim_inventoryitem dcim_inventoryitem_ltree_compute_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_inventoryitem_ltree_compute_path BEFORE INSERT OR UPDATE OF parent_id ON public.dcim_inventoryitem FOR EACH ROW EXECUTE FUNCTION public.dcim_inventoryitem_ltree_compute_path_fn();


--
-- Name: dcim_inventoryitemtemplate dcim_inventoryitemtemplate_ltree_cascade_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_inventoryitemtemplate_ltree_cascade_path AFTER UPDATE OF parent_id ON public.dcim_inventoryitemtemplate FOR EACH ROW WHEN (((old.path)::text IS DISTINCT FROM (new.path)::text)) EXECUTE FUNCTION public.dcim_inventoryitemtemplate_ltree_cascade_path_fn();


--
-- Name: dcim_inventoryitemtemplate dcim_inventoryitemtemplate_ltree_compute_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_inventoryitemtemplate_ltree_compute_path BEFORE INSERT OR UPDATE OF parent_id ON public.dcim_inventoryitemtemplate FOR EACH ROW EXECUTE FUNCTION public.dcim_inventoryitemtemplate_ltree_compute_path_fn();


--
-- Name: dcim_location dcim_location_ltree_cascade_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_location_ltree_cascade_path AFTER UPDATE OF parent_id, name ON public.dcim_location FOR EACH ROW WHEN ((((old.path)::text IS DISTINCT FROM (new.path)::text) OR (old.sort_path IS DISTINCT FROM new.sort_path))) EXECUTE FUNCTION public.dcim_location_ltree_cascade_path_fn();


--
-- Name: dcim_location dcim_location_ltree_compute_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_location_ltree_compute_path BEFORE INSERT OR UPDATE OF parent_id, name ON public.dcim_location FOR EACH ROW EXECUTE FUNCTION public.dcim_location_ltree_compute_path_fn();


--
-- Name: dcim_device dcim_modulebay_denorm_from_dcim_device; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_modulebay_denorm_from_dcim_device AFTER UPDATE OF site_id, location_id, rack_id ON public.dcim_device FOR EACH ROW WHEN (((old.site_id IS DISTINCT FROM new.site_id) OR (old.location_id IS DISTINCT FROM new.location_id) OR (old.rack_id IS DISTINCT FROM new.rack_id))) EXECUTE FUNCTION public.dcim_modulebay_denorm_from_dcim_device_fn();


--
-- Name: dcim_modulebay dcim_modulebay_ltree_cascade_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_modulebay_ltree_cascade_path AFTER UPDATE OF parent_id, name ON public.dcim_modulebay FOR EACH ROW WHEN ((((old.path)::text IS DISTINCT FROM (new.path)::text) OR (old.sort_path IS DISTINCT FROM new.sort_path))) EXECUTE FUNCTION public.dcim_modulebay_ltree_cascade_path_fn();


--
-- Name: dcim_modulebay dcim_modulebay_ltree_compute_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_modulebay_ltree_compute_path BEFORE INSERT OR UPDATE OF parent_id, name ON public.dcim_modulebay FOR EACH ROW EXECUTE FUNCTION public.dcim_modulebay_ltree_compute_path_fn();


--
-- Name: dcim_platform dcim_platform_ltree_cascade_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_platform_ltree_cascade_path AFTER UPDATE OF parent_id, name ON public.dcim_platform FOR EACH ROW WHEN ((((old.path)::text IS DISTINCT FROM (new.path)::text) OR (old.sort_path IS DISTINCT FROM new.sort_path))) EXECUTE FUNCTION public.dcim_platform_ltree_cascade_path_fn();


--
-- Name: dcim_platform dcim_platform_ltree_compute_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_platform_ltree_compute_path BEFORE INSERT OR UPDATE OF parent_id, name ON public.dcim_platform FOR EACH ROW EXECUTE FUNCTION public.dcim_platform_ltree_compute_path_fn();


--
-- Name: dcim_device dcim_poweroutlet_denorm_from_dcim_device; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_poweroutlet_denorm_from_dcim_device AFTER UPDATE OF site_id, location_id, rack_id ON public.dcim_device FOR EACH ROW WHEN (((old.site_id IS DISTINCT FROM new.site_id) OR (old.location_id IS DISTINCT FROM new.location_id) OR (old.rack_id IS DISTINCT FROM new.rack_id))) EXECUTE FUNCTION public.dcim_poweroutlet_denorm_from_dcim_device_fn();


--
-- Name: dcim_device dcim_powerport_denorm_from_dcim_device; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_powerport_denorm_from_dcim_device AFTER UPDATE OF site_id, location_id, rack_id ON public.dcim_device FOR EACH ROW WHEN (((old.site_id IS DISTINCT FROM new.site_id) OR (old.location_id IS DISTINCT FROM new.location_id) OR (old.rack_id IS DISTINCT FROM new.rack_id))) EXECUTE FUNCTION public.dcim_powerport_denorm_from_dcim_device_fn();


--
-- Name: dcim_device dcim_rearport_denorm_from_dcim_device; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_rearport_denorm_from_dcim_device AFTER UPDATE OF site_id, location_id, rack_id ON public.dcim_device FOR EACH ROW WHEN (((old.site_id IS DISTINCT FROM new.site_id) OR (old.location_id IS DISTINCT FROM new.location_id) OR (old.rack_id IS DISTINCT FROM new.rack_id))) EXECUTE FUNCTION public.dcim_rearport_denorm_from_dcim_device_fn();


--
-- Name: dcim_region dcim_region_ltree_cascade_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_region_ltree_cascade_path AFTER UPDATE OF parent_id, name ON public.dcim_region FOR EACH ROW WHEN ((((old.path)::text IS DISTINCT FROM (new.path)::text) OR (old.sort_path IS DISTINCT FROM new.sort_path))) EXECUTE FUNCTION public.dcim_region_ltree_cascade_path_fn();


--
-- Name: dcim_region dcim_region_ltree_compute_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_region_ltree_compute_path BEFORE INSERT OR UPDATE OF parent_id, name ON public.dcim_region FOR EACH ROW EXECUTE FUNCTION public.dcim_region_ltree_compute_path_fn();


--
-- Name: dcim_sitegroup dcim_sitegroup_ltree_cascade_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_sitegroup_ltree_cascade_path AFTER UPDATE OF parent_id, name ON public.dcim_sitegroup FOR EACH ROW WHEN ((((old.path)::text IS DISTINCT FROM (new.path)::text) OR (old.sort_path IS DISTINCT FROM new.sort_path))) EXECUTE FUNCTION public.dcim_sitegroup_ltree_cascade_path_fn();


--
-- Name: dcim_sitegroup dcim_sitegroup_ltree_compute_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dcim_sitegroup_ltree_compute_path BEFORE INSERT OR UPDATE OF parent_id, name ON public.dcim_sitegroup FOR EACH ROW EXECUTE FUNCTION public.dcim_sitegroup_ltree_compute_path_fn();


--
-- Name: dcim_location ipam_prefix_denorm_from_dcim_location; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ipam_prefix_denorm_from_dcim_location AFTER UPDATE OF site_id ON public.dcim_location FOR EACH ROW WHEN ((old.site_id IS DISTINCT FROM new.site_id)) EXECUTE FUNCTION public.ipam_prefix_denorm_from_dcim_location_fn();


--
-- Name: dcim_site ipam_prefix_denorm_from_dcim_site; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ipam_prefix_denorm_from_dcim_site AFTER UPDATE OF region_id, group_id ON public.dcim_site FOR EACH ROW WHEN (((old.region_id IS DISTINCT FROM new.region_id) OR (old.group_id IS DISTINCT FROM new.group_id))) EXECUTE FUNCTION public.ipam_prefix_denorm_from_dcim_site_fn();


--
-- Name: tenancy_contactgroup tenancy_contactgroup_ltree_cascade_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tenancy_contactgroup_ltree_cascade_path AFTER UPDATE OF parent_id, name ON public.tenancy_contactgroup FOR EACH ROW WHEN ((((old.path)::text IS DISTINCT FROM (new.path)::text) OR (old.sort_path IS DISTINCT FROM new.sort_path))) EXECUTE FUNCTION public.tenancy_contactgroup_ltree_cascade_path_fn();


--
-- Name: tenancy_contactgroup tenancy_contactgroup_ltree_compute_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tenancy_contactgroup_ltree_compute_path BEFORE INSERT OR UPDATE OF parent_id, name ON public.tenancy_contactgroup FOR EACH ROW EXECUTE FUNCTION public.tenancy_contactgroup_ltree_compute_path_fn();


--
-- Name: tenancy_tenantgroup tenancy_tenantgroup_ltree_cascade_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tenancy_tenantgroup_ltree_cascade_path AFTER UPDATE OF parent_id, name ON public.tenancy_tenantgroup FOR EACH ROW WHEN ((((old.path)::text IS DISTINCT FROM (new.path)::text) OR (old.sort_path IS DISTINCT FROM new.sort_path))) EXECUTE FUNCTION public.tenancy_tenantgroup_ltree_cascade_path_fn();


--
-- Name: tenancy_tenantgroup tenancy_tenantgroup_ltree_compute_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tenancy_tenantgroup_ltree_compute_path BEFORE INSERT OR UPDATE OF parent_id, name ON public.tenancy_tenantgroup FOR EACH ROW EXECUTE FUNCTION public.tenancy_tenantgroup_ltree_compute_path_fn();


--
-- Name: dcim_location virtualization_cluster_denorm_from_dcim_location; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER virtualization_cluster_denorm_from_dcim_location AFTER UPDATE OF site_id ON public.dcim_location FOR EACH ROW WHEN ((old.site_id IS DISTINCT FROM new.site_id)) EXECUTE FUNCTION public.virtualization_cluster_denorm_from_dcim_location_fn();


--
-- Name: dcim_site virtualization_cluster_denorm_from_dcim_site; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER virtualization_cluster_denorm_from_dcim_site AFTER UPDATE OF region_id, group_id ON public.dcim_site FOR EACH ROW WHEN (((old.region_id IS DISTINCT FROM new.region_id) OR (old.group_id IS DISTINCT FROM new.group_id))) EXECUTE FUNCTION public.virtualization_cluster_denorm_from_dcim_site_fn();


--
-- Name: dcim_location wireless_wirelesslan_denorm_from_dcim_location; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER wireless_wirelesslan_denorm_from_dcim_location AFTER UPDATE OF site_id ON public.dcim_location FOR EACH ROW WHEN ((old.site_id IS DISTINCT FROM new.site_id)) EXECUTE FUNCTION public.wireless_wirelesslan_denorm_from_dcim_location_fn();


--
-- Name: dcim_site wireless_wirelesslan_denorm_from_dcim_site; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER wireless_wirelesslan_denorm_from_dcim_site AFTER UPDATE OF region_id, group_id ON public.dcim_site FOR EACH ROW WHEN (((old.region_id IS DISTINCT FROM new.region_id) OR (old.group_id IS DISTINCT FROM new.group_id))) EXECUTE FUNCTION public.wireless_wirelesslan_denorm_from_dcim_site_fn();


--
-- Name: wireless_wirelesslangroup wireless_wirelesslangroup_ltree_cascade_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER wireless_wirelesslangroup_ltree_cascade_path AFTER UPDATE OF parent_id, name ON public.wireless_wirelesslangroup FOR EACH ROW WHEN ((((old.path)::text IS DISTINCT FROM (new.path)::text) OR (old.sort_path IS DISTINCT FROM new.sort_path))) EXECUTE FUNCTION public.wireless_wirelesslangroup_ltree_cascade_path_fn();


--
-- Name: wireless_wirelesslangroup wireless_wirelesslangroup_ltree_compute_path; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER wireless_wirelesslangroup_ltree_compute_path BEFORE INSERT OR UPDATE OF parent_id, name ON public.wireless_wirelesslangroup FOR EACH ROW EXECUTE FUNCTION public.wireless_wirelesslangroup_ltree_compute_path_fn();


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuit circuits_circuit_owner_id_c330c2d0_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuit
    ADD CONSTRAINT circuits_circuit_owner_id_c330c2d0_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuit circuits_circuit_provider_account_id_a7c8f61b_fk_circuits_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuit
    ADD CONSTRAINT circuits_circuit_provider_account_id_a7c8f61b_fk_circuits_ FOREIGN KEY (provider_account_id) REFERENCES public.circuits_provideraccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuit circuits_circuit_provider_id_d9195418_fk_circuits_provider_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuit
    ADD CONSTRAINT circuits_circuit_provider_id_d9195418_fk_circuits_provider_id FOREIGN KEY (provider_id) REFERENCES public.circuits_provider(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuit circuits_circuit_tenant_id_812508a5_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuit
    ADD CONSTRAINT circuits_circuit_tenant_id_812508a5_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuit circuits_circuit_termination_a_id_f891adac_fk_circuits_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuit
    ADD CONSTRAINT circuits_circuit_termination_a_id_f891adac_fk_circuits_ FOREIGN KEY (termination_a_id) REFERENCES public.circuits_circuittermination(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuit circuits_circuit_termination_z_id_377b8551_fk_circuits_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuit
    ADD CONSTRAINT circuits_circuit_termination_z_id_377b8551_fk_circuits_ FOREIGN KEY (termination_z_id) REFERENCES public.circuits_circuittermination(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuit circuits_circuit_type_id_1b9f485a_fk_circuits_circuittype_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuit
    ADD CONSTRAINT circuits_circuit_type_id_1b9f485a_fk_circuits_circuittype_id FOREIGN KEY (type_id) REFERENCES public.circuits_circuittype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuitgroupassignment circuits_circuitgrou_group_id_1a7b6580_fk_circuits_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuitgroupassignment
    ADD CONSTRAINT circuits_circuitgrou_group_id_1a7b6580_fk_circuits_ FOREIGN KEY (group_id) REFERENCES public.circuits_circuitgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuitgroupassignment circuits_circuitgrou_member_type_id_779d1a13_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuitgroupassignment
    ADD CONSTRAINT circuits_circuitgrou_member_type_id_779d1a13_fk_django_co FOREIGN KEY (member_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuitgroup circuits_circuitgroup_owner_id_1edf4d64_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuitgroup
    ADD CONSTRAINT circuits_circuitgroup_owner_id_1edf4d64_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuitgroup circuits_circuitgroup_tenant_id_5bafdc3f_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuitgroup
    ADD CONSTRAINT circuits_circuitgroup_tenant_id_5bafdc3f_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuittermination circuits_circuitterm__location_id_4a578dca_fk_dcim_loca; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuittermination
    ADD CONSTRAINT circuits_circuitterm__location_id_4a578dca_fk_dcim_loca FOREIGN KEY (_location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuittermination circuits_circuitterm__provider_network_id_85ca661e_fk_circuits_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuittermination
    ADD CONSTRAINT circuits_circuitterm__provider_network_id_85ca661e_fk_circuits_ FOREIGN KEY (_provider_network_id) REFERENCES public.circuits_providernetwork(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuittermination circuits_circuitterm__region_id_1fa03379_fk_dcim_regi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuittermination
    ADD CONSTRAINT circuits_circuitterm__region_id_1fa03379_fk_dcim_regi FOREIGN KEY (_region_id) REFERENCES public.dcim_region(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuittermination circuits_circuitterm__site_group_id_ec0c1998_fk_dcim_site; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuittermination
    ADD CONSTRAINT circuits_circuitterm__site_group_id_ec0c1998_fk_dcim_site FOREIGN KEY (_site_group_id) REFERENCES public.dcim_sitegroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuittermination circuits_circuitterm_circuit_id_257e87e7_fk_circuits_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuittermination
    ADD CONSTRAINT circuits_circuitterm_circuit_id_257e87e7_fk_circuits_ FOREIGN KEY (circuit_id) REFERENCES public.circuits_circuit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuittermination circuits_circuitterm_termination_type_id_c9262c91_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuittermination
    ADD CONSTRAINT circuits_circuitterm_termination_type_id_c9262c91_fk_django_co FOREIGN KEY (termination_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuittermination circuits_circuittermination__site_id_84942491_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuittermination
    ADD CONSTRAINT circuits_circuittermination__site_id_84942491_fk_dcim_site_id FOREIGN KEY (_site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuittermination circuits_circuittermination_cable_id_35e9f703_fk_dcim_cable_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuittermination
    ADD CONSTRAINT circuits_circuittermination_cable_id_35e9f703_fk_dcim_cable_id FOREIGN KEY (cable_id) REFERENCES public.dcim_cable(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_circuittype circuits_circuittype_owner_id_9c3200c2_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_circuittype
    ADD CONSTRAINT circuits_circuittype_owner_id_9c3200c2_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_provider_asns circuits_provider_as_provider_id_becc3f7e_fk_circuits_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_provider_asns
    ADD CONSTRAINT circuits_provider_as_provider_id_becc3f7e_fk_circuits_ FOREIGN KEY (provider_id) REFERENCES public.circuits_provider(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_provider_asns circuits_provider_asns_asn_id_0a6c53b3_fk_ipam_asn_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_provider_asns
    ADD CONSTRAINT circuits_provider_asns_asn_id_0a6c53b3_fk_ipam_asn_id FOREIGN KEY (asn_id) REFERENCES public.ipam_asn(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_provider circuits_provider_owner_id_9f9749b4_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_provider
    ADD CONSTRAINT circuits_provider_owner_id_9f9749b4_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_provideraccount circuits_provideracc_provider_id_4bcd7e50_fk_circuits_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_provideraccount
    ADD CONSTRAINT circuits_provideracc_provider_id_4bcd7e50_fk_circuits_ FOREIGN KEY (provider_id) REFERENCES public.circuits_provider(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_provideraccount circuits_provideraccount_owner_id_6dcd4819_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_provideraccount
    ADD CONSTRAINT circuits_provideraccount_owner_id_6dcd4819_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_providernetwork circuits_providernet_provider_id_7992236c_fk_circuits_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_providernetwork
    ADD CONSTRAINT circuits_providernet_provider_id_7992236c_fk_circuits_ FOREIGN KEY (provider_id) REFERENCES public.circuits_provider(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_providernetwork circuits_providernetwork_owner_id_caa8afde_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_providernetwork
    ADD CONSTRAINT circuits_providernetwork_owner_id_caa8afde_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_virtualcircuittermination circuits_virtualcirc_interface_id_d764b232_fk_dcim_inte; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_virtualcircuittermination
    ADD CONSTRAINT circuits_virtualcirc_interface_id_d764b232_fk_dcim_inte FOREIGN KEY (interface_id) REFERENCES public.dcim_interface(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_virtualcircuit circuits_virtualcirc_provider_account_id_d942f455_fk_circuits_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_virtualcircuit
    ADD CONSTRAINT circuits_virtualcirc_provider_account_id_d942f455_fk_circuits_ FOREIGN KEY (provider_account_id) REFERENCES public.circuits_provideraccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_virtualcircuit circuits_virtualcirc_provider_network_id_a902f409_fk_circuits_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_virtualcircuit
    ADD CONSTRAINT circuits_virtualcirc_provider_network_id_a902f409_fk_circuits_ FOREIGN KEY (provider_network_id) REFERENCES public.circuits_providernetwork(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_virtualcircuit circuits_virtualcirc_type_id_8527d682_fk_circuits_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_virtualcircuit
    ADD CONSTRAINT circuits_virtualcirc_type_id_8527d682_fk_circuits_ FOREIGN KEY (type_id) REFERENCES public.circuits_virtualcircuittype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_virtualcircuittermination circuits_virtualcirc_virtual_circuit_id_ca588886_fk_circuits_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_virtualcircuittermination
    ADD CONSTRAINT circuits_virtualcirc_virtual_circuit_id_ca588886_fk_circuits_ FOREIGN KEY (virtual_circuit_id) REFERENCES public.circuits_virtualcircuit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_virtualcircuit circuits_virtualcircuit_owner_id_89564a1e_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_virtualcircuit
    ADD CONSTRAINT circuits_virtualcircuit_owner_id_89564a1e_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_virtualcircuit circuits_virtualcircuit_tenant_id_4458eca7_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_virtualcircuit
    ADD CONSTRAINT circuits_virtualcircuit_tenant_id_4458eca7_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: circuits_virtualcircuittype circuits_virtualcircuittype_owner_id_12a50b80_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits_virtualcircuittype
    ADD CONSTRAINT circuits_virtualcircuittype_owner_id_12a50b80_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_autosyncrecord core_autosyncrecord_datafile_id_f2aad29e_fk_core_datafile_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_autosyncrecord
    ADD CONSTRAINT core_autosyncrecord_datafile_id_f2aad29e_fk_core_datafile_id FOREIGN KEY (datafile_id) REFERENCES public.core_datafile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_autosyncrecord core_autosyncrecord_object_type_id_62506cf6_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_autosyncrecord
    ADD CONSTRAINT core_autosyncrecord_object_type_id_62506cf6_fk_django_co FOREIGN KEY (object_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_datafile core_datafile_source_id_8d675be2_fk_core_datasource_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_datafile
    ADD CONSTRAINT core_datafile_source_id_8d675be2_fk_core_datasource_id FOREIGN KEY (source_id) REFERENCES public.core_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_datasource core_datasource_owner_id_3f4e6ba5_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_datasource
    ADD CONSTRAINT core_datasource_owner_id_3f4e6ba5_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_job core_job_object_type_id_ea17469a_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_job
    ADD CONSTRAINT core_job_object_type_id_ea17469a_fk_django_content_type_id FOREIGN KEY (object_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_job core_job_user_id_b69eefda_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_job
    ADD CONSTRAINT core_job_user_id_b69eefda_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_managedfile core_managedfile_data_file_id_2b6fc95e_fk_core_datafile_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_managedfile
    ADD CONSTRAINT core_managedfile_data_file_id_2b6fc95e_fk_core_datafile_id FOREIGN KEY (data_file_id) REFERENCES public.core_datafile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_managedfile core_managedfile_data_source_id_647d5dbe_fk_core_datasource_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_managedfile
    ADD CONSTRAINT core_managedfile_data_source_id_647d5dbe_fk_core_datasource_id FOREIGN KEY (data_source_id) REFERENCES public.core_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_objectchange core_objectchange_changed_object_type_id_2070ade6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_objectchange
    ADD CONSTRAINT core_objectchange_changed_object_type_id_2070ade6 FOREIGN KEY (changed_object_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_objectchange core_objectchange_related_object_type_id_b80958af; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_objectchange
    ADD CONSTRAINT core_objectchange_related_object_type_id_b80958af FOREIGN KEY (related_object_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_objectchange core_objectchange_user_id_2b2142be; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_objectchange
    ADD CONSTRAINT core_objectchange_user_id_2b2142be FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_objecttype core_objecttype_contenttype_ptr_id_d92548f5_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_objecttype
    ADD CONSTRAINT core_objecttype_contenttype_ptr_id_d92548f5_fk_django_co FOREIGN KEY (contenttype_ptr_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_cable dcim_cable_bundle_id_f893f393_fk_dcim_cablebundle_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_cable
    ADD CONSTRAINT dcim_cable_bundle_id_f893f393_fk_dcim_cablebundle_id FOREIGN KEY (bundle_id) REFERENCES public.dcim_cablebundle(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_cable dcim_cable_owner_id_9cea1430_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_cable
    ADD CONSTRAINT dcim_cable_owner_id_9cea1430_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_cable dcim_cable_tenant_id_3a7fdbb8_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_cable
    ADD CONSTRAINT dcim_cable_tenant_id_3a7fdbb8_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_cablebundle dcim_cablebundle_owner_id_8f2a8189_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_cablebundle
    ADD CONSTRAINT dcim_cablebundle_owner_id_8f2a8189_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_cabletermination dcim_cableterminatio_termination_type_id_20da439e_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_cabletermination
    ADD CONSTRAINT dcim_cableterminatio_termination_type_id_20da439e_fk_django_co FOREIGN KEY (termination_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_cabletermination dcim_cabletermination__device_id_f5884934_fk_dcim_device_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_cabletermination
    ADD CONSTRAINT dcim_cabletermination__device_id_f5884934_fk_dcim_device_id FOREIGN KEY (_device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_cabletermination dcim_cabletermination__location_id_ff4be503_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_cabletermination
    ADD CONSTRAINT dcim_cabletermination__location_id_ff4be503_fk_dcim_location_id FOREIGN KEY (_location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_cabletermination dcim_cabletermination__rack_id_83a548e1_fk_dcim_rack_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_cabletermination
    ADD CONSTRAINT dcim_cabletermination__rack_id_83a548e1_fk_dcim_rack_id FOREIGN KEY (_rack_id) REFERENCES public.dcim_rack(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_cabletermination dcim_cabletermination__site_id_616962fa_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_cabletermination
    ADD CONSTRAINT dcim_cabletermination__site_id_616962fa_fk_dcim_site_id FOREIGN KEY (_site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_cabletermination dcim_cabletermination_cable_id_b50010d1_fk_dcim_cable_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_cabletermination
    ADD CONSTRAINT dcim_cabletermination_cable_id_b50010d1_fk_dcim_cable_id FOREIGN KEY (cable_id) REFERENCES public.dcim_cable(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleport dcim_consoleport__location_id_d0e7437b_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleport
    ADD CONSTRAINT dcim_consoleport__location_id_d0e7437b_fk_dcim_location_id FOREIGN KEY (_location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleport dcim_consoleport__path_id_e40a4436_fk_dcim_cablepath_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleport
    ADD CONSTRAINT dcim_consoleport__path_id_e40a4436_fk_dcim_cablepath_id FOREIGN KEY (_path_id) REFERENCES public.dcim_cablepath(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleport dcim_consoleport__rack_id_71f16827_fk_dcim_rack_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleport
    ADD CONSTRAINT dcim_consoleport__rack_id_71f16827_fk_dcim_rack_id FOREIGN KEY (_rack_id) REFERENCES public.dcim_rack(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleport dcim_consoleport__site_id_9652df9c_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleport
    ADD CONSTRAINT dcim_consoleport__site_id_9652df9c_fk_dcim_site_id FOREIGN KEY (_site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleport dcim_consoleport_cable_id_a9ae5465_fk_dcim_cable_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleport
    ADD CONSTRAINT dcim_consoleport_cable_id_a9ae5465_fk_dcim_cable_id FOREIGN KEY (cable_id) REFERENCES public.dcim_cable(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleport dcim_consoleport_device_id_f2d90d3c_fk_dcim_device_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleport
    ADD CONSTRAINT dcim_consoleport_device_id_f2d90d3c_fk_dcim_device_id FOREIGN KEY (device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleport dcim_consoleport_module_id_d17b2519_fk_dcim_module_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleport
    ADD CONSTRAINT dcim_consoleport_module_id_d17b2519_fk_dcim_module_id FOREIGN KEY (module_id) REFERENCES public.dcim_module(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleport dcim_consoleport_owner_id_0648eae1_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleport
    ADD CONSTRAINT dcim_consoleport_owner_id_0648eae1_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleporttemplate dcim_consoleporttemp_device_type_id_075d4015_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleporttemplate
    ADD CONSTRAINT dcim_consoleporttemp_device_type_id_075d4015_fk_dcim_devi FOREIGN KEY (device_type_id) REFERENCES public.dcim_devicetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleporttemplate dcim_consoleporttemp_module_type_id_c0f35d97_fk_dcim_modu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleporttemplate
    ADD CONSTRAINT dcim_consoleporttemp_module_type_id_c0f35d97_fk_dcim_modu FOREIGN KEY (module_type_id) REFERENCES public.dcim_moduletype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleserverport dcim_consoleserverpo__location_id_7525ec0e_fk_dcim_loca; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleserverport
    ADD CONSTRAINT dcim_consoleserverpo__location_id_7525ec0e_fk_dcim_loca FOREIGN KEY (_location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleserverporttemplate dcim_consoleserverpo_device_type_id_579bdc86_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleserverporttemplate
    ADD CONSTRAINT dcim_consoleserverpo_device_type_id_579bdc86_fk_dcim_devi FOREIGN KEY (device_type_id) REFERENCES public.dcim_devicetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleserverporttemplate dcim_consoleserverpo_module_type_id_4abf751a_fk_dcim_modu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleserverporttemplate
    ADD CONSTRAINT dcim_consoleserverpo_module_type_id_4abf751a_fk_dcim_modu FOREIGN KEY (module_type_id) REFERENCES public.dcim_moduletype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleserverport dcim_consoleserverport__path_id_dc5abe09_fk_dcim_cablepath_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleserverport
    ADD CONSTRAINT dcim_consoleserverport__path_id_dc5abe09_fk_dcim_cablepath_id FOREIGN KEY (_path_id) REFERENCES public.dcim_cablepath(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleserverport dcim_consoleserverport__rack_id_3eea9f1b_fk_dcim_rack_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleserverport
    ADD CONSTRAINT dcim_consoleserverport__rack_id_3eea9f1b_fk_dcim_rack_id FOREIGN KEY (_rack_id) REFERENCES public.dcim_rack(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleserverport dcim_consoleserverport__site_id_c500ac62_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleserverport
    ADD CONSTRAINT dcim_consoleserverport__site_id_c500ac62_fk_dcim_site_id FOREIGN KEY (_site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleserverport dcim_consoleserverport_cable_id_f2940dfd_fk_dcim_cable_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleserverport
    ADD CONSTRAINT dcim_consoleserverport_cable_id_f2940dfd_fk_dcim_cable_id FOREIGN KEY (cable_id) REFERENCES public.dcim_cable(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleserverport dcim_consoleserverport_device_id_d9866581_fk_dcim_device_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleserverport
    ADD CONSTRAINT dcim_consoleserverport_device_id_d9866581_fk_dcim_device_id FOREIGN KEY (device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleserverport dcim_consoleserverport_module_id_d060cfc8_fk_dcim_module_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleserverport
    ADD CONSTRAINT dcim_consoleserverport_module_id_d060cfc8_fk_dcim_module_id FOREIGN KEY (module_id) REFERENCES public.dcim_module(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_consoleserverport dcim_consoleserverport_owner_id_12b1a827_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_consoleserverport
    ADD CONSTRAINT dcim_consoleserverport_owner_id_12b1a827_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingfeed dcim_coolingfeed_cooling_source_id_f09a946f_fk_dcim_cool; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingfeed
    ADD CONSTRAINT dcim_coolingfeed_cooling_source_id_f09a946f_fk_dcim_cool FOREIGN KEY (cooling_source_id) REFERENCES public.dcim_coolingsource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingfeed dcim_coolingfeed_owner_id_8d34da56_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingfeed
    ADD CONSTRAINT dcim_coolingfeed_owner_id_8d34da56_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingfeed dcim_coolingfeed_rack_id_c100ab11_fk_dcim_rack_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingfeed
    ADD CONSTRAINT dcim_coolingfeed_rack_id_c100ab11_fk_dcim_rack_id FOREIGN KEY (rack_id) REFERENCES public.dcim_rack(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingfeed dcim_coolingfeed_tenant_id_db41c14e_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingfeed
    ADD CONSTRAINT dcim_coolingfeed_tenant_id_db41c14e_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingintake dcim_coolingintake__location_id_19e02a96_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingintake
    ADD CONSTRAINT dcim_coolingintake__location_id_19e02a96_fk_dcim_location_id FOREIGN KEY (_location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingintake dcim_coolingintake__rack_id_53527d66_fk_dcim_rack_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingintake
    ADD CONSTRAINT dcim_coolingintake__rack_id_53527d66_fk_dcim_rack_id FOREIGN KEY (_rack_id) REFERENCES public.dcim_rack(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingintake dcim_coolingintake__site_id_8a7279a3_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingintake
    ADD CONSTRAINT dcim_coolingintake__site_id_8a7279a3_fk_dcim_site_id FOREIGN KEY (_site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingintake dcim_coolingintake_cooling_outflow_id_e1bd22b7_fk_dcim_cool; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingintake
    ADD CONSTRAINT dcim_coolingintake_cooling_outflow_id_e1bd22b7_fk_dcim_cool FOREIGN KEY (cooling_outflow_id) REFERENCES public.dcim_coolingoutflow(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingintake dcim_coolingintake_device_id_df1c3674_fk_dcim_device_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingintake
    ADD CONSTRAINT dcim_coolingintake_device_id_df1c3674_fk_dcim_device_id FOREIGN KEY (device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingintake dcim_coolingintake_module_id_5aa49e74_fk_dcim_module_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingintake
    ADD CONSTRAINT dcim_coolingintake_module_id_5aa49e74_fk_dcim_module_id FOREIGN KEY (module_id) REFERENCES public.dcim_module(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingintake dcim_coolingintake_owner_id_91bcbf27_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingintake
    ADD CONSTRAINT dcim_coolingintake_owner_id_91bcbf27_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingintaketemplate dcim_coolingintakete_device_type_id_4fffffed_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingintaketemplate
    ADD CONSTRAINT dcim_coolingintakete_device_type_id_4fffffed_fk_dcim_devi FOREIGN KEY (device_type_id) REFERENCES public.dcim_devicetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingintaketemplate dcim_coolingintakete_module_type_id_b734e68e_fk_dcim_modu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingintaketemplate
    ADD CONSTRAINT dcim_coolingintakete_module_type_id_b734e68e_fk_dcim_modu FOREIGN KEY (module_type_id) REFERENCES public.dcim_moduletype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingoutflow dcim_coolingoutflow__location_id_718fca97_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingoutflow
    ADD CONSTRAINT dcim_coolingoutflow__location_id_718fca97_fk_dcim_location_id FOREIGN KEY (_location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingoutflow dcim_coolingoutflow__rack_id_5af2d149_fk_dcim_rack_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingoutflow
    ADD CONSTRAINT dcim_coolingoutflow__rack_id_5af2d149_fk_dcim_rack_id FOREIGN KEY (_rack_id) REFERENCES public.dcim_rack(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingoutflow dcim_coolingoutflow__site_id_ba7ee355_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingoutflow
    ADD CONSTRAINT dcim_coolingoutflow__site_id_ba7ee355_fk_dcim_site_id FOREIGN KEY (_site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingoutflow dcim_coolingoutflow_cooling_intake_id_6ce03c77_fk_dcim_cool; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingoutflow
    ADD CONSTRAINT dcim_coolingoutflow_cooling_intake_id_6ce03c77_fk_dcim_cool FOREIGN KEY (cooling_intake_id) REFERENCES public.dcim_coolingintake(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingoutflow dcim_coolingoutflow_device_id_74dd615f_fk_dcim_device_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingoutflow
    ADD CONSTRAINT dcim_coolingoutflow_device_id_74dd615f_fk_dcim_device_id FOREIGN KEY (device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingoutflow dcim_coolingoutflow_module_id_6a2cc4b3_fk_dcim_module_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingoutflow
    ADD CONSTRAINT dcim_coolingoutflow_module_id_6a2cc4b3_fk_dcim_module_id FOREIGN KEY (module_id) REFERENCES public.dcim_module(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingoutflow dcim_coolingoutflow_owner_id_b4cd9c02_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingoutflow
    ADD CONSTRAINT dcim_coolingoutflow_owner_id_b4cd9c02_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingoutflowtemplate dcim_coolingoutflowt_cooling_intake_id_616147e2_fk_dcim_cool; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingoutflowtemplate
    ADD CONSTRAINT dcim_coolingoutflowt_cooling_intake_id_616147e2_fk_dcim_cool FOREIGN KEY (cooling_intake_id) REFERENCES public.dcim_coolingintaketemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingoutflowtemplate dcim_coolingoutflowt_device_type_id_f1ae955b_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingoutflowtemplate
    ADD CONSTRAINT dcim_coolingoutflowt_device_type_id_f1ae955b_fk_dcim_devi FOREIGN KEY (device_type_id) REFERENCES public.dcim_devicetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingoutflowtemplate dcim_coolingoutflowt_module_type_id_751812c7_fk_dcim_modu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingoutflowtemplate
    ADD CONSTRAINT dcim_coolingoutflowt_module_type_id_751812c7_fk_dcim_modu FOREIGN KEY (module_type_id) REFERENCES public.dcim_moduletype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingsource dcim_coolingsource_location_id_7490ac1d_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingsource
    ADD CONSTRAINT dcim_coolingsource_location_id_7490ac1d_fk_dcim_location_id FOREIGN KEY (location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingsource dcim_coolingsource_owner_id_7499d734_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingsource
    ADD CONSTRAINT dcim_coolingsource_owner_id_7499d734_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_coolingsource dcim_coolingsource_site_id_95af0633_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_coolingsource
    ADD CONSTRAINT dcim_coolingsource_site_id_95af0633_fk_dcim_site_id FOREIGN KEY (site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_device dcim_device_cluster_id_cf852f78_fk_virtualization_cluster_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_cluster_id_cf852f78_fk_virtualization_cluster_id FOREIGN KEY (cluster_id) REFERENCES public.virtualization_cluster(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_device dcim_device_config_template_id_316328c4_fk_extras_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_config_template_id_316328c4_fk_extras_co FOREIGN KEY (config_template_id) REFERENCES public.extras_configtemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_device dcim_device_device_type_id_d61b4086_fk_dcim_devicetype_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_device_type_id_d61b4086_fk_dcim_devicetype_id FOREIGN KEY (device_type_id) REFERENCES public.dcim_devicetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_device dcim_device_location_id_11a7bedb_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_location_id_11a7bedb_fk_dcim_location_id FOREIGN KEY (location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_device dcim_device_oob_ip_id_5e7219c1_fk_ipam_ipaddress_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_oob_ip_id_5e7219c1_fk_ipam_ipaddress_id FOREIGN KEY (oob_ip_id) REFERENCES public.ipam_ipaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_device dcim_device_owner_id_87378f76_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_owner_id_87378f76_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_device dcim_device_platform_id_468138f1_fk_dcim_platform_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_platform_id_468138f1_fk_dcim_platform_id FOREIGN KEY (platform_id) REFERENCES public.dcim_platform(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_device dcim_device_primary_ip4_id_2ccd943a_fk_ipam_ipaddress_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_primary_ip4_id_2ccd943a_fk_ipam_ipaddress_id FOREIGN KEY (primary_ip4_id) REFERENCES public.ipam_ipaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_device dcim_device_primary_ip6_id_d180fe91_fk_ipam_ipaddress_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_primary_ip6_id_d180fe91_fk_ipam_ipaddress_id FOREIGN KEY (primary_ip6_id) REFERENCES public.ipam_ipaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_device dcim_device_rack_id_23bde71f_fk_dcim_rack_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_rack_id_23bde71f_fk_dcim_rack_id FOREIGN KEY (rack_id) REFERENCES public.dcim_rack(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_device dcim_device_role_id_61edcc33_fk_dcim_devicerole_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_role_id_61edcc33_fk_dcim_devicerole_id FOREIGN KEY (role_id) REFERENCES public.dcim_devicerole(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_device dcim_device_site_id_ff897cf6_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_site_id_ff897cf6_fk_dcim_site_id FOREIGN KEY (site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_device dcim_device_tenant_id_dcea7969_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_tenant_id_dcea7969_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_device dcim_device_virtual_chassis_id_aed51693_fk_dcim_virt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_device
    ADD CONSTRAINT dcim_device_virtual_chassis_id_aed51693_fk_dcim_virt FOREIGN KEY (virtual_chassis_id) REFERENCES public.dcim_virtualchassis(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_devicebay dcim_devicebay__location_id_6c869a87_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicebay
    ADD CONSTRAINT dcim_devicebay__location_id_6c869a87_fk_dcim_location_id FOREIGN KEY (_location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_devicebay dcim_devicebay__rack_id_75672431_fk_dcim_rack_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicebay
    ADD CONSTRAINT dcim_devicebay__rack_id_75672431_fk_dcim_rack_id FOREIGN KEY (_rack_id) REFERENCES public.dcim_rack(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_devicebay dcim_devicebay__site_id_8ddc30f4_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicebay
    ADD CONSTRAINT dcim_devicebay__site_id_8ddc30f4_fk_dcim_site_id FOREIGN KEY (_site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_devicebay dcim_devicebay_device_id_0c8a1218_fk_dcim_device_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicebay
    ADD CONSTRAINT dcim_devicebay_device_id_0c8a1218_fk_dcim_device_id FOREIGN KEY (device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_devicebay dcim_devicebay_installed_device_id_04618112_fk_dcim_device_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicebay
    ADD CONSTRAINT dcim_devicebay_installed_device_id_04618112_fk_dcim_device_id FOREIGN KEY (installed_device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_devicebay dcim_devicebay_owner_id_d7bcb3e6_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicebay
    ADD CONSTRAINT dcim_devicebay_owner_id_d7bcb3e6_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_devicebaytemplate dcim_devicebaytempla_device_type_id_f4b24a29_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicebaytemplate
    ADD CONSTRAINT dcim_devicebaytempla_device_type_id_f4b24a29_fk_dcim_devi FOREIGN KEY (device_type_id) REFERENCES public.dcim_devicetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_devicerole dcim_devicerole_config_template_id_5874002c_fk_extras_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicerole
    ADD CONSTRAINT dcim_devicerole_config_template_id_5874002c_fk_extras_co FOREIGN KEY (config_template_id) REFERENCES public.extras_configtemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_devicerole dcim_devicerole_owner_id_fdcc527d_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicerole
    ADD CONSTRAINT dcim_devicerole_owner_id_fdcc527d_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_devicerole dcim_devicerole_parent_id_7f9ccf87_fk_dcim_devicerole_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicerole
    ADD CONSTRAINT dcim_devicerole_parent_id_7f9ccf87_fk_dcim_devicerole_id FOREIGN KEY (parent_id) REFERENCES public.dcim_devicerole(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_devicetype dcim_devicetype_default_platform_id_1f6ff6ac_fk_dcim_plat; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicetype
    ADD CONSTRAINT dcim_devicetype_default_platform_id_1f6ff6ac_fk_dcim_plat FOREIGN KEY (default_platform_id) REFERENCES public.dcim_platform(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_devicetype dcim_devicetype_manufacturer_id_a3e8029e_fk_dcim_manu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicetype
    ADD CONSTRAINT dcim_devicetype_manufacturer_id_a3e8029e_fk_dcim_manu FOREIGN KEY (manufacturer_id) REFERENCES public.dcim_manufacturer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_devicetype dcim_devicetype_owner_id_243048ed_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_devicetype
    ADD CONSTRAINT dcim_devicetype_owner_id_243048ed_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_frontport dcim_frontport__location_id_dc0402e7_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_frontport
    ADD CONSTRAINT dcim_frontport__location_id_dc0402e7_fk_dcim_location_id FOREIGN KEY (_location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_frontport dcim_frontport__rack_id_1ba6d11c_fk_dcim_rack_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_frontport
    ADD CONSTRAINT dcim_frontport__rack_id_1ba6d11c_fk_dcim_rack_id FOREIGN KEY (_rack_id) REFERENCES public.dcim_rack(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_frontport dcim_frontport__site_id_51efdefe_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_frontport
    ADD CONSTRAINT dcim_frontport__site_id_51efdefe_fk_dcim_site_id FOREIGN KEY (_site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_frontport dcim_frontport_cable_id_04ff8aab_fk_dcim_cable_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_frontport
    ADD CONSTRAINT dcim_frontport_cable_id_04ff8aab_fk_dcim_cable_id FOREIGN KEY (cable_id) REFERENCES public.dcim_cable(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_frontport dcim_frontport_device_id_950557b5_fk_dcim_device_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_frontport
    ADD CONSTRAINT dcim_frontport_device_id_950557b5_fk_dcim_device_id FOREIGN KEY (device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_frontport dcim_frontport_module_id_952c3f9a_fk_dcim_module_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_frontport
    ADD CONSTRAINT dcim_frontport_module_id_952c3f9a_fk_dcim_module_id FOREIGN KEY (module_id) REFERENCES public.dcim_module(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_frontport dcim_frontport_owner_id_dfb61151_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_frontport
    ADD CONSTRAINT dcim_frontport_owner_id_dfb61151_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_frontporttemplate dcim_frontporttempla_device_type_id_f088b952_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_frontporttemplate
    ADD CONSTRAINT dcim_frontporttempla_device_type_id_f088b952_fk_dcim_devi FOREIGN KEY (device_type_id) REFERENCES public.dcim_devicetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_frontporttemplate dcim_frontporttempla_module_type_id_66851ff9_fk_dcim_modu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_frontporttemplate
    ADD CONSTRAINT dcim_frontporttempla_module_type_id_66851ff9_fk_dcim_modu FOREIGN KEY (module_type_id) REFERENCES public.dcim_moduletype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface dcim_interface__location_id_72d5e107_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface__location_id_72d5e107_fk_dcim_location_id FOREIGN KEY (_location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface dcim_interface__path_id_f8f4f7f0_fk_dcim_cablepath_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface__path_id_f8f4f7f0_fk_dcim_cablepath_id FOREIGN KEY (_path_id) REFERENCES public.dcim_cablepath(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface dcim_interface__rack_id_0d3f84a6_fk_dcim_rack_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface__rack_id_0d3f84a6_fk_dcim_rack_id FOREIGN KEY (_rack_id) REFERENCES public.dcim_rack(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface dcim_interface__site_id_0fffd4ef_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface__site_id_0fffd4ef_fk_dcim_site_id FOREIGN KEY (_site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface dcim_interface_bridge_id_f2a8df85_fk_dcim_interface_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface_bridge_id_f2a8df85_fk_dcim_interface_id FOREIGN KEY (bridge_id) REFERENCES public.dcim_interface(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface dcim_interface_cable_id_1b264edb_fk_dcim_cable_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface_cable_id_1b264edb_fk_dcim_cable_id FOREIGN KEY (cable_id) REFERENCES public.dcim_cable(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface dcim_interface_device_id_359c6115_fk_dcim_device_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface_device_id_359c6115_fk_dcim_device_id FOREIGN KEY (device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface dcim_interface_lag_id_ea1a1d12_fk_dcim_interface_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface_lag_id_ea1a1d12_fk_dcim_interface_id FOREIGN KEY (lag_id) REFERENCES public.dcim_interface(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface dcim_interface_module_id_05ca2da5_fk_dcim_module_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface_module_id_05ca2da5_fk_dcim_module_id FOREIGN KEY (module_id) REFERENCES public.dcim_module(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface dcim_interface_owner_id_3ae797e2_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface_owner_id_3ae797e2_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface dcim_interface_parent_id_3e2b159b_fk_dcim_interface_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface_parent_id_3e2b159b_fk_dcim_interface_id FOREIGN KEY (parent_id) REFERENCES public.dcim_interface(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface dcim_interface_primary_mac_address__a0bb90ca_fk_dcim_maca; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface_primary_mac_address__a0bb90ca_fk_dcim_maca FOREIGN KEY (primary_mac_address_id) REFERENCES public.dcim_macaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface dcim_interface_qinq_svlan_id_21189a58_fk_ipam_vlan_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface_qinq_svlan_id_21189a58_fk_ipam_vlan_id FOREIGN KEY (qinq_svlan_id) REFERENCES public.ipam_vlan(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface_tagged_vlans dcim_interface_tagge_interface_id_5870c9e9_fk_dcim_inte; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface_tagged_vlans
    ADD CONSTRAINT dcim_interface_tagge_interface_id_5870c9e9_fk_dcim_inte FOREIGN KEY (interface_id) REFERENCES public.dcim_interface(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface_tagged_vlans dcim_interface_tagged_vlans_vlan_id_e027005c_fk_ipam_vlan_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface_tagged_vlans
    ADD CONSTRAINT dcim_interface_tagged_vlans_vlan_id_e027005c_fk_ipam_vlan_id FOREIGN KEY (vlan_id) REFERENCES public.ipam_vlan(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface dcim_interface_untagged_vlan_id_838dc7be_fk_ipam_vlan_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface_untagged_vlan_id_838dc7be_fk_ipam_vlan_id FOREIGN KEY (untagged_vlan_id) REFERENCES public.ipam_vlan(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface_vdcs dcim_interface_vdcs_interface_id_6d58dbaf_fk_dcim_interface_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface_vdcs
    ADD CONSTRAINT dcim_interface_vdcs_interface_id_6d58dbaf_fk_dcim_interface_id FOREIGN KEY (interface_id) REFERENCES public.dcim_interface(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface_vdcs dcim_interface_vdcs_virtualdevicecontext_af0bfd4b_fk_dcim_virt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface_vdcs
    ADD CONSTRAINT dcim_interface_vdcs_virtualdevicecontext_af0bfd4b_fk_dcim_virt FOREIGN KEY (virtualdevicecontext_id) REFERENCES public.dcim_virtualdevicecontext(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface dcim_interface_vlan_translation_pol_91060031_fk_ipam_vlan; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface_vlan_translation_pol_91060031_fk_ipam_vlan FOREIGN KEY (vlan_translation_policy_id) REFERENCES public.ipam_vlantranslationpolicy(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface dcim_interface_vrf_id_a92e59b2_fk_ipam_vrf_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface_vrf_id_a92e59b2_fk_ipam_vrf_id FOREIGN KEY (vrf_id) REFERENCES public.ipam_vrf(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface_wireless_lans dcim_interface_wirel_interface_id_80df3785_fk_dcim_inte; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface_wireless_lans
    ADD CONSTRAINT dcim_interface_wirel_interface_id_80df3785_fk_dcim_inte FOREIGN KEY (interface_id) REFERENCES public.dcim_interface(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface_wireless_lans dcim_interface_wirel_wirelesslan_id_f081e278_fk_wireless_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface_wireless_lans
    ADD CONSTRAINT dcim_interface_wirel_wirelesslan_id_f081e278_fk_wireless_ FOREIGN KEY (wirelesslan_id) REFERENCES public.wireless_wirelesslan(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interface dcim_interface_wireless_link_id_bc91108f_fk_wireless_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interface
    ADD CONSTRAINT dcim_interface_wireless_link_id_bc91108f_fk_wireless_ FOREIGN KEY (wireless_link_id) REFERENCES public.wireless_wirelesslink(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interfacetemplate dcim_interfacetempla_bridge_id_4e44355b_fk_dcim_inte; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interfacetemplate
    ADD CONSTRAINT dcim_interfacetempla_bridge_id_4e44355b_fk_dcim_inte FOREIGN KEY (bridge_id) REFERENCES public.dcim_interfacetemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interfacetemplate dcim_interfacetempla_device_type_id_4bfcbfab_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interfacetemplate
    ADD CONSTRAINT dcim_interfacetempla_device_type_id_4bfcbfab_fk_dcim_devi FOREIGN KEY (device_type_id) REFERENCES public.dcim_devicetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interfacetemplate dcim_interfacetempla_module_type_id_f941f180_fk_dcim_modu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interfacetemplate
    ADD CONSTRAINT dcim_interfacetempla_module_type_id_f941f180_fk_dcim_modu FOREIGN KEY (module_type_id) REFERENCES public.dcim_moduletype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_interfacetemplate dcim_interfacetempla_parent_id_1016cd00_fk_dcim_inte; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_interfacetemplate
    ADD CONSTRAINT dcim_interfacetempla_parent_id_1016cd00_fk_dcim_inte FOREIGN KEY (parent_id) REFERENCES public.dcim_interfacetemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_inventoryitem dcim_inventoryitem__location_id_05a23b33_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitem
    ADD CONSTRAINT dcim_inventoryitem__location_id_05a23b33_fk_dcim_location_id FOREIGN KEY (_location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_inventoryitem dcim_inventoryitem__rack_id_25b80d23_fk_dcim_rack_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitem
    ADD CONSTRAINT dcim_inventoryitem__rack_id_25b80d23_fk_dcim_rack_id FOREIGN KEY (_rack_id) REFERENCES public.dcim_rack(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_inventoryitem dcim_inventoryitem__site_id_cd94573b_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitem
    ADD CONSTRAINT dcim_inventoryitem__site_id_cd94573b_fk_dcim_site_id FOREIGN KEY (_site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_inventoryitem dcim_inventoryitem_component_type_id_f0e4d83a_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitem
    ADD CONSTRAINT dcim_inventoryitem_component_type_id_f0e4d83a_fk_django_co FOREIGN KEY (component_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_inventoryitem dcim_inventoryitem_device_id_033d83f8_fk_dcim_device_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitem
    ADD CONSTRAINT dcim_inventoryitem_device_id_033d83f8_fk_dcim_device_id FOREIGN KEY (device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_inventoryitem dcim_inventoryitem_manufacturer_id_dcd1b78a_fk_dcim_manu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitem
    ADD CONSTRAINT dcim_inventoryitem_manufacturer_id_dcd1b78a_fk_dcim_manu FOREIGN KEY (manufacturer_id) REFERENCES public.dcim_manufacturer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_inventoryitem dcim_inventoryitem_owner_id_ad4332eb_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitem
    ADD CONSTRAINT dcim_inventoryitem_owner_id_ad4332eb_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_inventoryitem dcim_inventoryitem_parent_id_7ebcd457_fk_dcim_inventoryitem_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitem
    ADD CONSTRAINT dcim_inventoryitem_parent_id_7ebcd457_fk_dcim_inventoryitem_id FOREIGN KEY (parent_id) REFERENCES public.dcim_inventoryitem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_inventoryitem dcim_inventoryitem_role_id_2bcfcb04_fk_dcim_inve; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitem
    ADD CONSTRAINT dcim_inventoryitem_role_id_2bcfcb04_fk_dcim_inve FOREIGN KEY (role_id) REFERENCES public.dcim_inventoryitemrole(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_inventoryitemrole dcim_inventoryitemrole_owner_id_067442e9_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitemrole
    ADD CONSTRAINT dcim_inventoryitemrole_owner_id_067442e9_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_inventoryitemtemplate dcim_inventoryitemte_component_type_id_161623a2_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitemtemplate
    ADD CONSTRAINT dcim_inventoryitemte_component_type_id_161623a2_fk_django_co FOREIGN KEY (component_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_inventoryitemtemplate dcim_inventoryitemte_device_type_id_6a1be904_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitemtemplate
    ADD CONSTRAINT dcim_inventoryitemte_device_type_id_6a1be904_fk_dcim_devi FOREIGN KEY (device_type_id) REFERENCES public.dcim_devicetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_inventoryitemtemplate dcim_inventoryitemte_manufacturer_id_b388c5d9_fk_dcim_manu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitemtemplate
    ADD CONSTRAINT dcim_inventoryitemte_manufacturer_id_b388c5d9_fk_dcim_manu FOREIGN KEY (manufacturer_id) REFERENCES public.dcim_manufacturer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_inventoryitemtemplate dcim_inventoryitemte_parent_id_0dac73bb_fk_dcim_inve; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitemtemplate
    ADD CONSTRAINT dcim_inventoryitemte_parent_id_0dac73bb_fk_dcim_inve FOREIGN KEY (parent_id) REFERENCES public.dcim_inventoryitemtemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_inventoryitemtemplate dcim_inventoryitemte_role_id_292676e6_fk_dcim_inve; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_inventoryitemtemplate
    ADD CONSTRAINT dcim_inventoryitemte_role_id_292676e6_fk_dcim_inve FOREIGN KEY (role_id) REFERENCES public.dcim_inventoryitemrole(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_location dcim_location_owner_id_919a8713_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_location
    ADD CONSTRAINT dcim_location_owner_id_919a8713_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_location dcim_location_parent_id_d77f3318_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_location
    ADD CONSTRAINT dcim_location_parent_id_d77f3318_fk_dcim_location_id FOREIGN KEY (parent_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_location dcim_location_site_id_b55e975f_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_location
    ADD CONSTRAINT dcim_location_site_id_b55e975f_fk_dcim_site_id FOREIGN KEY (site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_location dcim_location_tenant_id_2c4df974_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_location
    ADD CONSTRAINT dcim_location_tenant_id_2c4df974_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_macaddress dcim_macaddress_assigned_object_type_28814a20_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_macaddress
    ADD CONSTRAINT dcim_macaddress_assigned_object_type_28814a20_fk_django_co FOREIGN KEY (assigned_object_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_macaddress dcim_macaddress_owner_id_29ba2f60_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_macaddress
    ADD CONSTRAINT dcim_macaddress_owner_id_29ba2f60_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_manufacturer dcim_manufacturer_owner_id_8d78661f_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_manufacturer
    ADD CONSTRAINT dcim_manufacturer_owner_id_8d78661f_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_module dcim_module_device_id_53cfd5be_fk_dcim_device_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_module
    ADD CONSTRAINT dcim_module_device_id_53cfd5be_fk_dcim_device_id FOREIGN KEY (device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_module dcim_module_module_bay_id_8a1bf3e2_fk_dcim_modulebay_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_module
    ADD CONSTRAINT dcim_module_module_bay_id_8a1bf3e2_fk_dcim_modulebay_id FOREIGN KEY (module_bay_id) REFERENCES public.dcim_modulebay(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_module dcim_module_module_type_id_a50b39fc_fk_dcim_moduletype_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_module
    ADD CONSTRAINT dcim_module_module_type_id_a50b39fc_fk_dcim_moduletype_id FOREIGN KEY (module_type_id) REFERENCES public.dcim_moduletype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_module dcim_module_owner_id_ee6f1ef4_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_module
    ADD CONSTRAINT dcim_module_owner_id_ee6f1ef4_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_modulebay dcim_modulebay__location_id_17290069_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebay
    ADD CONSTRAINT dcim_modulebay__location_id_17290069_fk_dcim_location_id FOREIGN KEY (_location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_modulebay dcim_modulebay__rack_id_673d8fb5_fk_dcim_rack_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebay
    ADD CONSTRAINT dcim_modulebay__rack_id_673d8fb5_fk_dcim_rack_id FOREIGN KEY (_rack_id) REFERENCES public.dcim_rack(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_modulebay dcim_modulebay__site_id_cedd61bc_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebay
    ADD CONSTRAINT dcim_modulebay__site_id_cedd61bc_fk_dcim_site_id FOREIGN KEY (_site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_modulebay dcim_modulebay_device_id_3526abc2_fk_dcim_device_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebay
    ADD CONSTRAINT dcim_modulebay_device_id_3526abc2_fk_dcim_device_id FOREIGN KEY (device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_modulebay_module_bay_types dcim_modulebay_modul_modulebay_id_1bb84f17_fk_dcim_modu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebay_module_bay_types
    ADD CONSTRAINT dcim_modulebay_modul_modulebay_id_1bb84f17_fk_dcim_modu FOREIGN KEY (modulebay_id) REFERENCES public.dcim_modulebay(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_modulebay_module_bay_types dcim_modulebay_modul_modulebaytype_id_35dd161c_fk_dcim_modu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebay_module_bay_types
    ADD CONSTRAINT dcim_modulebay_modul_modulebaytype_id_35dd161c_fk_dcim_modu FOREIGN KEY (modulebaytype_id) REFERENCES public.dcim_modulebaytype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_modulebay dcim_modulebay_module_id_a21ddd9a_fk_dcim_module_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebay
    ADD CONSTRAINT dcim_modulebay_module_id_a21ddd9a_fk_dcim_module_id FOREIGN KEY (module_id) REFERENCES public.dcim_module(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_modulebay dcim_modulebay_owner_id_311f58c6_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebay
    ADD CONSTRAINT dcim_modulebay_owner_id_311f58c6_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_modulebay dcim_modulebay_parent_id_e483f9b7_fk_dcim_modulebay_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebay
    ADD CONSTRAINT dcim_modulebay_parent_id_e483f9b7_fk_dcim_modulebay_id FOREIGN KEY (parent_id) REFERENCES public.dcim_modulebay(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_modulebaytemplate dcim_modulebaytempla_device_type_id_9eaf9bd3_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebaytemplate
    ADD CONSTRAINT dcim_modulebaytempla_device_type_id_9eaf9bd3_fk_dcim_devi FOREIGN KEY (device_type_id) REFERENCES public.dcim_devicetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_modulebaytemplate dcim_modulebaytempla_module_type_id_2fdfb491_fk_dcim_modu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebaytemplate
    ADD CONSTRAINT dcim_modulebaytempla_module_type_id_2fdfb491_fk_dcim_modu FOREIGN KEY (module_type_id) REFERENCES public.dcim_moduletype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_modulebaytemplate_module_bay_types dcim_modulebaytempla_modulebaytemplate_id_b0b99ce5_fk_dcim_modu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebaytemplate_module_bay_types
    ADD CONSTRAINT dcim_modulebaytempla_modulebaytemplate_id_b0b99ce5_fk_dcim_modu FOREIGN KEY (modulebaytemplate_id) REFERENCES public.dcim_modulebaytemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_modulebaytemplate_module_bay_types dcim_modulebaytempla_modulebaytype_id_13a3815a_fk_dcim_modu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebaytemplate_module_bay_types
    ADD CONSTRAINT dcim_modulebaytempla_modulebaytype_id_13a3815a_fk_dcim_modu FOREIGN KEY (modulebaytype_id) REFERENCES public.dcim_modulebaytype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_modulebaytype dcim_modulebaytype_manufacturer_id_699547c4_fk_dcim_manu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebaytype
    ADD CONSTRAINT dcim_modulebaytype_manufacturer_id_699547c4_fk_dcim_manu FOREIGN KEY (manufacturer_id) REFERENCES public.dcim_manufacturer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_modulebaytype dcim_modulebaytype_owner_id_2a0cf25d_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_modulebaytype
    ADD CONSTRAINT dcim_modulebaytype_owner_id_2a0cf25d_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_moduletype dcim_moduletype_manufacturer_id_7347392e_fk_dcim_manu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_moduletype
    ADD CONSTRAINT dcim_moduletype_manufacturer_id_7347392e_fk_dcim_manu FOREIGN KEY (manufacturer_id) REFERENCES public.dcim_manufacturer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_moduletype_module_bay_types dcim_moduletype_modu_modulebaytype_id_04c73693_fk_dcim_modu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_moduletype_module_bay_types
    ADD CONSTRAINT dcim_moduletype_modu_modulebaytype_id_04c73693_fk_dcim_modu FOREIGN KEY (modulebaytype_id) REFERENCES public.dcim_modulebaytype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_moduletype_module_bay_types dcim_moduletype_modu_moduletype_id_4ff17f2d_fk_dcim_modu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_moduletype_module_bay_types
    ADD CONSTRAINT dcim_moduletype_modu_moduletype_id_4ff17f2d_fk_dcim_modu FOREIGN KEY (moduletype_id) REFERENCES public.dcim_moduletype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_moduletype dcim_moduletype_owner_id_2ea2fd3b_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_moduletype
    ADD CONSTRAINT dcim_moduletype_owner_id_2ea2fd3b_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_moduletype dcim_moduletype_profile_id_62b5d02d_fk_dcim_modu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_moduletype
    ADD CONSTRAINT dcim_moduletype_profile_id_62b5d02d_fk_dcim_modu FOREIGN KEY (profile_id) REFERENCES public.dcim_moduletypeprofile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_moduletypeprofile dcim_moduletypeprofile_owner_id_c4488ff6_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_moduletypeprofile
    ADD CONSTRAINT dcim_moduletypeprofile_owner_id_c4488ff6_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_platform dcim_platform_config_template_id_013a4d3c_fk_extras_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_platform
    ADD CONSTRAINT dcim_platform_config_template_id_013a4d3c_fk_extras_co FOREIGN KEY (config_template_id) REFERENCES public.extras_configtemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_platform dcim_platform_manufacturer_id_83f72d3d_fk_dcim_manufacturer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_platform
    ADD CONSTRAINT dcim_platform_manufacturer_id_83f72d3d_fk_dcim_manufacturer_id FOREIGN KEY (manufacturer_id) REFERENCES public.dcim_manufacturer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_platform dcim_platform_owner_id_0990eb87_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_platform
    ADD CONSTRAINT dcim_platform_owner_id_0990eb87_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_platform dcim_platform_parent_id_795c7101_fk_dcim_platform_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_platform
    ADD CONSTRAINT dcim_platform_parent_id_795c7101_fk_dcim_platform_id FOREIGN KEY (parent_id) REFERENCES public.dcim_platform(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_portmapping dcim_portmapping_device_id_eb86e378_fk_dcim_device_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_portmapping
    ADD CONSTRAINT dcim_portmapping_device_id_eb86e378_fk_dcim_device_id FOREIGN KEY (device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_portmapping dcim_portmapping_front_port_id_d8413d45_fk_dcim_frontport_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_portmapping
    ADD CONSTRAINT dcim_portmapping_front_port_id_d8413d45_fk_dcim_frontport_id FOREIGN KEY (front_port_id) REFERENCES public.dcim_frontport(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_portmapping dcim_portmapping_rear_port_id_dc3fb4b8_fk_dcim_rearport_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_portmapping
    ADD CONSTRAINT dcim_portmapping_rear_port_id_dc3fb4b8_fk_dcim_rearport_id FOREIGN KEY (rear_port_id) REFERENCES public.dcim_rearport(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_porttemplatemapping dcim_porttemplatemap_device_type_id_dede0eeb_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_porttemplatemapping
    ADD CONSTRAINT dcim_porttemplatemap_device_type_id_dede0eeb_fk_dcim_devi FOREIGN KEY (device_type_id) REFERENCES public.dcim_devicetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_porttemplatemapping dcim_porttemplatemap_front_port_id_090c3c11_fk_dcim_fron; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_porttemplatemapping
    ADD CONSTRAINT dcim_porttemplatemap_front_port_id_090c3c11_fk_dcim_fron FOREIGN KEY (front_port_id) REFERENCES public.dcim_frontporttemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_porttemplatemapping dcim_porttemplatemap_module_type_id_3a84e529_fk_dcim_modu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_porttemplatemapping
    ADD CONSTRAINT dcim_porttemplatemap_module_type_id_3a84e529_fk_dcim_modu FOREIGN KEY (module_type_id) REFERENCES public.dcim_moduletype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_porttemplatemapping dcim_porttemplatemap_rear_port_id_93a9b08f_fk_dcim_rear; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_porttemplatemapping
    ADD CONSTRAINT dcim_porttemplatemap_rear_port_id_93a9b08f_fk_dcim_rear FOREIGN KEY (rear_port_id) REFERENCES public.dcim_rearporttemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerfeed dcim_powerfeed__path_id_a1ea1f28_fk_dcim_cablepath_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerfeed
    ADD CONSTRAINT dcim_powerfeed__path_id_a1ea1f28_fk_dcim_cablepath_id FOREIGN KEY (_path_id) REFERENCES public.dcim_cablepath(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerfeed dcim_powerfeed_cable_id_ec44c4f8_fk_dcim_cable_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerfeed
    ADD CONSTRAINT dcim_powerfeed_cable_id_ec44c4f8_fk_dcim_cable_id FOREIGN KEY (cable_id) REFERENCES public.dcim_cable(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerfeed dcim_powerfeed_owner_id_97320081_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerfeed
    ADD CONSTRAINT dcim_powerfeed_owner_id_97320081_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerfeed dcim_powerfeed_power_panel_id_32bde3be_fk_dcim_powerpanel_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerfeed
    ADD CONSTRAINT dcim_powerfeed_power_panel_id_32bde3be_fk_dcim_powerpanel_id FOREIGN KEY (power_panel_id) REFERENCES public.dcim_powerpanel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerfeed dcim_powerfeed_rack_id_7abba090_fk_dcim_rack_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerfeed
    ADD CONSTRAINT dcim_powerfeed_rack_id_7abba090_fk_dcim_rack_id FOREIGN KEY (rack_id) REFERENCES public.dcim_rack(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerfeed dcim_powerfeed_tenant_id_947bee85_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerfeed
    ADD CONSTRAINT dcim_powerfeed_tenant_id_947bee85_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_poweroutlet dcim_poweroutlet__location_id_49563316_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_poweroutlet
    ADD CONSTRAINT dcim_poweroutlet__location_id_49563316_fk_dcim_location_id FOREIGN KEY (_location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_poweroutlet dcim_poweroutlet__path_id_cbb47bb9_fk_dcim_cablepath_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_poweroutlet
    ADD CONSTRAINT dcim_poweroutlet__path_id_cbb47bb9_fk_dcim_cablepath_id FOREIGN KEY (_path_id) REFERENCES public.dcim_cablepath(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_poweroutlet dcim_poweroutlet__rack_id_aca89672_fk_dcim_rack_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_poweroutlet
    ADD CONSTRAINT dcim_poweroutlet__rack_id_aca89672_fk_dcim_rack_id FOREIGN KEY (_rack_id) REFERENCES public.dcim_rack(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_poweroutlet dcim_poweroutlet__site_id_a956755e_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_poweroutlet
    ADD CONSTRAINT dcim_poweroutlet__site_id_a956755e_fk_dcim_site_id FOREIGN KEY (_site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_poweroutlet dcim_poweroutlet_cable_id_8dbea1ec_fk_dcim_cable_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_poweroutlet
    ADD CONSTRAINT dcim_poweroutlet_cable_id_8dbea1ec_fk_dcim_cable_id FOREIGN KEY (cable_id) REFERENCES public.dcim_cable(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_poweroutlet dcim_poweroutlet_device_id_286351d7_fk_dcim_device_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_poweroutlet
    ADD CONSTRAINT dcim_poweroutlet_device_id_286351d7_fk_dcim_device_id FOREIGN KEY (device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_poweroutlet dcim_poweroutlet_module_id_032f5af2_fk_dcim_module_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_poweroutlet
    ADD CONSTRAINT dcim_poweroutlet_module_id_032f5af2_fk_dcim_module_id FOREIGN KEY (module_id) REFERENCES public.dcim_module(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_poweroutlet dcim_poweroutlet_owner_id_0806d01d_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_poweroutlet
    ADD CONSTRAINT dcim_poweroutlet_owner_id_0806d01d_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_poweroutlet dcim_poweroutlet_power_port_id_9bdf4163_fk_dcim_powerport_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_poweroutlet
    ADD CONSTRAINT dcim_poweroutlet_power_port_id_9bdf4163_fk_dcim_powerport_id FOREIGN KEY (power_port_id) REFERENCES public.dcim_powerport(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_poweroutlettemplate dcim_poweroutlettemp_device_type_id_26b2316c_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_poweroutlettemplate
    ADD CONSTRAINT dcim_poweroutlettemp_device_type_id_26b2316c_fk_dcim_devi FOREIGN KEY (device_type_id) REFERENCES public.dcim_devicetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_poweroutlettemplate dcim_poweroutlettemp_module_type_id_6142b416_fk_dcim_modu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_poweroutlettemplate
    ADD CONSTRAINT dcim_poweroutlettemp_module_type_id_6142b416_fk_dcim_modu FOREIGN KEY (module_type_id) REFERENCES public.dcim_moduletype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_poweroutlettemplate dcim_poweroutlettemp_power_port_id_c0fb0c42_fk_dcim_powe; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_poweroutlettemplate
    ADD CONSTRAINT dcim_poweroutlettemp_power_port_id_c0fb0c42_fk_dcim_powe FOREIGN KEY (power_port_id) REFERENCES public.dcim_powerporttemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerpanel dcim_powerpanel_location_id_474b60f8_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerpanel
    ADD CONSTRAINT dcim_powerpanel_location_id_474b60f8_fk_dcim_location_id FOREIGN KEY (location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerpanel dcim_powerpanel_owner_id_11e7d421_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerpanel
    ADD CONSTRAINT dcim_powerpanel_owner_id_11e7d421_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerpanel dcim_powerpanel_site_id_c430bc89_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerpanel
    ADD CONSTRAINT dcim_powerpanel_site_id_c430bc89_fk_dcim_site_id FOREIGN KEY (site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerport dcim_powerport__location_id_ccf995e7_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerport
    ADD CONSTRAINT dcim_powerport__location_id_ccf995e7_fk_dcim_location_id FOREIGN KEY (_location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerport dcim_powerport__path_id_9fe4af8f_fk_dcim_cablepath_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerport
    ADD CONSTRAINT dcim_powerport__path_id_9fe4af8f_fk_dcim_cablepath_id FOREIGN KEY (_path_id) REFERENCES public.dcim_cablepath(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerport dcim_powerport__rack_id_4c1c316d_fk_dcim_rack_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerport
    ADD CONSTRAINT dcim_powerport__rack_id_4c1c316d_fk_dcim_rack_id FOREIGN KEY (_rack_id) REFERENCES public.dcim_rack(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerport dcim_powerport__site_id_87bfa142_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerport
    ADD CONSTRAINT dcim_powerport__site_id_87bfa142_fk_dcim_site_id FOREIGN KEY (_site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerport dcim_powerport_cable_id_c9682ba2_fk_dcim_cable_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerport
    ADD CONSTRAINT dcim_powerport_cable_id_c9682ba2_fk_dcim_cable_id FOREIGN KEY (cable_id) REFERENCES public.dcim_cable(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerport dcim_powerport_device_id_ef7185ae_fk_dcim_device_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerport
    ADD CONSTRAINT dcim_powerport_device_id_ef7185ae_fk_dcim_device_id FOREIGN KEY (device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerport dcim_powerport_module_id_d0c27534_fk_dcim_module_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerport
    ADD CONSTRAINT dcim_powerport_module_id_d0c27534_fk_dcim_module_id FOREIGN KEY (module_id) REFERENCES public.dcim_module(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerport dcim_powerport_owner_id_b83ff931_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerport
    ADD CONSTRAINT dcim_powerport_owner_id_b83ff931_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerporttemplate dcim_powerporttempla_device_type_id_1ddfbfcc_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerporttemplate
    ADD CONSTRAINT dcim_powerporttempla_device_type_id_1ddfbfcc_fk_dcim_devi FOREIGN KEY (device_type_id) REFERENCES public.dcim_devicetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_powerporttemplate dcim_powerporttempla_module_type_id_93e26849_fk_dcim_modu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_powerporttemplate
    ADD CONSTRAINT dcim_powerporttempla_module_type_id_93e26849_fk_dcim_modu FOREIGN KEY (module_type_id) REFERENCES public.dcim_moduletype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rack dcim_rack_group_id_44e90ea9_fk_dcim_rackgroup_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rack
    ADD CONSTRAINT dcim_rack_group_id_44e90ea9_fk_dcim_rackgroup_id FOREIGN KEY (group_id) REFERENCES public.dcim_rackgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rack dcim_rack_location_id_5f63ec31_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rack
    ADD CONSTRAINT dcim_rack_location_id_5f63ec31_fk_dcim_location_id FOREIGN KEY (location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rack dcim_rack_owner_id_7a5532fc_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rack
    ADD CONSTRAINT dcim_rack_owner_id_7a5532fc_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rack dcim_rack_rack_type_id_39433a22_fk_dcim_racktype_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rack
    ADD CONSTRAINT dcim_rack_rack_type_id_39433a22_fk_dcim_racktype_id FOREIGN KEY (rack_type_id) REFERENCES public.dcim_racktype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rack dcim_rack_role_id_62d6919e_fk_dcim_rackrole_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rack
    ADD CONSTRAINT dcim_rack_role_id_62d6919e_fk_dcim_rackrole_id FOREIGN KEY (role_id) REFERENCES public.dcim_rackrole(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rack dcim_rack_site_id_403c7b3a_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rack
    ADD CONSTRAINT dcim_rack_site_id_403c7b3a_fk_dcim_site_id FOREIGN KEY (site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rack dcim_rack_tenant_id_7cdf3725_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rack
    ADD CONSTRAINT dcim_rack_tenant_id_7cdf3725_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rackgroup dcim_rackgroup_owner_id_5484beb8_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rackgroup
    ADD CONSTRAINT dcim_rackgroup_owner_id_5484beb8_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rackreservation dcim_rackreservation_owner_id_12c19e94_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rackreservation
    ADD CONSTRAINT dcim_rackreservation_owner_id_12c19e94_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rackreservation dcim_rackreservation_rack_id_1ebbaa9b_fk_dcim_rack_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rackreservation
    ADD CONSTRAINT dcim_rackreservation_rack_id_1ebbaa9b_fk_dcim_rack_id FOREIGN KEY (rack_id) REFERENCES public.dcim_rack(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rackreservation dcim_rackreservation_tenant_id_eb5e045f_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rackreservation
    ADD CONSTRAINT dcim_rackreservation_tenant_id_eb5e045f_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rackreservation dcim_rackreservation_user_id_0785a527_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rackreservation
    ADD CONSTRAINT dcim_rackreservation_user_id_0785a527_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rackrole dcim_rackrole_owner_id_fb6f0b77_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rackrole
    ADD CONSTRAINT dcim_rackrole_owner_id_fb6f0b77_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_racktype dcim_racktype_manufacturer_id_d46a05c6_fk_dcim_manufacturer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_racktype
    ADD CONSTRAINT dcim_racktype_manufacturer_id_d46a05c6_fk_dcim_manufacturer_id FOREIGN KEY (manufacturer_id) REFERENCES public.dcim_manufacturer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_racktype dcim_racktype_owner_id_ce0a0d75_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_racktype
    ADD CONSTRAINT dcim_racktype_owner_id_ce0a0d75_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rearport dcim_rearport__location_id_72554006_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rearport
    ADD CONSTRAINT dcim_rearport__location_id_72554006_fk_dcim_location_id FOREIGN KEY (_location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rearport dcim_rearport__rack_id_9af9a402_fk_dcim_rack_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rearport
    ADD CONSTRAINT dcim_rearport__rack_id_9af9a402_fk_dcim_rack_id FOREIGN KEY (_rack_id) REFERENCES public.dcim_rack(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rearport dcim_rearport__site_id_35e05ccf_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rearport
    ADD CONSTRAINT dcim_rearport__site_id_35e05ccf_fk_dcim_site_id FOREIGN KEY (_site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rearport dcim_rearport_cable_id_42c0e4e7_fk_dcim_cable_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rearport
    ADD CONSTRAINT dcim_rearport_cable_id_42c0e4e7_fk_dcim_cable_id FOREIGN KEY (cable_id) REFERENCES public.dcim_cable(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rearport dcim_rearport_device_id_0bdfe9c0_fk_dcim_device_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rearport
    ADD CONSTRAINT dcim_rearport_device_id_0bdfe9c0_fk_dcim_device_id FOREIGN KEY (device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rearport dcim_rearport_module_id_9a7b7e91_fk_dcim_module_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rearport
    ADD CONSTRAINT dcim_rearport_module_id_9a7b7e91_fk_dcim_module_id FOREIGN KEY (module_id) REFERENCES public.dcim_module(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rearport dcim_rearport_owner_id_51174512_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rearport
    ADD CONSTRAINT dcim_rearport_owner_id_51174512_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rearporttemplate dcim_rearporttemplat_device_type_id_6a02fd01_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rearporttemplate
    ADD CONSTRAINT dcim_rearporttemplat_device_type_id_6a02fd01_fk_dcim_devi FOREIGN KEY (device_type_id) REFERENCES public.dcim_devicetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_rearporttemplate dcim_rearporttemplat_module_type_id_4d970e5b_fk_dcim_modu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_rearporttemplate
    ADD CONSTRAINT dcim_rearporttemplat_module_type_id_4d970e5b_fk_dcim_modu FOREIGN KEY (module_type_id) REFERENCES public.dcim_moduletype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_region dcim_region_owner_id_7e9d3adf_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_region
    ADD CONSTRAINT dcim_region_owner_id_7e9d3adf_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_region dcim_region_parent_id_2486f5d4_fk_dcim_region_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_region
    ADD CONSTRAINT dcim_region_parent_id_2486f5d4_fk_dcim_region_id FOREIGN KEY (parent_id) REFERENCES public.dcim_region(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_site_asns dcim_site_asns_asn_id_3cfd0f00_fk_ipam_asn_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_site_asns
    ADD CONSTRAINT dcim_site_asns_asn_id_3cfd0f00_fk_ipam_asn_id FOREIGN KEY (asn_id) REFERENCES public.ipam_asn(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_site_asns dcim_site_asns_site_id_112ccacf_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_site_asns
    ADD CONSTRAINT dcim_site_asns_site_id_112ccacf_fk_dcim_site_id FOREIGN KEY (site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_site dcim_site_group_id_3910c975_fk_dcim_sitegroup_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_site
    ADD CONSTRAINT dcim_site_group_id_3910c975_fk_dcim_sitegroup_id FOREIGN KEY (group_id) REFERENCES public.dcim_sitegroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_site dcim_site_owner_id_ef94687e_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_site
    ADD CONSTRAINT dcim_site_owner_id_ef94687e_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_site dcim_site_region_id_45210932_fk_dcim_region_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_site
    ADD CONSTRAINT dcim_site_region_id_45210932_fk_dcim_region_id FOREIGN KEY (region_id) REFERENCES public.dcim_region(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_site dcim_site_tenant_id_15e7df63_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_site
    ADD CONSTRAINT dcim_site_tenant_id_15e7df63_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_sitegroup dcim_sitegroup_owner_id_50283a64_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_sitegroup
    ADD CONSTRAINT dcim_sitegroup_owner_id_50283a64_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_sitegroup dcim_sitegroup_parent_id_533a5e44_fk_dcim_sitegroup_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_sitegroup
    ADD CONSTRAINT dcim_sitegroup_parent_id_533a5e44_fk_dcim_sitegroup_id FOREIGN KEY (parent_id) REFERENCES public.dcim_sitegroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_virtualchassis dcim_virtualchassis_master_id_ab54cfc6_fk_dcim_device_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_virtualchassis
    ADD CONSTRAINT dcim_virtualchassis_master_id_ab54cfc6_fk_dcim_device_id FOREIGN KEY (master_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_virtualchassis dcim_virtualchassis_owner_id_76116efe_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_virtualchassis
    ADD CONSTRAINT dcim_virtualchassis_owner_id_76116efe_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_virtualdevicecontext dcim_virtualdeviceco_primary_ip4_id_6bd0605b_fk_ipam_ipad; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_virtualdevicecontext
    ADD CONSTRAINT dcim_virtualdeviceco_primary_ip4_id_6bd0605b_fk_ipam_ipad FOREIGN KEY (primary_ip4_id) REFERENCES public.ipam_ipaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_virtualdevicecontext dcim_virtualdeviceco_primary_ip6_id_ed3b81bd_fk_ipam_ipad; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_virtualdevicecontext
    ADD CONSTRAINT dcim_virtualdeviceco_primary_ip6_id_ed3b81bd_fk_ipam_ipad FOREIGN KEY (primary_ip6_id) REFERENCES public.ipam_ipaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_virtualdevicecontext dcim_virtualdeviceco_tenant_id_b6a21753_fk_tenancy_t; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_virtualdevicecontext
    ADD CONSTRAINT dcim_virtualdeviceco_tenant_id_b6a21753_fk_tenancy_t FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_virtualdevicecontext dcim_virtualdevicecontext_device_id_4f39274b_fk_dcim_device_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_virtualdevicecontext
    ADD CONSTRAINT dcim_virtualdevicecontext_device_id_4f39274b_fk_dcim_device_id FOREIGN KEY (device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcim_virtualdevicecontext dcim_virtualdevicecontext_owner_id_33c19ef7_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dcim_virtualdevicecontext
    ADD CONSTRAINT dcim_virtualdevicecontext_owner_id_33c19ef7_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_bookmark extras_bookmark_object_type_id_18c4bb44_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_bookmark
    ADD CONSTRAINT extras_bookmark_object_type_id_18c4bb44_fk_django_co FOREIGN KEY (object_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_bookmark extras_bookmark_user_id_cb6c6677_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_bookmark
    ADD CONSTRAINT extras_bookmark_user_id_cb6c6677_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_cachedvalue extras_cachedvalue_object_type_id_6f47d444_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_cachedvalue
    ADD CONSTRAINT extras_cachedvalue_object_type_id_6f47d444_fk_django_co FOREIGN KEY (object_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_clusters extras_configcontext_cluster_id_6abd47a1_fk_virtualiz; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_clusters
    ADD CONSTRAINT extras_configcontext_cluster_id_6abd47a1_fk_virtualiz FOREIGN KEY (cluster_id) REFERENCES public.virtualization_cluster(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_cluster_groups extras_configcontext_clustergroup_id_f4322ce8_fk_virtualiz; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_cluster_groups
    ADD CONSTRAINT extras_configcontext_clustergroup_id_f4322ce8_fk_virtualiz FOREIGN KEY (clustergroup_id) REFERENCES public.virtualization_clustergroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_cluster_types extras_configcontext_clustertype_id_fa493b64_fk_virtualiz; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_cluster_types
    ADD CONSTRAINT extras_configcontext_clustertype_id_fa493b64_fk_virtualiz FOREIGN KEY (clustertype_id) REFERENCES public.virtualization_clustertype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_platforms extras_configcontext_configcontext_id_2a516699_fk_extras_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_platforms
    ADD CONSTRAINT extras_configcontext_configcontext_id_2a516699_fk_extras_co FOREIGN KEY (configcontext_id) REFERENCES public.extras_configcontext(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_site_groups extras_configcontext_configcontext_id_2e0f43cb_fk_extras_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_site_groups
    ADD CONSTRAINT extras_configcontext_configcontext_id_2e0f43cb_fk_extras_co FOREIGN KEY (configcontext_id) REFERENCES public.extras_configcontext(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_device_types extras_configcontext_configcontext_id_55632923_fk_extras_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_device_types
    ADD CONSTRAINT extras_configcontext_configcontext_id_55632923_fk_extras_co FOREIGN KEY (configcontext_id) REFERENCES public.extras_configcontext(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_roles extras_configcontext_configcontext_id_59b67386_fk_extras_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_roles
    ADD CONSTRAINT extras_configcontext_configcontext_id_59b67386_fk_extras_co FOREIGN KEY (configcontext_id) REFERENCES public.extras_configcontext(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_tags extras_configcontext_configcontext_id_64a392b1_fk_extras_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_tags
    ADD CONSTRAINT extras_configcontext_configcontext_id_64a392b1_fk_extras_co FOREIGN KEY (configcontext_id) REFERENCES public.extras_configcontext(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_regions extras_configcontext_configcontext_id_73003dbc_fk_extras_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_regions
    ADD CONSTRAINT extras_configcontext_configcontext_id_73003dbc_fk_extras_co FOREIGN KEY (configcontext_id) REFERENCES public.extras_configcontext(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_sites extras_configcontext_configcontext_id_8c54feb9_fk_extras_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_sites
    ADD CONSTRAINT extras_configcontext_configcontext_id_8c54feb9_fk_extras_co FOREIGN KEY (configcontext_id) REFERENCES public.extras_configcontext(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_cluster_groups extras_configcontext_configcontext_id_8f50b794_fk_extras_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_cluster_groups
    ADD CONSTRAINT extras_configcontext_configcontext_id_8f50b794_fk_extras_co FOREIGN KEY (configcontext_id) REFERENCES public.extras_configcontext(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_tenant_groups extras_configcontext_configcontext_id_92f68345_fk_extras_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_tenant_groups
    ADD CONSTRAINT extras_configcontext_configcontext_id_92f68345_fk_extras_co FOREIGN KEY (configcontext_id) REFERENCES public.extras_configcontext(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_tenants extras_configcontext_configcontext_id_b53552a6_fk_extras_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_tenants
    ADD CONSTRAINT extras_configcontext_configcontext_id_b53552a6_fk_extras_co FOREIGN KEY (configcontext_id) REFERENCES public.extras_configcontext(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_locations extras_configcontext_configcontext_id_cc629ec1_fk_extras_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_locations
    ADD CONSTRAINT extras_configcontext_configcontext_id_cc629ec1_fk_extras_co FOREIGN KEY (configcontext_id) REFERENCES public.extras_configcontext(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_cluster_types extras_configcontext_configcontext_id_d549b6f2_fk_extras_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_cluster_types
    ADD CONSTRAINT extras_configcontext_configcontext_id_d549b6f2_fk_extras_co FOREIGN KEY (configcontext_id) REFERENCES public.extras_configcontext(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_clusters extras_configcontext_configcontext_id_ed579a40_fk_extras_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_clusters
    ADD CONSTRAINT extras_configcontext_configcontext_id_ed579a40_fk_extras_co FOREIGN KEY (configcontext_id) REFERENCES public.extras_configcontext(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext extras_configcontext_data_file_id_8fdd620b_fk_core_datafile_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext
    ADD CONSTRAINT extras_configcontext_data_file_id_8fdd620b_fk_core_datafile_id FOREIGN KEY (data_file_id) REFERENCES public.core_datafile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontextprofile extras_configcontext_data_file_id_e0caf376_fk_core_data; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontextprofile
    ADD CONSTRAINT extras_configcontext_data_file_id_e0caf376_fk_core_data FOREIGN KEY (data_file_id) REFERENCES public.core_datafile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext extras_configcontext_data_source_id_1b2eb8af_fk_core_data; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext
    ADD CONSTRAINT extras_configcontext_data_source_id_1b2eb8af_fk_core_data FOREIGN KEY (data_source_id) REFERENCES public.core_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontextprofile extras_configcontext_data_source_id_b88dd849_fk_core_data; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontextprofile
    ADD CONSTRAINT extras_configcontext_data_source_id_b88dd849_fk_core_data FOREIGN KEY (data_source_id) REFERENCES public.core_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_roles extras_configcontext_devicerole_id_d3a84813_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_roles
    ADD CONSTRAINT extras_configcontext_devicerole_id_d3a84813_fk_dcim_devi FOREIGN KEY (devicerole_id) REFERENCES public.dcim_devicerole(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_device_types extras_configcontext_devicetype_id_b8788c2d_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_device_types
    ADD CONSTRAINT extras_configcontext_devicetype_id_b8788c2d_fk_dcim_devi FOREIGN KEY (devicetype_id) REFERENCES public.dcim_devicetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_locations extras_configcontext_location_id_9e19eac9_fk_dcim_loca; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_locations
    ADD CONSTRAINT extras_configcontext_location_id_9e19eac9_fk_dcim_loca FOREIGN KEY (location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext extras_configcontext_owner_id_6c8d9a06_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext
    ADD CONSTRAINT extras_configcontext_owner_id_6c8d9a06_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_platforms extras_configcontext_platform_id_3fdfedc0_fk_dcim_plat; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_platforms
    ADD CONSTRAINT extras_configcontext_platform_id_3fdfedc0_fk_dcim_plat FOREIGN KEY (platform_id) REFERENCES public.dcim_platform(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext extras_configcontext_profile_id_48c7bc6a_fk_extras_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext
    ADD CONSTRAINT extras_configcontext_profile_id_48c7bc6a_fk_extras_co FOREIGN KEY (profile_id) REFERENCES public.extras_configcontextprofile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_regions extras_configcontext_region_id_35c6ba9d_fk_dcim_regi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_regions
    ADD CONSTRAINT extras_configcontext_region_id_35c6ba9d_fk_dcim_regi FOREIGN KEY (region_id) REFERENCES public.dcim_region(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_site_groups extras_configcontext_sitegroup_id_3287c9e7_fk_dcim_site; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_site_groups
    ADD CONSTRAINT extras_configcontext_sitegroup_id_3287c9e7_fk_dcim_site FOREIGN KEY (sitegroup_id) REFERENCES public.dcim_sitegroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_sites extras_configcontext_sites_site_id_cbb76c96_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_sites
    ADD CONSTRAINT extras_configcontext_sites_site_id_cbb76c96_fk_dcim_site_id FOREIGN KEY (site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_tags extras_configcontext_tags_tag_id_129a5d87_fk_extras_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_tags
    ADD CONSTRAINT extras_configcontext_tags_tag_id_129a5d87_fk_extras_tag_id FOREIGN KEY (tag_id) REFERENCES public.extras_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_tenants extras_configcontext_tenant_id_8d0aa28e_fk_tenancy_t; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_tenants
    ADD CONSTRAINT extras_configcontext_tenant_id_8d0aa28e_fk_tenancy_t FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontext_tenant_groups extras_configcontext_tenantgroup_id_0909688d_fk_tenancy_t; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontext_tenant_groups
    ADD CONSTRAINT extras_configcontext_tenantgroup_id_0909688d_fk_tenancy_t FOREIGN KEY (tenantgroup_id) REFERENCES public.tenancy_tenantgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configcontextprofile extras_configcontextprofile_owner_id_6b1a975e_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configcontextprofile
    ADD CONSTRAINT extras_configcontextprofile_owner_id_6b1a975e_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configtemplate extras_configtemplat_data_source_id_f9d26d5d_fk_core_data; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configtemplate
    ADD CONSTRAINT extras_configtemplat_data_source_id_f9d26d5d_fk_core_data FOREIGN KEY (data_source_id) REFERENCES public.core_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configtemplate extras_configtemplate_data_file_id_20c7cff4_fk_core_datafile_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configtemplate
    ADD CONSTRAINT extras_configtemplate_data_file_id_20c7cff4_fk_core_datafile_id FOREIGN KEY (data_file_id) REFERENCES public.core_datafile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_configtemplate extras_configtemplate_owner_id_0925c336_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_configtemplate
    ADD CONSTRAINT extras_configtemplate_owner_id_0925c336_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_customfield_object_types extras_customfield_c_customfield_id_3842aaf3_fk_extras_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customfield_object_types
    ADD CONSTRAINT extras_customfield_c_customfield_id_3842aaf3_fk_extras_cu FOREIGN KEY (customfield_id) REFERENCES public.extras_customfield(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_customfield extras_customfield_choice_set_id_5590efc2_fk_extras_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customfield
    ADD CONSTRAINT extras_customfield_choice_set_id_5590efc2_fk_extras_cu FOREIGN KEY (choice_set_id) REFERENCES public.extras_customfieldchoiceset(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_customfield_object_types extras_customfield_o_contenttype_id_d9167062_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customfield_object_types
    ADD CONSTRAINT extras_customfield_o_contenttype_id_d9167062_fk_django_co FOREIGN KEY (contenttype_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_customfield extras_customfield_owner_id_558f69a3_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customfield
    ADD CONSTRAINT extras_customfield_owner_id_558f69a3_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_customfield extras_customfield_related_object_type__fa9aa45b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customfield
    ADD CONSTRAINT extras_customfield_related_object_type__fa9aa45b_fk_django_co FOREIGN KEY (related_object_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_customfieldchoiceset extras_customfieldchoiceset_owner_id_02d6fc4d_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customfieldchoiceset
    ADD CONSTRAINT extras_customfieldchoiceset_owner_id_02d6fc4d_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_customlink_object_types extras_customlink_co_customlink_id_229ba2bc_fk_extras_cu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customlink_object_types
    ADD CONSTRAINT extras_customlink_co_customlink_id_229ba2bc_fk_extras_cu FOREIGN KEY (customlink_id) REFERENCES public.extras_customlink(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_customlink_object_types extras_customlink_ob_contenttype_id_600977f4_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customlink_object_types
    ADD CONSTRAINT extras_customlink_ob_contenttype_id_600977f4_fk_django_co FOREIGN KEY (contenttype_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_customlink extras_customlink_owner_id_b4449049_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_customlink
    ADD CONSTRAINT extras_customlink_owner_id_b4449049_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_dashboard extras_dashboard_user_id_f1e1278b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_dashboard
    ADD CONSTRAINT extras_dashboard_user_id_f1e1278b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_eventrule extras_eventrule_action_object_type_i_1fe8a82e_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_eventrule
    ADD CONSTRAINT extras_eventrule_action_object_type_i_1fe8a82e_fk_django_co FOREIGN KEY (action_object_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_eventrule_object_types extras_eventrule_con_eventrule_id_c177fa54_fk_extras_ev; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_eventrule_object_types
    ADD CONSTRAINT extras_eventrule_con_eventrule_id_c177fa54_fk_extras_ev FOREIGN KEY (eventrule_id) REFERENCES public.extras_eventrule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_eventrule_object_types extras_eventrule_obj_contenttype_id_1ec4bbcc_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_eventrule_object_types
    ADD CONSTRAINT extras_eventrule_obj_contenttype_id_1ec4bbcc_fk_django_co FOREIGN KEY (contenttype_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_eventrule extras_eventrule_owner_id_a4c56a12_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_eventrule
    ADD CONSTRAINT extras_eventrule_owner_id_a4c56a12_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_exporttemplate_object_types extras_exporttemplat_contenttype_id_0f034708_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_exporttemplate_object_types
    ADD CONSTRAINT extras_exporttemplat_contenttype_id_0f034708_fk_django_co FOREIGN KEY (contenttype_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_exporttemplate extras_exporttemplat_data_source_id_d61d0feb_fk_core_data; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_exporttemplate
    ADD CONSTRAINT extras_exporttemplat_data_source_id_d61d0feb_fk_core_data FOREIGN KEY (data_source_id) REFERENCES public.core_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_exporttemplate_object_types extras_exporttemplat_exporttemplate_id_7645f081_fk_extras_ex; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_exporttemplate_object_types
    ADD CONSTRAINT extras_exporttemplat_exporttemplate_id_7645f081_fk_extras_ex FOREIGN KEY (exporttemplate_id) REFERENCES public.extras_exporttemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_exporttemplate extras_exporttemplate_data_file_id_40a91ef8_fk_core_datafile_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_exporttemplate
    ADD CONSTRAINT extras_exporttemplate_data_file_id_40a91ef8_fk_core_datafile_id FOREIGN KEY (data_file_id) REFERENCES public.core_datafile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_exporttemplate extras_exporttemplate_owner_id_a690b184_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_exporttemplate
    ADD CONSTRAINT extras_exporttemplate_owner_id_a690b184_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_imageattachment extras_imageattachme_object_type_id_a9400c38_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_imageattachment
    ADD CONSTRAINT extras_imageattachme_object_type_id_a9400c38_fk_django_co FOREIGN KEY (object_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_journalentry extras_journalentry_assigned_object_type_1bba9f68_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_journalentry
    ADD CONSTRAINT extras_journalentry_assigned_object_type_1bba9f68_fk_django_co FOREIGN KEY (assigned_object_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_journalentry extras_journalentry_created_by_id_8d4e4329_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_journalentry
    ADD CONSTRAINT extras_journalentry_created_by_id_8d4e4329_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_notification extras_notification_object_type_id_2efeb525_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_notification
    ADD CONSTRAINT extras_notification_object_type_id_2efeb525_fk_django_co FOREIGN KEY (object_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_notification extras_notification_user_id_4d8c96f5_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_notification
    ADD CONSTRAINT extras_notification_user_id_4d8c96f5_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_notificationgroup_groups extras_notificationg_group_id_af4b7b6c_fk_users_gro; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_notificationgroup_groups
    ADD CONSTRAINT extras_notificationg_group_id_af4b7b6c_fk_users_gro FOREIGN KEY (group_id) REFERENCES public.users_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_notificationgroup_users extras_notificationg_notificationgroup_id_0a8ec85c_fk_extras_no; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_notificationgroup_users
    ADD CONSTRAINT extras_notificationg_notificationgroup_id_0a8ec85c_fk_extras_no FOREIGN KEY (notificationgroup_id) REFERENCES public.extras_notificationgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_notificationgroup_groups extras_notificationg_notificationgroup_id_a41469f7_fk_extras_no; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_notificationgroup_groups
    ADD CONSTRAINT extras_notificationg_notificationgroup_id_a41469f7_fk_extras_no FOREIGN KEY (notificationgroup_id) REFERENCES public.extras_notificationgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_notificationgroup_users extras_notificationg_user_id_2c30da19_fk_users_use; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_notificationgroup_users
    ADD CONSTRAINT extras_notificationg_user_id_2c30da19_fk_users_use FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_savedfilter_object_types extras_savedfilter_c_savedfilter_id_1631b88b_fk_extras_sa; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_savedfilter_object_types
    ADD CONSTRAINT extras_savedfilter_c_savedfilter_id_1631b88b_fk_extras_sa FOREIGN KEY (savedfilter_id) REFERENCES public.extras_savedfilter(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_savedfilter_object_types extras_savedfilter_o_contenttype_id_bbf68799_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_savedfilter_object_types
    ADD CONSTRAINT extras_savedfilter_o_contenttype_id_bbf68799_fk_django_co FOREIGN KEY (contenttype_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_savedfilter extras_savedfilter_owner_id_e022149a_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_savedfilter
    ADD CONSTRAINT extras_savedfilter_owner_id_e022149a_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_savedfilter extras_savedfilter_user_id_10502e81_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_savedfilter
    ADD CONSTRAINT extras_savedfilter_user_id_10502e81_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_script extras_script_module_id_af9cffaa_fk_core_managedfile_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_script
    ADD CONSTRAINT extras_script_module_id_af9cffaa_fk_core_managedfile_id FOREIGN KEY (module_id) REFERENCES public.core_managedfile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_subscription extras_subscription_object_type_id_e53297d2_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_subscription
    ADD CONSTRAINT extras_subscription_object_type_id_e53297d2_fk_django_co FOREIGN KEY (object_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_subscription extras_subscription_user_id_37472a14_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_subscription
    ADD CONSTRAINT extras_subscription_user_id_37472a14_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_tableconfig extras_tableconfig_object_type_id_e43ad6ad_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_tableconfig
    ADD CONSTRAINT extras_tableconfig_object_type_id_e43ad6ad_fk_django_co FOREIGN KEY (object_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_tableconfig extras_tableconfig_user_id_0b525dff_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_tableconfig
    ADD CONSTRAINT extras_tableconfig_user_id_0b525dff_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_tag_object_types extras_tag_object_ty_contenttype_id_c1b220c3_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_tag_object_types
    ADD CONSTRAINT extras_tag_object_ty_contenttype_id_c1b220c3_fk_django_co FOREIGN KEY (contenttype_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_tag_object_types extras_tag_object_types_tag_id_2e1aab29_fk_extras_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_tag_object_types
    ADD CONSTRAINT extras_tag_object_types_tag_id_2e1aab29_fk_extras_tag_id FOREIGN KEY (tag_id) REFERENCES public.extras_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_tag extras_tag_owner_id_ebb991ad_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_tag
    ADD CONSTRAINT extras_tag_owner_id_ebb991ad_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_taggeditem extras_taggeditem_content_type_id_ba5562ed_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_taggeditem
    ADD CONSTRAINT extras_taggeditem_content_type_id_ba5562ed_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_taggeditem extras_taggeditem_tag_id_d48af7c7_fk_extras_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_taggeditem
    ADD CONSTRAINT extras_taggeditem_tag_id_d48af7c7_fk_extras_tag_id FOREIGN KEY (tag_id) REFERENCES public.extras_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: extras_webhook extras_webhook_owner_id_bcf756a8_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.extras_webhook
    ADD CONSTRAINT extras_webhook_owner_id_bcf756a8_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_aggregate ipam_aggregate_owner_id_fdaa939f_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_aggregate
    ADD CONSTRAINT ipam_aggregate_owner_id_fdaa939f_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_aggregate ipam_aggregate_rir_id_ef7a27bd_fk_ipam_rir_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_aggregate
    ADD CONSTRAINT ipam_aggregate_rir_id_ef7a27bd_fk_ipam_rir_id FOREIGN KEY (rir_id) REFERENCES public.ipam_rir(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_aggregate ipam_aggregate_tenant_id_637dd1a1_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_aggregate
    ADD CONSTRAINT ipam_aggregate_tenant_id_637dd1a1_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_asn ipam_asn_owner_id_2ab253b3_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_asn
    ADD CONSTRAINT ipam_asn_owner_id_2ab253b3_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_asn ipam_asn_rir_id_f5ad3cff_fk_ipam_rir_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_asn
    ADD CONSTRAINT ipam_asn_rir_id_f5ad3cff_fk_ipam_rir_id FOREIGN KEY (rir_id) REFERENCES public.ipam_rir(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_asn ipam_asn_role_id_86d8acd4_fk_ipam_role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_asn
    ADD CONSTRAINT ipam_asn_role_id_86d8acd4_fk_ipam_role_id FOREIGN KEY (role_id) REFERENCES public.ipam_role(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_asn ipam_asn_tenant_id_07e8188e_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_asn
    ADD CONSTRAINT ipam_asn_tenant_id_07e8188e_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_asnrange ipam_asnrange_owner_id_a943e984_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_asnrange
    ADD CONSTRAINT ipam_asnrange_owner_id_a943e984_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_asnrange ipam_asnrange_rir_id_c9c31183_fk_ipam_rir_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_asnrange
    ADD CONSTRAINT ipam_asnrange_rir_id_c9c31183_fk_ipam_rir_id FOREIGN KEY (rir_id) REFERENCES public.ipam_rir(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_asnrange ipam_asnrange_tenant_id_ed8f80b7_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_asnrange
    ADD CONSTRAINT ipam_asnrange_tenant_id_ed8f80b7_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_fhrpgroup ipam_fhrpgroup_owner_id_f5209119_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_fhrpgroup
    ADD CONSTRAINT ipam_fhrpgroup_owner_id_f5209119_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_fhrpgroupassignment ipam_fhrpgroupassign_interface_type_id_f3bcb487_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_fhrpgroupassignment
    ADD CONSTRAINT ipam_fhrpgroupassign_interface_type_id_f3bcb487_fk_django_co FOREIGN KEY (interface_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_fhrpgroupassignment ipam_fhrpgroupassignment_group_id_19f15ca4_fk_ipam_fhrpgroup_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_fhrpgroupassignment
    ADD CONSTRAINT ipam_fhrpgroupassignment_group_id_19f15ca4_fk_ipam_fhrpgroup_id FOREIGN KEY (group_id) REFERENCES public.ipam_fhrpgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_ipaddress ipam_ipaddress_assigned_object_type_02354370_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_ipaddress
    ADD CONSTRAINT ipam_ipaddress_assigned_object_type_02354370_fk_django_co FOREIGN KEY (assigned_object_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_ipaddress ipam_ipaddress_nat_inside_id_a45fb7c5_fk_ipam_ipaddress_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_ipaddress
    ADD CONSTRAINT ipam_ipaddress_nat_inside_id_a45fb7c5_fk_ipam_ipaddress_id FOREIGN KEY (nat_inside_id) REFERENCES public.ipam_ipaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_ipaddress ipam_ipaddress_owner_id_47736b63_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_ipaddress
    ADD CONSTRAINT ipam_ipaddress_owner_id_47736b63_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_ipaddress ipam_ipaddress_tenant_id_ac55acfd_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_ipaddress
    ADD CONSTRAINT ipam_ipaddress_tenant_id_ac55acfd_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_ipaddress ipam_ipaddress_vrf_id_51fcc59b_fk_ipam_vrf_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_ipaddress
    ADD CONSTRAINT ipam_ipaddress_vrf_id_51fcc59b_fk_ipam_vrf_id FOREIGN KEY (vrf_id) REFERENCES public.ipam_vrf(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_iprange ipam_iprange_owner_id_b327afb7_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_iprange
    ADD CONSTRAINT ipam_iprange_owner_id_b327afb7_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_iprange ipam_iprange_role_id_2782e864_fk_ipam_role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_iprange
    ADD CONSTRAINT ipam_iprange_role_id_2782e864_fk_ipam_role_id FOREIGN KEY (role_id) REFERENCES public.ipam_role(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_iprange ipam_iprange_tenant_id_856027ea_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_iprange
    ADD CONSTRAINT ipam_iprange_tenant_id_856027ea_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_iprange ipam_iprange_vrf_id_613e9dd2_fk_ipam_vrf_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_iprange
    ADD CONSTRAINT ipam_iprange_vrf_id_613e9dd2_fk_ipam_vrf_id FOREIGN KEY (vrf_id) REFERENCES public.ipam_vrf(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_l2vpn_export_targets ipam_l2vpn_export_ta_routetarget_id_5ccb758b_fk_ipam_rout; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_l2vpn_export_targets
    ADD CONSTRAINT ipam_l2vpn_export_ta_routetarget_id_5ccb758b_fk_ipam_rout FOREIGN KEY (routetarget_id) REFERENCES public.ipam_routetarget(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_l2vpn_export_targets ipam_l2vpn_export_targets_l2vpn_id_8749bbe8_fk_ipam_l2vpn_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_l2vpn_export_targets
    ADD CONSTRAINT ipam_l2vpn_export_targets_l2vpn_id_8749bbe8_fk_ipam_l2vpn_id FOREIGN KEY (l2vpn_id) REFERENCES public.vpn_l2vpn(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_l2vpn_import_targets ipam_l2vpn_import_ta_routetarget_id_58a188b2_fk_ipam_rout; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_l2vpn_import_targets
    ADD CONSTRAINT ipam_l2vpn_import_ta_routetarget_id_58a188b2_fk_ipam_rout FOREIGN KEY (routetarget_id) REFERENCES public.ipam_routetarget(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_l2vpn_import_targets ipam_l2vpn_import_targets_l2vpn_id_731f5bb4_fk_ipam_l2vpn_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_l2vpn_import_targets
    ADD CONSTRAINT ipam_l2vpn_import_targets_l2vpn_id_731f5bb4_fk_ipam_l2vpn_id FOREIGN KEY (l2vpn_id) REFERENCES public.vpn_l2vpn(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_prefix ipam_prefix__location_id_f5925c42_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_prefix
    ADD CONSTRAINT ipam_prefix__location_id_f5925c42_fk_dcim_location_id FOREIGN KEY (_location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_prefix ipam_prefix__region_id_54aedc72_fk_dcim_region_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_prefix
    ADD CONSTRAINT ipam_prefix__region_id_54aedc72_fk_dcim_region_id FOREIGN KEY (_region_id) REFERENCES public.dcim_region(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_prefix ipam_prefix__site_group_id_8277120b_fk_dcim_sitegroup_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_prefix
    ADD CONSTRAINT ipam_prefix__site_group_id_8277120b_fk_dcim_sitegroup_id FOREIGN KEY (_site_group_id) REFERENCES public.dcim_sitegroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_prefix ipam_prefix__site_id_b479fb05_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_prefix
    ADD CONSTRAINT ipam_prefix__site_id_b479fb05_fk_dcim_site_id FOREIGN KEY (_site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_prefix ipam_prefix_owner_id_12d43bc8_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_prefix
    ADD CONSTRAINT ipam_prefix_owner_id_12d43bc8_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_prefix ipam_prefix_role_id_0a98d415_fk_ipam_role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_prefix
    ADD CONSTRAINT ipam_prefix_role_id_0a98d415_fk_ipam_role_id FOREIGN KEY (role_id) REFERENCES public.ipam_role(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_prefix ipam_prefix_scope_type_id_413319e2_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_prefix
    ADD CONSTRAINT ipam_prefix_scope_type_id_413319e2_fk_django_content_type_id FOREIGN KEY (scope_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_prefix ipam_prefix_tenant_id_7ba1fcc4_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_prefix
    ADD CONSTRAINT ipam_prefix_tenant_id_7ba1fcc4_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_prefix ipam_prefix_vlan_id_1db91bff_fk_ipam_vlan_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_prefix
    ADD CONSTRAINT ipam_prefix_vlan_id_1db91bff_fk_ipam_vlan_id FOREIGN KEY (vlan_id) REFERENCES public.ipam_vlan(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_prefix ipam_prefix_vrf_id_34f78ed0_fk_ipam_vrf_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_prefix
    ADD CONSTRAINT ipam_prefix_vrf_id_34f78ed0_fk_ipam_vrf_id FOREIGN KEY (vrf_id) REFERENCES public.ipam_vrf(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_rir ipam_rir_owner_id_172cc053_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_rir
    ADD CONSTRAINT ipam_rir_owner_id_172cc053_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_role ipam_role_owner_id_b42367ab_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_role
    ADD CONSTRAINT ipam_role_owner_id_b42367ab_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_routetarget ipam_routetarget_owner_id_e968953a_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_routetarget
    ADD CONSTRAINT ipam_routetarget_owner_id_e968953a_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_routetarget ipam_routetarget_tenant_id_5a0b35e8_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_routetarget
    ADD CONSTRAINT ipam_routetarget_tenant_id_5a0b35e8_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_service_ipaddresses ipam_service_ipaddre_ipaddress_id_b4138c6d_fk_ipam_ipad; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_service_ipaddresses
    ADD CONSTRAINT ipam_service_ipaddre_ipaddress_id_b4138c6d_fk_ipam_ipad FOREIGN KEY (ipaddress_id) REFERENCES public.ipam_ipaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_service_ipaddresses ipam_service_ipaddresses_service_id_ae26b9ab_fk_ipam_service_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_service_ipaddresses
    ADD CONSTRAINT ipam_service_ipaddresses_service_id_ae26b9ab_fk_ipam_service_id FOREIGN KEY (service_id) REFERENCES public.ipam_service(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_service ipam_service_owner_id_ab1c827a_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_service
    ADD CONSTRAINT ipam_service_owner_id_ab1c827a_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_service ipam_service_parent_object_type_i_8e76bfb3_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_service
    ADD CONSTRAINT ipam_service_parent_object_type_i_8e76bfb3_fk_django_co FOREIGN KEY (parent_object_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_servicetemplate ipam_servicetemplate_owner_id_bd152acb_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_servicetemplate
    ADD CONSTRAINT ipam_servicetemplate_owner_id_bd152acb_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_vlan ipam_vlan_group_id_88cbfa62_fk_ipam_vlangroup_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlan
    ADD CONSTRAINT ipam_vlan_group_id_88cbfa62_fk_ipam_vlangroup_id FOREIGN KEY (group_id) REFERENCES public.ipam_vlangroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_vlan ipam_vlan_owner_id_ead15d2b_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlan
    ADD CONSTRAINT ipam_vlan_owner_id_ead15d2b_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_vlan ipam_vlan_qinq_svlan_id_acbd7a5d_fk_ipam_vlan_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlan
    ADD CONSTRAINT ipam_vlan_qinq_svlan_id_acbd7a5d_fk_ipam_vlan_id FOREIGN KEY (qinq_svlan_id) REFERENCES public.ipam_vlan(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_vlan ipam_vlan_role_id_f5015962_fk_ipam_role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlan
    ADD CONSTRAINT ipam_vlan_role_id_f5015962_fk_ipam_role_id FOREIGN KEY (role_id) REFERENCES public.ipam_role(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_vlan ipam_vlan_site_id_a59334e3_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlan
    ADD CONSTRAINT ipam_vlan_site_id_a59334e3_fk_dcim_site_id FOREIGN KEY (site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_vlan ipam_vlan_tenant_id_71a8290d_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlan
    ADD CONSTRAINT ipam_vlan_tenant_id_71a8290d_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_vlangroup ipam_vlangroup_owner_id_3a50b541_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlangroup
    ADD CONSTRAINT ipam_vlangroup_owner_id_3a50b541_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_vlangroup ipam_vlangroup_scope_type_id_6606a755_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlangroup
    ADD CONSTRAINT ipam_vlangroup_scope_type_id_6606a755_fk_django_content_type_id FOREIGN KEY (scope_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_vlangroup ipam_vlangroup_tenant_id_29197fca_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlangroup
    ADD CONSTRAINT ipam_vlangroup_tenant_id_29197fca_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_vlantranslationrule ipam_vlantranslation_policy_id_09157735_fk_ipam_vlan; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlantranslationrule
    ADD CONSTRAINT ipam_vlantranslation_policy_id_09157735_fk_ipam_vlan FOREIGN KEY (policy_id) REFERENCES public.ipam_vlantranslationpolicy(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_vlantranslationpolicy ipam_vlantranslationpolicy_owner_id_f4e1cb82_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vlantranslationpolicy
    ADD CONSTRAINT ipam_vlantranslationpolicy_owner_id_f4e1cb82_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_vrf_export_targets ipam_vrf_export_targ_routetarget_id_8d9319f7_fk_ipam_rout; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vrf_export_targets
    ADD CONSTRAINT ipam_vrf_export_targ_routetarget_id_8d9319f7_fk_ipam_rout FOREIGN KEY (routetarget_id) REFERENCES public.ipam_routetarget(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_vrf_export_targets ipam_vrf_export_targets_vrf_id_6f4875c4_fk_ipam_vrf_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vrf_export_targets
    ADD CONSTRAINT ipam_vrf_export_targets_vrf_id_6f4875c4_fk_ipam_vrf_id FOREIGN KEY (vrf_id) REFERENCES public.ipam_vrf(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_vrf_import_targets ipam_vrf_import_targ_routetarget_id_0e05b144_fk_ipam_rout; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vrf_import_targets
    ADD CONSTRAINT ipam_vrf_import_targ_routetarget_id_0e05b144_fk_ipam_rout FOREIGN KEY (routetarget_id) REFERENCES public.ipam_routetarget(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_vrf_import_targets ipam_vrf_import_targets_vrf_id_ed491b19_fk_ipam_vrf_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vrf_import_targets
    ADD CONSTRAINT ipam_vrf_import_targets_vrf_id_ed491b19_fk_ipam_vrf_id FOREIGN KEY (vrf_id) REFERENCES public.ipam_vrf(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_vrf ipam_vrf_owner_id_9b591781_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vrf
    ADD CONSTRAINT ipam_vrf_owner_id_9b591781_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ipam_vrf ipam_vrf_tenant_id_498b0051_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ipam_vrf
    ADD CONSTRAINT ipam_vrf_tenant_id_498b0051_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: social_auth_usersocialauth social_auth_usersocialauth_user_id_17d28448_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_auth_usersocialauth
    ADD CONSTRAINT social_auth_usersocialauth_user_id_17d28448_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: taggit_taggeditem taggit_taggeditem_content_type_id_9957a03c_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_content_type_id_9957a03c_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: taggit_taggeditem taggit_taggeditem_tag_id_f4f5b767_fk_taggit_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_tag_id_f4f5b767_fk_taggit_tag_id FOREIGN KEY (tag_id) REFERENCES public.taggit_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tenancy_contact_groups tenancy_contact_grou_contact_id_84c9d84f_fk_tenancy_c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contact_groups
    ADD CONSTRAINT tenancy_contact_grou_contact_id_84c9d84f_fk_tenancy_c FOREIGN KEY (contact_id) REFERENCES public.tenancy_contact(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tenancy_contact_groups tenancy_contact_grou_contactgroup_id_5c8d6c5a_fk_tenancy_c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contact_groups
    ADD CONSTRAINT tenancy_contact_grou_contactgroup_id_5c8d6c5a_fk_tenancy_c FOREIGN KEY (contactgroup_id) REFERENCES public.tenancy_contactgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tenancy_contact tenancy_contact_owner_id_9d93abff_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contact
    ADD CONSTRAINT tenancy_contact_owner_id_9d93abff_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tenancy_contactassignment tenancy_contactassig_contact_id_5302baf0_fk_tenancy_c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contactassignment
    ADD CONSTRAINT tenancy_contactassig_contact_id_5302baf0_fk_tenancy_c FOREIGN KEY (contact_id) REFERENCES public.tenancy_contact(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tenancy_contactassignment tenancy_contactassig_object_type_id_48881567_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contactassignment
    ADD CONSTRAINT tenancy_contactassig_object_type_id_48881567_fk_django_co FOREIGN KEY (object_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tenancy_contactassignment tenancy_contactassig_role_id_fc08bfb5_fk_tenancy_c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contactassignment
    ADD CONSTRAINT tenancy_contactassig_role_id_fc08bfb5_fk_tenancy_c FOREIGN KEY (role_id) REFERENCES public.tenancy_contactrole(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tenancy_contactgroup tenancy_contactgroup_owner_id_4bb044c2_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contactgroup
    ADD CONSTRAINT tenancy_contactgroup_owner_id_4bb044c2_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tenancy_contactgroup tenancy_contactgroup_parent_id_c087d69f_fk_tenancy_c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contactgroup
    ADD CONSTRAINT tenancy_contactgroup_parent_id_c087d69f_fk_tenancy_c FOREIGN KEY (parent_id) REFERENCES public.tenancy_contactgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tenancy_contactrole tenancy_contactrole_owner_id_3677102e_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_contactrole
    ADD CONSTRAINT tenancy_contactrole_owner_id_3677102e_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tenancy_tenant tenancy_tenant_group_id_7daef6f4_fk_tenancy_tenantgroup_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_tenant
    ADD CONSTRAINT tenancy_tenant_group_id_7daef6f4_fk_tenancy_tenantgroup_id FOREIGN KEY (group_id) REFERENCES public.tenancy_tenantgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tenancy_tenant tenancy_tenant_owner_id_02823f0b_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_tenant
    ADD CONSTRAINT tenancy_tenant_owner_id_02823f0b_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tenancy_tenantgroup tenancy_tenantgroup_owner_id_a4f64bbd_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_tenantgroup
    ADD CONSTRAINT tenancy_tenantgroup_owner_id_a4f64bbd_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tenancy_tenantgroup tenancy_tenantgroup_parent_id_2542fc18_fk_tenancy_t; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenancy_tenantgroup
    ADD CONSTRAINT tenancy_tenantgroup_parent_id_2542fc18_fk_tenancy_t FOREIGN KEY (parent_id) REFERENCES public.tenancy_tenantgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_group_object_permissions users_group_object_p_group_id_90dd183a_fk_users_gro; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_group_object_permissions
    ADD CONSTRAINT users_group_object_p_group_id_90dd183a_fk_users_gro FOREIGN KEY (group_id) REFERENCES public.users_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_group_object_permissions users_group_object_p_objectpermission_id_dd489dc4_fk_users_obj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_group_object_permissions
    ADD CONSTRAINT users_group_object_p_objectpermission_id_dd489dc4_fk_users_obj FOREIGN KEY (objectpermission_id) REFERENCES public.users_objectpermission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_group_permissions users_group_permissi_permission_id_d8b9c223_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_group_permissions
    ADD CONSTRAINT users_group_permissi_permission_id_d8b9c223_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_group_permissions users_group_permissions_group_id_d48652c3_fk_users_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_group_permissions
    ADD CONSTRAINT users_group_permissions_group_id_d48652c3_fk_users_group_id FOREIGN KEY (group_id) REFERENCES public.users_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_objectpermission_object_types users_objectpermissi_contenttype_id_594b1cc7_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_objectpermission_object_types
    ADD CONSTRAINT users_objectpermissi_contenttype_id_594b1cc7_fk_django_co FOREIGN KEY (contenttype_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_objectpermission_object_types users_objectpermissi_objectpermission_id_38c7d8f5_fk_users_obj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_objectpermission_object_types
    ADD CONSTRAINT users_objectpermissi_objectpermission_id_38c7d8f5_fk_users_obj FOREIGN KEY (objectpermission_id) REFERENCES public.users_objectpermission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_owner users_owner_group_id_197ecf75_fk_users_ownergroup_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_owner
    ADD CONSTRAINT users_owner_group_id_197ecf75_fk_users_ownergroup_id FOREIGN KEY (group_id) REFERENCES public.users_ownergroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_owner_user_groups users_owner_user_groups_group_id_7f7a78f5_fk_users_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_owner_user_groups
    ADD CONSTRAINT users_owner_user_groups_group_id_7f7a78f5_fk_users_group_id FOREIGN KEY (group_id) REFERENCES public.users_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_owner_user_groups users_owner_user_groups_owner_id_1d847a5b_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_owner_user_groups
    ADD CONSTRAINT users_owner_user_groups_owner_id_1d847a5b_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_owner_users users_owner_users_owner_id_efc9b423_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_owner_users
    ADD CONSTRAINT users_owner_users_owner_id_efc9b423_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_owner_users users_owner_users_user_id_2b2e2446_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_owner_users
    ADD CONSTRAINT users_owner_users_user_id_2b2e2446_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_token users_token_user_id_af964690_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_token
    ADD CONSTRAINT users_token_user_id_af964690_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_group_id_9afc8d0e_fk_users_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_users_group_id FOREIGN KEY (group_id) REFERENCES public.users_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_object_permissions users_user_object_pe_objectpermission_id_29b431b4_fk_users_obj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_user_object_permissions
    ADD CONSTRAINT users_user_object_pe_objectpermission_id_29b431b4_fk_users_obj FOREIGN KEY (objectpermission_id) REFERENCES public.users_objectpermission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_object_permissions users_user_object_permissions_user_id_9d647aac_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_user_object_permissions
    ADD CONSTRAINT users_user_object_permissions_user_id_9d647aac_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_userconfig users_userconfig_user_id_afd44184_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_userconfig
    ADD CONSTRAINT users_userconfig_user_id_afd44184_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_cluster virtualization_clust__location_id_f553e386_fk_dcim_loca; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_cluster
    ADD CONSTRAINT virtualization_clust__location_id_f553e386_fk_dcim_loca FOREIGN KEY (_location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_cluster virtualization_clust__site_group_id_7d9bff8f_fk_dcim_site; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_cluster
    ADD CONSTRAINT virtualization_clust__site_group_id_7d9bff8f_fk_dcim_site FOREIGN KEY (_site_group_id) REFERENCES public.dcim_sitegroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_cluster virtualization_clust_group_id_de379828_fk_virtualiz; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_cluster
    ADD CONSTRAINT virtualization_clust_group_id_de379828_fk_virtualiz FOREIGN KEY (group_id) REFERENCES public.virtualization_clustergroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_cluster virtualization_clust_scope_type_id_c49d797a_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_cluster
    ADD CONSTRAINT virtualization_clust_scope_type_id_c49d797a_fk_django_co FOREIGN KEY (scope_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_cluster virtualization_clust_type_id_4efafb0a_fk_virtualiz; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_cluster
    ADD CONSTRAINT virtualization_clust_type_id_4efafb0a_fk_virtualiz FOREIGN KEY (type_id) REFERENCES public.virtualization_clustertype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_cluster virtualization_cluster__region_id_9244325e_fk_dcim_region_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_cluster
    ADD CONSTRAINT virtualization_cluster__region_id_9244325e_fk_dcim_region_id FOREIGN KEY (_region_id) REFERENCES public.dcim_region(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_cluster virtualization_cluster__site_id_883df848_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_cluster
    ADD CONSTRAINT virtualization_cluster__site_id_883df848_fk_dcim_site_id FOREIGN KEY (_site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_cluster virtualization_cluster_owner_id_2ea44dea_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_cluster
    ADD CONSTRAINT virtualization_cluster_owner_id_2ea44dea_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_cluster virtualization_cluster_tenant_id_bc2868d0_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_cluster
    ADD CONSTRAINT virtualization_cluster_tenant_id_bc2868d0_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_clustergroup virtualization_clustergroup_owner_id_a865db22_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_clustergroup
    ADD CONSTRAINT virtualization_clustergroup_owner_id_a865db22_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_clustertype virtualization_clustertype_owner_id_7284f9e4_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_clustertype
    ADD CONSTRAINT virtualization_clustertype_owner_id_7284f9e4_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_virtualmachine virtualization_virtu_cluster_id_6c9f9047_fk_virtualiz; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualmachine
    ADD CONSTRAINT virtualization_virtu_cluster_id_6c9f9047_fk_virtualiz FOREIGN KEY (cluster_id) REFERENCES public.virtualization_cluster(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_virtualmachine virtualization_virtu_config_template_id_d7fc7874_fk_extras_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualmachine
    ADD CONSTRAINT virtualization_virtu_config_template_id_d7fc7874_fk_extras_co FOREIGN KEY (config_template_id) REFERENCES public.extras_configtemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_virtualmachinetype virtualization_virtu_default_platform_id_6f32d2ac_fk_dcim_plat; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualmachinetype
    ADD CONSTRAINT virtualization_virtu_default_platform_id_6f32d2ac_fk_dcim_plat FOREIGN KEY (default_platform_id) REFERENCES public.dcim_platform(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_virtualmachine virtualization_virtu_device_id_5a49ed18_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualmachine
    ADD CONSTRAINT virtualization_virtu_device_id_5a49ed18_fk_dcim_devi FOREIGN KEY (device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_virtualmachinetype virtualization_virtu_owner_id_97b13507_fk_users_own; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualmachinetype
    ADD CONSTRAINT virtualization_virtu_owner_id_97b13507_fk_users_own FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_virtualmachine virtualization_virtu_owner_id_f6593561_fk_users_own; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualmachine
    ADD CONSTRAINT virtualization_virtu_owner_id_f6593561_fk_users_own FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_virtualmachine virtualization_virtu_platform_id_a6c5ccb2_fk_dcim_plat; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualmachine
    ADD CONSTRAINT virtualization_virtu_platform_id_a6c5ccb2_fk_dcim_plat FOREIGN KEY (platform_id) REFERENCES public.dcim_platform(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_virtualmachine virtualization_virtu_primary_ip4_id_942e42ae_fk_ipam_ipad; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualmachine
    ADD CONSTRAINT virtualization_virtu_primary_ip4_id_942e42ae_fk_ipam_ipad FOREIGN KEY (primary_ip4_id) REFERENCES public.ipam_ipaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_virtualmachine virtualization_virtu_primary_ip6_id_b7904e73_fk_ipam_ipad; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualmachine
    ADD CONSTRAINT virtualization_virtu_primary_ip6_id_b7904e73_fk_ipam_ipad FOREIGN KEY (primary_ip6_id) REFERENCES public.ipam_ipaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_virtualmachine virtualization_virtu_role_id_0cc898f9_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualmachine
    ADD CONSTRAINT virtualization_virtu_role_id_0cc898f9_fk_dcim_devi FOREIGN KEY (role_id) REFERENCES public.dcim_devicerole(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_virtualmachine virtualization_virtu_tenant_id_d00d1d77_fk_tenancy_t; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualmachine
    ADD CONSTRAINT virtualization_virtu_tenant_id_d00d1d77_fk_tenancy_t FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_virtualdisk virtualization_virtu_virtual_machine_id_7bc8b6c2_fk_virtualiz; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualdisk
    ADD CONSTRAINT virtualization_virtu_virtual_machine_id_7bc8b6c2_fk_virtualiz FOREIGN KEY (virtual_machine_id) REFERENCES public.virtualization_virtualmachine(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_virtualmachine virtualization_virtu_virtual_machine_type_bdf5b257_fk_virtualiz; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualmachine
    ADD CONSTRAINT virtualization_virtu_virtual_machine_type_bdf5b257_fk_virtualiz FOREIGN KEY (virtual_machine_type_id) REFERENCES public.virtualization_virtualmachinetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_virtualdisk virtualization_virtualdisk_owner_id_2e14487d_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualdisk
    ADD CONSTRAINT virtualization_virtualdisk_owner_id_2e14487d_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_virtualmachine virtualization_virtualmachine_site_id_54475a27_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_virtualmachine
    ADD CONSTRAINT virtualization_virtualmachine_site_id_54475a27_fk_dcim_site_id FOREIGN KEY (site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_vminterface virtualization_vmint_bridge_id_7462b91e_fk_virtualiz; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_vminterface
    ADD CONSTRAINT virtualization_vmint_bridge_id_7462b91e_fk_virtualiz FOREIGN KEY (bridge_id) REFERENCES public.virtualization_vminterface(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_vminterface virtualization_vmint_parent_id_f86958e1_fk_virtualiz; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_vminterface
    ADD CONSTRAINT virtualization_vmint_parent_id_f86958e1_fk_virtualiz FOREIGN KEY (parent_id) REFERENCES public.virtualization_vminterface(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_vminterface virtualization_vmint_primary_mac_address__7a6c9b66_fk_dcim_maca; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_vminterface
    ADD CONSTRAINT virtualization_vmint_primary_mac_address__7a6c9b66_fk_dcim_maca FOREIGN KEY (primary_mac_address_id) REFERENCES public.dcim_macaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_vminterface virtualization_vmint_qinq_svlan_id_afacb024_fk_ipam_vlan; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_vminterface
    ADD CONSTRAINT virtualization_vmint_qinq_svlan_id_afacb024_fk_ipam_vlan FOREIGN KEY (qinq_svlan_id) REFERENCES public.ipam_vlan(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_vminterface virtualization_vmint_untagged_vlan_id_aea4fc69_fk_ipam_vlan; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_vminterface
    ADD CONSTRAINT virtualization_vmint_untagged_vlan_id_aea4fc69_fk_ipam_vlan FOREIGN KEY (untagged_vlan_id) REFERENCES public.ipam_vlan(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_vminterface virtualization_vmint_virtual_machine_id_e9f89829_fk_virtualiz; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_vminterface
    ADD CONSTRAINT virtualization_vmint_virtual_machine_id_e9f89829_fk_virtualiz FOREIGN KEY (virtual_machine_id) REFERENCES public.virtualization_virtualmachine(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_vminterface_tagged_vlans virtualization_vmint_vlan_id_4e77411e_fk_ipam_vlan; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_vminterface_tagged_vlans
    ADD CONSTRAINT virtualization_vmint_vlan_id_4e77411e_fk_ipam_vlan FOREIGN KEY (vlan_id) REFERENCES public.ipam_vlan(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_vminterface virtualization_vmint_vlan_translation_pol_938e6637_fk_ipam_vlan; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_vminterface
    ADD CONSTRAINT virtualization_vmint_vlan_translation_pol_938e6637_fk_ipam_vlan FOREIGN KEY (vlan_translation_policy_id) REFERENCES public.ipam_vlantranslationpolicy(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_vminterface_tagged_vlans virtualization_vmint_vminterface_id_904b12de_fk_virtualiz; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_vminterface_tagged_vlans
    ADD CONSTRAINT virtualization_vmint_vminterface_id_904b12de_fk_virtualiz FOREIGN KEY (vminterface_id) REFERENCES public.virtualization_vminterface(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_vminterface virtualization_vminterface_owner_id_486754ee_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_vminterface
    ADD CONSTRAINT virtualization_vminterface_owner_id_486754ee_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: virtualization_vminterface virtualization_vminterface_vrf_id_4b570a8c_fk_ipam_vrf_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtualization_vminterface
    ADD CONSTRAINT virtualization_vminterface_vrf_id_4b570a8c_fk_ipam_vrf_id FOREIGN KEY (vrf_id) REFERENCES public.ipam_vrf(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_ikepolicy vpn_ikepolicy_owner_id_dbcaf1bd_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ikepolicy
    ADD CONSTRAINT vpn_ikepolicy_owner_id_dbcaf1bd_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_ikepolicy_proposals vpn_ikepolicy_propos_ikepolicy_id_1e1deaab_fk_vpn_ikepo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ikepolicy_proposals
    ADD CONSTRAINT vpn_ikepolicy_propos_ikepolicy_id_1e1deaab_fk_vpn_ikepo FOREIGN KEY (ikepolicy_id) REFERENCES public.vpn_ikepolicy(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_ikepolicy_proposals vpn_ikepolicy_propos_ikeproposal_id_a9ead252_fk_vpn_ikepr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ikepolicy_proposals
    ADD CONSTRAINT vpn_ikepolicy_propos_ikeproposal_id_a9ead252_fk_vpn_ikepr FOREIGN KEY (ikeproposal_id) REFERENCES public.vpn_ikeproposal(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_ikeproposal vpn_ikeproposal_owner_id_018a3e69_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ikeproposal
    ADD CONSTRAINT vpn_ikeproposal_owner_id_018a3e69_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_ipsecpolicy vpn_ipsecpolicy_owner_id_e976d198_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ipsecpolicy
    ADD CONSTRAINT vpn_ipsecpolicy_owner_id_e976d198_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_ipsecpolicy_proposals vpn_ipsecpolicy_prop_ipsecpolicy_id_0e7771a1_fk_vpn_ipsec; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ipsecpolicy_proposals
    ADD CONSTRAINT vpn_ipsecpolicy_prop_ipsecpolicy_id_0e7771a1_fk_vpn_ipsec FOREIGN KEY (ipsecpolicy_id) REFERENCES public.vpn_ipsecpolicy(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_ipsecpolicy_proposals vpn_ipsecpolicy_prop_ipsecproposal_id_685fe509_fk_vpn_ipsec; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ipsecpolicy_proposals
    ADD CONSTRAINT vpn_ipsecpolicy_prop_ipsecproposal_id_685fe509_fk_vpn_ipsec FOREIGN KEY (ipsecproposal_id) REFERENCES public.vpn_ipsecproposal(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_ipsecprofile vpn_ipsecprofile_ike_policy_id_4eff5fb9_fk_vpn_ikepolicy_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ipsecprofile
    ADD CONSTRAINT vpn_ipsecprofile_ike_policy_id_4eff5fb9_fk_vpn_ikepolicy_id FOREIGN KEY (ike_policy_id) REFERENCES public.vpn_ikepolicy(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_ipsecprofile vpn_ipsecprofile_ipsec_policy_id_e06f2323_fk_vpn_ipsecpolicy_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ipsecprofile
    ADD CONSTRAINT vpn_ipsecprofile_ipsec_policy_id_e06f2323_fk_vpn_ipsecpolicy_id FOREIGN KEY (ipsec_policy_id) REFERENCES public.vpn_ipsecpolicy(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_ipsecprofile vpn_ipsecprofile_owner_id_d7ebc4a0_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ipsecprofile
    ADD CONSTRAINT vpn_ipsecprofile_owner_id_d7ebc4a0_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_ipsecproposal vpn_ipsecproposal_owner_id_fdb3b755_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_ipsecproposal
    ADD CONSTRAINT vpn_ipsecproposal_owner_id_fdb3b755_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_l2vpn vpn_l2vpn_owner_id_894bd11d_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_l2vpn
    ADD CONSTRAINT vpn_l2vpn_owner_id_894bd11d_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_l2vpn vpn_l2vpn_tenant_id_57ec8f92_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_l2vpn
    ADD CONSTRAINT vpn_l2vpn_tenant_id_57ec8f92_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_l2vpntermination vpn_l2vpntermination_assigned_object_type_id_f063b865_fk_django; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_l2vpntermination
    ADD CONSTRAINT vpn_l2vpntermination_assigned_object_type_id_f063b865_fk_django FOREIGN KEY (assigned_object_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_l2vpntermination vpn_l2vpntermination_l2vpn_id_f5367bbe_fk_vpn_l2vpn_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_l2vpntermination
    ADD CONSTRAINT vpn_l2vpntermination_l2vpn_id_f5367bbe_fk_vpn_l2vpn_id FOREIGN KEY (l2vpn_id) REFERENCES public.vpn_l2vpn(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_tunnel vpn_tunnel_group_id_56b1e7f7_fk_vpn_tunnelgroup_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_tunnel
    ADD CONSTRAINT vpn_tunnel_group_id_56b1e7f7_fk_vpn_tunnelgroup_id FOREIGN KEY (group_id) REFERENCES public.vpn_tunnelgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_tunnel vpn_tunnel_ipsec_profile_id_fd0361c5_fk_vpn_ipsecprofile_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_tunnel
    ADD CONSTRAINT vpn_tunnel_ipsec_profile_id_fd0361c5_fk_vpn_ipsecprofile_id FOREIGN KEY (ipsec_profile_id) REFERENCES public.vpn_ipsecprofile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_tunnel vpn_tunnel_owner_id_d04ee1fb_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_tunnel
    ADD CONSTRAINT vpn_tunnel_owner_id_d04ee1fb_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_tunnel vpn_tunnel_tenant_id_f3df2ab3_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_tunnel
    ADD CONSTRAINT vpn_tunnel_tenant_id_f3df2ab3_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_tunnelgroup vpn_tunnelgroup_owner_id_64609bfe_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_tunnelgroup
    ADD CONSTRAINT vpn_tunnelgroup_owner_id_64609bfe_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_tunneltermination vpn_tunnelterminatio_outside_ip_id_2c6f3a7c_fk_ipam_ipad; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_tunneltermination
    ADD CONSTRAINT vpn_tunnelterminatio_outside_ip_id_2c6f3a7c_fk_ipam_ipad FOREIGN KEY (outside_ip_id) REFERENCES public.ipam_ipaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_tunneltermination vpn_tunnelterminatio_termination_type_id_e546f7a1_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_tunneltermination
    ADD CONSTRAINT vpn_tunnelterminatio_termination_type_id_e546f7a1_fk_django_co FOREIGN KEY (termination_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vpn_tunneltermination vpn_tunneltermination_tunnel_id_962efa25_fk_vpn_tunnel_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vpn_tunneltermination
    ADD CONSTRAINT vpn_tunneltermination_tunnel_id_962efa25_fk_vpn_tunnel_id FOREIGN KEY (tunnel_id) REFERENCES public.vpn_tunnel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wireless_wirelesslan wireless_wirelesslan__location_id_c742912f_fk_dcim_location_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslan
    ADD CONSTRAINT wireless_wirelesslan__location_id_c742912f_fk_dcim_location_id FOREIGN KEY (_location_id) REFERENCES public.dcim_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wireless_wirelesslan wireless_wirelesslan__region_id_fd2a93ee_fk_dcim_region_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslan
    ADD CONSTRAINT wireless_wirelesslan__region_id_fd2a93ee_fk_dcim_region_id FOREIGN KEY (_region_id) REFERENCES public.dcim_region(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wireless_wirelesslan wireless_wirelesslan__site_group_id_d61285cc_fk_dcim_site; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslan
    ADD CONSTRAINT wireless_wirelesslan__site_group_id_d61285cc_fk_dcim_site FOREIGN KEY (_site_group_id) REFERENCES public.dcim_sitegroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wireless_wirelesslan wireless_wirelesslan__site_id_5dce5f6f_fk_dcim_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslan
    ADD CONSTRAINT wireless_wirelesslan__site_id_5dce5f6f_fk_dcim_site_id FOREIGN KEY (_site_id) REFERENCES public.dcim_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wireless_wirelesslan wireless_wirelesslan_group_id_d9e3d67f_fk_wireless_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslan
    ADD CONSTRAINT wireless_wirelesslan_group_id_d9e3d67f_fk_wireless_ FOREIGN KEY (group_id) REFERENCES public.wireless_wirelesslangroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wireless_wirelesslan wireless_wirelesslan_owner_id_9ea24eeb_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslan
    ADD CONSTRAINT wireless_wirelesslan_owner_id_9ea24eeb_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wireless_wirelesslangroup wireless_wirelesslan_parent_id_37ca8b87_fk_wireless_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslangroup
    ADD CONSTRAINT wireless_wirelesslan_parent_id_37ca8b87_fk_wireless_ FOREIGN KEY (parent_id) REFERENCES public.wireless_wirelesslangroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wireless_wirelesslan wireless_wirelesslan_scope_type_id_c3e37d35_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslan
    ADD CONSTRAINT wireless_wirelesslan_scope_type_id_c3e37d35_fk_django_co FOREIGN KEY (scope_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wireless_wirelesslan wireless_wirelesslan_tenant_id_5dfee941_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslan
    ADD CONSTRAINT wireless_wirelesslan_tenant_id_5dfee941_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wireless_wirelesslan wireless_wirelesslan_vlan_id_d7fa6ccc_fk_ipam_vlan_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslan
    ADD CONSTRAINT wireless_wirelesslan_vlan_id_d7fa6ccc_fk_ipam_vlan_id FOREIGN KEY (vlan_id) REFERENCES public.ipam_vlan(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wireless_wirelesslangroup wireless_wirelesslangroup_owner_id_0ba5f844_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslangroup
    ADD CONSTRAINT wireless_wirelesslangroup_owner_id_0ba5f844_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wireless_wirelesslink wireless_wirelesslin__interface_a_device__6c8e042e_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslink
    ADD CONSTRAINT wireless_wirelesslin__interface_a_device__6c8e042e_fk_dcim_devi FOREIGN KEY (_interface_a_device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wireless_wirelesslink wireless_wirelesslin__interface_b_device__43d5101a_fk_dcim_devi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslink
    ADD CONSTRAINT wireless_wirelesslin__interface_b_device__43d5101a_fk_dcim_devi FOREIGN KEY (_interface_b_device_id) REFERENCES public.dcim_device(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wireless_wirelesslink wireless_wirelesslin_interface_a_id_bc9e37fd_fk_dcim_inte; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslink
    ADD CONSTRAINT wireless_wirelesslin_interface_a_id_bc9e37fd_fk_dcim_inte FOREIGN KEY (interface_a_id) REFERENCES public.dcim_interface(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wireless_wirelesslink wireless_wirelesslin_interface_b_id_a82fb2ee_fk_dcim_inte; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslink
    ADD CONSTRAINT wireless_wirelesslin_interface_b_id_a82fb2ee_fk_dcim_inte FOREIGN KEY (interface_b_id) REFERENCES public.dcim_interface(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wireless_wirelesslink wireless_wirelesslink_owner_id_103f9be1_fk_users_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslink
    ADD CONSTRAINT wireless_wirelesslink_owner_id_103f9be1_fk_users_owner_id FOREIGN KEY (owner_id) REFERENCES public.users_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wireless_wirelesslink wireless_wirelesslink_tenant_id_4c0638ee_fk_tenancy_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wireless_wirelesslink
    ADD CONSTRAINT wireless_wirelesslink_tenant_id_4c0638ee_fk_tenancy_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenancy_tenant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

\unrestrict d6y9fg1XTM7yMgn856LsBEBRiYmpwbvxk0cyzeO2cIjhvPqzYUaXOelDZerYeUp

